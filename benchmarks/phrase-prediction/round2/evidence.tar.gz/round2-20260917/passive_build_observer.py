#!/usr/bin/env python3
"""Read-only process metadata around the next already-scheduled corequeue transition."""
import datetime as dt,json,subprocess,time
from pathlib import Path
import run_latency_baseline as d
root=Path(__file__).resolve().parent;destination=root/'passive-build-transition-2.jsonl'
private=str(d.runner.ROOT);started=d.now();count=0;last=None;initial_hosts=None;initial_launchers=None;max_gap=0;previous=None;seen_setup=False
with destination.open('x') as log:
 end=time.monotonic()+900
 while time.monotonic()<end:
  mono=time.monotonic();count+=1
  if previous is not None:max_gap=max(max_gap,mono-previous)
  previous=mono
  processes=d.parse_processes(subprocess.check_output(d.PS_COMMAND,text=True,timeout=3))
  exe_output=subprocess.check_output(d.PS_EXECUTABLE_COMMAND,text=True,timeout=3)
  executables={int(fields[0]):fields[1] for line in exe_output.splitlines() if len(fields:=line.split(None,1))==2}
  rows=[];hosts=set();launchers=set()
  for pid,p in processes.items():
   if 'Cotabby.app/Contents/MacOS/Cotabby' in p['command'] and private in p['command']:hosts.add(d.identity(p))
   kinds=[name for name,pattern in d.PATTERNS.items() if pattern.search(p['command'])]
   if 'xcodebuild' in p['command'] and private in p['command']:launchers.add(d.identity(p))
   if not set(kinds)&{'build','inference-or-benchmark'}:continue
   row={key:p[key] for key in ('pid','ppid','pgid','startedLocal','cpuPercent')}
   row.update(executable=executables.get(pid,'unavailable'),categories=kinds,privateCheckoutMentioned=private in p['command'],
              buildForTesting='build-for-testing' in p['command'],testWithoutBuilding='test-without-building' in p['command'])
   if row['privateCheckoutMentioned'] and row['buildForTesting']:seen_setup=True
   rows.append(row)
  if initial_hosts is None:initial_hosts=hosts;initial_launchers=launchers
  signature=[{k:v for k,v in row.items() if k!='cpuPercent'} for row in rows]
  if signature!=last:
   record={'observedUTC':d.now(),'rows':rows};log.write(json.dumps(record,sort_keys=True)+'\n');log.flush();last=signature
   print(json.dumps({'observedUTC':record['observedUTC'],'relevantProcesses':len(rows),'newPrivateHost':bool(hosts-initial_hosts),'seenSetup':seen_setup}),flush=True)
  if hosts-initial_hosts and launchers-initial_launchers:
   print('Observed next private host; stopping passive collector.',flush=True);break
  time.sleep(.5)
 summary={'schemaVersion':1,'purpose':'Passive observation of an existing scheduled build transition; no build or inference launched by this observer.',
          'startedUTC':started,'finishedUTC':d.now(),'sampleCount':count,'maximumSampleGapSeconds':max_gap,
          'privateSetupObserved':seen_setup,'newPrivateHostObserved':bool(hosts-initial_hosts),'observations':d.ref(destination),
          'limitations':'Half-second sampling may miss short-lived services; all non-owned arguments omitted.'}
 d.write_new(root/'passive-build-transition-summary-2.json',summary)
 print(json.dumps(summary,indent=2),flush=True)
