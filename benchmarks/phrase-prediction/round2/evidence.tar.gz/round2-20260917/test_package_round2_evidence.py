"""Exercise archive publication failures using only temporary invented evidence."""
import contextlib
import io
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

import package_round2_evidence as pack


class PackageTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.here = self.root / 'evidence'
        self.here.mkdir()
        self.destination = self.root / 'durable' / 'round2'
        data = {
            'decision-assessment.json': {'status': 'retained-baseline'},
            'baseline-characterization.json': {'status': 'descriptive-only'},
            'active.json': {'status': 'complete'},
        }
        for name, value in data.items():
            pack.write(self.here / name, value)
        for name in pack.REVIEW_FILES:
            if not (self.here / name).exists():
                (self.here / name).write_text('invented review data\n')
        (self.here / 'final-checklist.md').write_text('invented final checklist\n')
        (self.here / 'historical.py.before').write_text('original_driver = True\n')
        (self.here / 'Package.resolved').write_text('{}\n')
        (self.here / 'raw.log').write_text('invented raw evidence\n')
        self.stack = contextlib.ExitStack()
        self.addCleanup(self.stack.close)
        self.stack.enter_context(patch.object(pack, 'HERE', self.here))
        self.stack.enter_context(patch.object(pack, 'DESTINATION', self.destination))
        self.stack.enter_context(patch.object(pack, 'prepare_sources'))
        self.stack.enter_context(contextlib.redirect_stdout(io.StringIO()))

    def test_verified_publication_preserves_sources_and_checklist_identity(self):
        pack.package()
        manifest = json.loads((self.destination / 'manifest.json').read_text())
        archived = {row['path']: row for row in manifest['files']}
        self.assertIn('historical.py.before', archived)
        self.assertIn('Package.resolved', archived)
        self.assertEqual(manifest['reviewCopies']['IMPROVEMENT_BRAINSTORMING_ROUND_TWO.md'],
                         archived['final-checklist.md']['sha256'])
        self.assertEqual(manifest['archive']['sha256'], pack.sha(self.destination / 'evidence.tar.gz'))
        self.assertEqual(list(self.destination.parent.glob('.round2-package-*')), [])

    def test_mutation_after_archive_prevents_publication_and_preserves_original(self):
        original = pack.package_to_stage
        def mutate(*args):
            original(*args)
            (self.here / 'raw.log').write_text('changed during publication\n')
        with patch.object(pack, 'package_to_stage', side_effect=mutate):
            with self.assertRaisesRegex(ValueError, 'changed during packaging'):
                pack.package()
        self.assertFalse(self.destination.exists())
        self.assertTrue((self.here / 'raw.log').exists())
        self.assertEqual(list(self.destination.parent.glob('.round2-package-*')), [])

    def test_stage_exception_leaves_retryable_destination(self):
        with patch.object(pack, 'package_to_stage', side_effect=ValueError('invented failure')):
            with self.assertRaisesRegex(ValueError, 'invented failure'):
                pack.package()
        self.assertFalse(self.destination.exists())
        pack.package()
        self.assertTrue((self.destination / 'manifest.json').is_file())

    def test_existing_destination_is_never_replaced(self):
        self.destination.mkdir(parents=True)
        sentinel = self.destination / 'existing.txt'
        sentinel.write_text('preserve me')
        with self.assertRaisesRegex(ValueError, 'overwrite'):
            pack.package()
        self.assertEqual(sentinel.read_text(), 'preserve me')

    def test_active_benchmark_is_rejected(self):
        pack.write(self.here / 'active.json', {'status': 'running'})
        with self.assertRaisesRegex(ValueError, 'still active'):
            pack.package()
        self.assertFalse(self.destination.exists())


if __name__ == '__main__':
    unittest.main()
