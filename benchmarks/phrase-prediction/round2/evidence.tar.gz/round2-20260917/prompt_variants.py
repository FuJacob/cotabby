#!/usr/bin/env python3
"""Own only the round's two prompt files; freeze candidates before measurements.

Source variants are explicit reviewed bytes, not user settings. Applying a candidate checks
the previous bytes first so another edit cannot be overwritten by an experiment transition.
The benchmark and the model-free audit consume the resulting production request path.
"""
import argparse
import datetime
import hashlib
import json
import os
from pathlib import Path
import tempfile
import uuid

HERE = Path(__file__).resolve().parent
ROOT = Path(json.loads((HERE / 'execution.json').read_text())['root'])
PATHS = {
    'renderer': 'Cotabby/Support/Prompting/BaseCompletionPromptRenderer.swift',
    'composer': 'Cotabby/Support/Context/SurfaceContextComposer.swift',
}
SCREEN = '''        if let screen = Self.nonEmpty(visualContextSummary) {
            sections.append(Self.contextSection(
                "screen", "Nearby on screen: \\(screen)", priority: screenPriority, maxChars: maxScreenCharacters
            ))
        }
'''


def sha(data):
    return hashlib.sha256(data).hexdigest()


def replace(text, old, new):
    if text.count(old) != 1:
        raise ValueError('Source anchor is absent or ambiguous: ' + old[:80])
    return text.replace(old, new, 1)


def transformed(baseline, components):
    values = dict(baseline)
    formats = [x for x in components if x.startswith('F')]
    metadata = [x for x in components if x.startswith('M')]
    if len(formats) > 1 or len(metadata) > 1 or len(components) != len(set(components)):
        raise ValueError('At most one component from each prompt family is allowed')
    for variant in components:
        if variant in ('F1', 'F2'):
            label = {'F1': 'Context:', 'F2': 'Screen context:'}[variant]
            values['renderer'] = replace(values['renderer'], 'Nearby on screen: \\(screen)', label + ' \\(screen)')
        elif variant == 'F3':
            quoted = '''        if let screen = Self.nonEmpty(visualContextSummary) {
            // A blockquote marks reference material without an unmatched closing delimiter
            // if the optional section is shortened by the existing prompt budget.
            let quotedScreen = screen.components(separatedBy: .newlines).map { "> " + $0 }.joined(separator: "\\n")
            sections.append(Self.contextSection(
                "screen", "Nearby on screen:\\n\\(quotedScreen)", priority: screenPriority, maxChars: maxScreenCharacters
            ))
        }
'''
            values['renderer'] = replace(values['renderer'], SCREEN, quoted)
        elif variant == 'F4':
            renderer = replace(values['renderer'], SCREEN, '')
            values['renderer'] = replace(renderer, '        var sections: [PromptSection] = []\n',
                '        var sections: [PromptSection] = []\n' + SCREEN)
        elif variant in ('M1', 'M2'):
            original = '        var fields = ["Format: \\(format)", "App: \\(surface.applicationName)"]'
            remaining = {'M1': '        var fields = ["Format: \\(format)"]',
                         'M2': '        var fields = ["App: \\(surface.applicationName)"]'}[variant]
            values['composer'] = replace(values['composer'], original, remaining)
        elif variant == 'M3':
            values['composer'] = replace(values['composer'],
                '        if let title = surface.windowTitle { fields.append("Title: \\(title)") }\n', '')
        elif variant == 'M4':
            values['composer'] = replace(values['composer'],
                '        if let placeholder = surface.fieldPlaceholder { fields.append("Field: \\(placeholder)") }\n', '')
        else:
            raise ValueError('Unknown prompt component: ' + variant)
    return values


def freeze():
    folder = HERE / 'prompt-sources'
    folder.mkdir(exist_ok=False)
    baseline = {key: (ROOT / path).read_text() for key, path in PATHS.items()}
    variants = {'baseline': []} | {v: [v] for v in ('F1','F2','F3','F4','M1','M2','M3','M4')}
    manifest = {'root': str(ROOT), 'paths': PATHS, 'variants': {}}
    for label, components in variants.items():
        destination = folder / label
        destination.mkdir()
        rendered = transformed(baseline, components)
        hashes = {}
        for key, value in rendered.items():
            data = value.encode()
            (destination / (key + '.swift')).write_bytes(data)
            hashes[key] = sha(data)
        manifest['variants'][label] = {'components': components, 'hashes': hashes}
    (folder / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
    (HERE / 'applied-prompt.json').write_text(json.dumps({
        'components': [], 'hashes': manifest['variants']['baseline']['hashes']}, indent=2) + '\n')
    return manifest


def atomic_write(path, data):
    mode = path.stat().st_mode & 0o777 if path.exists() else 0o644
    fd, name = tempfile.mkstemp(prefix='.' + path.name + '.', dir=path.parent)
    try:
        with os.fdopen(fd, 'wb') as stream:
            stream.write(data)
            stream.flush()
            os.fsync(stream.fileno())
        os.chmod(name, mode)
        os.replace(name, path)
        directory = os.open(path.parent, os.O_RDONLY)
        try:
            os.fsync(directory)
        finally:
            os.close(directory)
    finally:
        if os.path.exists(name):
            os.unlink(name)


def encoded(value):
    return (json.dumps(value, indent=2, sort_keys=True) + '\n').encode()


def canonical(components):
    valid = {'F1', 'F2', 'F3', 'F4', 'M1', 'M2', 'M3', 'M4'}
    if any(value not in valid for value in components):
        raise ValueError('Unknown prompt component')
    if len(set(components)) != len(components) or any(
        sum(value.startswith(family) for value in components) > 1 for family in ('F', 'M')
    ):
        raise ValueError('At most one component from each prompt family is allowed')
    return tuple(sorted(components))


def frozen_catalog(include_combinations=True):
    catalog = {}
    folders = ['prompt-sources'] + (['combination-sources'] if include_combinations else [])
    for folder in folders:
        manifest = json.loads((HERE / folder / 'manifest.json').read_text())
        if manifest['root'] != str(ROOT) or manifest['paths'] != PATHS:
            raise ValueError('Frozen prompt identity disagrees')
        if folder == 'combination-sources' and manifest['singleManifestSHA256'] != sha(
            (HERE / 'prompt-sources/manifest.json').read_bytes()
        ):
            raise ValueError('Frozen combination component manifest changed')
        for label, item in manifest['variants'].items():
            components = canonical(item['components'])
            if label != ('+'.join(components) or 'baseline') or components in catalog:
                raise ValueError('Frozen candidate label or component identity disagrees')
            data = {key: (HERE / folder / label / (key + '.swift')).read_bytes() for key in PATHS}
            if {key: sha(value) for key, value in data.items()} != item['hashes']:
                raise ValueError('Frozen prompt bytes changed')
            catalog[components] = data
    expected = {()} | {(v,) for v in ('F1', 'F2', 'F3', 'F4', 'M1', 'M2', 'M3', 'M4')}
    if include_combinations:
        expected |= {(f, m) for f in ('F1', 'F2', 'F3', 'F4') for m in ('M1', 'M2', 'M3', 'M4')}
    if set(catalog) != expected:
        raise ValueError('Frozen catalog does not contain exactly the registered transforms')
    return catalog


def freeze_combinations():
    singles = frozen_catalog(include_combinations=False)
    baseline = {key: value.decode() for key, value in singles[()].items()}
    for components, data in singles.items():
        if {key: value.encode() for key, value in transformed(baseline, components).items()} != data:
            raise ValueError('Helper transform no longer matches frozen single candidate')
    combinations = {}
    for f in ('F1', 'F2', 'F3', 'F4'):
        for m in ('M1', 'M2', 'M3', 'M4'):
            # Families own distinct files. Compose frozen bytes, then independently
            # verify both registered transform orders generate precisely those bytes.
            data = {'renderer': singles[(f,)]['renderer'], 'composer': singles[(m,)]['composer']}
            for order in ((f, m), (m, f)):
                if {key: value.encode() for key, value in transformed(baseline, order).items()} != data:
                    raise ValueError('Prompt families do not compose independently')
            combinations[(f, m)] = data
    folder = HERE / 'combination-sources'
    folder.mkdir(exist_ok=False)
    manifest = {'root': str(ROOT), 'paths': PATHS,
                'singleManifestSHA256': sha((HERE / 'prompt-sources/manifest.json').read_bytes()),
                'variants': {}}
    for components, data in combinations.items():
        label = '+'.join(components)
        destination = folder / label
        destination.mkdir()
        for key, value in data.items():
            atomic_write(destination / (key + '.swift'), value)
        manifest['variants'][label] = {'components': list(components),
                                      'hashes': {key: sha(value) for key, value in data.items()}}
    atomic_write(folder / 'manifest.json', encoded(manifest))
    return manifest


def record_for(components, catalog):
    components = canonical(components)
    return {'components': list(components),
            'hashes': {key: sha(data) for key, data in catalog[components].items()}}


def validate_record(record, catalog):
    if record != record_for(record['components'], catalog):
        raise ValueError('Applied record is not a recognized frozen candidate')


def current_hashes():
    return {key: sha((ROOT / path).read_bytes()) for key, path in PATHS.items()}


def verify_current(catalog=None):
    catalog = frozen_catalog() if catalog is None else catalog
    record = json.loads((HERE / 'applied-prompt.json').read_text())
    validate_record(record, catalog)
    if current_hashes() != record['hashes']:
        raise ValueError('Unexpected source edit or interrupted transition; inspect journal and recover explicitly')
    return record


def active_transition():
    pointer = HERE / 'active-prompt-transition.json'
    if not pointer.exists():
        return None, None
    relative = json.loads(pointer.read_text())['journal']
    path = (HERE / relative).resolve()
    if not path.is_relative_to((HERE / 'prompt-transitions').resolve()):
        raise ValueError('Transition journal path escapes its round directory')
    return path, json.loads(path.read_text())


def save_journal(path, journal):
    journal['updatedAtUTC'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    atomic_write(path, encoded(journal))


def rollback(path, journal, catalog):
    if journal['root'] != str(ROOT) or journal['paths'] != PATHS:
        raise ValueError('Recovery journal belongs to another checkout or target set')
    validate_record(journal['before'], catalog)
    validate_record(journal['after'], catalog)
    before = {key: (path.parent / ('before-' + key + '.swift')).read_bytes() for key in PATHS}
    if {key: sha(value) for key, value in before.items()} != journal['before']['hashes']:
        raise ValueError('Recovery backups no longer match the registered before state')
    record_bytes = (path.parent / 'before-record.json').read_bytes()
    if json.loads(record_bytes) != journal['before']:
        raise ValueError('Recovery record backup changed')
    observed = current_hashes()
    # Check both files before restoring either. An external edit must never be
    # overwritten, even when the other file belongs to a half-finished switch.
    for key, value in observed.items():
        if value not in (journal['before']['hashes'][key], journal['after']['hashes'][key]):
            raise ValueError('Unknown current source bytes prevent recovery: ' + PATHS[key])
    current_record = json.loads((HERE / 'applied-prompt.json').read_text())
    if current_record not in (journal['before'], journal['after']):
        raise ValueError('Unknown applied record prevents recovery')
    for key, source in PATHS.items():
        if observed[key] != journal['before']['hashes'][key]:
            atomic_write(ROOT / source, before[key])
    atomic_write(HERE / 'applied-prompt.json', record_bytes)
    if verify_current(catalog) != journal['before']:
        raise ValueError('Rollback did not restore the exact before state')


def recover():
    catalog = frozen_catalog()
    path, journal = active_transition()
    if path is None:
        return {'state': 'no-transition', 'current': verify_current(catalog)}
    if journal['state'] in ('committed', 'rolled_back', 'recovered'):
        return {'state': journal['state'], 'current': verify_current(catalog)}
    try:
        rollback(path, journal, catalog)
        journal['state'] = 'recovered'
        save_journal(path, journal)
    except Exception as error:
        journal['state'] = 'recovery_required'
        journal['recoveryError'] = repr(error)
        try:
            save_journal(path, journal)
        except Exception:
            pass
        raise RuntimeError(f'Recovery failed; preserve and inspect {path}: {error}') from error
    return {'state': 'recovered', 'current': journal['before'], 'journal': str(path)}


def apply(components):
    catalog = frozen_catalog()
    _, previous = active_transition()
    if previous and previous['state'] not in ('committed', 'rolled_back', 'recovered'):
        raise ValueError('Unfinished prompt transition; run recover before applying another candidate')
    before = verify_current(catalog)
    after = record_for(components, catalog)
    target = catalog[canonical(components)]
    directory = HERE / 'prompt-transitions' / str(uuid.uuid4())
    directory.mkdir(parents=True)
    for key, source in PATHS.items():
        atomic_write(directory / ('before-' + key + '.swift'), (ROOT / source).read_bytes())
    atomic_write(directory / 'before-record.json', (HERE / 'applied-prompt.json').read_bytes())
    path = directory / 'journal.json'
    journal = {'schemaVersion': 1, 'state': 'prepared', 'before': before, 'after': after,
               'replaced': [], 'root': str(ROOT), 'paths': PATHS}
    save_journal(path, journal)
    # The durable pointer and backups exist before any production source changes.
    atomic_write(HERE / 'active-prompt-transition.json', encoded({'journal': str(path.relative_to(HERE))}))
    try:
        for key, source in PATHS.items():
            if current_hashes()[key] != before['hashes'][key]:
                raise ValueError('Source changed during transition: ' + source)
            if before['hashes'][key] != after['hashes'][key]:
                atomic_write(ROOT / source, target[key])
                journal['replaced'].append(key)
            journal['state'] = 'applying'
            save_journal(path, journal)
        if current_hashes() != after['hashes']:
            raise ValueError('Post-write source verification failed')
        atomic_write(HERE / 'applied-prompt.json', encoded(after))
        verify_current(catalog)
        journal['state'] = 'committed'
        save_journal(path, journal)
    except Exception as error:
        journal['error'] = repr(error)
        try:
            journal['observedAtFailure'] = current_hashes()
            rollback(path, journal, catalog)
            journal['state'] = 'rolled_back'
        except Exception as rollback_error:
            journal['state'] = 'recovery_required'
            journal['rollbackError'] = repr(rollback_error)
        try:
            save_journal(path, journal)
        except Exception as journal_error:
            # The initial prepared/applying journal remains durable; explicit recover
            # can verify its backups and recognize either known state after IO returns.
            journal['journalError'] = repr(journal_error)
        raise RuntimeError(f'Prompt transition failed ({journal["state"]}); inspect {path}: {error}') from error
    return dict(after, journal=str(path))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action', choices=('freeze', 'freeze-combinations', 'apply', 'verify', 'recover'))
    parser.add_argument('components', nargs='*')
    args = parser.parse_args()
    actions = {'freeze': freeze, 'freeze-combinations': freeze_combinations,
               'apply': lambda: apply(args.components), 'verify': verify_current, 'recover': recover}
    print(json.dumps(actions[args.action](), indent=2))
