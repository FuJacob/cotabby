# Fresh synthetic autocomplete validation corpus

This directory contains a synthetic convenience corpus authored by a Codex AI agent
for the blinded second validation round. The writing is AI-generated, not human-authored. It contains no material fetched from the network, no private user data,
and no prompts, references, failure cases, candidate code, or candidate-engine outputs
from earlier evaluations. It is not a sample of real user activity and does not establish real-user
representativeness.

`corpus.json` follows schema version 3. There are 700 English continuations: 100 each in
conversation, science, entertainment, work, technology, everyday, and travel. Each
continuation has an invented document prefix and screen context, one of the four specified
Mac application identities, an `evaluationGroup`, and a `contextKind`.

## Authorship and dependence

`author_data.py` is the complete source. It contains 140 individually authored scenario
seeds, twenty in each category. Each seed includes a separately written OCR content block
and five individually written prefix/continuation pairs. These are literal source data
written by the AI agent rather than expansions of a shared fill-in-the-blank sentence
template. No separate generation tool, candidate-engine inference call, or prior fixture
mining was used. A deterministic builder adds application chrome and emits the JSON.

The five cases within a family are dependent by design. They share the scenario seed,
application, screen content, and context kind. The five OCR strings differ only in a
plausible display timestamp; uniqueness of those strings does not make them independent.
The five prefixes and reference continuations are distinct. `families.json` preserves the
family mapping, source seed identifier, surface wrapper, and noisy-screen status.

The grouping count is **140 authored scenario families**, not 700 independent cases.
Even those 140 groups are not asserted to be probabilistically independent: they share one
authoring process, ordinary linguistic patterns, repeated UI scaffolding, and a common
noise construction. Generic UI wrappers do not count as additional authored families.
Use whole `evaluationGroup` units for splitting, resampling, or uncertainty estimates;
never treat sibling cases as separate independent samples. Report the convenience-sample
limitations alongside any result.

## Context construction

Families cycle through useful, distracting, and neutral screen context: 47 useful,
47 distracting, and 46 neutral families (235, 235, and 230 cases respectively). Every
family stays within one category and one context kind. Useful screens contain related
practical information; distracting screens contain an unrelated, invented notice;
neutral screens contain application/document chrome without task-specific facts.

Application identities cycle independently through Messages, Mail, Notes, and Safari,
with 175 cases per surface. These are actual application names and bundle identifiers;
there are no special fixture-only app labels or instructions telling a model the answer.
The wrappers represent plausible visible panes, messages, drafts, notes, or browser text.
They do not reproduce actual application screenshots or measured OCR errors.

Seven explicitly marked families (35 cases, 5%) have longer noisy screen text. Their
screens append duplicated sidebars and a small set of confused or clipped glyphs. This is
a deliberately synthetic stress subgroup, not an empirical model of OCR error. The
remaining screens are shorter and comparatively clean. The prespecified noisy-family ordinals in category order are 4, 6, 5, 7, 9, 8, and 10.
These give two families each on Messages, Mail, and Safari, and one on Notes; context kinds
are three useful, two distracting, and two neutral. This assignment was made before any
inference and is fixed, not random. Repeated UI strings are likely to be removed by OCR
deduplication, so this subgroup covers duplicated UI/OCR noise and raw screen length; it
must not be described as a sustained long-context challenge after deduplication.

Prefixes have one completed sentence followed by a partial sentence at the caret, and
end with a space. Continuations are four to eight words in this version. This is a narrow
short-continuation test, not a claim about the full distribution of writing lengths.
A reference is one natural continuation; alternative valid wording may exist, especially
under neutral and distracting context. Exact matching therefore measures agreement with
an authored reference as well as autocomplete quality.

## Reproduction and validation

From this directory, run:

```sh
python3 author_data.py
python3 validate.py
```

Both scripts use only the Python standard library and local authored data. They perform
no candidate-engine inference, build, network access, or user-data access. The generator writes only within
this directory. The validator emits aggregates and hashes, never raw cases.

`validate.py` checks:

- The exact schema, category counts, allowed context kinds, and application identities.
- Exactly 140 groups of five, with homogeneous category/context/surface within each group.
- Unique case IDs, document prefixes, screen strings, and prefix/reference pairs.
- Screen size bounds, short continuation length, prefix sentence count and trailing space.
- Absence of each full reference from its own screen/prefix, both verbatim and after
  case/punctuation/whitespace normalization.
- Absence of network addresses and common evaluation-instruction markers in context.
- Agreement between corpus and family metadata, including the marked noisy subgroup.

Structural checks cannot prove semantic usefulness, naturalness, answer uniqueness, or
absence of all possible unintended cues. A separate Codex AI custodian completed an
independent content audit and accepted the corpus at 2026-09-17 12:49:43 UTC. The audit
read at least one case from every family, checked all 700 cases structurally, and found
no systemic semantic/context-label issue or exact overlap with the prior corpus. The
author did not inspect that prior corpus. `custodian-audit.json` contains aggregate-only
audit findings. `validation-report.json` records the data-only check, and `manifest.json`
records provenance, readiness, file hashes, and the final freeze state.

Initial data-only readiness was reached at 2026-09-17 12:42:43 UTC, ahead of the specified
2026-09-17 13:06:09 UTC gate. Any pre-freeze audit fixes must be reflected in regenerated
JSON, a repeated validation pass, and updated final hashes. Do not edit frozen data during
candidate comparison.

Final corpus freeze: 2026-09-17 12:50:05 UTC. Corpus SHA256:
`2529c17f21b276eecafe7859853b1aafeba967346f205fa9f378631aa2dda828`.
