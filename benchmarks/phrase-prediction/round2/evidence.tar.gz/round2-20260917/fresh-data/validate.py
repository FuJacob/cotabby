#!/usr/bin/env python3
"""Deterministically validate this synthetic corpus without printing reference text.

This script is deliberately data-only: no candidate-engine inference, builds, network, or user data.
It validates structure, family preservation, bounds, uniqueness, and exact reference
leakage after case/punctuation/whitespace normalization. It does not establish semantic
quality, model utility, or representativeness. Errors identify only rule names/counts.
"""
from pathlib import Path
from collections import Counter, defaultdict
import argparse
import hashlib
import json
import re
import statistics
import sys

CATEGORIES = {'conversation','science','entertainment','work','technology','everyday','travel'}
KINDS = {'useful','distracting','neutral'}
APPS = {'Messages':'com.apple.MobileSMS','Safari':'com.apple.Safari',
        'Notes':'com.apple.Notes','Mail':'com.apple.mail'}
SCENARIO_KEYS = {'kind','applicationName','bundleIdentifier','windowTitle','fieldPlaceholder',
                 'documentPrefix','screenText'}
ROOT = Path(__file__).resolve().parent

def words(text):
    return re.findall(r"[a-z]+(?:['’][a-z]+)?|\d+", text.casefold())

def normalized(text):
    return ' '.join(words(text))

def sha256(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def stats(values):
    return {'min': min(values), 'median': statistics.median(values),
            'max': max(values)}

def validate(corpus_path, family_path):
    errors = Counter()
    corpus = json.loads(corpus_path.read_text())
    metadata = json.loads(family_path.read_text())['families']
    def check(condition, name):
        if not condition:
            errors[name] += 1
    check(corpus.get('version') == 3, 'version_must_be_3')
    check(corpus.get('language') == 'en', 'language_must_be_en')
    check(isinstance(corpus.get('provenance'), str) and len(corpus['provenance']) > 50,
          'substantive_provenance_required')
    phrases = corpus['phrases']
    check(len(phrases) == 700, 'expected_700_cases')
    category_counts = Counter()
    context_counts = Counter()
    app_counts = Counter()
    groups = defaultdict(list)
    ids, screens, prefixes, references, pairs = [], [], [], [], []
    screen_lengths, prefix_lengths, reference_words = [], [], []
    prefix_sentences = []
    for phrase in phrases:
        check(set(phrase) == {'id','category','text','evaluationGroup','contextKind','scenario'},
              'phrase_keys')
        for key in ['id','category','text','evaluationGroup','contextKind']:
            check(isinstance(phrase.get(key), str) and bool(phrase[key].strip()), 'nonempty_' + key)
        category_counts[phrase['category']] += 1
        context_counts[phrase['contextKind']] += 1
        check(phrase['category'] in CATEGORIES, 'unknown_category')
        check(phrase['contextKind'] in KINDS, 'unknown_context_kind')
        scenario = phrase['scenario']
        check(set(scenario) == SCENARIO_KEYS, 'scenario_keys')
        for key in SCENARIO_KEYS:
            check(isinstance(scenario.get(key), str) and bool(scenario[key].strip()),
                  'nonempty_scenario_' + key)
        app = scenario['applicationName']
        app_counts[app] += 1
        check(APPS.get(app) == scenario['bundleIdentifier'], 'surface_bundle_mismatch')
        check(scenario['kind'] in {'message','email','note','webForm'}, 'unknown_scenario_kind')
        prefix, screen, reference = scenario['documentPrefix'], scenario['screenText'], phrase['text']
        check(prefix.endswith((' ', '\n')), 'prefix_missing_trailing_whitespace')
        check(40 <= len(screen) <= 4000, 'screen_length_out_of_bounds')
        check(3 <= len(words(reference)) <= 20, 'continuation_word_length_out_of_bounds')
        check(len(reference) <= 150, 'continuation_not_short')
        # Count completed sentences. A following partial sentence is normal at a caret.
        sentence_count = len(re.findall(r'[.!?](?:\s|$)', prefix))
        check(1 <= sentence_count <= 3, 'prefix_sentence_count_out_of_bounds')
        check(reference == reference.strip(), 'reference_outer_whitespace')
        reference_normalized = normalized(reference)
        prefix_normalized = normalized(prefix)
        screen_normalized = normalized(screen)
        combined = screen_normalized + ' ' + prefix_normalized
        check(reference_normalized not in combined, 'complete_reference_in_context')
        check(reference not in prefix and reference not in screen, 'verbatim_reference_in_context')
        check(not re.search(r'https?://|www\.|[\w.+-]+@[\w.-]+\.[a-z]{2,}',
                            prefix + '\n' + screen, flags=re.I), 'unexpected_online_address')
        check(not re.search(r'expected\s+(?:word|answer)|fixture|benchmark|autocomplete\s+test',
                            prefix + '\n' + screen, flags=re.I), 'evaluation_instruction_in_context')
        ids.append(phrase['id'])
        screens.append(screen)
        prefixes.append(prefix)
        references.append(reference_normalized)
        pairs.append((prefix_normalized,reference_normalized))
        screen_lengths.append(len(screen))
        prefix_lengths.append(len(prefix))
        reference_words.append(len(words(reference)))
        prefix_sentences.append(sentence_count)
        groups[phrase['evaluationGroup']].append(phrase)
    check(set(category_counts) == CATEGORIES, 'category_set')
    check(all(count == 100 for count in category_counts.values()), 'category_not_100_cases')
    check(len(groups) == 140, 'expected_140_scenario_families')
    check(len(ids) == len(set(ids)), 'duplicate_case_id')
    check(len(screens) == len(set(screens)), 'duplicate_screen_text')
    check(len(prefixes) == len(set(prefixes)), 'duplicate_document_prefix')
    check(len(references) == len(set(references)), 'duplicate_normalized_reference')
    check(len(pairs) == len(set(pairs)), 'duplicate_prefix_reference_pair')
    family_context_counts = Counter()
    family_category_counts = Counter()
    for group in groups.values():
        check(len(group) == 5, 'family_not_five_cases')
        check(len({case['category'] for case in group}) == 1, 'mixed_category_family')
        check(len({case['contextKind'] for case in group}) == 1, 'mixed_context_family')
        check(len({case['scenario']['applicationName'] for case in group}) == 1,
              'mixed_surface_family')
        family_context_counts[group[0]['contextKind']] += 1
        family_category_counts[group[0]['category']] += 1
    check(max(family_context_counts.values()) - min(family_context_counts.values()) <= 1,
          'context_families_not_balanced')
    check(len(metadata) == 140, 'metadata_family_count')
    metadata_by_group = {item['evaluationGroup']: item for item in metadata}
    check(set(metadata_by_group) == set(groups), 'metadata_group_set')
    long_noisy_groups = []
    for group_id, item in metadata_by_group.items():
        group = groups[group_id]
        check(item['caseCount'] == len(group), 'metadata_case_count')
        check(item['category'] == group[0]['category'], 'metadata_category')
        check(item['contextKind'] == group[0]['contextKind'], 'metadata_context_kind')
        check(item['surfaceWrapper'] == group[0]['scenario']['applicationName'], 'metadata_surface')
        if item['longNoisyScreen']:
            long_noisy_groups.append(group_id)
            check(all(len(case['scenario']['screenText']) >= 900 for case in group),
                  'long_noisy_screen_too_short')
    check(len(long_noisy_groups) == 7, 'long_noisy_group_count')
    noisy_categories = Counter(groups[key][0]['category'] for key in long_noisy_groups)
    noisy_surfaces = Counter(groups[key][0]['scenario']['applicationName'] for key in long_noisy_groups)
    noisy_contexts = Counter(groups[key][0]['contextKind'] for key in long_noisy_groups)
    check(set(noisy_categories) == CATEGORIES and all(n == 1 for n in noisy_categories.values()),
          'noisy_subgroup_not_one_family_per_category')
    check(set(noisy_surfaces) == set(APPS) and max(noisy_surfaces.values()) <= 2,
          'noisy_subgroup_surface_imbalance')
    check(set(noisy_contexts) == KINDS and max(noisy_contexts.values()) <= 3,
          'noisy_subgroup_context_imbalance')
    source_path = ROOT / 'author_data.py'
    report = {
        'valid': not errors,
        'errors': dict(sorted(errors.items())),
        'caseCount': len(phrases),
        'scenarioFamilyCount': len(groups),
        'casesPerFamily': stats([len(group) for group in groups.values()]),
        'categoryCaseCounts': dict(sorted(category_counts.items())),
        'categoryFamilyCounts': dict(sorted(family_category_counts.items())),
        'contextCaseCounts': dict(sorted(context_counts.items())),
        'contextFamilyCounts': dict(sorted(family_context_counts.items())),
        'surfaceCaseCounts': dict(sorted(app_counts.items())),
        'uniqueScreenCount': len(set(screens)),
        'uniquePrefixCount': len(set(prefixes)),
        'uniqueNormalizedReferenceCount': len(set(references)),
        'longNoisyFamilyCount': len(long_noisy_groups),
        'longNoisyFamilySurfaceCounts': dict(sorted(noisy_surfaces.items())),
        'longNoisyFamilyContextCounts': dict(sorted(noisy_contexts.items())),
        'longNoisyCaseCount': sum(len(groups[key]) for key in long_noisy_groups),
        'screenCharacters': stats(screen_lengths),
        'documentPrefixCharacters': stats(prefix_lengths),
        'continuationWords': stats(reference_words),
        'completedPrefixSentences': stats(prefix_sentences),
        'sha256': {
            'corpus.json': sha256(corpus_path),
            'families.json': sha256(family_path),
            'author_data.py': sha256(source_path),
        },
        'limitations': [
            'AI-agent-authored synthetic convenience corpus; no real-user representativeness claimed.',
            'Five cases share each authored scenario seed; use evaluationGroup for uncertainty and splitting.',
            '140 scenario families are the grouping count, not a claim of probabilistic independence.',
            'One authoring process, repeated surface chrome, and shared noise construction can induce dependence across groups.',
            'Exact normalized reference leakage is checked; semantic uniqueness and usefulness remain judgments.',
            'A natural continuation need not be the only reasonable continuation.',
            'Long/noisy subgroup is duplicated UI/OCR noise; deduplication may remove most extra text.',
        ],
    }
    return report

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--corpus', type=Path, default=ROOT / 'corpus.json')
    parser.add_argument('--families', type=Path, default=ROOT / 'families.json')
    parser.add_argument('--output', type=Path, default=ROOT / 'validation-report.json')
    args = parser.parse_args()
    result = validate(args.corpus, args.families)
    args.output.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps(result, sort_keys=True))
    sys.exit(0 if result['valid'] else 1)
