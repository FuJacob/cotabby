"""Synthetic English continuation families authored for a blinded second-round check.

The content below is authored by a Codex AI agent from invented scenarios, not mined
from prior fixtures, logs, candidate-engine output, the network, or user data. Each FAMILY call contributes a distinct
scenario seed and five related prefix/continuation pairs. Reused surface wrappers are
presentation scaffolding; semantic dependence is retained by the family identifier.
"""
from pathlib import Path
import json, hashlib, re
ROOT = Path(__file__).resolve().parent
families = []

def FAMILY(category, slug, title, screen, cases):
    assert len(cases) == 5
    families.append(dict(category=category, slug=slug, title=title, screen=screen, cases=cases))

# Conversation: twenty separately authored everyday interpersonal scenarios.
FAMILY('conversation','bakery_meetup','Saturday breakfast',
       'Harbor Bakery\nSaturday hours 7:00–14:00\nCourtyard tables are first come, first served. Bicycle parking is beside the blue gate.',[
('I checked the bakery hours. On Saturday we can meet ', 'just after seven for breakfast.'),
('The courtyard does not take reservations. I will get there early and ', 'save us a small table.'),
('I am cycling over for breakfast. There is a rack ', 'right by the blue entrance gate.'),
('The bakery closes early this weekend. Shall we go ', 'in the morning instead?'),
('The weather should be mild for our breakfast. We could sit ', 'outside in the courtyard.')])
FAMILY('conversation','borrowed_ladder','Ladder return',
       'Neighborhood exchange\nMoss Lane book circle\nThe next discussion covers a sea voyage and a missing map. Bring a mug; tea will be available.',[
('Thanks for lending me the ladder. I finished the ceiling this morning and can ', 'bring it back this evening.'),
('Your ladder is folded up by my front door. Let me know ', 'when you will be home.'),
('I wiped the paint splashes off the ladder. It should look ', 'the same as before.'),
('I still need the ladder for one high shelf. Could I keep it ', 'until tomorrow after lunch?'),
('The ladder will not fit in my little car. Would you mind ', 'helping me carry it over?')])
FAMILY('conversation','missed_call','Call follow-up',
       'Messages\nConversation details\nNotifications enabled\nShared links and recent attachments\nTyping indicator unavailable\nSearch this conversation',[
('Sorry I missed your call. I was on the bus and ', 'could not hear my phone.'),
('I have a quiet half hour now. Are you free ', 'for a quick call?'),
('My battery died halfway through our conversation. I can call ', 'again once it charges.'),
('I saw your missed call after the meeting. Is everything ', 'all right over there?'),
('I am about to step into the library. I will ring you ', 'when I get outside.')])
FAMILY('conversation','garden_watering','Plants while away',
       'Balcony plant notes\nFern: keep soil lightly moist. Succulent: no watering this week. Spare watering can under the bench. Apartment key with the downstairs neighbor.',[
('Thank you for checking the balcony while I am away. The watering can is ', 'under the wooden bench.'),
('The little succulent does fine in dry soil. You can ', 'leave that one alone.'),
('The fern dries out faster than the other plants. Please give it ', 'a little water each visit.'),
('My departure may be earlier than your visit. If I have already left, the spare key is ', 'with our neighbor on the floor below.'),
('I grouped the plants together to make this easier. Only the fern needs ', 'attention during this week.')])
FAMILY('conversation','forgotten_scarf','Scarf at dinner',
       'Museum members\nNew exhibit: clocks and calendars\nTimed entry begins every twenty minutes. The upstairs gallery is closed for lighting maintenance.',[
('I think I left my scarf on your coat rack after dinner. Could you ', 'check when you have time?'),
('The scarf I lost is green with a narrow cream stripe. It might be ', 'under the dining chair.'),
('Thanks for finding my scarf. I will stop by ', 'on my way home.'),
('There is no rush to return the scarf. Keep it somewhere safe ', 'until we meet again.'),
('That blue scarf belongs to someone else. Mine is ', 'the green striped one.')])
FAMILY('conversation','surprise_visit','Unexpected visitor',
       'Conversation\nContact card\nShare contact\nAudio call\nPinned messages\nRecent photos\nNo shared location\nText message field',[
('I am in your neighborhood for an appointment. Would it be okay ', 'to drop by afterward?'),
('I did not know you were coming today. Give me ten minutes ', 'to tidy the kitchen.'),
('You are welcome to stay for dinner. We have ', 'more than enough soup.'),
('The doorbell is broken at the moment. Send me a message ', 'when you get here.'),
('I will be back from the shop soon. You can wait ', 'on the covered porch.')])
FAMILY('conversation','movie_change','Change of film plans',
       'Cedar Cinema\nEvening screening cancelled because of a projector fault. All advance tickets refunded automatically. The afternoon matinee remains on the schedule.',[
('The cinema cancelled our evening screening. Our tickets will be ', 'refunded without another request.'),
('It looks like the projector broke again. We could watch something ', 'at my place instead.'),
('The afternoon showing is still happening. Would you rather go ', 'earlier in the day?'),
('There is no evening film now, but we already made time. Let us keep ', 'our dinner plans anyway.'),
('I checked the notice from the cinema. We do not need ', 'to apply for a refund.')])
FAMILY('conversation','birthday_card','Card for a friend',
       'Community garden noticeboard\nTool shed inspection Thursday\nPlease keep the central path clear. The compost delivery has moved to the west entrance.',[
('I am writing a birthday card for Mira. Is there a memory ', 'you would like me to include?'),
('We are all signing the same card before lunch. I left it ', 'beside the coffee machine.'),
('I have room for one more line on the card. Send me ', 'a short birthday message.'),
('The envelope is larger than I expected. We can tuck ', 'the photograph inside too.'),
('I forgot to sign the birthday card yesterday. Could you add ', 'my name at the bottom?')])
FAMILY('conversation','new_neighbor','Welcome next door',
       'Messages\nNew conversation\nRecipient information\nAdd to contacts\nFilter unknown senders\nAttachment options\nMessage input',[
('Welcome to the building. If you need a hand with the boxes, ', 'just knock on my door.'),
('The recycling bins are a little hard to find. They are ', 'behind the rear stairwell.'),
('I made an extra loaf this morning. Would you like ', 'some freshly baked bread?'),
('I am still learning everyone in the building. What name should I ', 'put in my contacts?'),
('Your delivery arrived while you were out. I left it ', 'outside your apartment door.')])
FAMILY('conversation','picnic_weather','Rain plan',
       'Hilltop Park\nWeather update: steady rain from noon. Lakeside pavilion has a roof and six picnic tables. Dogs must remain on leads near the playground.',[
('The forecast says rain from noon. We should move our picnic ', 'under the lakeside pavilion.'),
('There are only six covered tables at the park. I will arrive early ', 'to find a dry spot.'),
('You can bring the dog to the picnic. Near the playground, keep him ', 'on a short lead.'),
('The ground will probably be wet by lunch. Bring something waterproof ', 'to sit on anyway.'),
('I still want to meet even if it rains. The pavilion should keep ', 'most of us dry.')])
FAMILY('conversation','quiet_hours','Evening noise',
       'Recipe collection\nRoasted squash with lentils\nToast the cumin briefly before adding the onions. Serve with a spoonful of yogurt and chopped parsley.',[
('I have an early shift tomorrow. Could we turn the music ', 'down after ten tonight?'),
('Sorry about the drilling this afternoon. The repair is finished, so ', 'it should be quiet now.'),
('The sound travels through our shared wall. I can hear ', 'the bass in my bedroom.'),
('Thanks for keeping the hallway quiet last night. I finally got ', 'a full night of sleep.'),
('We are having a few friends over on Friday. Please text me ', 'if the noise bothers you.')])
FAMILY('conversation','photo_request','Shared photos',
       'Conversation settings\nPhotos\nLinks\nDocuments\nDownload attachments\nShow in shared content\nStorage information\nMessage composer',[
('The group photo on the bridge turned out well. Could you send me ', 'the original when you can?'),
('My eyes are closed in that first picture. Do you have ', 'another one from the same spot?'),
('I made a small album from the weekend. I will share it ', 'after I sort the duplicates.'),
('The file is too big for a text message. I can send ', 'a download link instead.'),
('Please check with everyone in the photo before posting it. Some people prefer ', 'to keep pictures private.')])
FAMILY('conversation','dinner_preferences','Dinner choices',
       'Dinner notes\nNo mushrooms for Rowan. Quinn prefers mild food. Rice is already in the cupboard. Four people confirmed; one person will arrive late.',[
('I am planning dinner for the four of us. I will leave ', 'mushrooms out of the sauce.'),
('Quinn prefers food without much heat. Let us serve the chili ', 'in a separate bowl.'),
('We already have plenty of rice. The shopping list only needs ', 'vegetables and a few herbs.'),
('One person will arrive after we start eating. I will save ', 'a plate in the kitchen.'),
('I want everyone to enjoy the same main dish. A mild vegetable curry ', 'should work for our group.')])
FAMILY('conversation','weekend_walk','Walking invitation',
       'Public lecture programme\nThe history of handwriting\nDoors open at 18:15. The speaker will demonstrate three historic pen shapes. Tickets include a printed booklet.',[
('I need a break from sitting at my desk. Would you like ', 'to go for a walk?'),
('The river path is muddy after the rain. We could take ', 'the route through town.'),
('I am only up for a short walk today. Let us turn back ', 'at the old footbridge.'),
('I will bring water for both of us. You just need ', 'a pair of comfortable shoes.'),
('I am running a few minutes late for our walk. Please wait ', 'by the park entrance.')])
FAMILY('conversation','reassuring_friend','Before a big day',
       'Messages\nFocus status unavailable\nConversation search\nContact details\nCall options\nShared attachments\nSend a message',[
('You have prepared carefully for tomorrow. Try to get ', 'some rest this evening.'),
('It makes sense to feel nervous before an interview. I am sure ', 'you will find your rhythm.'),
('You do not have to explain everything right now. I am here ', 'whenever you want to talk.'),
('The plan does not have to be perfect. Even if tomorrow is difficult, we can take it ', 'one step at a time.'),
('I will keep my phone nearby after your appointment. Send me ', 'a message when you finish.')])
FAMILY('conversation','shared_ride','Ride to rehearsal',
       'Rehearsal change\nStart: 18:45 in Studio C\nNorth car park closed. Drop-off is permitted beside the south entrance. Instruments can be stored in the side room.',[
('Rehearsal starts later this week. I can pick you up ', 'at a quarter past six.'),
('The north car park is closed. I will meet you ', 'by the south entrance.'),
('There is a side room for our instrument cases. We can leave them ', 'there during the rehearsal.'),
('I have room for one more person in the car. Let me know ', 'if someone else needs a ride.'),
('We are in Studio C this evening. I will look for you ', 'outside that room before we start.')])
FAMILY('conversation','apology_delay','Late response',
       'Harbor ferry news\nPier maintenance is complete. The ticket kiosk has moved inside the terminal. Bicycles board after pedestrians on busy sailings.',[
('I meant to reply yesterday and then got distracted. Sorry for ', 'leaving you waiting so long.'),
('I read your message while I was out. I wanted to wait ', 'until I could answer properly.'),
('Things have been busy here this week. I have not forgotten ', 'about our plans for Sunday.'),
('Thanks for checking in again. Your first message got ', 'buried under several other conversations.'),
('I cannot give you a firm answer tonight. Could I get back ', 'to you tomorrow morning?')])
FAMILY('conversation','tea_visit','Tea after lunch',
       'Chat details\nPinned conversation\nHide alerts\nOpen contact card\nShow shared content\nSearch messages\nCompose a reply',[
('I have just put the kettle on. Would you like ', 'a cup of tea?'),
('We are out of ordinary milk. Is oat milk ', 'all right with you?'),
('I bought those little biscuits you liked. There are still ', 'a few in the tin.'),
('Take whichever mug you prefer. The larger ones are ', 'on the lower shelf.'),
('I can stay for one more cup. After that I need ', 'to head back home.')])
FAMILY('conversation','board_game_invite','Games at home',
       'Game night\nPlayers confirmed: five\nBring a cooperative game if possible. The dining table seats six. Snacks will be nut free; drinks are already sorted.',[
('There will be five of us for games. Bring something ', 'we can all play together.'),
('We are trying a cooperative game this time. It will be nice ', 'to work as one team.'),
('The dining table seats six people. There is room ', 'if you want to join us.'),
('We have already bought drinks for game night. You could bring ', 'a nut free snack.'),
('I will clear the table before everyone arrives. We should have space ', 'for the larger game board.')])
FAMILY('conversation','cat_sitting_update','Cat update',
       'Library returns\nThe outside book chute is temporarily locked. Return items at the main desk during opening hours. Renewals remain available from the account page.',[
('Your cat came out as soon as I opened the food tin. She seems ', 'perfectly happy this morning.'),
('I changed the water and cleaned the litter tray. Everything is ', 'all sorted for today.'),
('She has chosen the sunny chair for her afternoon nap. I will send ', 'a picture when she wakes.'),
('The cat was shy at first but settled quickly. She is now ', 'sitting right beside me.'),
('I could not find the spare food pouch. Is it ', 'in the kitchen cupboard?')])

# Science: invented laboratory, field, and explanatory writing scenarios.
FAMILY('science','seed_light','Seedling trial',
       'Lab notebook\nLocal copy\nAll changes saved\nSection list\nInsert table\nSearch notes\nPage outline\nText editing area',[
('Both seed trays received the same amount of water. The only difference was ', 'how much light they received.'),
('The seedlings nearest the window grew toward the glass. This suggests that ', 'their growth responded to light.'),
('We measured each stem at the same time every morning. This kept ', 'the comparison consistent across days.'),
('A few seeds never sprouted in either tray. We recorded them ', 'separately from the growing seedlings.'),
('Next time we should use more seeds in each group. A larger sample ', 'would make the comparison stronger.')])
FAMILY('science','stream_temperature','Creek measurements',
       'Field survey\nSite A: shaded bank, 11.8 C\nSite B: open gravel, 14.1 C\nMeasurements taken at 13:00 with the same probe. Air conditions were stable.',[
('The shaded section of the creek was cooler than the open section. Tree cover may have ', 'reduced warming from direct sunlight.'),
('We used the same probe at both sampling sites. That reduced differences ', 'caused by the measuring equipment.'),
('The open gravel reach measured 14.1 degrees. The shaded bank was ', 'a little over two degrees cooler.'),
('Both readings were taken at one in the afternoon. This avoids comparing ', 'different times of the day.'),
('These two readings do not establish a seasonal pattern. We should repeat ', 'the measurements throughout the year.')])
FAMILY('science','salt_crystals','Evaporating saltwater',
       'Studio pottery newsletter\nGlaze samples are ready for collection. The blue kiln shelf has been replaced. Weekend classes now include a short trimming demonstration.',[
('As the water evaporated, salt remained in the dish. Small crystals appeared ', 'along the dry edges first.'),
('We weighed the empty dish before adding the solution. That allowed us ', 'to subtract its mass later.'),
('The dish near the heater dried more quickly. Its water was lost ', 'at a faster rate.'),
('We covered each dish with a loose mesh. This kept dust out ', 'without stopping the water from evaporating.'),
('The final crystals were not all the same size. Some had grown ', 'much larger than their neighbors.')])
FAMILY('science','moon_sketches','Moon observation log',
       'Notes\nObservation journal\nSort by date edited\nShow folders\nAdd attachment\nLocked notes\nSearch this note\nEditing enabled',[
('The bright part of the Moon looked wider than it did last week. I sketched ', 'its outline beside the date.'),
('Thin cloud covered the Moon during the second observation. The boundary was ', 'harder to see clearly.'),
('I made each drawing from the same balcony. This kept my view ', 'clear of the neighboring roof.'),
('The Moon was visible before sunset today. I could see it ', 'against the pale blue sky.'),
('The sketch records appearance rather than exact size. I did not use ', 'a calibrated measuring instrument.')])
FAMILY('science','pendulum_length','Pendulum timing',
       'Timing sheet\nShort string: 10 swings in 12.0 s\nLong string: 10 swings in 17.1 s\nSame bob, small release angle, three trials for each length.',[
('The longer pendulum took more time to complete ten swings. Its period was ', 'greater than that of the shorter pendulum.'),
('We counted ten swings instead of timing only one. This made human reaction time ', 'a smaller part of the measurement.'),
('The same bob was used for both string lengths. We changed ', 'only the length of the string.'),
('We released the bob from a small angle each time. That helped keep ', 'the trials comparable to each other.'),
('Three trials were recorded for every string length. We calculated ', 'the mean time for each set.')])
FAMILY('science','soil_layers','Soil jar study',
       'Railway heritage weekend\nSignal box tours begin at the west platform. Volunteers will demonstrate mechanical levers. The station cafe opens before the first guided walk.',[
('After the soil settled in the jar, several layers became visible. The coarsest particles ', 'collected near the bottom.'),
('We marked the water level before shaking the jar. This gave us ', 'a reference for later observations.'),
('Tiny particles stayed suspended longer than the sand. The water remained ', 'cloudy for several hours.'),
('The sample from the garden contained bits of leaf. We removed the largest pieces ', 'before comparing the mineral layers.'),
('The jar test gives only a rough description of texture. A precise analysis would need ', 'more carefully controlled measurements.')])
FAMILY('science','bird_count','Wetland bird count',
       'Field notes\nUntitled section\nSaved on this Mac\nTable controls\nDocument outline\nRecent notes\nShare options\nSearch field',[
('We counted birds from the same lookout each morning. Moving between viewpoints might ', 'count the same birds twice.'),
('Fog made the far bank difficult to see. We marked that count ', 'as having limited visibility.'),
('A large flock arrived just before we finished. We recorded its arrival ', 'separately in the field notes.'),
('The observer used binoculars for every survey. Small distant birds would otherwise ', 'have been easy to miss.'),
('One morning had many more birds than the others. We should check ', 'whether the tide was different.')])
FAMILY('science','ice_insulation','Insulation comparison',
       'Experiment setup\nEqual ice masses in identical cups\nCup A wrapped in felt; Cup B unwrapped\nRoom temperature 21 C\nMeltwater collected after thirty minutes.',[
('The felt wrapped cup produced less meltwater in thirty minutes. The wrapping slowed ', 'the transfer of heat inward.'),
('Both cups started with equal masses of ice. This made the amount of meltwater ', 'easier to compare fairly.'),
('We kept the cups away from direct sunlight. Otherwise one cup might receive ', 'additional energy from the Sun.'),
('The room remained close to twenty one degrees throughout. We recorded this ', 'as a controlled condition.'),
('A useful follow-up would compare several wrapping materials. We could measure which one ', 'slows the melting most effectively.')])
FAMILY('science','sound_tube','Tube resonance',
       'Harbor arts programme\nPaper lantern workshop\nBring an apron and an empty box for transport. Glue and cutting tools are supplied. Registration closes on Monday.',[
('The tone became louder at a particular tube length. This was consistent with ', 'resonance of the air column.'),
('We kept the tuning fork away from the rim. Touching the tube could ', 'change the sound we heard.'),
('Background noise made the quietest tones difficult to judge. We repeated the trial ', 'in a quieter room.'),
('The tube length was read at eye level. This reduced error ', 'from viewing the scale at an angle.'),
('We noted a second loud position farther along the tube. Its spacing gave us ', 'another way to check the pattern.')])
FAMILY('science','leaf_stomata','Leaf microscopy',
       'Observation document\nInsert image\nZoom controls\nPage navigation\nSaved locally\nFind in document\nTable of contents\nText cursor',[
('We focused the microscope slowly on the leaf surface. Several small pores ', 'came into clear view.'),
('The lower surface had more visible pores in this sample. We should examine ', 'more leaves before generalizing.'),
('A bubble was trapped under the cover slip. It obscured ', 'part of the leaf impression.'),
('We drew the field of view before changing magnification. The sketch included ', 'a scale and brief labels.'),
('The image became dimmer at higher magnification. We adjusted the illumination ', 'to restore a clear view.')])
FAMILY('science','magnet_distance','Magnetic force demonstration',
       'Distance trial\nSame bar magnet and steel paper clip\nThin card spacers added one at a time\nClip no longer lifted after the sixth spacer was inserted.',[
('The magnet lifted the clip through several layers of card. Adding more space eventually ', 'prevented it from lifting the clip.'),
('We used identical card spacers for every step. Each addition increased ', 'the separation by the same amount.'),
('The sixth spacer changed the outcome of the trial. At that distance the magnetic force ', 'could not lift the clip.'),
('The same paper clip was used throughout the test. That kept its mass ', 'constant between the trials.'),
('This demonstration does not give a precise force measurement. It only shows ', 'how the lifting ability changes.')])
FAMILY('science','yeast_balloons','Yeast activity',
       'Theater wardrobe list\nVelvet jacket needs a repaired cuff. Two hats are stored in the upper cupboard. All borrowed shoes must be labeled before rehearsal.',[
('The balloon above the warm mixture inflated slowly. Gas was being produced ', 'inside the closed bottle.'),
('We checked that the balloons fitted tightly over the bottle necks. A loose fit could ', 'allow gas to escape.'),
('The cold mixture showed little change during the observation period. We recorded ', 'the room and liquid temperatures.'),
('Every bottle received the same quantity of yeast. This helped us isolate ', 'the effect of the temperature.'),
('The balloon circumference is only an approximate measure of gas. The rubber can stretch ', 'differently from one balloon to another.')])
FAMILY('science','rock_weathering','Weathered stone',
       'Research note\nDocument saved\nFormatting toolbar\nComments panel\nAttachment menu\nRecent files\nOutline view\nParagraph editing area',[
('The exposed face of the stone was rougher than the sheltered face. Weathering had ', 'altered its outer surface.'),
('Water had entered the narrow crack near the edge. Repeated freezing could ', 'help widen that opening.'),
('The rounded pebbles differed from the angular fragments nearby. Their shapes suggest ', 'different histories of movement.'),
('We photographed the sample beside a ruler. This preserved ', 'a reference for its size.'),
('Surface color alone was not enough to identify the mineral. We also examined ', 'its texture and crystal form.')])
FAMILY('science','water_density','Layered liquids',
       'Demonstration notes\nColored fresh water above clear saltwater\nPour slowly down the side of the cylinder\nKeep both liquids at room temperature\nAvoid shaking after pouring.',[
('The colored fresh water stayed above the saltwater at first. The lower layer was ', 'denser than the upper layer.'),
('We poured the liquid down the side of the cylinder. This reduced ', 'mixing during the initial setup.'),
('Both liquids were kept at room temperature. A temperature difference could also ', 'affect their relative densities.'),
('The boundary became less distinct as the experiment continued. The two liquids were ', 'gradually mixing with each other.'),
('Shaking the cylinder erased the visible layers quickly. We therefore left it ', 'undisturbed during the observation period.')])
FAMILY('science','shadow_stick','Noon shadow record',
       'Bicycle workshop\nPuncture repair demonstration at 11:00\nSpare inner tubes are available in three sizes. Please remove lights and bags before placing bikes on the stand.',[
('We marked the tip of the stick shadow every hour. The marks traced ', 'a curve across the ground.'),
('The shadow was shorter around the middle of the day. The Sun appeared ', 'higher in the sky.'),
('We checked that the stick stayed upright. A tilted stick would ', 'change the recorded shadow positions.'),
('Clouds hid the shadow during the final observation. We left that time ', 'blank in the data table.'),
('The next observation should use the same fixed marker. That will let us ', 'compare the two days directly.')])
FAMILY('science','reaction_dissolving','Dissolving tablets',
       'Experiment record\nLocal workspace\nInsert table\nAttachment list\nParagraph styles\nSaved changes\nSearch document\nEditing tools',[
('The crushed tablet disappeared faster than the whole tablet. More of its surface ', 'was exposed to the water.'),
('We stirred both beakers at the same steady rate. This kept stirring ', 'from becoming an extra variable.'),
('The endpoint was difficult to judge through the bubbles. We defined it as ', 'the disappearance of visible solid.'),
('The water volume was measured before each trial. Equal volumes helped ', 'keep the conditions comparable.'),
('One tablet fragment stuck to the wall above the water. We repeated that trial ', 'after correcting the setup.')])
FAMILY('science','planet_transit','Brightness dip',
       'Simulated star observation\nRelative brightness drops by 0.8 percent every 5.2 days\nDip duration about three hours\nA neighboring comparison star shows no matching decrease.',[
('The brightness decrease repeated at regular intervals. That pattern could indicate ', 'an orbiting object crossing the star.'),
('The comparison star did not show a matching drop. This makes a shared observing error ', 'less likely as the explanation.'),
('The simulated dips occurred every 5.2 days. That interval provides ', 'an estimate of the orbital period.'),
('The dip depth was less than one percent. Accurate measurements were needed ', 'to distinguish it from noise.'),
('A repeating dip alone does not prove the interpretation. Additional observations would help ', 'rule out alternative explanations.')])
FAMILY('science','fungus_log','Forest decomposition',
       'Community choir\nSpring repertoire notes\nThe opening song begins without accompaniment. Please mark page turns before the next rehearsal. Spare folders are on the piano.',[
('Fungal threads spread across the underside of the fallen log. They were part of ', 'the wood decomposition process.'),
('The damp log felt softer than the dry branch nearby. Moisture can influence ', 'how quickly organic matter breaks down.'),
('We lifted the log only briefly before replacing it. This limited disturbance ', 'to the organisms living underneath.'),
('Several insects were sheltering beneath the loose bark. We recorded them ', 'without removing them from the site.'),
('The decay was uneven across the length of the log. We photographed ', 'both the firm and softened areas.')])
FAMILY('science','static_charge','Static electricity',
       'Class notes\nSearch all notes\nRecently edited\nPage attachments\nFormatting controls\nShow outline\nSaved on device\nText entry',[
('After rubbing the balloon, it attracted small paper pieces. The pieces moved ', 'toward the charged surface.'),
('The effect weakened after we touched the balloon with a damp hand. Moisture allowed charge ', 'to dissipate more easily.'),
('We used paper pieces of similar size. Larger pieces would require ', 'more force to lift.'),
('The balloon did not need to touch the paper first. The attraction acted ', 'across a small gap.'),
('We repeated the demonstration on a humid day. The results were ', 'less pronounced than before.')])
FAMILY('science','pollen_slide','Pollen comparison',
       'Microscope sample list\nSample A: smooth oval grains\nSample B: rounded grains with a spiny outline\nBoth images use the same magnification. Scale bar represents twenty micrometers.',[
('The two pollen samples had different surface textures. One appeared smooth while the other ', 'had a visibly spiny outline.'),
('Both images were captured at the same magnification. This allowed ', 'a direct comparison of size.'),
('The scale bar represented twenty micrometers. We used it ', 'to estimate each grain diameter.'),
('Some grains overlapped near the edge of the slide. We measured only those ', 'with a clearly visible outline.'),
('Shape alone may not identify the plant species reliably. We would need ', 'additional features and reference material.')])

# Entertainment: production, attendance, and discussion rather than factual trivia.
FAMILY('entertainment','puppet_show','Puppet show setup',
       'Bakery order board\nWholegrain loaves ready at 08:30\nSourdough collection closes at noon. Please bring a bag for larger orders. The card reader is beside the till.',[
('The puppet curtain is too low for the tallest character. We should raise it ', 'before the audience comes in.'),
('The dragon puppet needs two people to move it. One controls the head and ', 'the other handles the tail.'),
('The children could see the puppeteer during the first scene. We moved the lamp ', 'farther behind the curtain.'),
('The final joke depends on the tiny hat falling off. Make sure it ', 'is loose enough to drop.'),
('We need a quiet place to put unused puppets. The padded basket ', 'will stop them from rattling.')])
FAMILY('entertainment','record_listening','Listening evening',
       'Notes\nListening journal\nNew note\nSearch folders\nAttachment options\nParagraph format\nSaved locally\nText area',[
('The second side of the record has a quieter mood. I noticed ', 'the bass line more clearly.'),
('There was a little crackle before the first song. It disappeared ', 'once the music began.'),
('I liked the piano part near the end. It gave the song ', 'a gentle sense of closure.'),
('The singer left long pauses between phrases. Those gaps made ', 'the words feel more deliberate.'),
('We listened to the whole album without skipping tracks. The sequence felt ', 'carefully planned from start to finish.')])
FAMILY('entertainment','outdoor_concert','Garden concert',
       'Garden stage\nDoors 18:00, music 19:00\nLow chairs allowed; tall folding chairs at the rear\nNo glass containers\nWater refill station beside the ticket desk.',[
('The music begins an hour after the doors open. We have time ', 'to find a comfortable spot.'),
('We are taking low chairs to the garden concert. The taller chairs must stay ', 'at the back of the audience.'),
('Glass bottles are not allowed inside the venue. I will bring ', 'a reusable plastic water bottle.'),
('There is a refill station by the ticket desk. We can top up ', 'our water when we arrive.'),
('The stage faces the lawn. Let us choose somewhere ', 'with a clear view of the musicians.')])
FAMILY('entertainment','mystery_book','Mystery discussion',
       'Bus service notice\nRoute 28 diversion\nThe market stop is temporarily closed. Use the next stop beside the pharmacy. Normal service resumes after road resurfacing.',[
('The detective notices the missing key early in the story. That small detail ', 'becomes important in the final chapter.'),
('I suspected the gardener because of the muddy coat. The author had planted ', 'a very convincing false clue.'),
('The ending surprised me without feeling unfair. Looking back, the clues ', 'were there all along.'),
('I have not finished the last three chapters yet. Please do not tell me ', 'who took the missing necklace.'),
('The village setting makes everyone seem connected. Even the minor characters ', 'have reasons to hide something.')])
FAMILY('entertainment','improv_rehearsal','Improvisation practice',
       'Session notes\nRecently edited\nLocal storage\nSearch this page\nAdd checklist\nShow attachments\nParagraph tools\nText input',[
('The scene slowed down when we kept rejecting each other’s ideas. We should practice ', 'building on what is offered.'),
('I forgot the name we gave the imaginary shopkeeper. Next time I will ', 'repeat it early in the scene.'),
('The audience laughed when the chair became a tiny spaceship. We can trust ', 'simple physical choices more often.'),
('We started the exercise without choosing a location. That made it harder ', 'to agree on the setting.'),
('The scene already had a clear ending after the phone call. We should stop ', 'while that moment still lands.')])
FAMILY('entertainment','festival_workshop','Animation workshop',
       'Festival workshop\nStop motion with paper figures\nSessions last forty minutes\nParticipants share tablets in pairs\nFinished clips can be exported at the end\nNo experience required.',[
('The workshop uses paper figures for stop motion. We will move them ', 'a little between each photograph.'),
('Everyone shares a tablet with one partner. We can take turns ', 'moving figures and capturing frames.'),
('The session lasts only forty minutes. We should keep ', 'our story very simple.'),
('We can export the finished clip before leaving. I will save ', 'a copy to my device.'),
('No animation experience is needed for the workshop. The first few minutes should ', 'cover the basic technique.')])
FAMILY('entertainment','costume_fix','Costume repair',
       'Seed swap\nPackets arranged by growing season\nPlease write the collection year on each envelope. The tomato table is near the window; herbs are by the entrance.',[
('The jacket button came loose during rehearsal. I need to sew it ', 'back on before the performance.'),
('The cape is catching on the actor’s shoes. We should shorten ', 'the hem by a few inches.'),
('The hat looks too plain under the stage lights. A narrow ribbon ', 'might give it more definition.'),
('We have two identical coats for the quick change. Please label them ', 'inside the collar to avoid confusion.'),
('The repaired seam feels stiff against the shoulder. I will cover it ', 'with a strip of soft fabric.')])
FAMILY('entertainment','comedy_review','Comedy night review',
       'Draft review\nSpelling suggestions\nWord count\nSaved changes\nDocument outline\nAttachment controls\nFind text\nReview field',[
('The opening act took a while to settle into the room. By the third story, ', 'the audience was laughing freely.'),
('The strongest joke returned to a detail from the beginning. That callback gave ', 'the set a satisfying shape.'),
('A long interruption broke the rhythm halfway through. The comedian recovered ', 'with a quick improvised reply.'),
('Some jokes were difficult to hear from the back row. The sound system ', 'needed a little more volume.'),
('The final routine was short and sharply timed. It left the audience ', 'wanting another few minutes.')])
FAMILY('entertainment','board_rules','Learning a board game',
       'Meadow Paths quick reference\nEach turn: place one tile, then move one marker\nPaths cannot cross rivers without bridges\nThe final round begins when the tile bag is empty.',[
('We place a tile before moving a marker. I had been doing those steps ', 'in the wrong order.'),
('A path cannot cross the river by itself. We need to draw ', 'a tile with a bridge.'),
('The tile bag is almost empty now. We are getting close ', 'to the final round.'),
('I will keep the quick reference beside the board. That should help us ', 'remember the order of a turn.'),
('My marker is blocked by the river. I need to build ', 'a route toward the nearest bridge.')])
FAMILY('entertainment','museum_audio','Audio guide notes',
       'Apartment maintenance\nLift inspection Tuesday 09:00–11:00\nPlease use the stairs during testing. Parcel deliveries will be held at the reception desk until service resumes.',[
('The audio guide described a detail I had missed in the painting. I went back ', 'to look at the background.'),
('The recording moved on before I finished studying the sculpture. I paused it ', 'for a few extra minutes.'),
('The gallery was quiet enough to hear without high volume. I kept one ear ', 'free for the room around me.'),
('The guide included a short recording of the artist. Hearing that voice ', 'made the explanation feel more personal.'),
('I liked choosing the order of the audio stops. It let me follow ', 'whatever caught my attention first.')])
FAMILY('entertainment','choir_balance','Choir rehearsal notes',
       'Rehearsal notebook\nAll notes\nSearch\nNew section\nTable options\nAttachment list\nLast edited today\nBody text area',[
('The melody was hidden by the lower voices in the first verse. We should sing ', 'more softly beneath that line.'),
('We kept arriving at the final consonant at different times. The conductor asked us ', 'to watch for the cutoff.'),
('The room made every long note sound louder. We needed less effort ', 'than in the rehearsal hall.'),
('The tenors have a difficult entrance after the pause. The piano can give ', 'a quiet note before they begin.'),
('The last chord sounded clearer after we changed positions. Everyone could hear ', 'the neighboring voices more easily.')])
FAMILY('entertainment','film_subtitles','Subtitled film night',
       'Screening room\nOriginal language with English subtitles\nDoors open 17:30\nFilm duration 108 minutes\nSubtitles appear near the lower edge\nFront row has a steep viewing angle.',[
('The film uses subtitles near the bottom of the screen. We should avoid seats ', 'too close to the front.'),
('The running time is a little under two hours. We could get dinner ', 'after the screening finishes.'),
('Doors open well before the film begins. Let us arrive early ', 'to choose seats together.'),
('I prefer hearing the actors’ original voices. This subtitled showing ', 'sounds like a good choice.'),
('The front row has a steep viewing angle. A seat farther back ', 'should be easier on our necks.')])
FAMILY('entertainment','magic_practice','Card trick practice',
       'Garden centre stock\nClay pots on the lower shelf\nPeat free compost beside the outdoor register\nDelivery slots available for large planters\nPlease ask before moving display trees.',[
('The card slipped when I turned the packet over. I need to practice ', 'that movement more slowly.'),
('The explanation is giving away too much before the reveal. I should keep ', 'the opening story much shorter.'),
('My hand covered the chosen card at the wrong moment. The audience needs ', 'a clear view of it.'),
('The trick worked better when I stopped rushing. A small pause made ', 'the final reveal more convincing.'),
('I used a fresh deck for the rehearsal. The cards were ', 'a little too slippery at first.')])
FAMILY('entertainment','radio_drama','Radio drama recording',
       'Recording notes\nDocument tools\nAdd comment\nSearch in draft\nPage thumbnail\nParagraph style\nLocal changes saved\nScript editor',[
('The footsteps sounded like tapping on a table. We need a surface ', 'that resembles a wooden floor.'),
('The actor moved away from the microphone during the quiet line. The recording lost ', 'some of the final words.'),
('The door sound arrived before the character reached it. We should shift ', 'that effect a little later.'),
('The scene depends on a long uncomfortable silence. We should leave ', 'enough room for that pause.'),
('Two characters sound too similar in the opening exchange. Different speaking rhythms ', 'might help listeners tell them apart.')])
FAMILY('entertainment','dance_lesson','Dance class reminder',
       'Beginner dance session\nSoft indoor shoes recommended\nPartner changes optional\nClass starts with a fifteen minute warm-up\nWater breaks between sections\nMirrored studio on the first floor.',[
('The class begins with a fifteen minute warm-up. I want to arrive ', 'before that part starts.'),
('We should bring soft shoes for the studio. Outdoor soles might ', 'mark the dance floor.'),
('Partner changes are optional during the lesson. We can stay together ', 'while we learn the steps.'),
('There will be breaks between sections. I will bring water ', 'to drink during those pauses.'),
('The mirrored studio is on the first floor. We should look ', 'upstairs when we enter.')])
FAMILY('entertainment','comic_layout','Comic page planning',
       'Community kitchen\nLunch collection from 12:15\nContainers must have secure lids. Vegetarian portions are on the left. Please return borrowed trays before Friday.',[
('The first panel contains too much dialogue. I could split it ', 'across two smaller panels.'),
('The reader should notice the hidden cat before the character does. I will place it ', 'near the edge of the frame.'),
('The action moves from left to right on this page. Reversing that direction now ', 'might confuse the reader.'),
('The final panel needs more empty space around the figure. That would make ', 'the quiet moment feel longer.'),
('The speech balloon overlaps the character’s expression. I need to move it ', 'higher without covering the drawing.')])
FAMILY('entertainment','puzzle_evening','Jigsaw progress',
       'Evening notes\nList view\nSort by title\nRecently updated\nSearch\nDocument options\nSave status\nText insertion point',[
('We finished the border of the puzzle first. The middle still has ', 'a large patch of empty space.'),
('All the sky pieces look almost identical. I started sorting them ', 'by the shape of their edges.'),
('One piece has been hiding under the box lid. It belongs ', 'near the top left corner.'),
('The picture on the lid is too small to show that detail. We need to compare ', 'the colors on the pieces themselves.'),
('The table is needed for dinner soon. We can slide the puzzle ', 'onto the large cardboard sheet.')])
FAMILY('entertainment','open_mic','Open microphone signup',
       'Acoustic open mic\nFive minute sets\nSign-up closes at 19:15\nHouse guitar available\nPlease tell the host if you need a stool\nOne microphone and a small amplifier provided.',[
('Each performer gets five minutes at the open mic. I should choose ', 'one short song to play.'),
('There is a house guitar available tonight. I do not need ', 'to carry my own across town.'),
('The host asks performers to request a stool in advance. I will mention ', 'that I prefer to sit.'),
('Sign-up closes at a quarter past seven. We should get there ', 'before the list is full.'),
('Only one microphone is provided for each set. Our arrangement will need ', 'to work with that setup.')])
FAMILY('entertainment','ballet_reflection','Performance reflection',
       'Waterfront clean-up\nMeet beside the old boathouse\nGloves and bags supplied\nPlease wear closed shoes. Volunteers will sort collected material at the end of the morning.',[
('The dancers crossed the stage in a slow diagonal line. It drew my attention ', 'toward the figure at the back.'),
('The music stopped while the movement continued. That sudden silence made ', 'the next landing feel heavier.'),
('The costumes changed color under the blue lighting. White fabric became ', 'a pale shade of silver.'),
('The duet repeated the same gesture near the end. This time it felt ', 'more like an invitation than a refusal.'),
('I could not follow every part of the story. The movement still conveyed ', 'a strong sense of loss.')])
FAMILY('entertainment','playlist_order','Playlist sequencing',
       'Playlist notes\nDraft saved\nRecent documents\nFind text\nShow sidebar\nInsert list\nFormatting menu\nEditing area',[
('The transition between those two songs feels abrupt. I need something ', 'with a slower opening beat.'),
('I want the playlist to begin gently. The loudest track should come ', 'a little later in the sequence.'),
('We have three songs by the same artist in a row. I will spread them ', 'through the rest of the playlist.'),
('The last song fades out very slowly. It could make ', 'a good ending for the evening.'),
('The playlist is longer than the train journey. I can remove ', 'a few of the repeated tracks.')])

# Work: ordinary collaborative writing with invented projects and organizations.
FAMILY('work','agenda_trim','Planning meeting',
       'Meeting preparation\nBudget update 10 min\nLaunch checklist 20 min\nOpen questions 10 min\nRoom booking ends at 11:00\nDesign review moved to a separate session.',[
('The room booking ends at eleven. We need to keep ', 'the discussion within forty minutes.'),
('The launch checklist is the longest agenda item. Let us reserve ', 'twenty minutes for that discussion.'),
('The design review has its own meeting now. I will remove it ', 'from the planning agenda.'),
('We should cover the budget before the launch checklist. That order will make ', 'the resource limits clear early.'),
('We have ten minutes left for open questions. Please send detailed topics ', 'before the meeting if possible.')])
FAMILY('work','handover_leave','Leave handover',
       'Birdwatching society\nDawn walk on Sunday\nBring binoculars and waterproof footwear. The reserve gate opens at 06:30. A volunteer will wait beside the visitor map.',[
('I will be away for the next three working days. The handover note includes ', 'the status of each open task.'),
('The weekly report is ready except for one figure. Please add it ', 'when the finance team replies.'),
('I have set up a shared folder for the handover. All the current files are ', 'linked from the first page.'),
('The client may ask about the revised delivery date. The latest agreement is ', 'in the email from Tuesday.'),
('Nothing urgent is expected while I am away. If something changes, contact ', 'the person listed beside that task.')])
FAMILY('work','invoice_query','Invoice clarification',
       'Mail\nDrafts\nTo\nSubject\nAttachment menu\nSaved draft\nFormatting controls\nMessage body\nSend later options',[
('Thank you for sending the invoice. Could you clarify ', 'the extra delivery charge?'),
('The invoice lists two visits on the same date. Our records show ', 'only one scheduled appointment.'),
('I have attached the original purchase order. Please check ', 'the quantity against that document.'),
('The billing address has changed since our last order. I have included ', 'the updated details below.'),
('The current invoice needs one small change. Once the corrected invoice arrives, I can pass it ', 'to our accounts team.')])
FAMILY('work','workshop_access','Workshop arrangements',
       'Staff workshop\nRoom: East Hall\nStep-free entrance on Oak Street\nLive captions available\nMaterials in large print by request\nLunch served in the adjacent foyer.',[
('The workshop uses the East Hall this year. The step-free entrance is ', 'on Oak Street beside the hall.'),
('Live captions will be available during the presentations. I will include that ', 'in the joining instructions.'),
('Large print materials can be prepared in advance. Please let us know ', 'if you would like a copy.'),
('Lunch will be served in the adjacent foyer. Attendees will not need ', 'to leave the building.'),
('The access information should appear near the top of the invitation. That makes it ', 'easier for attendees to find.')])
FAMILY('work','feedback_draft','Draft feedback',
       'Weekend market\nLocal honey and seasonal fruit\nThe craft stalls have moved under the covered walkway. Card payments accepted at most stalls. Dogs welcome on leads.',[
('The opening paragraph explains the problem clearly. The next section would benefit from ', 'a concrete example of the impact.'),
('Several headings use different terms for the same process. We should choose ', 'one term and use it consistently.'),
('The table is useful but difficult to scan quickly. Could we move ', 'the main totals to the top?'),
('The recommendation arrives quite late in the document. I suggest stating it ', 'before the supporting detail.'),
('I left comments beside the two unclear figures. Everything else looks ', 'ready for the next review.')])
FAMILY('work','deadline_shift','Revised schedule',
       'Project notes\nCurrent draft\nLast saved today\nDocument outline\nComments\nFind in note\nText styles\nBody editor',[
('The supplier needs an extra day to finish the samples. We should move ', 'the review to Thursday afternoon.'),
('The revised schedule leaves less time for proofreading. I will ask ', 'someone to review the draft early.'),
('The delivery date has changed but the scope is the same. Please update ', 'the calendar and the status note.'),
('We can still finish on time if approval arrives tomorrow. Otherwise we will need ', 'to adjust the release date.'),
('I want to flag the delay before it surprises anyone. The main reason is ', 'a dependency outside our team.')])
FAMILY('work','onboarding_kit','New starter welcome',
       'New starter checklist\nBadge collection at reception\nLaptop pickup from IT desk\nTeam introduction at 10:30\nBuddy lunch at 12:15\nBuilding tour follows lunch.',[
('Please collect your badge from reception when you arrive. After that, head ', 'to the IT desk for your laptop.'),
('The team introduction begins at half past ten. I will meet you ', 'just before that session starts.'),
('Your buddy has arranged lunch at a quarter past twelve. The building tour ', 'will follow after lunch.'),
('There is a gap between laptop collection and the introduction. We can use it ', 'to check your account access.'),
('Your first morning is mostly about getting settled. There will be time ', 'to ask questions throughout the day.')])
FAMILY('work','room_conflict','Room booking conflict',
       'Cooking club\nAutumn menu planning\nSoup recipes are on the shared board. Bring a container for leftovers. The next gathering includes a bread shaping demonstration.',[
('The training room is double booked on Wednesday. I am looking for ', 'another space with a projector.'),
('Our meeting only needs four chairs and a screen. The smaller room ', 'should work just as well.'),
('The other group has already invited external guests. We can move ', 'our internal meeting more easily.'),
('I have updated the room in the calendar invitation. Please use ', 'the new location shown there.'),
('The available room is on a different floor. I will put ', 'a sign outside the original room.')])
FAMILY('work','survey_summary','Staff survey summary',
       'Summary draft\nMail folders\nRecipient list\nSubject field\nSaved draft\nAttachment picker\nFormat text\nMessage composition',[
('The survey received fewer responses than we expected. We should be cautious ', 'about treating it as representative.'),
('Several comments mention the same scheduling problem. I have grouped them ', 'under a single theme.'),
('The chart shows counts rather than percentages. That makes the small sample ', 'easier to interpret honestly.'),
('We removed identifying details from the quoted comments. The summary should focus ', 'on patterns across the responses.'),
('The results suggest a useful topic for discussion. They do not establish ', 'a single explanation for the problem.')])
FAMILY('work','print_order','Printed guide order',
       'Print estimate\nEighty copies, forty pages each\nRecycled uncoated paper\nStapled binding\nProof required before production\nCollection available two business days after approval.',[
('The printer needs approval of the proof before production. I will check ', 'the page order and margins.'),
('We ordered eighty copies of the guide. Each copy will have ', 'forty pages with stapled binding.'),
('The paper is recycled and uncoated. The colors may appear ', 'softer than on a screen.'),
('Collection is available two business days after approval. Our timetable needs ', 'to allow for that gap.'),
('Please send any final corrections before I approve the proof. Changes afterward could ', 'delay the print order.')])
FAMILY('work','supplier_choice','Supplier comparison',
       'Astronomy club\nObserving evening at the sports field\nCloud cover will determine the programme. Bring a red torch if possible. Equipment must stay clear of the marked path.',[
('The lowest quote excludes setup and delivery. We should compare ', 'the full cost of each option.'),
('One supplier can meet the date but offers fewer sizes. The choice depends on ', 'which requirement matters most.'),
('The samples differ in texture more than color. I suggest checking them ', 'under the same lighting.'),
('We should document why we chose the supplier. That will help ', 'when the contract is reviewed.'),
('The comparison sheet is missing the warranty terms. I will ask ', 'each supplier for that information.')])
FAMILY('work','weekly_update','Weekly progress note',
       'Mail\nNew message\nDraft saved\nRecipient fields\nSubject\nText format\nAttach file\nMessage editor\nSignature menu',[
('This week we completed the first round of interviews. Next week we will ', 'compare notes and identify themes.'),
('The main risk remains the delayed equipment shipment. We are checking ', 'the delivery status each morning.'),
('Two tasks are waiting for approval from another team. I have listed ', 'the owners and next steps below.'),
('The draft is ready for internal review. Please add comments ', 'by the end of Wednesday.'),
('There are no changes to the budget this week. The current estimate ', 'still matches the agreed plan.')])
FAMILY('work','event_signage','Conference signs',
       'Event floor plan\nRegistration in main lobby\nBreakout A upstairs\nBreakout B beside courtyard\nQuiet room opposite reception\nDirectional signs must leave exit notices visible.',[
('Registration is in the main lobby. We should put the first sign ', 'just inside the entrance.'),
('Breakout A is upstairs and Breakout B is by the courtyard. The signs need ', 'clear arrows toward both rooms.'),
('The quiet room is opposite reception. I will add it ', 'to the attendee information sheet.'),
('The temporary signs must not cover exit notices. We need to check ', 'their placement before doors open.'),
('People may arrive while the opening session is underway. A sign at registration ', 'should direct late arrivals to the room.')])
FAMILY('work','archive_cleanup','Shared folder cleanup',
       'Plant care workshop\nRepotting demonstration\nBring a small houseplant if you wish. Potting mats are provided. The tutor will discuss drainage and root growth before the practical session.',[
('The shared folder contains several files named final. We should rename them ', 'to make the current version clear.'),
('The old drafts may still explain past decisions. I will move them ', 'into a clearly labeled archive.'),
('Some links point to documents that no longer exist. We need to repair ', 'those references before sharing the folder.'),
('The cleanup should not remove anyone’s active work. I will check ', 'with the listed document owners first.'),
('A short readme could explain the folder structure. That would help new colleagues ', 'find the right files quickly.')])
FAMILY('work','customer_followup','Follow-up after demo',
       'Draft email\nTo\nCc\nSubject\nSaved in Drafts\nInsert link\nAttachments\nFormatting tools\nBody of message',[
('Thank you for taking the time to join the demonstration. I have attached ', 'the notes from our discussion.'),
('You asked whether the report can be exported. I will confirm ', 'the available formats with our team.'),
('We did not cover the scheduling feature during the call. I can send ', 'a short example of that workflow.'),
('The next step is to test the sample with your data. Please let us know ', 'which date would suit you.'),
('I have summarized the open questions below. Feel free to add ', 'anything we may have missed.')])
FAMILY('work','shift_swap','Shift cover request',
       'Front desk rota\nThursday afternoon: two staff required\nFriday morning: training overlap\nShift changes need the coordinator copied\nKey handover recorded in the desk log.',[
('I can cover Thursday afternoon if someone takes my Friday morning. Please copy ', 'the coordinator into the reply.'),
('Thursday afternoon needs two people at the desk. We should check ', 'that the swap preserves that coverage.'),
('There is a training overlap on Friday morning. That may make ', 'the handover easier to arrange.'),
('The desk keys must be signed over in the log. I will record ', 'the handover when the shift changes.'),
('The request is ready for approval. Once the coordinator confirms the swap, I will update ', 'the rota with both names.')])
FAMILY('work','training_notes','Training recap',
       'Neighborhood cinema\nClassic film double bill\nAn interval follows the first screening. Refreshments are sold in the foyer. Please keep the side aisle clear for late arrivals.',[
('The training covered more features than we can remember at once. I made ', 'a short reference sheet for the team.'),
('The practice exercise helped explain the new process. We should include ', 'a similar example in the guide.'),
('Several people asked the same question during the session. I will add ', 'that answer to the notes.'),
('The recording is useful but quite long. A list of timestamps would ', 'make the key sections easier to find.'),
('We should check whether people can apply the process next week. A brief follow-up ', 'would show where more help is needed.')])
FAMILY('work','proposal_scope','Proposal boundaries',
       'Proposal notes\nOutline\nComments\nSaved on this Mac\nInsert table\nParagraph tools\nSearch document\nText editor',[
('The proposal includes the initial setup and one training session. Ongoing support would need ', 'a separate agreement after launch.'),
('The request has grown since our first discussion. We should confirm ', 'which items belong in this phase.'),
('The current budget cannot cover every suggested feature. We need to prioritize ', 'the parts with the clearest value.'),
('The timeline assumes that source material arrives next Monday. Any delay would affect ', 'the date of the first review.'),
('The scope section should make responsibilities explicit. I will list ', 'what each team is expected to provide.')])
FAMILY('work','stock_count','Office supply count',
       'Supply check\nPrinter paper: six sealed packs\nBlack pens: twelve\nShipping labels: one partial roll\nReorder labels before the monthly mailing\nStorage cupboard beside the copy room.',[
('We have six sealed packs of printer paper. There is no need ', 'to order more this week.'),
('The shipping labels are down to one partial roll. We should reorder ', 'before the monthly mailing begins.'),
('There are twelve black pens in the cupboard. I will note that ', 'on the supply count sheet.'),
('The stock is stored beside the copy room. Please return unused supplies ', 'to that cupboard after the event.'),
('The mailing uses more labels than a normal week. I will make sure ', 'the new roll arrives in time.')])
FAMILY('work','interview_panel','Interview panel notes',
       'Local history society\nMap exhibition\nThe oldest town plan is displayed in the reading room. Volunteers can explain the street name changes. Admission includes a folded walking map.',[
('We should ask every candidate the same core questions. That will make ', 'the answers easier to compare fairly.'),
('The panel needs time to take notes between interviews. I suggest leaving ', 'a short gap in the schedule.'),
('Our notes should describe evidence from the answers. Avoid comments based only on ', 'a vague first impression.'),
('The candidate asked for the question to be repeated. I read it again ', 'without changing the original wording.'),
('We should discuss scores after each panel member has recorded them. This reduces ', 'the influence of the first opinion.')])

# Technology: generic invented troubleshooting and design scenarios.
FAMILY('technology','offline_sync','Offline edits',
       'Notes\nLocal notebook\nSort by date\nSearch\nAttach file\nShow folders\nText format\nAll edits saved on this device\nBody field',[
('The notes were edited while the laptop was offline. They should synchronize ', 'when the connection returns.'),
('Two devices changed the same paragraph before syncing. The app needs ', 'a way to resolve the conflict.'),
('The local copy contains a newer revision than the server. We should avoid ', 'replacing it without a check.'),
('A sync failure should not erase the unsent changes. The application must keep ', 'a durable copy on the device.'),
('The status indicator still says waiting after the network reconnects. I will check ', 'whether the retry was scheduled.')])
FAMILY('technology','usb_hub','Desk connection issue',
       'Device checklist\nMonitor works when connected directly\nKeyboard works through hub\nExternal drive disconnects under load\nHub has no separate power supply\nCable length: one meter.',[
('The drive disconnects only when it is busy. The unpowered hub may not provide ', 'enough power for the device.'),
('The monitor works when connected directly to the laptop. That narrows the problem ', 'to the hub or its connection.'),
('The keyboard still works through the hub. The failure does not affect ', 'every connected device in the same way.'),
('I will test the drive with a direct connection. That should help ', 'isolate the hub from the problem.'),
('A powered hub would be a useful comparison. It could show whether ', 'the available power is the limiting factor.')])
FAMILY('technology','search_index','Search indexing',
       'Weekend craft market\nHandmade notebooks in the east aisle\nDemonstrations begin on the hour. The cafe accepts reusable cups. Lost items can be collected at the information desk.',[
('The document exists but does not appear in search yet. The index may still be ', 'catching up with recent changes.'),
('The search index stores references to the original documents. Deleting an entry there should not ', 'delete the source file itself.'),
('A renamed file still appears under its old title. We need to update ', 'the indexed metadata after a rename.'),
('The results include documents the user cannot open. Permission checks should happen ', 'before those results are displayed.'),
('The search query is short and ambiguous. We can improve the results ', 'by including the current folder context.')])
FAMILY('technology','backup_restore','Backup verification',
       'Draft technical note\nOutline view\nRecent documents\nInsert checklist\nSaved locally\nFormatting controls\nText area\nSearch note',[
('The backup completed without reporting an error. We still need to test ', 'whether the files can be restored.'),
('A copy on the same disk does not protect against disk failure. We need ', 'a backup on separate storage.'),
('The restore test should use a temporary folder. That avoids replacing ', 'the current working files by accident.'),
('The oldest backup no longer includes the deleted folder. We should check ', 'the retention settings before relying on it.'),
('A readable file is more useful than a reassuring status message. I will open ', 'a sample from the restored backup.')])
FAMILY('technology','notification_grouping','Notification design',
       'Prototype feedback\nOne alert per uploaded file caused interruptions\nBatch completed in under one minute\nUsers preferred a single summary\nFailures should remain individually visible.',[
('Showing an alert for every file interrupted the workflow. We should combine ', 'successful uploads into one summary.'),
('The batch usually completes in less than a minute. A final summary would give ', 'enough feedback without repeated interruptions.'),
('Failed uploads need more specific attention than successful ones. Each failure should remain ', 'easy to inspect on its own.'),
('The summary can show how many files finished successfully. It should also link ', 'to any items that failed.'),
('The feedback suggests that timing matters as much as wording. We should wait ', 'until the batch has settled.')])
FAMILY('technology','keyboard_layout','Keyboard mismatch',
       'Walking route bulletin\nThe western footbridge is open again. Marsh paths remain muddy after heavy rain. Please use the raised boardwalk near the nesting area.',[
('The key labels do not match the characters appearing on screen. The selected keyboard layout ', 'may be different from the physical keyboard.'),
('The shortcut works on one keyboard but not the other. We should check ', 'which modifier keys are being reported.'),
('An external keyboard was connected just before the problem began. I will compare ', 'the input settings for both devices.'),
('Only the punctuation keys are producing unexpected characters. That pattern points toward ', 'a layout mismatch rather than broken keys.'),
('The application should show the shortcut using the current layout. Hardcoded key labels could ', 'confuse people using another keyboard.')])
FAMILY('technology','loading_state','Loading feedback',
       'Design draft\nLocal edits\nComment sidebar\nSearch this page\nInsert sketch\nText styles\nSaved status\nEditing canvas',[
('The button can be pressed again while the request is running. We should disable it ', 'until the operation finishes.'),
('The spinner appears immediately even for very fast responses. A short delay could ', 'reduce unnecessary visual flicker.'),
('The loading message does not explain what is happening. We can name ', 'the operation currently in progress.'),
('If the request fails, the screen should offer a retry. It should also preserve ', 'the information already entered.'),
('A progress bar would imply a measurable amount of work. If we cannot estimate that, ', 'a simple activity indicator is clearer.')])
FAMILY('technology','image_export','Image export settings',
       'Export preview\nSource image 2400 × 1600\nOutput width 1200\nMaintain aspect ratio enabled\nTransparent background available only for selected formats\nEstimated file size updates after selection.',[
('The original image is twice as wide as the selected output. Keeping the aspect ratio gives ', 'a height of eight hundred pixels.'),
('The background needs to remain transparent after export. We should choose ', 'a format that supports transparency.'),
('The preview estimates the file size after each setting changes. We can use that ', 'to balance quality and download size.'),
('The aspect ratio option is enabled. Resizing the width should also ', 'adjust the height automatically.'),
('The exported image is intended for a smaller display. There is no need ', 'to keep the full source dimensions.')])
FAMILY('technology','password_manager','Credential entry flow',
       'Community orchestra\nRehearsal room change\nWoodwinds meet in Room D before the full session. Please bring the revised score pages. Instrument cases must stay clear of the doorway.',[
('The sign-in form prevents pasting into the password field. That makes it harder ', 'to use a password manager.'),
('The browser filled the username but skipped the password. We should check ', 'the form field attributes.'),
('The error message should not repeat the entered password. Sensitive values must stay ', 'out of diagnostic text.'),
('The user may have more than one account for this service. The form should let them ', 'choose a different saved login.'),
('The session expired while the user was writing. After sign-in, the app should restore ', 'the unfinished draft if possible.')])
FAMILY('technology','cache_invalidation','Cached document',
       'Technical notes\nNew page\nShared attachments\nDocument properties\nFind text\nLocal save status\nParagraph controls\nEditor',[
('The page still shows the old title after a successful edit. The cached copy ', 'may not have been invalidated.'),
('The cache key includes the document identifier but no revision. Different versions could ', 'be treated as the same result.'),
('Refreshing the entire cache after every change is expensive. We should invalidate ', 'only the entries affected by that change.'),
('A cached result should not outlive the permission that allowed it. Access changes need ', 'to clear the relevant stored data.'),
('The application works correctly after a restart. That suggests the stale value ', 'is being kept in memory.')])
FAMILY('technology','wifi_placement','Wireless coverage',
       'Home network notes\nRouter inside metal cabinet\nStrong signal in hallway\nWeak signal in back room\nWired connection stable\nMoving the router onto a shelf improved the test reading.',[
('The wired connection is stable while wireless coverage varies. The problem appears ', 'related to signal strength or interference.'),
('The router was inside a metal cabinet. Moving it out could ', 'reduce obstruction of the wireless signal.'),
('The back room has a weaker signal than the hallway. We should test ', 'a more central router position.'),
('The shelf position improved the signal during testing. I will repeat ', 'the measurement at several times of day.'),
('Changing the router position is easy to reverse. It is a useful first step ', 'before buying additional network equipment.')])
FAMILY('technology','file_naming','Export file names',
       'Library exhibition\nHandmade maps and travel diaries\nDisplay cases close fifteen minutes before the reading room. Photography is allowed without flash. Pencils are available at the desk.',[
('Two exports used the same filename and one replaced the other. The naming scheme needs ', 'a way to distinguish repeated exports.'),
('The date in the filename uses slashes on some systems. We should choose ', 'characters that are safe across platforms.'),
('A long title creates an unreadable filename. We can shorten it ', 'while keeping the identifying part.'),
('The export should warn before replacing an existing file. Silent replacement could ', 'destroy work the user intended to keep.'),
('The file extension should match the selected format. Otherwise other applications may ', 'open it with the wrong handler.')])
FAMILY('technology','accessibility_labels','Interface labels',
       'Review document\nComment count\nSaved changes\nFind in page\nInsert screenshot\nOutline\nFormatting options\nText input area',[
('The icon button has no visible text or accessible label. A screen reader user cannot tell ', 'what action it performs.'),
('The label should describe the action rather than the icon shape. That gives people ', 'the information they need to act.'),
('The form reports an error only by changing the border color. We should add ', 'a clear message beside the field.'),
('Keyboard focus disappears when the dialog closes. It should return ', 'to the control that opened the dialog.'),
('The reading order differs from the visual order. We need to check ', 'how the controls are grouped.')])
FAMILY('technology','battery_usage','Battery observation',
       'Usage notes\nVideo call: high energy use\nScreen brightness near maximum\nBackground file transfer active\nBattery drains faster during calls\nNo unusual drain while sleeping.',[
('The battery drains fastest during video calls. The bright screen and active camera ', 'both contribute to the load.'),
('A background file transfer ran throughout the call. We should repeat the observation ', 'with that transfer paused.'),
('There is no unusual drain while the laptop sleeps. The issue seems tied ', 'to active use of the device.'),
('The display was near maximum brightness during the test. Lowering it may reduce ', 'one source of energy use.'),
('Several demanding activities happened at the same time. We need separate tests ', 'to understand their individual effects.')])
FAMILY('technology','version_notes','Release note draft',
       'Garden volunteer rota\nSaturday watering team\nThe hose connector is stored in the shed. Seed trays need shade after noon. Please log any damaged tools in the notebook.',[
('The release note describes an internal refactor without explaining the benefit. We should say ', 'what users will notice after updating.'),
('This fix prevents the editor from losing the selection. The note can describe ', 'that visible change in plain language.'),
('The feature is available only when an account is connected. We need to mention ', 'that requirement beside the description.'),
('The old wording implies that every crash is fixed. A more accurate sentence would ', 'name the specific problem addressed.'),
('We grouped all the small fixes under one heading. The most significant change should ', 'appear first in that list.')])
FAMILY('technology','database_migration','Local schema update',
       'Engineering note\nDraft\nSaved on device\nSearch document\nTable view\nComments hidden\nText formatting\nInsertion area',[
('The new version adds a column to the local database. Existing rows need ', 'a sensible value for that field.'),
('A migration may be interrupted if the app closes. It should leave ', 'the database in a recoverable state.'),
('We should test the upgrade using a copy of an older database. A fresh database ', 'does not exercise the migration path.'),
('The migration changes stored data before the main screen loads. Errors need ', 'to be handled before normal editing begins.'),
('The schema version is already current on this device. The migration should ', 'skip work that has already completed.')])
FAMILY('technology','display_scaling','External display text',
       'Display test\nLaptop screen clear\nExternal screen text appears soft\nNative panel resolution differs from selected output\nCable seated correctly\nScreenshots look sharp on the laptop.',[
('Screenshots look sharp on the laptop but soft on the external display. The issue may involve ', 'the selected resolution or scaling.'),
('The selected output differs from the panel’s native resolution. That can make text ', 'look less crisp after scaling.'),
('The cable is already seated correctly. I will check ', 'the display settings next.'),
('The laptop screen renders the same text clearly. That gives us ', 'a useful comparison for the external screen.'),
('We should change one display setting at a time. Otherwise it will be hard ', 'to identify which change helped.')])
FAMILY('technology','undo_stack','Undo behavior',
       'Pottery studio\nOpen practice hours\nPlease clean the wheel after use. Damp work should be covered before leaving. Finished pieces are collected from the numbered shelf.',[
('Typing one word creates too many separate undo steps. We should group ', 'related edits into a single action.'),
('Undo restored the text but left the cursor in the wrong place. The saved state must include ', 'the selection as well as the content.'),
('A new edit after undo should discard the old redo branch. Otherwise redo could restore ', 'a change that no longer fits.'),
('The user expects one undo action to reverse the paste. Splitting it into many steps ', 'would make recovery unnecessarily tedious.'),
('The document closes while its undo history is still referenced. We need to ensure ', 'those objects are released together.')])
FAMILY('technology','error_retry','Network retry logic',
       'Design notebook\nRecent files\nSearch\nAdd page\nLocal save indicator\nDocument outline\nText formatting menu\nEditor focus',[
('The request failed because the connection briefly dropped. A retry may succeed ', 'once the network is available again.'),
('Repeated retries without a pause create unnecessary traffic. We should increase ', 'the delay between consecutive attempts.'),
('A canceled request should not restart itself later. Cancellation needs to stop ', 'the pending retry as well.'),
('The server rejected the request because a required field was missing. Retrying unchanged data ', 'will not resolve that error.'),
('Submitting the same operation twice could create duplicate records. The retry design needs ', 'a way to recognize repeated submissions.')])
FAMILY('technology','permissions_prompt','Camera permission flow',
       'Prototype notes\nCamera requested only when joining video\nPreview screen explains the need\nAudio-only join remains available\nDenied permission can be changed in system settings\nNo request at launch.',[
('The camera is needed only when joining with video. We should request access ', 'at that point in the flow.'),
('The preview screen explains why camera access is needed. That gives the prompt ', 'a clear and immediate context.'),
('Someone who declines camera access can still join with audio. The interface should keep ', 'that option easy to find.'),
('Permission was denied during an earlier attempt. We can explain ', 'where to change it in system settings.'),
('The application does not use the camera at launch. Asking then would provide ', 'little context for the request.')])

# Everyday: small household, neighborhood, and personal organization situations.
FAMILY('everyday','laundry_drying','Laundry day',
       'Neighborhood film society\nShort films on Thursday\nThe screening room opens at 18:40. Please return borrowed cushions to the shelf. Programme notes are available beside the entrance.',[
('The towels are still damp after the short drying cycle. I will hang them ', 'over the rack for another hour.'),
('The red shirt is new and may lose some dye. I should wash it ', 'separately from the pale clothes.'),
('One sock is missing from the clean laundry. It might still be ', 'inside the fitted sheet.'),
('The drying rack blocks the cupboard door. I can move it ', 'closer to the window.'),
('I folded the clothes while they were still warm. That helped smooth ', 'some of the deeper creases.')])
FAMILY('everyday','grocery_substitution','Shopping list change',
       'Notes\nShopping list\nChecked items hidden\nNew checklist\nSearch all notes\nSaved on device\nAttachment button\nText entry',[
('The shop had no fresh spinach left. I bought ', 'a bag of frozen spinach instead.'),
('We already have two jars of mustard at home. Please take it ', 'off the shopping list.'),
('The recipe needs plain yogurt, not the sweetened kind. I will check ', 'the label before buying it.'),
('The large bag is cheaper per kilo, but we may not use it all. The smaller pack ', 'could still be the better choice.'),
('I am taking the bus home with the groceries. I will leave ', 'the heavy bottles for another trip.')])
FAMILY('everyday','shelf_assembly','New bookcase',
       'Assembly sheet\nLay panels on a soft surface\nShort screws for the back panel\nLong screws for side joints\nAttach wall restraint after leveling\nTwo people recommended for lifting.',[
('The side joints use the longer screws. I will sort them ', 'before starting the assembly.'),
('The panels could scratch the floor while we work. Let us put ', 'a blanket underneath them.'),
('The bookcase should be level before attaching the restraint. We can adjust ', 'the feet while it is empty.'),
('The instructions recommend two people for lifting. I will wait ', 'until someone can help.'),
('The back panel uses the short screws. Using the long ones could ', 'push through the other side.')])
FAMILY('everyday','shoe_repair','Worn shoes',
       'Public garden\nHerb border tour\nMeet at the sundial at 14:00. The gravel paths may be uneven. A printed plant list is available from the volunteer guide.',[
('The sole has started separating near the toe. I will ask ', 'the repair shop to inspect it.'),
('The shoes are comfortable apart from one rough seam. A small patch inside ', 'might stop it from rubbing.'),
('The laces are fraying near the ends. I should replace them ', 'before one breaks completely.'),
('Mud dried into the grooves of the sole. I used a brush ', 'to clear it out gently.'),
('The leather feels stiff after getting wet. I will let the shoes dry ', 'away from direct heat.')])
FAMILY('everyday','meal_prep','Lunch preparation',
       'Kitchen notes\nRecent lists\nSort by edited date\nSearch\nInsert checklist\nShow attachments\nSaved locally\nNote body',[
('I cooked extra rice for tomorrow’s lunch. I will put it ', 'in a container once it cools.'),
('The salad dressing makes the leaves soggy overnight. I will pack it ', 'in a separate small jar.'),
('We have enough roasted vegetables for two meals. One portion can go ', 'into tomorrow’s lunch box.'),
('The soup is too thick after sitting overnight. A little water should ', 'bring it back to the right texture.'),
('I want lunches that are easy to carry. A container with a tight lid ', 'will help prevent spills in my bag.')])
FAMILY('everyday','recycling_sort','Recycling reminder',
       'Building waste room\nFlatten cardboard before placing it in the cage\nGlass collection in green bins\nFood scraps in sealed caddy liners\nBulky items require a booked collection\nKeep doorway clear.',[
('The cardboard cage fills up quickly. We should flatten ', 'the boxes before taking them downstairs.'),
('The broken chair is too large for the regular bins. We need to arrange ', 'a separate bulky item collection.'),
('The glass containers go in the green bins. I will carry them ', 'down in a sturdy bag.'),
('Someone left boxes in the waste room doorway. They need moving ', 'so people can enter safely.'),
('The food caddy liner is nearly full. I should seal it ', 'before carrying it to the waste room.')])
FAMILY('everyday','lost_keys','Searching for keys',
       'Community reading group\nNext title: The Orchard House\nDiscussion begins at 19:30. Copies can be borrowed from the main desk. New members are welcome to listen first.',[
('I remember holding my keys when I brought in the groceries. They may be ', 'on the kitchen counter.'),
('I checked the coat pockets twice already. Next I will look ', 'under the sofa cushions.'),
('The spare key is not on its usual hook. Did someone move it ', 'to the drawer by the door?'),
('I found the keys inside the shopping bag. They had slipped ', 'beneath the folded receipt.'),
('I keep misplacing the keys when I come home. A small bowl by the door ', 'might help me remember their place.')])
FAMILY('everyday','window_draft','Drafty window',
       'Home notes\nNew note\nSearch folders\nAttachment tools\nParagraph format\nLocal changes saved\nDocument list\nText editor',[
('There is a cold draft along the lower edge of the window. The seal may have ', 'pulled away from the frame.'),
('The curtain moves even when the window is shut. I will check ', 'whether the latch closes fully.'),
('I can hear more street noise than before. That might be related ', 'to the gap around the frame.'),
('The window sticks halfway through opening. I should clear ', 'the dirt from the track.'),
('The temporary strip stopped most of the draft. I still need ', 'to arrange a proper repair.')])
FAMILY('everyday','library_renewal','Borrowed books',
       'Library account\nTwo books due Friday\nOne title reserved by another reader and cannot be renewed\nReturns slot beside main entrance\nDesk open until 18:00 on weekdays.',[
('One of the books has a reservation from another reader. I will need ', 'to return it by Friday.'),
('The other book is still eligible for renewal. I can keep it ', 'for a little longer.'),
('The desk closes at six on weekdays. If I arrive later, I can use ', 'the returns slot by the entrance.'),
('Both borrowed books are due on Friday. I should put them ', 'in my bag before leaving home.'),
('I have not finished the reserved book yet. I may borrow it again ', 'after the next reader has finished.')])
FAMILY('everyday','garden_weeds','Garden afternoon',
       'Town gallery\nPortrait exhibition\nThe final guided visit begins at 15:30. Sketching is welcome with dry materials. Large bags should be stored in the cloakroom.',[
('The soil is soft after last night’s rain. It should be easier ', 'to pull the weeds out.'),
('I found a small seedling beside the path. I will leave it ', 'until I know what it is.'),
('The roots keep breaking when I pull too quickly. I need to loosen ', 'the soil around them first.'),
('The garden gloves are wet from yesterday. I will hang them ', 'where they can dry before evening.'),
('I filled the green bin before finishing the border. The remaining weeds can wait ', 'until the next collection.')])
FAMILY('everyday','pantry_labels','Pantry sorting',
       'Household list\nSaved note\nSearch\nChecklist options\nRecently edited\nDocument tools\nAttachments\nText insertion area',[
('Two jars contain flour but have no labels. I cannot tell ', 'which one is the bread flour.'),
('The oldest packet was hidden behind the newer ones. I will move it ', 'to the front of the shelf.'),
('The rice bag does not close properly anymore. A sealed container would keep ', 'the grains from spilling everywhere.'),
('I wrote the opening date on the jar lid. That will help me ', 'remember how long it has been open.'),
('The tall bottles do not fit on the middle shelf. I can move them ', 'to the lower cupboard instead.')])
FAMILY('everyday','package_pickup','Parcel collection',
       'Parcel notice\nCollection point: Maple counter\nReady from 15:00 today\nBring collection code and photo identification\nHeld for seven days\nCounter closes at 19:00.',[
('The parcel will be ready after three this afternoon. I can collect it ', 'on my way back from work.'),
('The collection counter asks for the code and identification. I will take ', 'both of those with me.'),
('The parcel is held for seven days. There is still time ', 'to collect it this weekend.'),
('The counter closes at seven this evening. I should get there ', 'before the end of the day.'),
('The notice names the Maple counter as the pickup point. I will check ', 'that location before setting off.')])
FAMILY('everyday','coffee_grinder','Morning coffee',
       'Community swimming pool\nLane schedule\nTwo lanes reserved for lessons from 16:00. The shallow pool remains open. Please leave outdoor shoes beyond the changing room entrance.',[
('The coffee tasted bitter with the new grinder setting. I will try ', 'a slightly coarser grind tomorrow.'),
('The filter folded over when I poured the water. I should fit it ', 'more carefully before brewing.'),
('I forgot to rinse the cup after washing it. That may explain ', 'the faint soapy taste.'),
('The beans smell less fresh than last week. I should keep them ', 'in a tightly closed container.'),
('The mug cooled the coffee almost immediately. Warming it first ', 'might keep the drink hot longer.')])
FAMILY('everyday','linen_cupboard','Cupboard organization',
       'Notes\nHome folder\nRecent documents\nSearch\nAdd checklist\nInsert table\nText format\nSaved on device\nEditing area',[
('The fitted sheets take up too much room when rolled loosely. I will fold them ', 'into smaller stacks by size.'),
('We rarely use the heavy blankets in summer. They can go ', 'on the highest shelf.'),
('The guest towels were mixed with the cleaning cloths. I will separate them ', 'into two clearly marked baskets.'),
('One shelf sags when all the blankets are on it. We should spread ', 'the weight across the cupboard.'),
('I found three pillowcases without matching sheets. I can keep them ', 'together in the spare linen basket.')])
FAMILY('everyday','bicycle_tire','Bicycle preparation',
       'Bike check note\nRear tire soft\nPump stored behind the hallway bench\nFront light charged\nRear light needs new batteries\nChain wiped after last wet ride.',[
('The rear tire feels soft this morning. I will get the pump ', 'from behind the hallway bench.'),
('The front light is already charged. I only need to replace ', 'the batteries in the rear light.'),
('The chain was wiped after the wet ride. I should still check ', 'that it moves smoothly before leaving.'),
('I want to leave in ten minutes. Pumping the rear tire ', 'needs to be done first.'),
('The rear light is too dim to rely on. I will fit fresh batteries ', 'before riding after dark.')])
FAMILY('everyday','fridge_space','Making fridge space',
       'Photography club\nPrint exchange evening\nBring one unframed photograph no larger than A4. A short caption is optional. Tables will be arranged by the windows.',[
('The tall bowl prevents the shelf above from fitting. I can transfer the leftovers ', 'to a flatter container.'),
('The jar at the back has no visible label. I will check ', 'what is inside before moving it.'),
('We need room for the food guests are bringing. I should clear ', 'one shelf before they arrive.'),
('The vegetable drawer is packed too tightly. I can move ', 'the unopened drinks to another shelf.'),
('The milk keeps tipping when the door opens. A spot in the door rack ', 'would hold it more securely.')])
FAMILY('everyday','sewing_patch','Small sewing repair',
       'Personal notebook\nDraft saved\nShow folders\nSearch\nAdd attachment\nParagraph tools\nRecent notes\nBody text',[
('The pocket has a small hole along the seam. A few careful stitches ', 'should close it neatly.'),
('The thread is much lighter than the fabric. I will look for ', 'a closer color match.'),
('The needle keeps catching in the thick edge. I need one ', 'that suits the heavier fabric.'),
('The patch is larger than the worn area. I will trim it ', 'before sewing around the edges.'),
('I tied the final knot on the inside. That keeps it ', 'out of sight when worn.')])
FAMILY('everyday','community_swap','Household swap table',
       'Community swap day\nClean working items only\nNo electrical appliances\nBooks, toys, and kitchenware welcome\nUnclaimed items collected at 16:00\nLabel any missing pieces clearly.',[
('The swap table accepts books and kitchenware. I can bring ', 'the spare mixing bowls.'),
('Electrical appliances are not accepted at this event. I will leave ', 'the old toaster at home.'),
('The puzzle is missing one piece. I should write that ', 'clearly on the box.'),
('Unclaimed items are collected at four. We need to return ', 'before the event closes.'),
('Everything should be clean and usable. I will wash ', 'the bowls before packing them.')])
FAMILY('everyday','rainy_entryway','Wet entryway',
       'Evening lecture\nDrawing city trees\nBring a pencil and a small sketchbook. The tutor will show examples before the walk. Heavy rain moves the session into the studio.',[
('Everyone came in with wet shoes at the same time. I should put ', 'another mat by the door.'),
('The umbrella is dripping onto the wooden floor. I will stand it ', 'inside the empty bucket.'),
('The coat hooks are too close together for wet jackets. We need to leave ', 'some space for air to circulate.'),
('A small puddle has formed beside the shoe rack. I will wipe it ', 'before someone slips on it.'),
('The boots are muddy along the soles. They can stay ', 'on the tray until dry.')])
FAMILY('everyday','calendar_reset','Weekly planning',
       'Personal notes\nThis week\nLocal copy\nNew checklist\nSearch\nShow sidebar\nSaved changes\nText tools\nEditor',[
('I wrote the appointment on the wrong day. I need to move it ', 'to the correct calendar entry.'),
('There are too many errands planned for one afternoon. I can spread them ', 'across the rest of the week.'),
('The calendar shows two things at the same time. I should decide ', 'which one can be rescheduled.'),
('I keep forgetting to allow time for travel. I will add ', 'a short buffer between appointments.'),
('Sunday is clear apart from one small task. I would like to keep ', 'most of that day free.')])

# Travel: wholly invented itineraries, locations, bookings, and observations.
FAMILY('travel','ferry_arrival','Island ferry plan',
       'Northport ferry\nCheck-in closes twenty minutes before sailing\nFoot passengers use Gate 3\nLarge bags stored on lower deck\nCrossing time about forty-five minutes\nCafe opens after departure.',[
('Check-in closes twenty minutes before the ferry leaves. We should reach the terminal ', 'with plenty of time to spare.'),
('We are traveling as foot passengers. The notice directs us ', 'to gate three for boarding.'),
('Large bags stay on the lower deck during the crossing. I will keep ', 'my small day bag with me.'),
('The crossing takes about forty-five minutes. We can get a drink ', 'once the onboard cafe opens.'),
('The cafe does not open until after departure. I should fill ', 'my water bottle before boarding.')])
FAMILY('travel','hotel_late','Late hotel arrival',
       'Craft circle\nPatchwork afternoon\nBring fabric scraps and a ruler. Shared cutting mats are available. Tea will be served halfway through the session. Beginners can borrow a simple pattern.',[
('Our train arrives after the front desk closes. Could you explain ', 'how we should collect the key?'),
('We may reach the hotel close to midnight. I wanted to let you know ', 'about our late arrival.'),
('The booking is for two nights starting Friday. Please confirm ', 'that the room is still reserved.'),
('We will have one large suitcase with us. Is there a lift ', 'to the upper floors?'),
('Thank you for sending the entry instructions. I have saved them ', 'so I can read them offline.')])
FAMILY('travel','packing_layers','Packing for the coast',
       'Travel notebook\nPacking list\nNew checklist\nSearch\nAttach document\nSaved locally\nShow folders\nText format\nNote body',[
('The coast can feel cool even when the inland forecast is warm. I will pack ', 'a light extra layer.'),
('I do not want to carry a separate bag for the beach. The foldable tote ', 'can fit inside my backpack.'),
('The walking shoes take up most of the suitcase. I will wear them ', 'on the journey instead.'),
('We can wash a few clothes during the trip. That means I can bring ', 'fewer shirts than I first planned.'),
('The return trip may be wet. I should leave ', 'a waterproof jacket near the top.')])
FAMILY('travel','station_transfer','Train connection',
       'Connection notice\nArrival platform 2\nOnward service platform 7\nUnderpass links all platforms\nLifts at the southern end\nTransfer time eighteen minutes\nNo ticket barriers between platforms.',[
('We arrive on platform two and leave from platform seven. The underpass should take us ', 'directly between the two platforms.'),
('We have eighteen minutes for the connection. I will check ', 'the departure board as soon as we arrive.'),
('The lifts are at the southern end of the platforms. We should head there ', 'with the heavy suitcase.'),
('There are no ticket barriers between the platforms. We can stay ', 'inside the station during the transfer.'),
('The onward train uses platform seven. I will keep ', 'that number in our travel notes.')])
FAMILY('travel','walking_tour','Old town walk',
       'Music school notice\nPiano rooms available by booking\nPlease leave the practice bench at its original height. The tuning schedule is posted at reception. Food is not allowed near instruments.',[
('The streets in the old town are steep and narrow. We should allow ', 'more time than the map suggests.'),
('The walking tour meets by the stone fountain. I will look for ', 'the guide with the red folder.'),
('We missed the turn beside the clock tower. Let us go back ', 'to the previous street corner.'),
('The route passes several small courtyards. I want to stop ', 'for a few photographs along the way.'),
('The guide gave us a paper map at the start. It will be useful ', 'if our phones lose signal.')])
FAMILY('travel','beach_bus','Bus to the beach',
       'Trip notes\nSaved draft\nSearch notebook\nNew section\nAttachment controls\nShow outline\nText style menu\nEditor area',[
('The beach bus is crowded around lunchtime. We could leave ', 'earlier in the morning.'),
('The stop is on the opposite side of the road. We need to cross ', 'at the marked pedestrian crossing.'),
('The driver asked us to fold the stroller before boarding. I will hold ', 'the bags while you do that.'),
('We should check the final return bus before settling on the beach. I do not want ', 'to miss the last ride back.'),
('The bus takes a longer route through the villages. We will see ', 'more of the coast that way.')])
FAMILY('travel','cabin_checkin','Cabin check-in',
       'Birch Hollow cabin\nKey safe beside kitchen door\nParking space marked B\nTap water suitable for drinking\nWood basket under covered porch\nPlease close roof windows before leaving.',[
('The cabin key is in the safe beside the kitchen door. We should approach ', 'from that side of the building.'),
('Our parking space is marked with the letter B. I will check ', 'the painted sign when we arrive.'),
('The tap water is suitable for drinking. We do not need ', 'to bring several large bottles.'),
('The firewood is stored beneath the covered porch. I can bring ', 'a small basket inside later.'),
('The roof windows must be closed when we go out. I will check them ', 'before we leave for the day.')])
FAMILY('travel','market_breakfast','Market breakfast stop',
       'Repair cafe\nBring small household items\nVolunteers assess repairs before work begins. Replacement parts may need ordering. The sewing table is beside the window and the tool bench is at the back.',[
('The market stalls were just opening when we arrived. We found ', 'a bakery serving warm rolls.'),
('There were no empty tables near the food stalls. We took our breakfast ', 'to a bench by the square.'),
('I did not recognize several pastries on the counter. I asked ', 'which one had a fruit filling.'),
('The coffee queue moved slowly but the bread stall was quiet. We split up ', 'to save a little time.'),
('The market was livelier than the main shopping street. I would like to return ', 'before we leave the town.')])
FAMILY('travel','luggage_storage','Bags before check-in',
       'Mail\nTravel correspondence\nDraft saved\nRecipients\nSubject\nAttach file\nFormatting controls\nSignature\nMessage editor',[
('We arrive several hours before the room is ready. Could we leave ', 'our bags at reception?'),
('We will have two small suitcases and a backpack. Please let us know ', 'if there is a storage fee.'),
('Our train home leaves after dinner on the final day. It would help ', 'to store the bags after checkout.'),
('Thank you for confirming the luggage room is available. We will collect ', 'everything before the desk closes.'),
('I have kept the luggage receipt in my wallet. We may need it ', 'when we return for the bags.')])
FAMILY('travel','trail_detour','Forest trail detour',
       'Forest path notice\nEast bridge closed\nSigned detour follows the ridge path\nAdds approximately thirty minutes\nWater available only at visitor centre\nWet roots on shaded slopes.',[
('The east bridge is closed for repairs. We will need to follow ', 'the signed route along the ridge.'),
('The detour adds about half an hour to the walk. We should start ', 'a little earlier than planned.'),
('There is no water point beyond the visitor centre. I will fill ', 'both bottles before we leave.'),
('The shaded slopes have wet roots across the path. We should take ', 'those sections slowly and carefully.'),
('The original route crosses the closed bridge. I will update ', 'the walk saved in our notes.')])
FAMILY('travel','museum_bags','Museum visit logistics',
       'Allotment noticeboard\nShared tools must be returned clean\nWater supply shuts off briefly on Friday morning. Extra compost is available near Plot 8. Please keep the gate latched after dusk.',[
('The museum asks visitors to leave large bags in lockers. I will take ', 'only a small shoulder bag inside.'),
('We booked the first entry time of the morning. It should give us ', 'a quieter start to the visit.'),
('The special exhibition is on a different floor. We should check ', 'how much time remains before it closes.'),
('We have already spent an hour in the first gallery. Let us choose ', 'which rooms we most want to see.'),
('The museum cafe is busy at lunchtime. We could eat ', 'after the main rush has passed.')])
FAMILY('travel','road_trip_stop','Road trip pause',
       'Journey note\nRoute ideas\nSaved locally\nRecent edits\nSearch\nChecklist tools\nAttachments\nText format\nBody field',[
('We have been driving for nearly two hours. It is time to find ', 'somewhere to stop and stretch.'),
('The next service area is farther away than expected. We should use ', 'the rest stop coming up now.'),
('The scenic road takes longer but avoids the heavy traffic. We can choose it ', 'if we leave enough time.'),
('I saved the route before leaving the hotel. We should still be able ', 'to navigate without a mobile signal.'),
('The driver needs a break before the last section. I can take over ', 'after we stop for lunch.')])
FAMILY('travel','reservation_change','Restaurant booking change',
       'Reservation details\nTable for four at 19:00\nTerrace seating weather dependent\nIndoor table available on request\nKitchen closes at 21:00\nPlease call for changes in party size.',[
('Our reservation is for four people at seven. One more friend would like ', 'to join us for dinner.'),
('The terrace depends on the weather staying dry. Could we request ', 'a table indoors instead?'),
('The kitchen closes at nine. We should avoid ', 'arriving much later than planned.'),
('The booking note asks us to call about a larger group. I will phone ', 'to check whether five can be seated.'),
('We have a seven o’clock table booked. I will aim ', 'to arrive a few minutes early.')])
FAMILY('travel','souvenir_space','Packing to return',
       'Community theatre\nSet painting weekend\nWear clothes that can get marked. Brushes and rollers are provided. Please label personal tools. The stage door will be open from nine.',[
('The pottery bowl is too fragile to pack loose. I will wrap it ', 'inside a soft sweater.'),
('The suitcase is fuller than it was on the outward trip. I need to leave ', 'some items in my day bag.'),
('The postcards can bend between the clothes. I will put them ', 'inside the flat document folder.'),
('The bottle needs extra padding around the neck. I can use ', 'a rolled pair of socks.'),
('I bought more small gifts than I expected. Before closing the case, I should check ', 'that nothing is being crushed.')])
FAMILY('travel','language_note','Useful phrases',
       'Travel notebook\nLocal notes\nSearch\nNew checklist\nParagraph styles\nAttach image\nShow folders\nChanges saved\nText editor',[
('I wrote down the address in the local language. That should help ', 'if we need to ask directions.'),
('The server spoke slowly when I looked confused. I thanked them ', 'for being patient with me.'),
('I can pronounce the first part of the station name. The final syllable ', 'still takes a little practice.'),
('A short greeting made the conversation feel friendlier. I want to learn ', 'a few more useful phrases.'),
('The translation on my phone looked uncertain. I pointed to ', 'the item on the menu instead.')])
FAMILY('travel','airport_shuttle','Hotel shuttle timing',
       'Airport shuttle\nDepartures every thirty minutes\nFirst departure 05:00\nPickup behind hotel reception\nJourney normally twenty-five minutes\nReserve seats the evening before\nOne suitcase per passenger.',[
('The shuttle leaves every half hour from five in the morning. We could take ', 'the first departure of the day.'),
('Seats must be reserved the evening before. I will speak ', 'to reception after dinner.'),
('The pickup point is behind reception. We should wait ', 'at the rear hotel entrance.'),
('The usual journey takes twenty-five minutes. We should still allow ', 'extra time for unexpected traffic.'),
('Each passenger can bring one suitcase on the shuttle. Our two cases ', 'fit within that limit.')])
FAMILY('travel','seaside_walk','Evening by the sea',
       'Library workshop\nBookbinding basics\nPaper and thread provided\nBring a ruler if you have one. The demonstration begins promptly at ten. Finished booklets can dry on the marked shelf.',[
('The promenade was much quieter after dinner. We walked slowly ', 'toward the end of the pier.'),
('The wind grew stronger as we approached the headland. I was glad ', 'to have brought a jacket.'),
('The tide had covered the lower path by evening. We stayed ', 'on the raised walkway.'),
('The lights along the harbor came on one by one. We stopped ', 'to watch their reflections in the water.'),
('We had planned only a short walk after dinner. The view persuaded us ', 'to stay out a little longer.')])
FAMILY('travel','ticket_download','Saving travel documents',
       'Trip planning note\nAttachments\nRecent edits\nSave status\nNew checklist\nSearch\nText formatting\nDocument body',[
('The ticket is currently visible only inside the booking email. I will save ', 'an offline copy before we leave.'),
('The confirmation includes both the outward and return journeys. I should check ', 'the dates on each section.'),
('The phone screen is difficult to read in bright sunlight. A printed copy ', 'could be useful at the gate.'),
('I put the booking number at the top of the travel note. That makes it ', 'easier to find when needed.'),
('The attachment did not finish downloading over the weak connection. I will try again ', 'when the signal is stronger.')])
FAMILY('travel','bike_rental','Bicycle rental return',
       'Cycle hire receipt\nReturn by 17:30\nUse side gate after 17:00\nHelmet included\nLock supplied with each bicycle\nReport damage before leaving the shop\nLate returns charged in half-hour blocks.',[
('The bicycles must be returned by half past five. We should turn back ', 'with enough time to reach the shop.'),
('After five we need to use the side gate. I will remember that ', 'when we bring the bicycles back.'),
('The rental includes a lock for each bicycle. We can secure them ', 'while we stop for lunch.'),
('There is a scratch on the frame before we start. I should point it out ', 'before leaving the rental shop.'),
('Late returns are charged in half-hour blocks. It is worth keeping ', 'an eye on the time.')])
FAMILY('travel','last_morning','Final morning away',
       'Community orchard\nApple pressing day\nClean fruit crates are stacked near the shed. Volunteers should sign in at the gate. Bring a bottle if you would like to take juice home.',[
('We have a free morning before the train home. I would like to revisit ', 'the little square near the river.'),
('Most of the packing is already done. We can have ', 'a relaxed breakfast before checking out.'),
('I do not want to spend the last hour rushing. Let us leave ', 'for the station a little early.'),
('The cafe we liked is on the way to the station. We could stop ', 'for one final cup of coffee.'),
('The trip felt short once we reached the final day. I am glad ', 'we left some time unplanned.')])

CATEGORIES = ['conversation','science','entertainment','work','technology','everyday','travel']
CONTEXT_KINDS = ['useful','distracting','neutral']
SURFACES = [
    ('message','Messages','com.apple.MobileSMS','iMessage'),
    ('email','Mail','com.apple.mail','Message body'),
    ('note','Notes','com.apple.Notes','Start writing'),
    ('webForm','Safari','com.apple.Safari','Write a reply'),
]
# Reused chrome is intentionally not treated as an independently authored source.
# This is ordinary UI scaffolding; all semantic family seeds and pairings above
# were separately authored. Five siblings remain one evaluationGroup.
CHROME = {
    'Messages': ('Messages\nFile  Edit  View  Conversation  Window  Help\nSearch\n', '\nDetails\nText Message\n'),
    'Mail': ('Mail\nInbox  Drafts  Sent\nCompose  Reply  Forward\n', '\nTo  Subject\nMessage body\n'),
    'Notes': ('Notes\nFile  Edit  Format  View  Window  Help\nFolders  Search\n', '\nAll Notes\nLast edited today\n'),
    'Safari': ('Safari\nFile  Edit  View  History  Bookmarks  Window  Help\nReader  Share\n', '\nBack  Forward\nReply field\n'),
}
NOISY_SIDEBARS = {
    'Messages': 'Conversation list\nPinned\nWeekend plans\nYesterday 18:42\nPhoto attachment\nShared links\nContact information\nHide alerts\nAudio message\nRead\nToday\n',
    'Mail': 'Mailboxes\nFavorites\nAll Inboxes\nDrafts\nSent\nArchive\nFlagged\nUnread\nAttachment\nYesterday\nToday\nView as thread\nReply  Reply All  Forward\n',
    'Notes': 'Folders\nAll Notes\nRecently Deleted\nQuick Notes\nGallery View\nList View\nAttachments\nChecklist\nTable\nParagraph\nTitle  Heading  Body\nSearch Results\n',
    'Safari': 'Favorites\nReading List\nBookmarks\nTab Overview\nReload\nShare\nReader\nPage 1\nPrevious  Next\nSearch this page\nAccount\nHelp\nPrivacy\nTerms\n',
}

def build():
    assert len(families) == 140
    phrases = []
    metadata = []
    per_category = {category: 0 for category in CATEGORIES}
    for family_index, family in enumerate(families):
        category = family['category']
        per_category[category] += 1
        family_ordinal = per_category[category]
        group = f"{category}-{family_ordinal:02d}-{family['slug']}"
        context_kind = CONTEXT_KINDS[family_index % 3]
        kind, app, bundle, placeholder = SURFACES[family_index % 4]
        # Fixed before inference: one family/category, approximately balanced across
        # surfaces and context kinds. This avoids confounding the noise with one app.
        noisy_ordinals = dict(zip(CATEGORIES, [4, 6, 5, 7, 9, 8, 10]))
        long_noisy = family_ordinal == noisy_ordinals[category]
        metadata.append({
            'evaluationGroup': group,
            'category': category,
            'contextKind': context_kind,
            'authoredScenarioSeed': family['slug'],
            'caseCount': 5,
            'longNoisyScreen': long_noisy,
            'surfaceWrapper': app,
        })
        for case_index, (prefix, continuation) in enumerate(family['cases']):
            assert prefix.endswith((' ', '\n')), (group, case_index)
            header, footer = CHROME[app]
            # The display timestamp is plausible surface metadata and ensures that
            # siblings have distinct OCR text without exposing their reference.
            timestamp = f"{8 + family_index % 10:02d}:{10 + case_index * 7:02d}"
            screen = header + family['screen'] + footer + f"Updated today at {timestamp}\n"
            if long_noisy:
                # Synthetic OCR artifact: duplicated sidebars plus clipped glyphs.
                # Noise is a shared construction method, not another source family.
                screen += '\n' + NOISY_SIDEBARS[app] * 6
                screen += 'I  l  |  0  O\n—  …\nView   Vlew\nSidebar   Side bar\n'
            phrases.append({
                'id': f"fresh-{category}-{family_ordinal:02d}-{case_index + 1:02d}",
                'category': category,
                'text': continuation,
                'evaluationGroup': group,
                'contextKind': context_kind,
                'scenario': {
                    'kind': kind,
                    'applicationName': app,
                    'bundleIdentifier': bundle,
                    'windowTitle': family['title'],
                    'fieldPlaceholder': placeholder,
                    'documentPrefix': prefix,
                    'screenText': screen,
                },
            })
    corpus = {
        'version': 3,
        'language': 'en',
        'provenance': 'Fresh synthetic English autocomplete contexts and continuations authored by a Codex AI agent from invented scenarios for this evaluation round. No prior evaluation corpus, candidate code, failure cases, candidate-engine outputs, online sources, or private user data were used. No separate generation tool or candidate-engine inference run was used to create this corpus. Five related cases share each evaluationGroup; these are scenario families, not 700 independent observations. This convenience corpus does not claim real-user representativeness.',
        'phrases': phrases,
    }
    corpus_path = ROOT / 'corpus.json'
    corpus_path.write_text(json.dumps(corpus, ensure_ascii=False, indent=2) + '\n')
    family_path = ROOT / 'families.json'
    family_path.write_text(json.dumps({'families': metadata}, ensure_ascii=False, indent=2) + '\n')
    return corpus_path, family_path

if __name__ == '__main__':
    corpus_path, family_path = build()
    # Deliberately keep reference text out of stdout for blinded controls.
    print(json.dumps({'corpusPath': str(corpus_path), 'familyMetadataPath': str(family_path),
                      'phrases': 700, 'scenarioFamilies': len(families)}, sort_keys=True))
