import Foundation
import CryptoKit

// Compile beside the actual pure Swift scorer. Emitting only checkpoint positions lets
// the decision validator detect omissions from both paired reports without disclosing
// protected references to the agent selecting candidates. This process owns no app state.
let arguments = CommandLine.arguments
precondition(arguments.count == 6 || arguments.count == 7,
             "corpus mode perCategory output scorerSource [screenIDs]")
let inputURL = URL(fileURLWithPath: arguments[1])
let data = try Data(contentsOf: inputURL)
let corpus = try JSONDecoder().decode(PhrasePredictionCorpus.self, from: data)
try corpus.validate()
guard let mode = PhrasePredictionScorer.Mode(rawValue: arguments[2]),
      let perCategory = Int(arguments[3]), perCategory >= 0 else {
    fatalError("Invalid mode or category limit")
}
var phrases = corpus.phrases
if arguments.count == 7 {
    precondition(perCategory == 0)
    let ids = try JSONDecoder().decode([String].self,
        from: Data(contentsOf: URL(fileURLWithPath: arguments[6])))
    precondition(Set(ids).count == ids.count)
    phrases = phrases.filter { Set(ids).contains($0.id) }
    precondition(phrases.count == ids.count)
} else if perCategory > 0 {
    var counts: [String: Int] = [:]
    phrases = phrases.filter { phrase in
        let count = counts[phrase.category, default: 0]
        counts[phrase.category] = count + 1
        return count < perCategory
    }
}
let records: [[String: Any]] = phrases.map { phrase in
    let checkpoints = PhrasePredictionScorer.checkpoints(for: phrase, mode: mode)
    return ["phraseID": phrase.id, "category": phrase.category,
            "checkpoints": checkpoints.map {
                ["wordIndex": $0.wordIndex, "typedCharacters": $0.typedCharacters]
            }]
}
func hash(_ bytes: Data) -> String {
    SHA256.hash(data: bytes).map { String(format: "%02x", $0) }.joined()
}
let result: [String: Any] = [
    "schemaVersion": 1,
    "generatedUTC": ISO8601DateFormatter().string(from: Date()),
    "corpusSHA256": hash(data), "corpusVersion": corpus.version,
    "scorerSourceSHA256": hash(try Data(contentsOf: URL(fileURLWithPath: arguments[5]))),
    "mode": mode.rawValue, "perCategory": perCategory,
    "selection": arguments.count == 7 ? "screen" : "all",
    "phraseCount": phrases.count,
    "checkpointsPerCondition": phrases.reduce(0) {
        $0 + PhrasePredictionScorer.checkpoints(for: $1, mode: mode).count
    },
    "phrases": records
]
let encoded = try JSONSerialization.data(withJSONObject: result,
                                         options: [.prettyPrinted, .sortedKeys])
try encoded.write(to: URL(fileURLWithPath: arguments[4]), options: .atomic)
print("Exported opaque \(mode.rawValue) positions for \(phrases.count) phrases")
