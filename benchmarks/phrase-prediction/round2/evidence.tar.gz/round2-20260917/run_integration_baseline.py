#!/usr/bin/env python3
"""Run the retained baseline in the verified current-main integration snapshot.

This driver owns only orchestration and evidence. It never changes application/native sources,
main files, the frozen decision, or the ordinary experiment execution.json. Its optional --plan
is read-only; actual checks/replay require an explicit invocation without --plan by the scheduler.
"""
import argparse
import contextlib
import datetime
import fcntl
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import sys
import time

import assess_round2 as scoring_evidence
import prepare_current_main as snapshot_tools
import production_inventory
import run_checks

HERE=Path(__file__).resolve().parent
LABEL='integration-production-baseline'
SEED=12648430
SAMPLING={'temperature':.1,'repetition_penalty':1.025,'top_k':20,'top_p':.7,'min_p':.08,'seed':SEED}
CHECKPOINT_PATH='checkpoint-manifests/old-word-all.json'
OLD_CORPUS='b41c8089a58ae1e0ee84b95ac9283cf71db4e713e25bd8fed47220be69d8b0f6'
BROWSER_TEST='CotabbyTests/Support/Focus/Applications/BrowserAppDetectorTests.swift'
ORIGINAL_MAIN_HEAD='cd99305b169c714074c6ea1fda33f21e6cd0beda'
CERTIFIED_MAIN_HEAD='585179bd2fcc34d0147861ecc479ca4020731acb'
REVISION_CERTIFICATE='integration-preparation/current-main-revision-certificate.json'


def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def read(path):return json.loads(path.read_text())
def sha(path):return snapshot_tools.file_sha(path)
def ref(path):return {'path':str(path.resolve()),'sha256':sha(path)}
def artifact(reference):
    path=Path(reference['path']);path=path if path.is_absolute() else HERE/path
    if sha(path)!=reference['sha256']:raise ValueError('Evidence artifact changed: '+str(path))
    return path

def load_module(name,path):
    spec=importlib.util.spec_from_file_location(name,path);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);return module


def deadline():
    end=datetime.datetime.fromisoformat(read(HERE/'round.json')['deadlineUTC'].replace('Z','+00:00'))
    return (end-datetime.timedelta(minutes=20)).replace(second=0,microsecond=0).timestamp()


def admit(limit,estimate):
    if estimate<0 or time.time()+estimate>=limit:
        raise TimeoutError('Integration workload does not fit before18:01UTC and the closure reserve')


@contextlib.contextmanager
def check_execution(execution):
    """Rebind the shared checker in this process; its root execution file stays untouched."""
    previous={name:getattr(run_checks,name) for name in ('EXECUTION','ROOT','DERIVED')}
    run_checks.EXECUTION=dict(execution);run_checks.ROOT=Path(execution['root']);run_checks.DERIVED=Path(execution['derivedData'])
    try:yield
    finally:
        for name,value in previous.items():setattr(run_checks,name,value)


def capture_helper():
    helper=load_module('integration_snapshot_capture',HERE.parent/'round1-20260917/prepare_integration_snapshot.py')
    snapshot_tools.configure_capture(helper);return helper


def capture_main(helper,execution):
    return {role:helper.capture(Path(execution[key]),native=role=='native')[0]
            for role,key in (('app','main'),('native','mainNative'))}


def same_sources(before,after):
    return all(before[role]['head']==after[role]['head'] and before[role]['files']==after[role]['files']
               for role in ('app','native'))


def logical_hashes(sources):
    return {role+'/'+name:entry['sha256'] for role,snapshot in sources.items()
            for name,entry in snapshot['files'].items() if entry['kind']!='deleted'}


def verify_private_sources(helper,execution,snapshot):
    """Include physical ignored/untracked source inputs; exempt only canonical resolver locks."""
    locks={'app':{'Cotabby.xcodeproj/project.xcworkspace/xcshareddata/swiftpm/Package.resolved'},
           'native':{'Package.resolved'}}
    result={}
    for role,key in (('app','root'),('native','native')):
        current=helper.capture(Path(execution[key]),native=role=='native')[0]
        expected=snapshot['snapshotAfterOverlay'][role]
        protected=lambda entries:{name:value for name,value in entries.items() if name not in locks[role]}
        if current['head']!=expected['head'] or protected(current['files'])!=protected(expected['files']):
            raise ValueError('Private integration source drift outside canonical package locks: '+role)
        result[role]=current
    return result


def validate_compatibility(frozen,snapshot,execution):
    certificate_path=artifact(snapshot['productionDifferenceCertificate']);certificate=read(certificate_path)
    if (certificate.get('schemaVersion')!=1 or certificate.get('status')!='reviewed'
            or certificate.get('reviewer')!='/root' or certificate.get('allOtherProductionInputsEqual') is not True
            or certificate['baselineFreezeSHA256']!=sha(HERE/'finalist-freeze.json')
            or scoring_evidence.timestamp(certificate['reviewedUTC'])>scoring_evidence.timestamp(now())):
        raise ValueError('Compatibility difference is not bound to a prior explicit frozen-decision review')
    expected_change={'path':snapshot_tools.REVIEWED_PATH,'beforeSHA256':snapshot_tools.REVIEWED_FROZEN,
                     'afterSHA256':snapshot_tools.REVIEWED_CURRENT}
    if certificate['differences']!=[expected_change]:raise ValueError('Compatibility difference exceeded reviewed scope')
    frozen_inventory=read(artifact(frozen['productionInventories']['baseline']))
    if read(artifact(certificate['frozenInventory']))!=frozen_inventory:raise ValueError('Compatibility frozen inventory disagrees')
    current=read(artifact(certificate['currentInventory']))
    expected=json.loads(json.dumps(frozen_inventory));expected['files'][snapshot_tools.REVIEWED_PATH]=snapshot_tools.REVIEWED_CURRENT
    if current!=expected or len(current['files'])!=344:raise ValueError('Compatibility inventory contains another production difference')
    artifact(certificate['diff'])
    scope=read(artifact(certificate['fixtureScopeProof']))
    sources={item['kind']:item for item in scope['sources']}
    if (scope.get('schemaVersion')!=1 or scope.get('status')!='passed'
            or scope.get('affectedBundleIdentifiers')!=['com.openai.codex'] or len(scope['sources'])!=2
            or set(sources)!={'historical','fresh'}
            or sources['historical']['corpusSHA256']!=OLD_CORPUS or sources['historical']['phraseCount']!=1337
            or sources['fresh']['corpusSHA256']!=frozen['freshCorpusSHA256'] or sources['fresh']['phraseCount']!=700
            or any(item['matchingScenarioCount']!=0 for item in sources.values())):
        raise ValueError('Compatibility fixture-scope proof is incomplete')
    if production_inventory.capture(execution['root'],execution['native'])!=current:
        raise ValueError('Private production inputs changed after compatibility review')
    if {key:current['files'][name] for key,name in production_inventory.TARGET_PATHS.items()}!=frozen['baselineTargets']:
        raise ValueError('Private baseline target bytes changed')
    return certificate_path,artifact(certificate['currentInventory'])


def verify_harness(frozen,snapshot,execution):
    expected={name.removeprefix('app/'):digest for name,digest in frozen['validationHarnessHashes'].items()}
    overlays={item['path']:item['after']['sha256'] for item in snapshot['harnessOverlays']}
    for name in snapshot_tools.EXTRA_HARNESS:expected[name]=overlays[name]
    for name,digest in expected.items():
        if sha(Path(execution['root'])/name)!=digest:raise ValueError('Frozen validation harness drift: '+name)
    return expected


def verify_preserved_browser_test(snapshot,execution):
    """Bind the independently edited focus test already present in the original snapshot."""
    path=HERE/'integration-preparation/preserved-browser-test.json';certificate=read(path)
    expected=snapshot['snapshotAfterOverlay']['app']['files'][BROWSER_TEST]
    if (certificate.get('schemaVersion')!=1 or certificate.get('status')!='verified-already-preserved'
            or certificate.get('path')!=BROWSER_TEST or certificate.get('sourceWritesPerformed') is not False
            or certificate.get('additionalChangesAfterSnapshot') is not False
            or certificate.get('entry')!=expected
            or artifact(certificate['snapshot']).resolve()!=(HERE/'integration-snapshot.json').resolve()
            or any(snapshot[key]['app']['files'][BROWSER_TEST]!=expected
                   for key in ('mainBefore','mainAfter','snapshotBeforeOverlay'))):
        raise ValueError('Preserved Browser test certificate disagrees with original snapshot')
    artifact(certificate['diffFromHEAD'])
    before=read(artifact(certificate['mainBefore']));after=read(artifact(certificate['mainAfter']))
    if not same_sources(before,after) or not same_sources(before,snapshot['mainAfter']):
        raise ValueError('Browser test certificate contains additional main source changes')
    for root in ('main','root'):
        target=Path(execution[root])/BROWSER_TEST
        if sha(target)!=expected['sha256'] or target.stat().st_mode&0o777!=expected['mode']:
            raise ValueError('Preserved Browser test changed after its snapshot')
    return ref(path)


def verify_main_revision(snapshot):
    """Admit only the recorded metadata-only commit, while preserving private snapshot identity."""
    path=HERE/REVISION_CERTIFICATE;certificate=read(path);original=snapshot['mainAfter']
    if (certificate.get('schemaVersion')!=1 or certificate.get('status')!='verified-head-only'
            or certificate.get('authorizedBy')!='/root' or certificate.get('allSourceEntriesIdentical') is not True
            or certificate.get('mainBeforeAfterEqual') is not True
            or certificate.get('sourceWritesPerformed') is not False or certificate.get('privateSnapshotModified') is not False
            or artifact(certificate['originalSnapshot']).resolve()!=(HERE/'integration-snapshot.json').resolve()
            or original['app']['head']!=ORIGINAL_MAIN_HEAD):
        raise ValueError('Main revision certificate is not the explicitly scoped metadata-only change')
    before=read(artifact(certificate['currentMainBefore']));after=read(artifact(certificate['currentMainAfter']))
    expected_heads={'app':CERTIFIED_MAIN_HEAD,'native':original['native']['head']}
    if (set(before)!=set(original) or set(after)!=set(original) or not same_sources(before,after)
            or certificate['originalMainHeads']!={role:value['head'] for role,value in original.items()}
            or certificate['currentMainHeads']!=expected_heads
            or {role:value['head'] for role,value in after.items()}!=expected_heads
            or certificate['fileCounts']!={role:len(value['files']) for role,value in original.items()}
            or any(after[role]['files']!=original[role]['files'] for role in ('app','native'))):
        raise ValueError('Main revision certificate permits source, mode, inventory or unregistered HEAD drift')
    commit=read(artifact(certificate['commit']))
    if (commit['head']!=CERTIFIED_MAIN_HEAD or commit['parent']!=ORIGINAL_MAIN_HEAD
            or commit['changedPaths']!=[snapshot_tools.REVIEWED_PATH.removeprefix('app/')]
            or commit.get('workingSourceChanged') is not False):
        raise ValueError('Main revision commit exceeds the preserved BrowserAppDetector scope')
    return after,ref(path)


def prepare_plan(initial_build_allowance=300):
    execution=read(HERE/'integration-execution.json');snapshot=read(HERE/'integration-snapshot.json');frozen=read(HERE/'finalist-freeze.json')
    if frozen['candidate']!='baseline' or frozen['selectionQualified'] is not False:raise ValueError('Descriptive baseline driver cannot run a finalist')
    if snapshot['status']!='ready-not-built' or snapshot['execution']!=execution or snapshot['mainBeforeAfterEqual'] is not True:
        raise ValueError('Integration snapshot is not the verified current-main baseline')
    artifact(snapshot['frozenDecision'])
    if read(Path(execution['root']).parent/'execution.json')!=execution:raise ValueError('Private execution records disagree')
    if Path(execution['derivedData'])!=Path(execution['root'])/'build/DerivedData':raise ValueError('DerivedData must remain private and repo-scoped')
    if sha(artifact(snapshot['workspace']))!=snapshot['workspace']['sha256']:raise ValueError('Private workspace changed')
    if sha(Path(execution['model']))!=frozen['modelSHA256']:raise ValueError('Private model no longer matches frozen model')
    certificate,production=validate_compatibility(frozen,snapshot,execution)
    harness=verify_harness(frozen,snapshot,execution)
    browser_test_certificate=verify_preserved_browser_test(snapshot,execution)
    expected_main,revision_certificate=verify_main_revision(snapshot)
    fixture=Path(execution['root'])/'CotabbyTests/Fixtures/phrase-prediction-1337.json'
    if sha(fixture)!=OLD_CORPUS:raise ValueError('Historical corpus changed')
    checkpoint_path=HERE/CHECKPOINT_PATH;checkpoints=read(checkpoint_path);scoring_evidence.validate_checkpoint_manifest(checkpoints)
    if (checkpoints['corpusSHA256']!=OLD_CORPUS or checkpoints['corpusVersion']!=2 or checkpoints['mode']!='word'
            or checkpoints['selection']!='all' or checkpoints['perCategory']!=0 or checkpoints['phraseCount']!=1337
            or checkpoints['checkpointsPerCondition']!=7437
            or checkpoints['scorerSourceSHA256']!=frozen['validationHarnessHashes']['app/CotabbyTests/Evals/PhrasePredictionScoring.swift']):
        raise ValueError('Integration checkpoint plan is not full historical word mode')
    workloads=read(HERE/'baseline-workloads.json')
    selected=[row for row in workloads['runs'] if row['label']==LABEL]
    if workloads['freezeSHA256']!=sha(HERE/'finalist-freeze.json') or workloads['candidate']!='baseline' or len(selected)!=1:
        raise ValueError('Integration workload lacks prior frozen registration')
    workload=selected[0]
    expected={'kind':'historicalWord','seed':SEED,'workerCount':3,'mode':'word','corpusSHA256':OLD_CORPUS,
              'selection':'all','perCategory':0,'estimatedSeconds':1823,'guardException':None}
    if any(workload[key]!=value for key,value in expected.items()):raise ValueError('Integration workload changed from registered scope')
    if scoring_evidence.timestamp(workloads['registeredUTC'])>scoring_evidence.timestamp(now()):raise ValueError('Workload registration is in the future')
    baseline_checks=read(HERE/'baseline-checks/validation.json')
    expected_methods=run_checks.passed_tests(HERE/'baseline-checks/validation.log')
    if baseline_checks['status']!='passed' or len(expected_methods)!=108:raise ValueError('Baseline108-test anchor is missing')
    tests=list(baseline_checks['tests'])
    browser=Path(execution['root'])/BROWSER_TEST
    if browser.is_file():
        tests.append('BrowserAppDetectorTests')
        expected_methods+=['BrowserAppDetectorTests/'+name for name in re.findall(r'func\s+(test\w+)\s*\(',browser.read_text())]
    if initial_build_allowance<0:raise ValueError('Initial build allowance must be nonnegative')
    return {'label':LABEL,'execution':execution,'snapshot':snapshot,'frozen':frozen,'workload':workload,
            'initialBuildAllowanceSeconds':initial_build_allowance,'tests':tests,'expectedMethods':sorted(set(expected_methods)),
            'certificate':ref(certificate),'productionInventory':ref(production),'harness':harness,
            'preservedBrowserTest':browser_test_certificate,
            'expectedMain':expected_main,'currentMainRevision':revision_certificate,
            'fixture':str(fixture),'checkpointManifest':ref(checkpoint_path),
            'evidence':{name:ref(HERE/name) for name in ('integration-snapshot.json','integration-execution.json',
                'finalist-freeze.json','baseline-workloads.json','baseline-checks/validation.json','baseline-checks/validation.log',
                'baseline-checks/prompt-audit.json','integration-preparation/preserved-browser-test.json',REVISION_CERTIFICATE)}}


def benchmark_command(plan):
    execution=plan['execution']
    return [sys.executable,str(Path(execution['root'])/'scripts/phrase_eval.py'),'run','--model',execution['model'],
            '--workspace',execution['workspace'],'--output',str(HERE/LABEL),'--label',LABEL,'--mode','word',
            '--context','paired','--workers','3','--split','all','--split-seed','1337','--screen-per-category','20',
            '--seed',str(SEED),'--temperature','0.1','--repetition-penalty','1.025','--top-k','20','--top-p','0.7','--min-p','0.08']


def verify_run(report,manifest,checks,plan):
    if (checks['status']!='passed' or checks['buildInputs']!=manifest['buildInputs']
            or checks['productSHA256']!=manifest['build']['productSHA256']
            or manifest['build']['sourceSHA256']!=checks['buildInputs']['sourceSHA256']
            or manifest['build'].get('reused') is not False):raise ValueError('Integration build/check identity does not match')
    frozen_manifest=read(HERE/plan['frozen']['baselineLabel']/'manifest.json')
    lock_values=lambda value:sorted(str(item) for item in value['buildInputs']['packageLocks'].values())
    if lock_values(manifest)!=lock_values(frozen_manifest):raise ValueError('Resolved dependency locks differ from frozen baseline')
    cohort=read(artifact(plan['checkpointManifest']));metadata=report['metadata']
    if (manifest['label']!=LABEL or manifest['mode']!='word' or manifest['contextMode']!='paired'
            or manifest['workerCount']!=3 or manifest['samplingOverrides']!=SAMPLING
            or manifest['phraseIDs']!=[row['phraseID'] for row in cohort['phrases']]
            or manifest['corpusSHA256']!=OLD_CORPUS or manifest['corpusInput']['sha256']!=OLD_CORPUS
            or manifest['corpusInput']['version']!=2 or manifest['corpusInput']['replayPath'] is not None
            or Path(manifest['corpusInput']['sourcePath']).resolve()!=Path(plan['fixture']).resolve()
            or manifest['selection']!={'split':'all','splitSeed':1337,'screenPerCategory':20,'perCategory':None,'limit':None}
            or metadata['runLabel']!=LABEL or metadata['seed']!=SEED or metadata['workerCount']!=3):
        raise ValueError('Integration executed different registered controls or corpus selection')
    expected_eval=hashlib.sha256(json.dumps({'compilerInputsSHA256':checks['buildInputs']['sourceSHA256'],
                                           'corpusSHA256':OLD_CORPUS},sort_keys=True).encode()).hexdigest()
    if manifest['evaluationInputsSHA256']!=expected_eval:raise ValueError('Integration evaluation input identity differs')
    anchor=read(HERE/plan['frozen']['baselineLabel']/'report.json')['metadata']['configuration']
    expected_config=dict(anchor,randomSeed=f'Optional({SEED})',selectionSplit='all')
    if metadata['configuration']!=expected_config:raise ValueError('Integration effective configuration differs from frozen baseline')
    if Path(metadata['model']).resolve()!=Path(plan['execution']['model']).resolve():raise ValueError('Integration model path differs')
    scoring_evidence.validate_report(report,cohort,read(Path(plan['fixture'])))


def run(initial_build_allowance=300):
    plan=prepare_plan(initial_build_allowance);limit=deadline()
    admit(limit,plan['workload']['estimatedSeconds']+initial_build_allowance)
    registration=HERE/(LABEL+'-registration.json');proof_path=HERE/(LABEL+'-snapshot-proof.json')
    evidence_dir=HERE/(LABEL+'-driver-evidence');checks_path=HERE/(LABEL+'-checks')
    if any(path.exists() for path in (registration,HERE/LABEL,checks_path,evidence_dir,proof_path)):
        raise ValueError('Refusing to overwrite an existing integration attempt')
    helper=capture_helper();before=capture_main(helper,plan['execution'])
    if not same_sources(before,plan['expectedMain']):raise ValueError('Current main changed since the certified integration source inventory')
    verify_private_sources(helper,plan['execution'],plan['snapshot'])
    execution=plan['execution'];cli=load_module('private_integration_cli',Path(execution['root'])/'scripts/phrase_eval.py')
    initial_inputs=cli.build_input_snapshot(Path(execution['workspace']))
    evidence_dir.mkdir();snapshot_tools.write(evidence_dir/'main-before.json',before)
    record={'label':LABEL,'candidate':'baseline','components':[],'phase':'validation','status':'checking','startedUTC':now(),
            'purpose':'Descriptive current-main retained-baseline parity only; no adoption gates',
            'phaseDeadlineUTC':datetime.datetime.fromtimestamp(limit,datetime.timezone.utc).isoformat(),
            'estimatedReplaySeconds':1823,'initialBuildAllowanceSeconds':initial_build_allowance,
            'promptSource':{'components':[],'hashes':{key:plan['frozen']['baselineTargets'][key] for key in ('renderer','composer')}},
            'nativeSource':{'before':'baseline','after':'baseline','sha256':plan['frozen']['baselineTargets']['nativeEngine']},
            'checks':str(checks_path/'validation.json'),'compatibilityDifference':plan['certificate'],
            'productionInventory':plan['productionInventory'],'inputEvidence':plan['evidence'],
            'currentMainRevision':plan['currentMainRevision'],
            'checkpointManifest':plan['checkpointManifest'],'orchestrationSHA256':{name:sha(HERE/name) for name in
                ('run_integration_baseline.py','run_checks.py','prepare_current_main.py','production_inventory.py','assess_round2.py')}}
    snapshot_tools.write(registration,record)
    error=None;started=None;binding=None
    try:
        with check_execution(execution):
            checks=run_checks.run(checks_path.name,plan['tests'],deadline=limit)
            actual=run_checks.passed_tests(checks_path/'validation.log')
            run_checks.require_test_coverage(plan['tests'],checks['tests'],actual)
            if not set(plan['expectedMethods'])<=set(actual):raise ValueError('Integration did not pass all108 baseline tests plus selected Browser methods')
            if checks['buildInputs']!=cli.build_input_snapshot(Path(execution['workspace'])) or checks['buildInputs']['nonLockSourceSHA256']!=initial_inputs['nonLockSourceSHA256']:
                raise ValueError('Integration source changed during dependency resolution/checks')
            audit=sha(checks_path/'prompt-audit.json');baseline_audit=plan['evidence']['baseline-checks/prompt-audit.json']['sha256']
            if audit!=baseline_audit:raise ValueError('Integration prompt audit differs from frozen baseline')
            record['promptAudit']={'comparedCheckpoints':1540,'changedPrompts':{'none':0,'screen':0},
                                  'baselineAuditSHA256':baseline_audit,'candidateAuditSHA256':audit}
            verify_private_sources(helper,execution,plan['snapshot']);validate_compatibility(plan['frozen'],plan['snapshot'],execution)
            verify_harness(plan['frozen'],plan['snapshot'],execution)
            admit(limit,1823)
            command=benchmark_command(plan);record.update(command=command,status='running',inferenceStartedUTC=now())
            snapshot_tools.write(registration,record);snapshot_tools.write(HERE/'active.json',record)
            started=time.time()
            with (HERE/(LABEL+'.console.log')).open('x') as stream:
                run_checks.bounded_command(command,stream,deadline=limit,cwd=Path(execution['root']))
        report=read(HERE/LABEL/'report.json');manifest=read(HERE/LABEL/'manifest.json')
        verify_run(report,manifest,checks,plan)
        if cli.build_input_snapshot(Path(execution['workspace']))!=checks['buildInputs']:raise ValueError('Integration compiler inputs drifted after replay')
        if sha(Path(execution['model']))!=plan['frozen']['modelSHA256']:raise ValueError('Model changed across integration replay')
        verify_private_sources(helper,execution,plan['snapshot']);validate_compatibility(plan['frozen'],plan['snapshot'],execution)
        verify_harness(plan['frozen'],plan['snapshot'],execution)
        for reference in plan['evidence'].values():artifact(reference)
        certified_main,certificate_reference=verify_main_revision(plan['snapshot'])
        if not same_sources(certified_main,plan['expectedMain']) or certificate_reference!=plan['currentMainRevision']:
            raise ValueError('Certified current-main revision evidence changed during replay')
        binding={'label':LABEL,'role':'baseline','sourceSHA256':manifest['buildInputs']['sourceSHA256'],
                 'targets':plan['frozen']['baselineTargets'],'productionInventory':plan['productionInventory'],
                 'compatibilityDifference':plan['certificate']}
        record.update(status='validated-awaiting-preservation-proof',scores={key:value['suite']['nextWord'] for key,value in report['conditions'].items()},
                      allScores={key:value['suite']['all'] for key,value in report['conditions'].items()},
                      evidenceSHA256={'checks':sha(checks_path/'validation.json'),'manifest':sha(HERE/LABEL/'manifest.json'),'report':sha(HERE/LABEL/'report.json')})
    except BaseException as caught:error=caught
    finally:
        try:
            after=capture_main(helper,execution);snapshot_tools.write(evidence_dir/'main-after.json',after)
            if not same_sources(before,after):raise ValueError('Main app/native source changed during integration; no parity claim allowed')
            if error is None:
                proof={'schemaVersion':1,'status':'passed','mainBefore':logical_hashes(before),'mainAfter':logical_hashes(after),
                       'productionInventory':plan['productionInventory'],'compatibilityDifference':plan['certificate'],
                       'snapshotPreparation':plan['evidence']['integration-snapshot.json'],
                       'currentMainRevision':plan['currentMainRevision'],
                       'sourceInventories':{'before':ref(evidence_dir/'main-before.json'),'after':ref(evidence_dir/'main-after.json')},
                       'mainBeforeAfterEqual':True,'scope':record['purpose']}
                snapshot_tools.write(proof_path,proof)
                binding_path=HERE/(LABEL+'-source-binding.json');snapshot_tools.write(binding_path,binding)
                record.update(status='complete',snapshotProof=ref(proof_path),sourceBinding=ref(binding_path))
        except BaseException as preservation_error:
            if error is None:error=preservation_error
            else:record['preservationError']=f'{type(preservation_error).__name__}: {preservation_error}'
        if error is not None:record.update(status='failed-or-interrupted',error=f'{type(error).__name__}: {error}')
        record.update(finishedUTC=now(),replayWallSeconds=time.time()-started if started is not None else 0)
        snapshot_tools.write(registration,record);snapshot_tools.write(HERE/'active.json',record)
    if error is not None:raise error
    with (HERE/'completed.jsonl').open('a') as stream:stream.write(json.dumps(record,sort_keys=True)+'\n')
    print(json.dumps({'label':LABEL,'status':record['status'],'snapshotProof':record['snapshotProof'],
                      'sourceBinding':record['sourceBinding'],'scores':record['scores']},indent=2))
    return record


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--plan',action='store_true',help='Read-only proof validation and command preview; no registration, checks or inference')
    parser.add_argument('--initial-build-allowance-seconds',type=int,default=300)
    args=parser.parse_args()
    if args.plan:
        planned=prepare_plan(args.initial_build_allowance_seconds)
        print(json.dumps({'label':LABEL,'command':benchmark_command(planned),'tests':planned['tests'],
                          'expectedPassingMethods':len(planned['expectedMethods']),'estimatedReplaySeconds':1823,
                          'initialBuildAllowanceSeconds':args.initial_build_allowance_seconds,
                          'deadlineUTC':datetime.datetime.fromtimestamp(deadline(),datetime.timezone.utc).isoformat()},indent=2))
    else:
        with (HERE/'experiment.lock').open('a') as lock:
            fcntl.flock(lock.fileno(),fcntl.LOCK_EX|fcntl.LOCK_NB)
            run(args.initial_build_allowance_seconds)
