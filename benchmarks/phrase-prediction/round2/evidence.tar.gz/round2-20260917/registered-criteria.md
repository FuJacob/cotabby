# Cotabby 1337 improvement experiments — round two

This is round two's working checklist, hypothesis register, and decision record. The benchmark
runner owns replay and scoring; this document connects those measurements to a bounded decision.
Round one's completed record remains in `IMPROVEMENT_BRAINSTORMING.md`.

## Window and baseline

- Status: **running**.
- Start: **2026-09-17 05:21:09 PDT / 12:21:09 UTC**.
- Full six-hour deadline: **2026-09-17 11:21:09 PDT / 18:21:09 UTC**.
- Fresh-data readiness gate: **06:06:09 PDT / 13:06:09 UTC**.
- Finalist freeze deadline: **08:21:09 PDT / 15:21:09 UTC**, preferably earlier.
- Starting app revision: `cd99305b169c714074c6ea1fda33f21e6cd0beda`.
- Baseline behavior: round-one P2-H, compact surface metadata; temperature 0.1,
  repetition penalty 1.025, top-k 20, top-p 0.7, min-p 0.08. Native repetition history is 64 tokens.
- Model remains the existing local `Qwen3.5-0.8B-Base.i1-Q6_K.gguf`.
- Main already contains unrelated/documentation changes. Preserve them. Controlled experiments
  use a byte-verified app/native snapshot outside Documents, with explicit source/model hashes.
- All native token-healing changes present at round start are baseline prerequisites, not round-two gains.
- Raw evidence: `build/eval/round2-20260917/`. No corpus answers or outputs enter production rules.

## Question and registered experiment list

Does changing which tokens receive repetition penalties, and which context facts the model sees,
improve next-word accuracy without harming partial-word behavior or responsiveness?

All candidates retain the same model, sampler strength/filters, output budget, seed, score matching,
display eligibility, and input identities. Changes are experimental until the adoption gates pass.

| ID | Single change from baseline | Status |
| --- | --- | --- |
| H1 | Repetition history: last 16 tokens | Planned |
| H2 | Repetition history: last 32 tokens | Planned |
| H3 | Repetition history: last 128 tokens | Planned |
| H4 | Apply repetition penalties only to generated tokens | Planned; native correctness review required |
| F1 | Screen label `Context:` | Planned |
| F2 | Screen label `Screen context:` | Planned |
| F3 | Quote the bounded screen reference block | Planned |
| F4 | Place screen section before surface metadata; exact caret prefix stays last | Planned |
| M1 | Omit only App from compact surface metadata | Planned |
| M2 | Omit only Format | Planned |
| M3 | Omit only Title | Planned |
| M4 | Omit only Field | Planned |

Before inference, audit that a prompt variant changes actual screening inputs; a no-op does not
count as a tested alternative. One predeclared replacement for a universally absent metadata field
is existing metadata rendered one field per line. Native windows must change effective history
membership in a targeted check. H4 matches unpenalized sampling at the first sampled token but
can differ after generated tokens accumulate; preserve other sampler state and token healing.

After single variants, select the highest-screen-accuracy nonbaseline candidate in each family,
breaking exact ties by no-screen accuracy and then fixed ID order. A component qualifies only if
its screen correct count exceeds baseline and no-screen correct count is at least baseline.
Eligible combinations are the three family-winner pairs and the triple, at most four total.
Run only those that compose cleanly and fit before the freeze deadline. No second adaptive grid.
Rank the final completed candidate set with the same primary/tie rules and freeze one candidate
before opening fresh validation results. An absence of a qualifying candidate means baseline wins.

## Data and acceptance criteria registered before scores

1. The existing 1337 corpus is development/regression data: every old scenario has contributed to
   inspected evidence. Use the same balanced 140-phrase screening subset as round one. A new
   shuffle of the old corpus is not fresh validation.
2. Independently author approximately 600–700 new synthetic validation scenarios, with explicit
   source/template-family identities, useful/distracting/neutral context labels, and a distinct
   fixture version/hash. Keep all related cases in a family together. Freeze the data before
   candidate tuning; candidate selection must not inspect fresh reference examples or results.
   Audit duplication against old data mechanically, not by tuning hypotheses to fresh answers.
3. Preserve the default version-two corpus's exact 1337/191-per-category contract. Supplementary
   data requires its own explicit fixture pathway and validity checks. If checked fresh data and
   that pathway are not ready by minute 45, the round is exploratory and baseline defaults remain.
4. Fresh paired screen-context gain must be at least **+0.50 percentage points**, with a 95%
   category-stratified family-bootstrap lower bound above zero. No-screen change must be at least
   **-0.50 pp**, with its lower bound above **-1.0 pp**. Use 20,000 bootstrap resamples, seed 1337.
   These intervals describe the synthetic scenario families, not population writing quality.
5. No fresh screen category may decline by more than **3 pp**. Report useful/distracting/neutral
   groups separately. Preserve visible category uncertainty and all unfavorable results.
6. Require nonnegative overall word-score changes in both conditions on the unchanged 1337
   matched regression pair. This is historical comparison, not independent confirmation.
7. Overall partial-word accuracy must not decline in either condition on the registered balanced
   character subset (initial plan: first 50 scenarios/category in corpus order). Report boundary
   and partial-only scores separately and retain category intervals.
8. One-worker p95 latency uses matching inputs with no overlapping builds/inference. Investigate
   regression above the larger of **10% or 20 ms** before adoption. Benchmark latency excludes
   focus tracking, debounce, and overlay rendering.
9. Verify the frozen candidate with a matching production-seed baseline (`12648430`) if primary
   comparisons use benchmark seed 42; require positive screen gain and no-screen delta >= -0.50 pp.
   Prefer the production seed for the full current-main integration comparison.
10. Require error-free complete reports, source/model/fixture integrity, focused unit tests and
    build, and current-main integration. Preserve native cache, cancellation, and token-healing
    invariants. Failed or inconclusive protected validation keeps P2-H; no replacement finalist
    may be selected after looking at those results.

## Six-hour allocation

| Elapsed | Work |
| --- | --- |
| 0:00–0:45 | Snapshot, fresh fixture/data readiness, correctness checks, baseline timing |
| 0:45–2:30 | Implement and screen the feasible 12 single alternatives |
| 2:30–3:00 | Eligible combinations and candidate freeze |
| 3:00–4:00 | Fresh validation first, then the old 1337 regression pair |
| 4:00–5:00 | Character/stress checks and isolated one-worker latency |
| 5:00–6:00 | Current-main integration, tests, decision, evidence, and cleanup |

Reserve the final 20 minutes for closure. Admit a run only when its complete comparison and
protected reserve fit the measured remaining time. Run inference experiments sequentially; each
may use three independent workers. If implementation takes longer, record skipped candidates
and protect validation. A complete negative/inconclusive decision still completes the round.

## Progress checklist

- [x] Start the six-hour goal and record the deadline.
- [x] Create this separate round-two brainstorming and decision file.
- [x] Register candidates, combination rule, data policy, and acceptance gates before scores.
- [ ] Freeze and verify current app/native/model inputs in an isolated execution directory.
- [ ] Prepare, audit, and hash fresh validation data without exposing it to candidate selection.
- [ ] Add and validate the supplementary-fixture pathway; preserve the 1337 contract.
- [ ] Validate native-history feasibility, cache restoration, and token healing.
- [ ] Audit prompt variants for actual input changes.
- [ ] Run a fresh matching screening baseline and measure runtime.
- [ ] Benchmark each feasible single candidate; update the table with results or skip reasons.
- [ ] Benchmark eligible combinations under the registered rule.
- [ ] Freeze one finalist or retain baseline by the three-hour deadline.
- [ ] Complete fresh and historical word comparisons.
- [ ] Complete partial-word and one-worker latency comparisons.
- [ ] Complete production-seed/current-main integration and focused tests/build.
- [ ] Apply only a fully supported winner, otherwise retain P2-H.
- [ ] Preserve compact results, source prerequisites, and reproduction commands.
- [ ] Review changes and remove experiment `build/DerivedData` after all testing finishes.
- [ ] Complete the full six-hour window and report the decision and limitations.

## Experiment log

- 05:21 PDT: Round two started. The app has advanced to `cd99305` since round one; a new baseline
  snapshot is required. Main documentation/untracked results and pre-existing native edits remain
  untouched. Fresh-data authorship, supplementary harness support, and native-history review are
  separate parallel tasks; controlled inference will run sequentially.
- 05:22 PDT: User requested a separate round-two Markdown file. Created this document as the
  active checklist; the original six-hour start/deadline remain unchanged.
