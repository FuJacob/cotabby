"""Model-free launch adapter and temporary plist tests; no app build or inference."""
import argparse,copy,datetime as dt,json,plistlib,tempfile,types,unittest
from pathlib import Path
from unittest import mock
import phrase_eval_hidden_host as h
import run_experiment as runner
import run_latency_baseline as latency

FAKE_CLI='''import sys,json
from pathlib import Path
def inject_environment(value,environment):
 count=0
 if isinstance(value,dict):
  if "CotabbyTests.xctest" in str(value.get("TestBundlePath","")):
   value.setdefault("EnvironmentVariables",{}).update(environment);count+=1
  else:
   for item in value.values():count+=inject_environment(item,environment)
 elif isinstance(value,list):
  for item in value:count+=inject_environment(item,environment)
 return count
def main():
 label=sys.argv[sys.argv.index("--label")+1];output=sys.argv[sys.argv.index("--output")+1]
 configuration={"TestConfigurations":[{"TestTargets":[{"TestBundlePath":"__TESTROOT__/CotabbyTests.xctest","CommandLineArguments":["-cotabby-debug"],"EnvironmentVariables":{"UNCHANGED":"safe"}}]}]}
 env={"COTABBY_PHRASE_EVAL":"1","COTABBY_PHRASE_LABEL":label,"COTABBY_PHRASE_OUTPUT":output}
 assert inject_environment(configuration,env)==1
 Path(output+"-fake-configuration.json").write_text(json.dumps({"configuration":configuration,"argv":sys.argv}))
 if "--synthetic-failure" in sys.argv:raise RuntimeError("synthetic failure")
'''
class HiddenHost(unittest.TestCase):
 def fixture(self,root):
  app=root/'app';(app/'scripts').mkdir(parents=True);cli=app/'scripts/phrase_eval.py';cli.write_text(FAKE_CLI)
  frozen={'candidate':'baseline','selectionQualified':False,'frozenUTC':'2026-09-17T13:25:00Z','validationHarnessHashes':{'app/scripts/phrase_eval.py':h.sha(cli)}}
  (root/'finalist-freeze.json').write_text(json.dumps(frozen))
  plan={'schemaVersion':1,'status':'registered','candidate':'baseline','target':'CotabbyTests','commandLineArguments':h.HOST_ARGS,'persistentPreferenceWrites':False,'sourceOrBinaryChanges':False,'registeredUTC':'2026-09-17T15:00:00Z','freezeSHA256':h.sha(root/'finalist-freeze.json'),'wrapper':h.ref(Path(h.__file__)),'originalCLI':h.ref(cli)}
  path=root/'launch-plan.json';path.write_text(json.dumps(plan));return app,path,plan
 def test_exact_mutation_preserves_other_targets_and_existing_arguments(self):
  for layout in ('legacy','modern'):
   target={'TestBundlePath':'__TESTROOT__/CotabbyTests.xctest','CommandLineArguments':['-cotabby-debug'],'EnvironmentVariables':{'UNCHANGED':'value'}};other={'TestBundlePath':'Other.xctest','CommandLineArguments':['keep']}
   config={'CotabbyTests':target,'Other':other} if layout=='legacy' else {'TestConfigurations':[{'TestTargets':[other,target]}]}
   before=copy.deepcopy(config);change=h.add_host_arguments(config)
   self.assertEqual(target['CommandLineArguments'],['-cotabby-debug',*h.HOST_ARGS]);self.assertEqual(other['CommandLineArguments'],['keep']);self.assertTrue(change['onlyCommandLineArgumentsChanged'])
   list(h.targets(before))[0]['CommandLineArguments']=['-cotabby-debug',*h.HOST_ARGS];self.assertEqual(config,before)
 def test_rejects_duplicate_imprecise_or_existing_visibility_arguments(self):
  cases=[{'target':{'TestBundlePath':'NotCotabbyTests.xctest'}},[{'TestBundlePath':'CotabbyTests.xctest'},{'TestBundlePath':'CotabbyTests.xctest'}],{'TestBundlePath':'CotabbyTests.xctest','CommandLineArguments':'bad'}, {'TestBundlePath':'CotabbyTests.xctest','CommandLineArguments':['-cotabbyMenuBarIconVisible','YES']}]
  for config in cases:
   with self.subTest(config=config),self.assertRaises(ValueError):h.add_host_arguments(config)
 def test_plan_pins_all_bytes_and_fixed_scope(self):
  with tempfile.TemporaryDirectory() as tmp:
   root=Path(tmp);app,path,plan=self.fixture(root)
   with mock.patch.object(h,'HERE',root),mock.patch.object(h,'ROOT',app):
    value=h.load_plan(path,h.sha(path));self.assertEqual(value['commandLineArguments'],h.HOST_ARGS)
    for key,changed in [('commandLineArguments',['-other','YES']),('candidate','H1'),('persistentPreferenceWrites',True),('sourceOrBinaryChanges',True),('target','OtherTests'),('registeredUTC','2099-01-01T00:00:00Z')]:
     bad=copy.deepcopy(plan);bad[key]=changed;path.write_text(json.dumps(bad))
     with self.subTest(key=key),self.assertRaises(ValueError):h.load_plan(path,h.sha(path))
    path.write_text(json.dumps(plan));(app/'scripts/phrase_eval.py').write_text('changed')
    with self.assertRaisesRegex(ValueError,'artifact changed'):h.load_plan(path,h.sha(path))
 def test_real_recursive_injection_and_forwarded_arguments_unchanged(self):
  with tempfile.TemporaryDirectory() as tmp:
   root=Path(tmp);app,path,_=self.fixture(root)
   with mock.patch.object(h,'HERE',root),mock.patch.object(h,'ROOT',app):
    value=h.load_plan(path,h.sha(path));args=['run','--label','fake','--output',str(root/'fake')]
    argv=h.sys.argv;record=h.execute(value,args);self.assertIs(h.sys.argv,argv);self.assertEqual(record['status'],'passed');self.assertEqual(len(record['mutations']),1)
    data=json.loads((root/'fake-fake-configuration.json').read_text());target=list(h.targets(data['configuration']))[0]
    self.assertEqual(target['EnvironmentVariables']['UNCHANGED'],'safe');self.assertEqual(target['CommandLineArguments'],['-cotabby-debug',*h.HOST_ARGS]);self.assertEqual(data['argv'][1:],args)
    self.assertEqual(h.verify_completed(value,'fake',['python',str(app/'scripts/phrase_eval.py'),*args]),h.ref(root/'fake-host-launch.json'))
    with self.assertRaisesRegex(ValueError,'overwrite'):h.execute(value,args)
 def test_cli_failure_preserves_failed_evidence_and_restores_globals(self):
  with tempfile.TemporaryDirectory() as tmp:
   root=Path(tmp);app,path,_=self.fixture(root)
   with mock.patch.object(h,'HERE',root),mock.patch.object(h,'ROOT',app):
    value=h.load_plan(path,h.sha(path));argv=h.sys.argv
    with self.assertRaisesRegex(RuntimeError,'synthetic failure'):h.execute(value,['run','--label','failed','--output',str(root/'failed'),'--synthetic-failure'])
    self.assertIs(h.sys.argv,argv);self.assertEqual(h.read(root/'failed-host-launch.json')['status'],'failed')
    with self.assertRaisesRegex(ValueError,'fresh-build'):h.execute(value,['run','--skip-build'])
 def test_optional_admission_is_baseline_validation_only(self):
  self.assertIsNone(h.admission(argparse.Namespace()))
  with mock.patch.object(h,'load_plan',return_value={'checked':True}):
   self.assertEqual(h.admission(argparse.Namespace(candidate='baseline',phase='validation',launch_plan='p',launch_plan_sha256='s')),{'checked':True})
   for candidate,phase in [('H1','validation'),('baseline','screening')]:
    with self.assertRaises(ValueError):h.admission(argparse.Namespace(candidate=candidate,phase=phase,launch_plan='p',launch_plan_sha256='s'))
 def test_latency_boundary_requires_exact_registered_wrapper_prefix(self):
  label='latency-baseline-2';value={'wrapper':{'path':'/round/wrapper.py'},'plan':{'path':'/round/plan.json','sha256':'a'*64}}
  original=['python',str(h.ROOT/'scripts/phrase_eval.py'),'run','--label',label];wrapped=h.wrap_command(original,value)
  collector=argparse.Namespace(sample=mock.Mock(return_value={'processes':[]}))
  with mock.patch.object(latency.runner.run_checks,'bounded_command') as launch:
   with latency.before_cli_observation(collector,label,value):latency.runner.run_checks.bounded_command(wrapped,None)
   launch.assert_called_once();collector.sample.assert_called_once_with('before-cli-launch')
   bad=list(wrapped);bad[5]='wrong'
   with self.assertRaisesRegex(ValueError,'wrapper identity'):
    with latency.before_cli_observation(collector,label,value):latency.runner.run_checks.bounded_command(bad,None)
 def test_latency_hidden_host_needs_artifact_and_live_argument_pair(self):
  with tempfile.TemporaryDirectory() as tmp:
   root=Path(tmp);label='latency-baseline-2';launch={'plan':{'path':'registered','sha256':'a'*64}}
   with mock.patch.object(latency,'HERE',root),mock.patch.object(latency.runner,'ROOT',root/'app'),mock.patch.object(h,'recheck'):
    host=latency.HostedTestIdentity(label,root,launch);start=dt.datetime(2026,9,17,15,0,tzinfo=dt.timezone.utc).timestamp();stamp=dt.datetime.fromtimestamp(start).strftime('%a %b %d %H:%M:%S %Y')
    make=lambda pid,ppid,command:dict(pid=pid,ppid=ppid,pgid=pid,startedLocal=stamp,cpuPercent=0,command=command)
    host.baseline({},dt.datetime.fromtimestamp(start,dt.timezone.utc).isoformat());(root/(label+'-registration.json')).write_text(json.dumps({'inferenceStartedUTC':dt.datetime.fromtimestamp(start,dt.timezone.utc).isoformat()}))
    config=root/'app/build/DerivedData/Build/Products/Cotabby_phrase-eval-hidden.xctestrun';config.parent.mkdir(parents=True);config.write_bytes(plistlib.dumps({'target':{'TestBundlePath':'CotabbyTests.xctest','EnvironmentVariables':host.expected,'CommandLineArguments':['-cotabby-debug',*h.HOST_ARGS]}}))
    launcher=dict(make(10,9,'xcodebuild test-without-building -xctestrun '+str(config)),ownership='owned',ancestryEvidence=[])
    child=make(11,1,host.executable);observed=dt.datetime.fromtimestamp(start+1,dt.timezone.utc).isoformat()
    env=' '.join(key+'='+value for key,value in host.expected.items())
    with mock.patch.object(latency.subprocess,'run',return_value=types.SimpleNamespace(stdout=env)):
     rows=[copy.deepcopy(launcher),dict(child,ownership='external')];host.annotate({10:launcher,11:child},rows,observed);self.assertEqual(rows[1]['ownership'],'external')
     child['command']+=' -cotabbyMenuBarIconVisible NO';rows=[copy.deepcopy(launcher),dict(child,ownership='external')];host.annotate({10:launcher,11:child},rows,observed);self.assertEqual(rows[1]['ownership'],'authorized-host')
     child['command']=host.executable;rows=[copy.deepcopy(launcher),dict(child,ownership='external')];host.annotate({10:launcher,11:child},rows,observed);self.assertEqual(rows[1]['ownership'],'external')
if __name__=='__main__':unittest.main()
