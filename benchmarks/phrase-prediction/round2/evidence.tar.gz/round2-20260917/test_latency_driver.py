"""Synthetic process/interval tests; never invokes actual benchmark or ps."""
import copy,datetime as dt,json,plistlib,tempfile,types,unittest
from pathlib import Path
from unittest import mock
import run_latency_baseline as d
STAMP='Thu Sep 17 06:00:00 2026'
def proc(pid,ppid,cmd,cpu=0,start=STAMP):return {'pid':pid,'ppid':ppid,'pgid':pid,'startedLocal':start,'cpuPercent':cpu,'command':cmd}
def utc(n):return dt.datetime.fromtimestamp(n,dt.timezone.utc).isoformat()
def sample(n,external=False):return {'observedUTC':utc(n),'finishedUTC':utc(n+.01),'monotonicSeconds':n,'processes':[{'ownership':'external','command':'xcodebuild'}] if external else []}
class LatencyDriver(unittest.TestCase):
 def test_registered_plan_one_worker_original_screen_seed42(self):
  for label in d.LABELS:
   args=d.prepare(label)['args'];self.assertEqual((args.candidate,args.phase,args.workers,args.split,args.mode,args.seed,args.estimated_seconds),('baseline','validation',1,'screen','word',42,600));self.assertIsNone(args.corpus)
  with self.assertRaises(ValueError):d.prepare('another-label')
 def test_parse_preserves_full_command_and_identity(self):
  rows=d.parse_processes(' 10 1 10 Thu Sep 17 06:00:00 2026 5.5 /path/host --flag two words\n');self.assertEqual(rows[10]['command'],'/path/host --flag two words');self.assertEqual(rows[10]['cpuPercent'],5.5)
  with self.assertRaises(ValueError):d.parse_processes('broken row')
 def test_ancestry_requires_witnessed_chain_and_rejects_pid_reuse(self):
  owner=proc(10,1,'python driver');child=proc(11,10,'xcodebuild test');other=proc(12,1,'xcodebuild test');known={}
  result=d.observe_processes({10:owner,11:child,12:other},10,d.identity(owner),known);self.assertEqual({r['pid']:r['ownership'] for r in result},{10:'owned',11:'owned',12:'external'})
  child['ppid']=1;self.assertEqual([r for r in d.observe_processes({10:owner,11:child},10,d.identity(owner),known) if r['pid']==11][0]['ownership'],'owned')
  child['startedLocal']='Thu Sep 17 06:01:00 2026';self.assertEqual([r for r in d.observe_processes({10:owner,11:child},10,d.identity(owner),known) if r['pid']==11][0]['ownership'],'external')
 def test_other_analyzer_and_cpu_load_external(self):
  owner=proc(10,1,'python run_latency_baseline.py');other=proc(12,1,'python analyze_phrase_experiments.py');heavy=proc(13,1,'other-app',70)
  rows=d.observe_processes({10:owner,12:other,13:heavy},10,d.identity(owner),{});self.assertEqual([r['ownership'] for r in rows if r['pid']!=10],['external','external'])
 def test_swift_build_service_requires_owned_builder_ancestry(self):
  owner=proc(10,1,'python run_latency_baseline.py');cli=proc(11,10,'python phrase_eval.py run');builder=proc(12,11,'xcodebuild build-for-testing')
  service=proc(13,12,'/Xcode/SwiftBuild.framework/SWBBuildService',64);unrelated=proc(14,1,'/Xcode/SwiftBuild.framework/SWBBuildService',64)
  rows=d.observe_processes({p['pid']:p for p in (owner,cli,builder,service,unrelated)},10,d.identity(owner),{})
  by_pid={r['pid']:r for r in rows};self.assertEqual(by_pid[13]['ownership'],'owned');self.assertEqual(by_pid[14]['ownership'],'external');self.assertEqual([p['pid'] for p in by_pid[13]['ancestryEvidence']],[13,12,11,10])
 def test_interval_requires_bracketing_continuity_complete_run(self):
  reg={'status':'complete','inferenceStartedUTC':utc(1),'finishedUTC':utc(4)};samples=[sample(n) for n in range(6)];self.assertEqual(d.isolation_findings(samples,[],reg),([],[]))
  for changed in ([sample(0),sample(7)],samples[1:],samples[:-2]):self.assertTrue(d.isolation_findings(changed,[],reg)[0])
  self.assertTrue(d.isolation_findings(samples,[{'error':'ps failed'}],reg)[0]);self.assertTrue(d.isolation_findings(samples,[],dict(reg,status='failed'))[0])
 def test_prechecks_excluded_but_external_within_interval_fails(self):
  reg={'status':'complete','inferenceStartedUTC':utc(1),'finishedUTC':utc(4)};samples=[sample(n,external=n==0) for n in range(6)];self.assertEqual(d.isolation_findings(samples,[],reg),([],[]))
  samples[2]=sample(2,True);issues,external=d.isolation_findings(samples,[],reg);self.assertTrue(issues);self.assertEqual(len(external),1)
 def test_owned_setup_is_separate_from_concurrent_compilation(self):
  reg={'status':'complete','inferenceStartedUTC':utc(1),'finishedUTC':utc(4)};samples=[sample(n) for n in range(6)]
  compiler={'ownership':'owned','categories':['build'],'command':'xcodebuild build-for-testing'}
  samples[1]['processes']=[compiler]
  for i in (2,3):samples[i]['processes']=[{'ownership':'authorized-host','categories':['inference-or-benchmark']}]
  self.assertEqual(d.isolation_findings(samples,[],reg),([],[]));self.assertEqual(len(d.activity_phases(samples)['ownedSetupOrPostprocessing']),1)
  samples[2]['processes'].append(compiler);self.assertTrue(d.isolation_findings(samples,[],reg)[0])
 def test_environment_matching_exact_without_unknown_values(self):
  expected={'COTABBY_PHRASE_LABEL':'latency-baseline-1','COTABBY_PHRASE_WORKERS':'1'}
  self.assertEqual(d.environment_matches('SECRET=hidden COTABBY_PHRASE_LABEL=latency-baseline-1 COTABBY_PHRASE_WORKERS=1',expected),{k:True for k in expected})
  self.assertFalse(d.environment_matches('COTABBY_PHRASE_LABEL=latency-baseline-10',expected)['COTABBY_PHRASE_LABEL'])
 def test_external_arguments_are_not_retained_even_in_failure_evidence(self):
  external=dict(proc(12,1,'python analyzer.py --token SECRET'),ownership='external',categories=['heavy-analysis'],executable='/usr/bin/python',ancestryEvidence=[])
  retained=d.retain_process(external);self.assertNotIn('SECRET',json.dumps(retained));self.assertNotIn('command',retained);self.assertEqual(retained['executable'],'/usr/bin/python')
  self.assertEqual(d.retain_process(dict(external,ownership='owned'))['command'],external['command'])
 def test_host_exception_exact_artifact_environment_and_single_new_host(self):
  with tempfile.TemporaryDirectory() as tmp:
   root=Path(tmp);label=d.LABELS[0]
   with mock.patch.object(d,'HERE',root),mock.patch.object(d.runner,'ROOT',root/'private'):
    host=d.HostedTestIdentity(label,root);start=d.process_started(proc(10,1,''));host.baseline({},utc(start));d.write_new(root/(label+'-registration.json'),{'inferenceStartedUTC':utc(start)})
    config=root/'private/build/DerivedData/Build/Products/Cotabby_phrase-eval-test.xctestrun';config.parent.mkdir(parents=True);config.write_bytes(plistlib.dumps({'target':{'EnvironmentVariables':dict(host.expected,UNRELATED_SECRET='do-not-retain')}}))
    launcher=dict(proc(11,10,'xcodebuild test-without-building -xctestrun '+str(config)),ownership='owned',ancestryEvidence=[{'pid':10}]);child=proc(12,1,host.executable);rows=[copy.deepcopy(launcher),dict(child,ownership='external')]
    env=' '.join(k+'='+v for k,v in host.expected.items())+' SECRET=unretained'
    with mock.patch.object(d.subprocess,'run',return_value=types.SimpleNamespace(stdout=env)) as query:
     host.annotate({11:launcher,12:child},rows,utc(start+1));self.assertEqual(rows[1]['ownership'],'authorized-host');query.assert_called_once();self.assertNotIn('SECRET',json.dumps(host.authorized))
     self.assertTrue(list(root.glob('launch-*.json')))
     for saved in root.glob('launch-*.json'):self.assertNotIn('do-not-retain',saved.read_text());self.assertNotIn('UNRELATED_SECRET',saved.read_text())
    with self.assertRaises(RuntimeError):host.baseline({12:child},utc(start))
    rows=[copy.deepcopy(launcher),dict(child,ownership='owned'),dict(proc(13,11,host.executable),ownership='owned')];host.annotate({11:launcher,12:child,13:rows[2]},rows,utc(start+2));self.assertTrue(all(r['ownership']=='external' for r in rows[1:]))
    self.assertFalse(host.exact_host(proc(14,1,'/other/Cotabby.app/Contents/MacOS/Cotabby')))
    fresh=d.HostedTestIdentity(label,root);fresh.baseline({},utc(start));rows=[copy.deepcopy(launcher),dict(child,ownership='external')]
    with mock.patch.object(d.subprocess,'run',return_value=types.SimpleNamespace(stdout='COTABBY_PHRASE_LABEL=other')):
     fresh.annotate({11:launcher,12:child},rows,utc(start+1));self.assertEqual(rows[1]['ownership'],'external')
 def test_cli_boundary_observed_and_adapter_restored_after_failure(self):
  before=d.runner.run_checks.bounded_command;label=d.LABELS[0];collector=types.SimpleNamespace(sample=mock.Mock(return_value={'processes':[]}));command=['python',str(d.runner.ROOT/'scripts/phrase_eval.py'),'run','--label',label]
  with mock.patch.object(d.runner.run_checks,'bounded_command',side_effect=RuntimeError('fake child')) as child:
   with self.assertRaisesRegex(RuntimeError,'fake child'):
    with d.before_cli_observation(collector,label):d.runner.run_checks.bounded_command(command,None)
   self.assertIs(d.runner.run_checks.bounded_command,child)
  self.assertIs(d.runner.run_checks.bounded_command,before);collector.sample.assert_called_once_with('before-cli-launch')
 def test_exact_deadline_restored(self):
  previous=d.runner.DEADLINE
  with self.assertRaises(RuntimeError):
   with d.exact_deadline(500):self.assertEqual(d.runner.DEADLINE,1700);raise RuntimeError()
  self.assertEqual(d.runner.DEADLINE,previous)

class LatencyRetry(unittest.TestCase):
 def fixture(self,root):
  freeze=d.read(d.HERE/'finalist-freeze.json');original=d.read(d.HERE/'baseline-workloads.json')
  d.write_new(root/'finalist-freeze.json',freeze);original['freezeSHA256']=d.sha(root/'finalist-freeze.json');d.write_new(root/'baseline-workloads.json',original)
  base='latency-baseline-1';folder=root/(base+'-isolation-evidence');folder.mkdir()
  arguments={'label':base,'candidate':'baseline','phase':'validation','split':'screen','mode':'word','seed':42,'workers':1,'per_category':None,'corpus':None,'estimated_seconds':600,'reuse_checks':'baseline-checks','descriptive_workload':None,'descriptive_workload_sha256':None}
  d.write_new(folder/'plan.json',{'schemaVersion':1,'label':base,'preparedUTC':'2026-09-17T15:00:00Z','arguments':arguments,'workload':d.ref(root/'baseline-workloads.json'),'freeze':d.ref(root/'finalist-freeze.json')})
  (folder/'process-observations.jsonl').write_text('{}\n')
  d.write_new(folder/'summary.json',{'schemaVersion':1,'label':base,'finishedUTC':'2026-09-17T15:00:01Z','registration':None,'issues':['busy'],'plan':d.ref(folder/'plan.json'),'observations':d.ref(folder/'process-observations.jsonl')})
  proof=root/(base+'-isolation.json');d.write_new(proof,{'schemaVersion':1,'status':'failed','labels':[base],'intervals':[],'noOverlappingBuildOrInference':False,'evidence':d.ref(folder/'summary.json')})
  row=copy.deepcopy(next(row for row in original['runs'] if row['label']==base));row.update(label=base+'-retry1',name='latency-one-retry1',originalAttempt={'label':base,'isolation':d.ref(proof)})
  extension={key:copy.deepcopy(value) for key,value in original.items() if key!='runs'};extension.update(registeredUTC='2026-09-17T15:00:02Z',runs=[row]);path=root/'retry-workload.json';d.write_new(path,extension)
  return path,extension
 def test_retry_requires_exact_explicit_registered_scope_and_preserved_origin(self):
  with tempfile.TemporaryDirectory() as tmp:
   root=Path(tmp);path,extension=self.fixture(root);label=extension['runs'][0]['label']
   with mock.patch.object(d,'HERE',root):
    plan=d.prepare(label,path,d.sha(path));self.assertEqual(plan['args'].workers,1);self.assertEqual(len(plan['originArtifacts']),5)
    for path_arg,hash_arg in ((None,None),(path,None),(None,d.sha(path)),(path,'0'*64)):
     with self.subTest(path=path_arg,sha=hash_arg),self.assertRaises(ValueError):d.prepare(label,path_arg,hash_arg)
    for field,value in [('seed',1337),('workerCount',3),('workerCount',True),('mode','character'),('selection','all'),('estimatedSeconds',601),('perCategory',20),('name','latency-one')]:
     changed=copy.deepcopy(extension);changed['runs'][0][field]=value;path.write_text(json.dumps(changed))
     with self.subTest(field=field,value=value),self.assertRaises(ValueError):d.prepare(label,path,d.sha(path))
    path.write_text(json.dumps(extension));origin=root/'latency-baseline-1-isolation.json';original_bytes=origin.read_bytes();origin.write_text('{}')
    with self.assertRaisesRegex(ValueError,'artifact changed'):d.prepare(label,path,d.sha(path))
    origin.write_bytes(original_bytes);(root/'latency-baseline-1-registration.json').write_text('{}')
    with self.assertRaisesRegex(ValueError,'without benchmark registration'):d.prepare(label,path,d.sha(path))
 def test_retry_rejects_wrong_origin_label_and_future_or_preorigin_registration(self):
  with tempfile.TemporaryDirectory() as tmp:
   root=Path(tmp);path,extension=self.fixture(root);label=extension['runs'][0]['label']
   with mock.patch.object(d,'HERE',root):
    for when in ('2026-09-17T14:59:59Z','2099-01-01T00:00:00Z'):
     changed=copy.deepcopy(extension);changed['registeredUTC']=when;path.write_text(json.dumps(changed))
     with self.assertRaises(ValueError):d.prepare(label,path,d.sha(path))
    changed=copy.deepcopy(extension);changed['runs'][0]['originalAttempt']['label']='latency-baseline-2';path.write_text(json.dumps(changed))
    with self.assertRaisesRegex(ValueError,'original baseline latency'):d.prepare(label,path,d.sha(path))
 def test_read_only_preflight_never_writes_or_launches_and_sanitizes_backup(self):
  external=dict(proc(740,1,'backupd --unrelated-secret hidden',64),ownership='external',categories=['high-cpu'],executable='/System/backupd')
  with mock.patch.object(d,'process_snapshot',return_value=({740:external},[external],'owner')),mock.patch.object(d,'write_new') as write,mock.patch.object(d.runner,'run') as run:
   result=d.quiet_preflight();self.assertEqual(result['status'],'busy');self.assertFalse(result['labelConsumed']);self.assertFalse(result['artifactsWritten']);self.assertNotIn('hidden',json.dumps(result));write.assert_not_called();run.assert_not_called()
  with mock.patch.object(d,'process_snapshot',return_value=({},[],'owner')):self.assertEqual(d.quiet_preflight()['status'],'quiet-now')
  with mock.patch.object(d,'process_snapshot',side_effect=RuntimeError('sample failed')):self.assertEqual(d.quiet_preflight()['status'],'observation-failed')

if __name__=='__main__':unittest.main()
