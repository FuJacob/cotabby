#!/usr/bin/env python3
"""Run the registered single alternatives sequentially and publish observed counts.

This finite queue owns scheduling only. The experiment runner still owns source selection,
correctness checks, admission before the freeze deadline, and scored replay. A failed attempt
stops the queue for inspection rather than silently retrying or changing the experiment.
"""
import datetime
import fcntl
import json
from pathlib import Path
import subprocess
import sys

HERE = Path(__file__).resolve().parent
CANDIDATES = [f'{family}{index}' for family in 'HFM' for index in range(1, 5)]


def run():
    for candidate in CANDIDATES:
        label = 'screen-' + candidate
        registration = HERE / (label + '-registration.json')
        if registration.exists():
            if json.loads(registration.read_text())['status'] == 'complete':
                continue
            raise ValueError(f'{label} has incomplete evidence; inspect before resuming')
        print(f'{datetime.datetime.now(datetime.timezone.utc).isoformat()} Starting {candidate}', flush=True)
        with (HERE / (label + '.orchestrator.log')).open('x') as stream:
            subprocess.run([sys.executable, str(HERE / 'run_experiment.py'), label,
                '--candidate', candidate, '--estimated-seconds', '360'],
                cwd=HERE, stdout=stream, stderr=subprocess.STDOUT, check=True)
        subprocess.run([sys.executable, str(HERE / 'summarize_screening.py')], cwd=HERE, check=True)
    print('All 12 registered single alternatives have complete screening evidence.', flush=True)


if __name__ == '__main__':
    with (HERE / 'singles-queue.lock').open('a') as lock:
        fcntl.flock(lock.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        run()
