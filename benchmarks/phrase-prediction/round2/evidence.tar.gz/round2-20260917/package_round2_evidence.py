#!/usr/bin/env python3
"""Preserve a compact, hash-addressed copy of the completed round's text evidence.

This packaging boundary does not choose results or rescore outputs. It copies final
assessments for easy review and archives the underlying records, fixtures, patches and
drivers so deleting compiler caches cannot erase the experiment's provenance.
"""
import argparse
import contextlib
import datetime
import fcntl
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import tarfile
import tempfile

HERE = Path(__file__).resolve().parent
MAIN = HERE.parents[2]
DESTINATION = MAIN / 'benchmarks/phrase-prediction/round2'
TEXT_SUFFIXES = {'.json', '.jsonl', '.md', '.py', '.swift', '.cpp', '.h', '.patch', '.log', '.txt',
                 '.plist', '.xctestrun', '.xcworkspacedata', '.resolved', '.before'}
REVIEW_FILES = ['RESULTS.md', 'baseline-characterization.json', 'decision-assessment.json',
                'screening-ranking.json', 'screening-diagnostics.md', 'finalist-freeze.json',
                'baseline-workloads.json', 'reproduction-notes.md']


def sha(path):
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(block)
    return digest.hexdigest()


def read(path):
    return json.loads(path.read_text())


def write(path, value):
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')


def prepare_sources():
    execution = read(HERE / 'execution.json')
    app = Path(execution['root'])
    with (HERE / 'frozen-evaluation-harness.patch').open('wb') as stream:
        subprocess.run(['git', 'diff', '--binary', '--', 'CotabbyTests', 'scripts'], cwd=app,
                       stdout=stream, check=True)
    # New fixture-pathway files can be untracked, so include their exact source bytes too.
    files = subprocess.check_output(['git', 'ls-files', '--others', '--exclude-standard',
                                     '--', 'CotabbyTests', 'scripts'], cwd=app).decode().splitlines()
    untracked = HERE / 'frozen-evaluation-untracked'
    for name in files:
        source = app / name
        if source.is_file() and not source.is_symlink():
            target = untracked / name
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(source, target)
    # Integration preparation deliberately reused this round-one inventory helper.
    # Preserve that imported source without altering the original driver path strings.
    dependency = HERE / 'historical-harness-dependencies/prepare_integration_snapshot.py'
    dependency.parent.mkdir(exist_ok=True)
    shutil.copyfile(HERE.parent / 'round1-20260917/prepare_integration_snapshot.py', dependency)
    source_map = []

    def preserve(source, relative, expected=None):
        source = Path(source)
        if source.is_symlink() or not source.is_file():
            raise ValueError('Expected a regular evidence source: ' + str(source))
        identity = sha(source)
        if expected is not None and identity != expected:
            raise ValueError('Frozen source changed: ' + str(source))
        target = HERE / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(source, target)
        if sha(target) != identity or sha(source) != identity:
            raise ValueError('Source changed while preserving: ' + str(source))
        source_map.append({'originalPath': str(source), 'archivePath': relative,
                           'sha256': identity, 'present': True})

    frozen = read(HERE / 'finalist-freeze.json')
    old_manifest = read(HERE / 'screen-baseline/manifest.json')
    preserve(app / 'CotabbyTests/Fixtures/phrase-prediction-1337.json',
             'frozen-validation-fixtures/phrase-prediction-1337.json', old_manifest['corpusSHA256'])
    for name, expected in frozen['validationHarnessHashes'].items():
        if not name.startswith('app/'):
            raise ValueError('Unrecognized validation harness namespace')
        preserve(app / name.removeprefix('app/'), 'frozen-validation-harness/' + name, expected)
    for name, report_label in (('execution.json', 'fullproduction-baseline'),
                               ('integration-execution.json', 'integration-production-baseline')):
        settings = read(HERE / name)
        workspace = Path(settings['workspace']) / 'contents.xcworkspacedata'
        preserve(workspace, 'frozen-' + name.removesuffix('.json') + '.xcworkspacedata')
        manifest = read(HERE / report_label / 'manifest.json')
        for index, (original, expected) in enumerate(sorted(manifest['buildInputs']['packageLocks'].items())):
            if expected is None:
                if Path(original).exists():
                    raise ValueError('Previously absent dependency lock appeared: ' + original)
                source_map.append({'originalPath': original, 'present': False, 'sha256': None,
                                   'archivePath': None})
            else:
                preserve(original, f'frozen-dependency-locks/{report_label}/{index}/Package.resolved', expected)
    # Include the user-facing checklist in the same immutable inventory as the raw evidence.
    preserve(MAIN / 'IMPROVEMENT_BRAINSTORMING_ROUND_TWO.md', 'final-checklist.md')
    write(HERE / 'preserved-source-map.json', {'schemaVersion': 1, 'sources': source_map})


def inventory():
    files = [path for path in HERE.rglob('*') if path.is_file() and not path.is_symlink()
             and path.suffix in TEXT_SUFFIXES and '__pycache__' not in path.parts]
    return [{'path': str(path.relative_to(HERE)), 'bytes': path.stat().st_size,
             'sha256': sha(path)} for path in sorted(files)]


def package():
    if DESTINATION.exists():
        raise ValueError('Refusing to overwrite an existing durable round-two package')
    decision = read(HERE / 'decision-assessment.json')
    characterization = read(HERE / 'baseline-characterization.json')
    if decision['status'] != 'retained-baseline' or characterization['status'] != 'descriptive-only':
        raise ValueError('Final package requires the validated retained-baseline decision and characterization')
    active = read(HERE / 'active.json')
    if active.get('status') in ('checking', 'running', 'validated-awaiting-preservation-proof'):
        raise ValueError('An experiment is still active')
    prepare_sources()
    entries = inventory()
    expected_hashes = {entry['path']: entry['sha256'] for entry in entries}
    DESTINATION.parent.mkdir(parents=True, exist_ok=True)
    # A failed verification leaves no half-published durable package. Only this tool's
    # private staging directory is removed on failure; original experiment evidence stays.
    with tempfile.TemporaryDirectory(prefix='.round2-package-', dir=DESTINATION.parent) as temporary:
        stage = Path(temporary) / 'round2'
        stage.mkdir()
        package_to_stage(stage, entries, expected_hashes)
        if inventory() != entries:
            raise ValueError('Evidence changed during packaging')
        if DESTINATION.exists():
            raise ValueError('Destination appeared during packaging')
        stage.rename(DESTINATION)
    archive = DESTINATION / 'evidence.tar.gz'
    print(json.dumps({'status': 'verified', 'destination': str(DESTINATION),
                      'files': len(entries), 'archiveBytes': archive.stat().st_size}, indent=2))


def package_to_stage(stage, entries, expected_hashes):
    archive = stage / 'evidence.tar.gz'
    with tarfile.open(archive, 'w:gz', compresslevel=9) as bundle:
        for item in entries:
            path = HERE / item['path']
            if sha(path) != item['sha256']:
                raise ValueError('Evidence changed during packaging: ' + item['path'])
            bundle.add(path, arcname='round2-20260917/' + item['path'], recursive=False)
    for name in REVIEW_FILES:
        shutil.copyfile(HERE / name, stage / name)
        if sha(stage / name) != expected_hashes[name]:
            raise ValueError('Review copy differs from archived evidence: ' + name)
    checklist = 'IMPROVEMENT_BRAINSTORMING_ROUND_TWO.md'
    shutil.copyfile(HERE / 'final-checklist.md', stage / checklist)
    if sha(stage / checklist) != expected_hashes['final-checklist.md']:
        raise ValueError('Checklist copy differs from archived evidence')
    with tarfile.open(archive, 'r:gz') as bundle:
        members = {member.name: member for member in bundle.getmembers()}
        if len(members) != len(entries):
            raise ValueError('Archive member count differs from the evidence inventory')
        for item in entries:
            member = members['round2-20260917/' + item['path']]
            stream = bundle.extractfile(member)
            digest = hashlib.file_digest(stream, 'sha256').hexdigest()
            if member.size != item['bytes'] or digest != item['sha256']:
                raise ValueError('Archive verification failed: ' + item['path'])
    manifest = {'schemaVersion': 1, 'createdUTC': datetime.datetime.now(datetime.timezone.utc).isoformat(),
                'purpose': 'Durable text evidence; original absolute paths remain provenance, not portable execution promises.',
                'originalEvidenceDirectory': str(HERE), 'modelIncluded': False, 'compilerProductsIncluded': False,
                'archive': {'path': archive.name, 'sha256': sha(archive), 'bytes': archive.stat().st_size},
                'files': entries,
                'reviewCopies': {name: sha(stage / name) for name in [*REVIEW_FILES, checklist]}}
    write(stage / 'manifest.json', manifest)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--execute', action='store_true', required=True,
                        help='Package only after all benchmark and analysis writers have stopped')
    parser.parse_args()
    with contextlib.ExitStack() as stack:
        for name in ('experiment.lock', 'descriptive-analysis.lock'):
            lock = stack.enter_context((HERE / name).open('a'))
            fcntl.flock(lock.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        package()
