#!/usr/bin/env python3
"""Describe registered runs of the retained baseline; never make an adoption decision.

The immutable round assessor owns correctness/provenance checks. This separate boundary
adds within-run context contrasts, matched seed comparisons, and exact integration parity.
Only aggregate observations are emitted. There is no inference or lexical rescoring.
"""
from __future__ import annotations

import argparse
import collections
import datetime as dt
from fractions import Fraction
import importlib.util
import json
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent
SPEC = importlib.util.spec_from_file_location('round2_frozen_assessment', HERE / 'assess_round2.py')
BASE = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(BASE)
require = BASE.require
EvidenceError = BASE.EvidenceError
KINDS = {'freshWord', 'historicalWord', 'historicalCharacter', 'freshCharacter', 'latency'}
SEEDS = {42, 1337, 12648430}


def without_latency(value):
    """Accuracy-run timings are contended diagnostics, not isolated latency evidence."""
    if isinstance(value, dict):
        return {key: without_latency(item) for key, item in value.items() if not key.startswith('latency')}
    if isinstance(value, list):
        return [without_latency(item) for item in value]
    return value


def subset_metrics(indexed, subset):
    selected = BASE.subset_index(indexed, subset)
    result = {}
    for condition in sorted(BASE.CONDITIONS):
        categories = sorted({row['phrase']['category'] for (_, key), row in selected.items() if key == condition})
        result[condition] = {}
        for category in ('suite', *categories):
            rows = [row for (_, key), row in selected.items() if key == condition
                    and (category == 'suite' or row['phrase']['category'] == category)]
            result[condition][category] = dict(BASE.metrics([o for row in rows for o in row['observations']]),
                                               phraseCount=len(rows))
    return result


def context_contrast(indexed, analyzer, subset='word', context_kind=None):
    """Project paired conditions into one contrast, retaining each family's identity.

    One checkpoint contributes once. A single synthetic condition key prevents the
    bootstrap from treating two copies of the same screen-minus-none effect as evidence.
    """
    selected = BASE.subset_index(indexed, subset, context_kind)
    before, after = {}, {}
    ids = sorted({identifier for identifier, _ in selected})
    for identifier in ids:
        a, b = selected[(identifier, 'none')], selected[(identifier, 'screen')]
        require(a['phrase'] == b['phrase'] and [o['checkpoint'] for o in a['observations']] ==
                [o['checkpoint'] for o in b['observations']], 'Context contrast inputs differ')
        key = (identifier, 'screenMinusNone')
        before[key] = dict(a, condition='screenMinusNone')
        after[key] = dict(b, condition='screenMinusNone')
    bootstrap = analyzer.paired_statistics(before, after, samples=20000, seed=1337, metric='all')
    categories = sorted({row['phrase']['category'] for row in before.values()})
    deltas = {}
    for category in ('suite', *categories):
        keys = [key for key, row in before.items() if category == 'suite' or row['phrase']['category'] == category]
        a = [o for key in keys for o in before[key]['observations']]
        b = [o for key in keys for o in after[key]['observations']]
        no_screen, screen = BASE.metrics(a), BASE.metrics(b)
        delta = Fraction(screen['correct'] - no_screen['correct'], len(a))
        deltas[category] = {'withoutScreen': no_screen, 'withScreen': screen,
                            'accuracyDelta': float(delta), 'deltaNumerator': delta.numerator,
                            'deltaDenominator': delta.denominator,
                            'helped': sum(not x['correct'] and y['correct'] for x, y in zip(a, b)),
                            'harmed': sum(x['correct'] and not y['correct'] for x, y in zip(a, b))}
    return {'comparisonType': 'within-run screen minus none', 'subset': subset, 'contextKind': context_kind,
            'deltas': deltas, 'bootstrap': bootstrap}


def seed_comparison(reference, comparison, analyzer, subset='word'):
    require(reference['metadata']['seed'] != comparison['metadata']['seed'], 'Seed comparison requires different inference seeds')
    require(reference['manifest']['workerCount'] == comparison['manifest']['workerCount'], 'Seed comparison changed worker count')
    ignored = {'randomSeed'}
    clean = lambda run: {key: value for key, value in run['metadata']['configuration'].items() if key not in ignored}
    require(clean(reference) == clean(comparison), 'Seed comparison changed effective configuration beyond its seed')
    result = BASE.compare_indices(reference['index'], comparison['index'], analyzer, subset)
    for rows in result['deltas'].values():
        for row in rows.values():
            row['reference'] = row.pop('baseline')
            row['comparison'] = row.pop('finalist')
    return without_latency(dict(result, comparisonType='matched inference-seed sensitivity',
                                 referenceSeed=reference['metadata']['seed'], comparisonSeed=comparison['metadata']['seed']))


def exact_parity(reference, comparison):
    require(reference['metadata']['seed'] == comparison['metadata']['seed']
            and reference['metadata']['configuration'] == comparison['metadata']['configuration']
            and reference['manifest']['workerCount'] == comparison['manifest']['workerCount'],
            'Integration parity requires identical seed, configuration, and worker count')
    a, b = reference['index'], comparison['index']
    require(a.keys() == b.keys(), 'Integration parity changed paired phrase identities')
    fields = ('checkpoint', 'prompt', 'raw', 'shown', 'predictedWord', 'correct', 'wasShown', 'suppression')
    result = {condition: {'checkpoints': 0, 'anyMismatch': 0,
                         'fieldMismatches': {field: 0 for field in fields}} for condition in sorted(BASE.CONDITIONS)}
    for key in a:
        require(a[key]['phrase'] == b[key]['phrase'] and len(a[key]['observations']) == len(b[key]['observations']),
                'Integration parity changed input phrases/checkpoint counts')
        for first, second in zip(a[key]['observations'], b[key]['observations']):
            tally = result[key[1]]
            tally['checkpoints'] += 1
            differences = {field: first.get(field) != second.get(field) for field in fields}
            tally['anyMismatch'] += any(differences.values())
            for field, differs in differences.items():
                tally['fieldMismatches'][field] += differs
    return {'comparisonType': 'exact current-main runtime parity; latency excluded',
            'identical': not any(row['anyMismatch'] for row in result.values()), 'conditions': result}


class BaselineCharacterization(BASE.Assessment):
    """Reader for explicitly registered descriptive workloads after baseline retention."""
    def __init__(self, root):
        super().__init__(root)
        self.checkpoint_exporter = None
        self.workloads = {}
        self.descriptive_bindings = set()

    def add_binding(self, item):
        if 'compatibilityDifference' not in item:
            return super().add_binding(item)
        require(item['role'] == 'baseline' and BASE.is_hash(item['sourceSHA256'])
                and item['targets'] == self.frozen['baselineTargets'],
                'Compatibility binding must retain the frozen baseline target bytes')
        certificate = self.artifact(item['compatibilityDifference'])
        require(certificate.get('schemaVersion') == 1 and certificate.get('status') == 'reviewed'
                and certificate.get('reviewer') == '/root' and isinstance(certificate.get('rationale'), str)
                and certificate['rationale'].strip() and certificate.get('allOtherProductionInputsEqual') is True
                and certificate['baselineFreezeSHA256'] == BASE.digest(self.read_bytes('finalist-freeze.json')),
                'Current-main compatibility difference lacks an explicit frozen-decision review')
        require(BASE.timestamp(self.frozen['frozenUTC']) <= BASE.timestamp(certificate['reviewedUTC']),
                'Compatibility certificate predates this frozen decision')
        frozen = self.inventory(certificate['frozenInventory'])
        current = self.inventory(certificate['currentInventory'])
        require(frozen == self.inventories['baseline'] and self.inventory(item['productionInventory']) == current,
                'Compatibility certificate inventories do not bind the selected source')
        differences = certificate['differences']
        path = 'app/Cotabby/Support/Focus/Applications/BrowserAppDetector.swift'
        require(len(differences) == 1 and differences[0]['path'] == path,
                'Compatibility exception is limited to the reviewed BrowserAppDetector change')
        change = differences[0]
        require(change['beforeSHA256'] == frozen['files'].get(path) and change['afterSHA256'] == current['files'].get(path)
                and change['beforeSHA256'] != change['afterSHA256'], 'Compatibility before/after hashes disagree')
        expected = dict(frozen['files'], **{path: change['afterSHA256']})
        require(current['files'] == expected, 'Compatibility snapshot contains an additional production difference')
        self.artifact_path(certificate['diff'])
        scope = self.artifact(certificate['fixtureScopeProof'])
        require(scope.get('schemaVersion') == 1 and scope.get('status') == 'passed'
                and scope.get('affectedBundleIdentifiers') == ['com.openai.codex'], 'Compatibility fixture-scope proof changed')
        sources = {row['kind']: row for row in scope['sources']}
        require(len(sources) == len(scope['sources']) == 2
                and sources['historical']['corpusSHA256'] == BASE.OLD_CORPUS_SHA
                and sources['historical']['phraseCount'] == 1337
                and sources['fresh']['corpusSHA256'] == BASE.FRESH_CORPUS_SHA
                and sources['fresh']['phraseCount'] == 700
                and all(row['matchingScenarioCount'] == 0 for row in sources.values()),
                'Compatibility proof does not exclude the affected bundle from both exact corpora')
        require(item['label'] not in self.bindings or self.bindings[item['label']] == item, 'Conflicting compatibility source bindings')
        self.bindings[item['label']] = item
        self.descriptive_bindings.add(item['label'])

    def exporter(self, reference):
        record = self.artifact(reference)
        require(record.get('schemaVersion') == 1 and isinstance(record.get('compilerVersion'), str)
                and record['compilerVersion'].strip() and isinstance(record.get('manifests'), list)
                and record['manifests'], 'Checkpoint exporter provenance is incomplete')
        for name in ('scorerSource', 'helperSource', 'binary'):
            self.artifact_path(record[name])
        expected = self.frozen['validationHarnessHashes']['app/CotabbyTests/Evals/PhrasePredictionScoring.swift']
        require(record['scorerSource']['sha256'] == expected, 'Opaque checkpoint exporter uses a different frozen scorer')
        for item in record['manifests']:
            self.artifact_path(item)
        self.checkpoint_exporter = record

    def register_workload(self, reference):
        record = self.artifact(reference)
        require(record.get('schemaVersion') == 1 and record.get('candidate') == 'baseline'
                and isinstance(record.get('purpose'), str) and record['purpose'].strip(),
                'Workload must explicitly describe the retained baseline')
        require(record['freezeSHA256'] == BASE.digest(self.read_bytes('finalist-freeze.json')),
                'Workload is not bound to the frozen baseline decision')
        registered = BASE.timestamp(record['registeredUTC'])
        require(BASE.timestamp(self.frozen['frozenUTC']) <= registered <= BASE.timestamp(self.round_record['deadlineUTC']),
                'Descriptive workload registration is outside the frozen round window')
        rows = record['runs']
        require(isinstance(rows, list) and rows and len({row['label'] for row in rows}) == len(rows)
                and len({row['name'] for row in rows}) == len(rows), 'Duplicate/empty planned workload identities')
        for row in rows:
            require(row['kind'] in KINDS and type(row['seed']) is int and row['seed'] in SEEDS
                    and type(row['workerCount']) is int and row['workerCount'] in (1, 2, 3)
                    and type(row['perCategory']) is int and row['perCategory'] >= 0
                    and type(row['estimatedSeconds']) in (int, float) and row['estimatedSeconds'] > 0,
                    'Unsupported or unestimated descriptive workload')
            require(row['mode'] in ('word', 'character') and row['selection'] in ('all', 'screen')
                    and BASE.is_hash(row['corpusSHA256']), 'Malformed workload input identity')
            value = {'registration': record, 'row': row, 'artifact': reference}
            require(row['label'] not in self.workloads or self.workloads[row['label']] == value,
                    'A planned workload was redefined')
            self.workloads[row['label']] = value
        return record

    def validate_descriptive_cohort(self, plan, kind):
        BASE.validate_checkpoint_manifest(plan)
        require(plan['scorerSourceSHA256'] == self.checkpoint_exporter['scorerSource']['sha256'],
                'Descriptive checkpoint plan changed the scorer')
        categories = collections.Counter(row['category'] for row in plan['phrases'])
        require(set(categories) == BASE.CATEGORIES, 'Descriptive cohort must preserve all seven categories')
        fresh = kind in ('freshWord', 'freshCharacter')
        require(plan['corpusSHA256'] == (BASE.FRESH_CORPUS_SHA if fresh else BASE.OLD_CORPUS_SHA)
                and plan['corpusVersion'] == (3 if fresh else 2), 'Descriptive workload changed the frozen corpus')
        if fresh:
            require(plan['selection'] == 'all' and plan['perCategory'] == 0 and plan['phraseCount'] == 700
                    and set(categories.values()) == {100}, 'Fresh characterization requires the complete all700 cohort')
            require(plan['mode'] == ('word' if kind == 'freshWord' else 'character'), 'Wrong fresh workload mode')
            if kind == 'freshWord':
                require(plan['checkpointsPerCondition'] == 2892, 'Fresh word denominator changed')
        elif kind == 'historicalWord':
            require(plan['mode'] == 'word' and plan['selection'] == 'all' and plan['perCategory'] == 0
                    and plan['phraseCount'] == 1337 and set(categories.values()) == {191},
                    'Historical word characterization requires all1337 cases')
        elif kind == 'historicalCharacter':
            require(plan['mode'] == 'character' and plan['selection'] == 'all' and plan['perCategory'] in (0, 50, 150),
                    'Unregistered historical character population')
            size = plan['perCategory'] or 191
            require(plan['phraseCount'] == 7 * size and set(categories.values()) == {size},
                    'Historical character subset is incomplete')
        else:
            require(kind == 'latency' and plan['mode'] == 'word' and plan['perCategory'] == 0,
                    'Latency uses registered historical word cohorts')
            size = 20 if plan['selection'] == 'screen' else 191
            require(plan['phraseCount'] == 7 * size and set(categories.values()) == {size}, 'Latency cohort is incomplete')

    def validate_workload(self, spec, plan, registration):
        require(spec['label'] in self.workloads, 'Run lacks a hash-bound workload registration')
        workload = self.workloads[spec['label']]
        require(spec['workload'] == workload['artifact'], 'Run uses a different workload artifact than the declared plan')
        record, row = workload['registration'], workload['row']
        require(BASE.timestamp(record['registeredUTC']) <= BASE.timestamp(registration['startedUTC']),
                'Workload was registered after the run started')
        for key in ('name', 'label', 'kind', 'seed'):
            require(spec[key] == row[key], 'Descriptive run identity differs from its preregistered workload')
        for key in ('mode', 'corpusSHA256', 'selection', 'perCategory'):
            require(plan[key] == row[key], 'Opaque checkpoint selection differs from the preregistered workload')
        if spec['kind'] == 'freshCharacter':
            exception = self.artifact(row['guardException'])
            require(exception.get('schemaVersion') == 1 and exception.get('candidate') == 'baseline'
                    and exception.get('descriptiveOnly') is True and exception.get('allowedKind') == 'freshCharacter'
                    and exception.get('freezeSHA256') == record['freezeSHA256']
                    and isinstance(exception.get('reason'), str) and exception['reason'].strip()
                    and BASE.timestamp(self.frozen['frozenUTC']) <= BASE.timestamp(exception['registeredUTC'])
                    <= BASE.timestamp(record['registeredUTC']), 'Fresh-character guard exception is missing or overbroad')
            admitted = registration.get('validationAdmission', {}).get('descriptiveWorkload', {})
            require(admitted.get('descriptiveOnly') is True and admitted.get('kind') == 'freshCharacter'
                    and admitted.get('name') == row['name'] and admitted.get('seed') == row['seed']
                    and admitted.get('workerCount') == row['workerCount']
                    and admitted.get('estimatedSeconds') == row['estimatedSeconds'],
                    'Fresh-character run did not record the explicit descriptive admission')
            for name, expected in [('workload', workload['artifact']), ('guardException', row['guardException'])]:
                actual = admitted[name]
                require(actual['sha256'] == expected['sha256'] and self.path(actual['path']).resolve() == self.path(expected['path']).resolve(),
                        'Fresh-character admission artifacts differ from the registered evidence')
        else:
            require(row.get('guardException') is None, 'Unexpected workload guard exception')
        return row

    def load_descriptive_run(self, spec):
        require(spec['kind'] in KINDS and type(spec['seed']) is int and spec['seed'] in SEEDS,
                'Unsupported descriptive run kind/seed')
        require(spec['checkpoints'] in self.checkpoint_exporter['manifests'], 'Unbound checkpoint export')
        plan = self.artifact(spec['checkpoints'])
        self.validate_descriptive_cohort(plan, spec['kind'])
        registration = self.read_json(f"{spec['label']}-registration.json")
        host_launch = self.validate_host_launch(registration)
        workload = self.validate_workload(spec, plan, registration)
        if spec['label'] in self.descriptive_bindings:
            certificate = self.artifact(self.bindings[spec['label']]['compatibilityDifference'])
            require(BASE.timestamp(certificate['reviewedUTC']) <= BASE.timestamp(registration['startedUTC']),
                    'Compatibility difference was reviewed after the run started')
        seed_kind = {42: 'historical', 1337: 'freshSeed', 12648430: 'productionSeed'}[spec['seed']]
        run = self.load_run(spec['label'], 'baseline', plan, seed_kind)
        require(run['manifest']['workerCount'] == workload['workerCount'], 'Executed workers differ from registered workload')
        if spec['kind'] == 'latency':
            require(workload['workerCount'] == 1, 'Latency characterization requires a single worker')
        run.update(name=spec['name'], kind=spec['kind'], plan=plan, hostLaunch=host_launch)
        return run

    def validate_host_launch(self, registration):
        """Bind an optional process-local menu argument without trusting imported drivers."""
        admission = registration.get('hostLaunch')
        if admission is None:
            require('hostLaunchEvidence' not in registration, 'Host launch proof lacks its registered admission')
            return None
        args = ['-cotabbyMenuBarIconVisible', 'NO']
        require(isinstance(admission, dict) and set(admission) == {
                    'plan', 'wrapper', 'originalCLI', 'commandLineArguments', 'freezeSHA256', 'registeredUTC'},
                'Host launch admission has an unsupported shape')
        require(registration['candidate'] == 'baseline' and registration['phase'] == 'validation'
                and registration['status'] == 'complete' and self.frozen['candidate'] == 'baseline'
                and self.frozen['selectionQualified'] is False, 'Host launch evidence is baseline-only validation')
        plan = self.artifact(admission['plan'])
        freeze_sha = BASE.digest(self.read_bytes('finalist-freeze.json'))
        require(plan.get('schemaVersion') == 1 and plan.get('status') == 'registered'
                and plan.get('candidate') == 'baseline' and plan.get('target') == 'CotabbyTests'
                and plan.get('persistentPreferenceWrites') is False and plan.get('sourceOrBinaryChanges') is False
                and plan.get('commandLineArguments') == args == admission['commandLineArguments']
                and plan.get('freezeSHA256') == freeze_sha == admission['freezeSHA256']
                and plan.get('registeredUTC') == admission['registeredUTC'], 'Host launch plan exceeds its frozen UI scope')
        require(BASE.timestamp(self.frozen['frozenUTC']) <= BASE.timestamp(plan['registeredUTC'])
                <= BASE.timestamp(registration['startedUTC']), 'Host launch plan was not registered before this run')
        for key in ('wrapper', 'originalCLI'):
            require(plan[key] == admission[key], 'Host plan/admission source references disagree')
            self.artifact_path(admission[key])
        original = Path(self.read_json('execution.json')['root']) / 'scripts/phrase_eval.py'
        require(self.path(admission['wrapper']['path']).resolve() == (self.root / 'phrase_eval_hidden_host.py').resolve()
                and self.path(admission['originalCLI']['path']).resolve() == original.resolve()
                and admission['originalCLI']['sha256'] == self.frozen['validationHarnessHashes']['app/scripts/phrase_eval.py'],
                'Host launch wrapper or original frozen CLI path/hash changed')
        command = registration['command']
        prefix = [admission['wrapper']['path'], '--launch-plan', admission['plan']['path'],
                  '--launch-plan-sha256', admission['plan']['sha256'], '--', 'run']
        require(isinstance(command, list) and all(isinstance(item, str) for item in command)
                and command[1:8] == prefix and '--skip-build' not in command[8:],
                'Registered host command differs from the exact frozen wrapper admission')
        sidecar_ref = registration['hostLaunchEvidence']
        require(self.path(sidecar_ref['path']).resolve() == (self.root / (registration['label'] + '-host-launch.json')).resolve(),
                'Host launch evidence must use the exact label sidecar')
        sidecar = self.artifact(sidecar_ref)
        output = self.root / registration['label']
        require(sidecar.get('schemaVersion') == 1 and sidecar.get('status') == 'passed'
                and sidecar.get('label') == registration['label'] and sidecar.get('launchAdmission') == admission
                and sidecar.get('forwardedArguments') == command[7:]
                and sidecar.get('output') == str(output) and sidecar.get('persistentPreferenceWrites') is False,
                'Completed host sidecar differs from registered forwarding or scope')
        for flag, value in [('--label', registration['label']), ('--output', str(output))]:
            require(command[7:].count(flag) == 1 and command[command.index(flag) + 1:command.index(flag) + 2] == [value],
                    'Host sidecar forwarded another run/output identity')
        require(BASE.timestamp(registration['inferenceStartedUTC']) <= BASE.timestamp(sidecar['startedUTC'])
                <= BASE.timestamp(sidecar['finishedUTC']) <= BASE.timestamp(registration['finishedUTC']),
                'Host sidecar lies outside its registered execution interval')
        mutations = sidecar.get('mutations')
        require(isinstance(mutations, list) and len(mutations) == 1, 'Expected exactly one temporary host mutation')
        mutation = mutations[0]
        before = mutation['argumentsBefore']
        require(isinstance(before, list) and all(isinstance(item, str) for item in before)
                and not any(item.lstrip('-').startswith('cotabbyMenuBarIconVisible') for item in before)
                and mutation.get('argumentsAfter') == [*before, *args]
                and mutation.get('target') == 'CotabbyTests' and mutation.get('onlyCommandLineArgumentsChanged') is True
                and BASE.is_hash(mutation.get('configurationBeforeSHA256'))
                and BASE.is_hash(mutation.get('configurationAfterSHA256'))
                and mutation['configurationBeforeSHA256'] != mutation['configurationAfterSHA256'],
                'Temporary host mutation exceeds the single exact argument pair')
        return {'scope': 'Registered process-local test-host UI isolation; frozen model/scorer/source unchanged.',
                'commandLineArguments': args, 'plan': admission['plan'], 'wrapper': admission['wrapper'],
                'originalCLI': admission['originalCLI'], 'evidence': sidecar_ref}

    def summarize_run(self, run, analyzer):
        plan = run['plan']
        subsets = ('word',) if plan['mode'] == 'word' else ('word', 'partial', 'all')
        result = {key: run[key] for key in ('name', 'label', 'kind', 'sourceSHA256')}
        if run.get('hostLaunch') is not None:
            result['hostLaunch'] = run['hostLaunch']
        result.update(seed=run['metadata']['seed'], workerCount=run['manifest']['workerCount'],
                      corpusSHA256=plan['corpusSHA256'], modelSHA256=self.frozen['modelSHA256'],
                      phraseCount=plan['phraseCount'], checkpointsPerCondition=plan['checkpointsPerCondition'],
                      subsets={})
        for subset in subsets:
            item = {'metrics': subset_metrics(run['index'], subset),
                    'contextContrast': context_contrast(run['index'], analyzer, subset)}
            if plan['corpusVersion'] == 3:
                item['contextKinds'] = {kind: context_contrast(run['index'], analyzer, subset, kind)
                                        for kind in sorted(BASE.KINDS)}
            result['subsets'][subset] = item
        result = without_latency(result)
        result['timingInterpretation'] = 'Accuracy characterization; timings omitted. Controlled latency is reported separately after isolation verification.'
        return result

    def preservation_proof(self, reference, current_run):
        proof = self.artifact(reference)
        require(proof.get('schemaVersion') == 1 and proof.get('status') == 'passed'
                and isinstance(proof.get('mainBefore'), dict) and proof['mainBefore']
                and proof['mainBefore'] == proof.get('mainAfter')
                and all(BASE.is_hash(value) for value in proof['mainBefore'].values()),
                'Current-main compatibility snapshot does not prove unrelated files were preserved')
        inventory = self.inventory(proof['productionInventory'])
        binding = self.bindings.get(current_run['label'])
        expected = self.inventory(binding['productionInventory']) if binding else self.inventories['baseline']
        require(inventory == expected, 'Current-main snapshot and executed binding inventory differ')
        return {'status': 'verified', 'sourceSHA256': current_run['sourceSHA256'],
                'compatibilityDifference': binding.get('compatibilityDifference') if binding else None}

    def planned_status(self, completed_names):
        results = []
        for label, item in sorted(self.workloads.items()):
            row = item['row']
            path = self.root / f'{label}-registration.json'
            if path.exists():
                registration = self.read_json(path)
                status = registration.get('status', 'unknown')
                require(registration.get('candidate') == 'baseline', 'Descriptive plan contains a nonbaseline attempt')
            else:
                status = 'not-started'
            results.append({'name': row['name'], 'label': label, 'kind': row['kind'], 'seed': row['seed'],
                            'registeredStatus': status, 'analyzed': row['name'] in completed_names})
        # Every validation attempt is visible even if it failed before enough fields
        # existed to associate it with a workload. None is silently called completed.
        registered = []
        for path in self.root.glob('*-registration.json'):
            record = self.read_json(path)
            if record.get('phase') == 'validation':
                require(record.get('candidate') == 'baseline', 'Post-freeze descriptive evidence includes an alternative candidate attempt')
                registered.append({key: record.get(key) for key in ('label', 'candidate', 'status', 'startedUTC', 'finishedUTC')})
        return results, sorted(registered, key=lambda row: row['label'])

    def preflight_diagnostics(self, previous=()):
        """Retain failed latency admission receipts without inventing benchmark runs.

        The collector can refuse a noisy machine before run_experiment creates its
        ordinary registration. Its immutable proof/summary/plan chain still explains
        why that planned workload is not started; none of it is scoring evidence.
        """
        supplied = {}
        for entry in previous:
            require(set(entry) == {'name', 'label', 'kind', 'status', 'isolation'}
                    and entry['label'] not in supplied, 'Malformed or duplicate preflight diagnostic entry')
            self.artifact_path(entry['isolation'])
            supplied[entry['label']] = entry
        labels = set(supplied)
        for label, item in self.workloads.items():
            if item['row']['kind'] == 'latency' and not (self.root / f'{label}-registration.json').exists() \
                    and (self.root / f'{label}-isolation.json').exists():
                labels.add(label)
        entries, summaries = [], []
        for label in sorted(labels):
            require(label in self.workloads and self.workloads[label]['row']['kind'] == 'latency',
                    'Preflight diagnostic is outside registered latency workloads')
            require(not (self.root / f'{label}-registration.json').exists()
                    and not (self.root / label).exists(), 'Preflight-only receipt has benchmark registration/output artifacts')
            workload = self.workloads[label]
            row = workload['row']
            path = self.root / f'{label}-isolation.json'
            reference = {'path': str(path), 'sha256': BASE.digest(self.read_bytes(path))}
            entry = {'name': row['name'], 'label': label, 'kind': 'latency-preflight',
                     'status': 'failed-before-benchmark', 'isolation': reference}
            if label in supplied:
                old = supplied[label]
                require({k: v for k, v in old.items() if k != 'isolation'} == {k: v for k, v in entry.items() if k != 'isolation'}
                        and old['isolation']['sha256'] == reference['sha256']
                        and self.path(old['isolation']['path']).resolve() == path.resolve(),
                        'Previously recorded preflight diagnostic changed')
                entry['isolation'] = old['isolation']
            proof = self.artifact(entry['isolation'])
            require(proof.get('schemaVersion') == 1 and proof.get('status') == 'failed'
                    and proof.get('labels') == [label] and proof.get('intervals') == []
                    and proof.get('noOverlappingBuildOrInference') is False,
                    'Preflight receipt is not an explicit failed admission before an inference interval')
            summary = self.artifact(proof['evidence'])
            require(summary.get('schemaVersion') == 1 and summary.get('label') == label
                    and 'registration' in summary and summary['registration'] is None
                    and type(summary.get('sampleCount')) is int and summary['sampleCount'] >= 0
                    and isinstance(summary.get('issues'), list) and summary['issues']
                    and all(isinstance(issue, str) for issue in summary['issues']),
                    'Failed preflight lacks its completed collector summary')
            plan = self.artifact(summary['plan'])
            self.artifact_path(summary['observations'])
            require(plan.get('schemaVersion') == 1 and plan.get('label') == label,
                    'Preflight plan labels disagree')
            for actual, expected in [(plan['workload'], workload['artifact']),
                                     (plan['freeze'], {'path': 'finalist-freeze.json', 'sha256': BASE.digest(self.read_bytes('finalist-freeze.json'))})]:
                self.artifact_path(actual)
                require(actual['sha256'] == expected['sha256']
                        and self.path(actual['path']).resolve() == self.path(expected['path']).resolve(),
                        'Preflight plan is not bound to its registered workload and frozen decision')
            require(BASE.timestamp(workload['registration']['registeredUTC']) <= BASE.timestamp(plan['preparedUTC'])
                    <= BASE.timestamp(summary['finishedUTC']) <= BASE.timestamp(self.round_record['deadlineUTC']),
                    'Preflight timing is outside its registered workload/round')
            require(row['seed'] == 42 and row['workerCount'] == 1 and row['estimatedSeconds'] == 600
                    and row['mode'] == 'word' and row['selection'] == 'screen' and row['perCategory'] == 0
                    and row['corpusSHA256'] == BASE.OLD_CORPUS_SHA and row.get('guardException') is None,
                    'Preflight diagnostic changed the fixed latency workload')
            args = plan['arguments']
            expected = {'label': label, 'candidate': 'baseline', 'phase': 'validation', 'mode': 'word',
                        'split': 'screen', 'corpus': None, 'per_category': None, 'seed': 42, 'workers': 1,
                        'estimated_seconds': 600}
            require(all(args.get(key) == value for key, value in expected.items())
                    and type(args.get('seed')) is int and type(args.get('workers')) is int
                    and type(args.get('estimated_seconds')) in (int, float), 'Preflight collector arguments differ from fixed workload')
            entries.append(entry)
            summaries.append({**entry, 'benchmarkRegistrationStatus': 'not-started',
                              'preparedUTC': plan['preparedUTC'], 'finishedUTC': summary['finishedUTC'],
                              'sampleCount': summary['sampleCount'], 'issues': summary['issues'],
                              'collectorSummary': proof['evidence'], 'collectorPlan': summary['plan'],
                              'processObservations': summary['observations'],
                              'scope': 'Admission diagnostic only; no benchmark registration, inference interval, or score.'})
        return entries, summaries

    def characterize(self, evidence_path):
        frozen = self.validate_freeze()
        require(frozen['candidate'] == 'baseline' and frozen['selectionQualified'] is False,
                'Descriptive baseline route requires the final frozen baseline-retention decision')
        evidence = self.read_json(evidence_path)
        require(evidence.get('schemaVersion') == 1, 'Unsupported baseline characterization schema')
        self.exporter(evidence['checkpointExporter'])
        for binding in evidence.get('sourceBindings', []):
            require(binding['role'] == 'baseline', 'Descriptive source binding must be the retained baseline')
            self.add_binding(binding)
        for reference in evidence['plannedWorkloads']:
            self.register_workload(reference)
        _, preflight_diagnostics = self.preflight_diagnostics(evidence.get('attemptDiagnostics', []))
        execution = self.read_json('execution.json')
        analyzer_path = Path(execution['root']) / 'scripts/analyze_phrase_experiments.py'
        self.read_bytes(analyzer_path)
        spec = importlib.util.spec_from_file_location('round2_baseline_analyzer', analyzer_path)
        analyzer = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(analyzer)
        entries = evidence['runs']
        require(isinstance(entries, list) and len({row['name'] for row in entries}) == len(entries)
                and len({row['label'] for row in entries}) == len(entries), 'Duplicate descriptive evidence runs')
        result = {'schemaVersion': 1, 'status': 'descriptive-only', 'candidate': 'baseline',
                  'selectionDecision': 'retained-baseline; no alternative qualified before protected validation',
                  'frozenUTC': frozen['frozenUTC'], 'runs': {}, 'seedComparisons': {},
                  'currentMainParity': {}, 'latency': {}, 'latencyRepeats': {}, 'issues': [],
                  'attemptDiagnostics': preflight_diagnostics,
                  'limitations': [
                      'Descriptive characterization only; no new candidate selection or adoption criteria.',
                      'One local model, synthetic references and one authoring process; family intervals do not measure population writing quality.',
                      'Exact reference scoring can reject other reasonable continuations; no lexical rescoring is performed.',
                      'Context contrasts pair the same checkpoint with and without synthetic OCR; they do not establish a benefit for every category or real application.',
                      'Character subsets are explicit corpus-order cohorts; boundary and partial-only denominators remain separate.',
                      'Changing seed describes this model and these scenarios, not a population distribution over arbitrary random seeds.',
                      'Latency excludes focus tracking, debounce and overlays; registered isolation cannot exclude unlogged machine activity.',
                      'Repeated raw UI noise can disappear during OCR deduplication and does not establish sustained long-context performance.']}
        result['compatibilityDifferences'] = {label: self.bindings[label]['compatibilityDifference']
                                               for label in sorted(self.descriptive_bindings)}
        if self.descriptive_bindings:
            result['limitations'].append('Current-main compatibility permits one reviewed bundle-classification edit; neither corpus exercises that new bundle identifier, so parity does not validate its new application behavior.')
        def attempt(name, operation):
            try:
                return operation()
            except FileNotFoundError:
                result['issues'].append({'area': name, 'reason': 'Required evidence artifact is absent'})
            except (EvidenceError, KeyError, TypeError, ValueError) as error:
                result['issues'].append({'area': name, 'reason': str(error) if isinstance(error, EvidenceError) else 'Malformed evidence structure'})
            return None
        needed = set()
        for entry in evidence.get('seedPairs', []):
            needed.update((entry['reference'], entry['comparison']))
        for entry in evidence.get('parityPairs', []):
            needed.update((entry['reference'], entry['currentMain']))
        for entry in evidence.get('latencyPairs', []):
            needed.update((entry['first'], entry['second']))
        needed.update(entry['name'] for entry in evidence.get('latencyRuns', []))
        runs = {}
        for entry in entries:
            def process(entry=entry):
                run = self.load_descriptive_run(entry)
                summary = self.summarize_run(run, analyzer)
                runs[entry['name']] = run if entry['name'] in needed else {key: value for key, value in run.items() if key != 'index'}
                return summary
            summary = attempt(entry['name'], process)
            if summary is not None:
                result['runs'][entry['name']] = summary
                print(f"Validated descriptive run: {entry['name']}", flush=True)
        for entry in evidence.get('seedPairs', []):
            def compare_seed(entry=entry):
                a, b = runs[entry['reference']], runs[entry['comparison']]
                require(a['kind'] == b['kind'] and a['plan'] == b['plan'], 'Seed comparison changed the registered cohort')
                subsets = ('word',) if a['plan']['mode'] == 'word' else ('word', 'partial', 'all')
                return {'reference': entry['reference'], 'comparison': entry['comparison'],
                        'subsets': {subset: seed_comparison(a, b, analyzer, subset) for subset in subsets}}
            result['seedComparisons'][entry['name']] = attempt(entry['name'], compare_seed)
        for entry in evidence.get('parityPairs', []):
            def compare_parity(entry=entry):
                a, b = runs[entry['reference']], runs[entry['currentMain']]
                require(a['plan'] == b['plan'], 'Current-main parity changed the registered cohort')
                proof = self.preservation_proof(entry['snapshotProof'], b)
                return dict(exact_parity(a, b), reference=entry['reference'], currentMain=entry['currentMain'], preservation=proof)
            result['currentMainParity'][entry['name']] = attempt(entry['name'], compare_parity)
        latency_entries = evidence.get('latencyRuns', [])
        expected_latency = {name for name, run in runs.items() if run['kind'] == 'latency'}
        supplied_latency = {entry['name'] for entry in latency_entries}
        if len(supplied_latency) != len(latency_entries) or supplied_latency != expected_latency:
            result['issues'].append({'area': 'latencyIsolation', 'reason': 'Every completed latency workload requires exactly one isolation entry'})
        for entry in latency_entries:
            def validate_latency(entry=entry):
                run = runs[entry['name']]
                require(run['kind'] == 'latency' and run['manifest']['workerCount'] == 1,
                        'Latency evidence requires its registered single-worker workload')
                self.validate_isolation(entry['isolation'], [run])
                measured = subset_metrics(run['index'], 'word')
                return {'status': 'isolated', 'seed': run['metadata']['seed'],
                        'conditions': {condition: measured[condition]['suite']
                                       for condition in sorted(BASE.CONDITIONS)}}
            result['latency'][entry['name']] = attempt(entry['name'], validate_latency)
        for entry in evidence.get('latencyPairs', []):
            def repeat_latency(entry=entry):
                a, b = runs[entry['first']], runs[entry['second']]
                require(entry['first'] in result['latency'] and result['latency'][entry['first']] is not None
                        and entry['second'] in result['latency'] and result['latency'][entry['second']] is not None,
                        'Both repeated latency runs need isolation evidence')
                require(a['plan'] == b['plan'], 'Repeated latency run changed cohort')
                parity = exact_parity(a, b)
                conditions = {}
                for condition in sorted(BASE.CONDITIONS):
                    first = result['latency'][entry['first']]['conditions'][condition]
                    second = result['latency'][entry['second']]['conditions'][condition]
                    conditions[condition] = {'firstP95Milliseconds': first['latencyP95Milliseconds'],
                                             'secondP95Milliseconds': second['latencyP95Milliseconds'],
                                             'p95DeltaMilliseconds': second['latencyP95Milliseconds'] - first['latencyP95Milliseconds']}
                return {'comparisonType': 'same-baseline latency repeatability', 'first': entry['first'],
                        'second': entry['second'], 'conditions': conditions, 'outputParity': parity}
            result['latencyRepeats'][entry['name']] = attempt(entry['name'], repeat_latency)
        allowed = {frozen['baselineSourceSHA256']} | {binding['sourceSHA256'] for binding in self.bindings.values()}
        result['focusedTests'] = attempt('focusedTests', lambda: self.final_tests(evidence['focusedTests'], allowed))
        result['plannedWorkloads'], result['registeredValidationAttempts'] = self.planned_status(set(result['runs']))
        unregistered = [row['label'] for row in result['registeredValidationAttempts'] if row['label'] not in self.workloads]
        if unregistered:
            result['issues'].append({'area': 'workloadRegistration', 'reason': 'Validation attempts lack a descriptive workload registration',
                                     'labels': unregistered})
        complete_omitted = [row['name'] for row in result['plannedWorkloads'] if row['registeredStatus'] == 'complete' and not row['analyzed']]
        if complete_omitted:
            result['issues'].append({'area': 'attemptVisibility', 'reason': 'Completed planned runs were not analyzed', 'names': complete_omitted})
        if result['issues']:
            result['status'] = 'incomplete-or-invalid'
        result['completedRunCount'] = len(result['runs'])
        result['plannedRunCount'] = len(result['plannedWorkloads'])
        return result


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--round', type=Path, default=HERE)
    parser.add_argument('--evidence', default='baseline-evidence.json')
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args(argv)
    reader = BaselineCharacterization(args.round)
    try:
        result = reader.characterize(args.evidence)
        result['artifactSHA256'] = reader.stable_artifacts()
        result['characterizerSHA256'] = BASE.digest(Path(__file__).read_bytes())
        result['immutableAssessorSHA256'] = BASE.digest((HERE / 'assess_round2.py').read_bytes())
        result['assessedUTC'] = dt.datetime.now(dt.timezone.utc).isoformat()
    except FileNotFoundError:
        result = {'schemaVersion': 1, 'status': 'incomplete-or-invalid', 'reason': 'Required evidence artifact is absent'}
    except (EvidenceError, KeyError, TypeError, ValueError) as error:
        result = {'schemaVersion': 1, 'status': 'incomplete-or-invalid',
                  'reason': str(error) if isinstance(error, EvidenceError) else 'Malformed evidence structure'}
    require(args.output.resolve() not in {Path(path) for path in reader.artifacts}, 'Output cannot overwrite evidence')
    args.output.write_text(json.dumps(result, indent=2, sort_keys=True) + '\n')
    print(json.dumps({key: result[key] for key in ('status', 'completedRunCount', 'plannedRunCount') if key in result}, sort_keys=True))
    return 0 if result['status'] == 'descriptive-only' else 2


if __name__ == '__main__':
    sys.exit(main())
