#!/usr/bin/env python3
"""Sequence a source selection, correctness/input checks, and one scored replay.

The round owns this orchestration; Swift owns scoring and the CLI owns compilation/input
identity. A process lock prevents competing experiment transitions in this isolated checkout.
"""
import argparse
import datetime
import fcntl
import hashlib
import importlib.util
import json
import math
import os
import re
from pathlib import Path
import signal
import subprocess
import sys
import time

import prompt_variants
import run_checks
import production_inventory
import phrase_eval_hidden_host as hidden_host

HERE = Path(__file__).resolve().parent
EXECUTION = json.loads((HERE / 'execution.json').read_text())
ROUND = json.loads((HERE / 'round.json').read_text())
ROOT = Path(EXECUTION['root'])
NATIVE = Path(EXECUTION['native'])
DEADLINE = datetime.datetime.fromisoformat(ROUND['deadlineUTC'].replace('Z', '+00:00')).timestamp()
FREEZE = datetime.datetime.fromisoformat(ROUND['freezeDeadlineUTC'].replace('Z', '+00:00')).timestamp()
NATIVE_TESTS = ['LlamaRuntimeCoreIntegrationTests/' + name for name in (
    'testSampledRestoredRequestResetsRandomStreamAndRepetitionHistory',
    'testSampledEditedPromptMatchesFreshStateAfterDiscardedGeneration',
    'testSampledHistorySensitiveMidwordEditsMatchFreshState',
    'testHealingStreamsOnlyValidCumulativeContinuation',
    'testCancelledRetainedTailCanBeRestoredByNextRequest')]


def load_module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def audit_changes(path, components):
    def index(source):
        records = json.loads(source.read_text())
        indexed = {(r['id'], r['condition'], r['wordIndex']): r for r in records}
        if len(indexed) != len(records) or len(records) != 1540:
            raise ValueError('Invalid prompt audit identities')
        return indexed
    baseline = index(HERE / 'baseline-checks/prompt-audit.json')
    candidate = index(path)
    if baseline.keys() != candidate.keys():
        raise ValueError('Prompt audit changed screening inputs')
    changed = {condition: sum(baseline[k]['promptSHA256'] != candidate[k]['promptSHA256']
                             for k in baseline if k[1] == condition) for condition in ('none', 'screen')}
    prompt = [c for c in components if c[0] in 'FM']
    if prompt and not sum(changed.values()):
        raise ValueError('Prompt candidate is an input no-op; do not score it')
    if not prompt and sum(changed.values()):
        raise ValueError('Native-only candidate unexpectedly changed a prompt')
    if any(c.startswith('F') for c in prompt) and not any(c.startswith('M') for c in prompt) and changed['none']:
        raise ValueError('Screen-only formatting changed no-screen prompts')
    return {'comparedCheckpoints': 1540, 'changedPrompts': changed,
            'baselineAuditSHA256': hashlib.sha256((HERE/'baseline-checks/prompt-audit.json').read_bytes()).hexdigest(),
            'candidateAuditSHA256': hashlib.sha256(path.read_bytes()).hexdigest()}


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def artifact(reference):
    path = Path(reference['path'])
    path = path if path.is_absolute() else HERE / path
    if digest(path) != reference['sha256']:
        raise ValueError('Frozen evidence artifact changed: ' + str(path))
    return path


def check_time(limit, estimate=0):
    if estimate < 0 or time.time() + estimate >= limit:
        raise TimeoutError('Complete run does not fit before phase deadline and closure reserve')


def evidence_time(value):
    parsed = datetime.datetime.fromisoformat(value.replace('Z', '+00:00'))
    if parsed.tzinfo is None:
        raise ValueError('Descriptive evidence timestamps require a timezone')
    return parsed.timestamp()


def descriptive_fresh_character_admission(args, components, frozen, readiness, freeze_path):
    """Admit one explicitly registered baseline-only descriptive workload.

    The optional extension changes checkpoint density, not the frozen selection,
    references, model, sampler, production code or benchmark scoring. An eligible
    alternative can never use this exception as additional candidate validation.
    """
    path = getattr(args, 'descriptive_workload', None)
    expected_hash = getattr(args, 'descriptive_workload_sha256', None)
    if path is None or not isinstance(expected_hash, str) or not re.fullmatch('[0-9a-f]{64}', expected_hash):
        raise ValueError('Fresh character characterization requires an explicit workload path and SHA-256')
    if (args.phase != 'validation' or args.candidate != 'baseline' or components
            or frozen['candidate'] != 'baseline' or frozen['components']
            or frozen.get('selectionQualified') is not False):
        raise ValueError('Fresh character characterization requires the frozen no-qualifier baseline decision')
    if (args.corpus is None or args.mode != 'character' or args.split != 'all' or args.per_category is not None
            or readiness.get('phraseCount') != 700 or readiness.get('familyCount', 0) < 140):
        raise ValueError('Fresh character characterization requires the complete protected all700 corpus')
    workload_ref = {'path': str(Path(path).resolve()), 'sha256': expected_hash}
    workload = json.loads(artifact(workload_ref).read_text())
    freeze_hash = digest(freeze_path)
    if (workload.get('schemaVersion') != 1 or workload.get('candidate') != 'baseline'
            or workload.get('freezeSHA256') != freeze_hash
            or not isinstance(workload.get('purpose'), str) or not workload['purpose'].strip()):
        raise ValueError('Descriptive workload is not bound to the frozen baseline decision')
    registered = evidence_time(workload['registeredUTC'])
    frozen_at = evidence_time(frozen['frozenUTC'])
    if not frozen_at <= registered <= time.time():
        raise ValueError('Descriptive workload must be registered after freeze and before launch')
    rows = workload['runs']
    if (not isinstance(rows, list) or not rows or len({row['label'] for row in rows}) != len(rows)
            or len({row['name'] for row in rows}) != len(rows)):
        raise ValueError('Descriptive workload identities are empty or duplicated')
    selected = [row for row in rows if row['label'] == args.label]
    if len(selected) != 1:
        raise ValueError('Run label is absent from its descriptive workload registration')
    row = selected[0]
    expected = {'kind': 'freshCharacter', 'seed': args.seed, 'workerCount': args.workers,
                'mode': 'character', 'corpusSHA256': frozen['freshCorpusSHA256'],
                'selection': 'all', 'perCategory': 0, 'estimatedSeconds': args.estimated_seconds}
    if (any(row.get(key) != value for key, value in expected.items())
            or type(row.get('seed')) is not int or row['seed'] not in (42, 1337, 12648430)
            or type(row.get('workerCount')) is not int or row['workerCount'] not in (1, 2, 3)
            or type(row.get('perCategory')) is not int
            or type(row.get('estimatedSeconds')) not in (int, float)
            or not math.isfinite(row['estimatedSeconds']) or row['estimatedSeconds'] <= 0
            or not isinstance(row.get('name'), str) or not row['name']):
        raise ValueError('Fresh character arguments differ from the exact registered kind/seed/cohort/workload')
    exception_ref = row['guardException']
    exception = json.loads(artifact(exception_ref).read_text())
    if (exception.get('schemaVersion') != 1 or exception.get('candidate') != 'baseline'
            or exception.get('descriptiveOnly') is not True or exception.get('allowedKind') != 'freshCharacter'
            or exception.get('freezeSHA256') != freeze_hash
            or not isinstance(exception.get('reason'), str) or not exception['reason'].strip()
            or not frozen_at <= evidence_time(exception['registeredUTC']) <= registered):
        raise ValueError('Fresh character exception must be baseline-only, explicit and registered before its workload')
    return {'descriptiveOnly': True, 'kind': 'freshCharacter', 'name': row['name'],
            'workload': workload_ref, 'guardException': exception_ref,
            'seed': row['seed'], 'workerCount': row['workerCount'],
            'estimatedSeconds': row['estimatedSeconds']}


def verify_admission_artifacts(admission):
    if not admission:
        return
    if digest(Path(admission['path'])) != admission['sha256']:
        raise ValueError('Finalist freeze changed during validation')
    if admission.get('protectedCorpus'):
        artifact(admission['protectedCorpus'])
    descriptive = admission.get('descriptiveWorkload')
    if descriptive:
        artifact(descriptive['workload'])
        artifact(descriptive['guardException'])


def validation_admission(args, components):
    """Authorize only pre-frozen comparisons before opening any validation result."""
    if args.phase != 'validation':
        if args.corpus or getattr(args, 'descriptive_workload', None) or getattr(args, 'descriptive_workload_sha256', None):
            raise ValueError('Protected supplementary data is validation-only')
        return None
    descriptive_requested = bool(getattr(args, 'descriptive_workload', None) or getattr(args, 'descriptive_workload_sha256', None))
    if descriptive_requested and (args.corpus is None or args.mode != 'character'):
        raise ValueError('Descriptive workload admission is only available for protected fresh character mode')
    path = HERE / 'finalist-freeze.json'
    frozen = json.loads(path.read_text())
    frozen_at = datetime.datetime.fromisoformat(frozen['frozenUTC'].replace('Z', '+00:00')).timestamp()
    if frozen.get('schemaVersion') != 1 or frozen_at > FREEZE or frozen_at > time.time():
        raise ValueError('Finalist freeze timestamp/schema is invalid')
    if frozen['candidate'] != ('+'.join(frozen['components']) or 'baseline'):
        raise ValueError('Frozen candidate/component identity disagrees')
    if args.candidate not in ('baseline', frozen['candidate']):
        raise ValueError('Validation admits only baseline and the frozen finalist')
    if args.candidate != 'baseline' and (frozen.get('selectionQualified') is not True or components != frozen['components']):
        raise ValueError('Unqualified or inconsistent finalist cannot enter validation')
    if frozen['modelSHA256'] != ROUND['modelSHA256']:
        raise ValueError('Frozen model differs from round registration')
    artifact(frozen['criteria'])
    screening = frozen['screeningEvidence']
    if screening['sha256'] != frozen['screeningEvidenceSHA256']:
        raise ValueError('Frozen screening artifact identities disagree')
    artifact(screening)
    readiness = json.loads(artifact(frozen['freshReadiness']).read_text())
    if readiness['status'] != 'pass' or readiness['corpusSHA256'] != frozen['freshCorpusSHA256']:
        raise ValueError('Frozen fresh-data readiness disagrees')
    ready_at = datetime.datetime.fromisoformat(readiness['readyUTC'].replace('Z', '+00:00')).timestamp()
    ready_deadline = datetime.datetime.fromisoformat(ROUND['freshReadinessDeadlineUTC'].replace('Z', '+00:00')).timestamp()
    if ready_at > frozen_at or ready_at > ready_deadline:
        raise ValueError('Fresh data was not ready before the registered deadline/freeze')
    descriptive = None
    if args.corpus:
        if (args.corpus.resolve() != Path(readiness['corpusPath']).resolve()
                or digest(args.corpus.resolve()) != frozen['freshCorpusSHA256']):
            raise ValueError('Fresh validation must use the exact protected frozen corpus')
        if args.mode == 'character':
            descriptive = descriptive_fresh_character_admission(args, components, frozen, readiness, path)
        elif args.split != 'all' or args.mode != 'word' or args.per_category is not None:
            raise ValueError('Fresh validation requires all700 word checkpoints without narrowing')
    elif args.label.startswith('fresh-'):
        raise ValueError('Fresh-labeled validation requires the protected corpus explicitly')
    role = 'baseline' if args.candidate == 'baseline' else 'candidate'
    inventory_role = 'baseline' if role == 'baseline' else 'finalist'
    production = json.loads(artifact(frozen['productionInventories'][inventory_role]).read_text())
    return {'path': str(path), 'sha256': digest(path), 'role': role,
            'sourceSHA256': frozen[role + 'SourceSHA256'],
            'targets': frozen[role + 'Targets'], 'freshCorpusSHA256': frozen['freshCorpusSHA256'],
            'protectedCorpus': {'path': str(args.corpus.resolve()), 'sha256': frozen['freshCorpusSHA256']} if args.corpus else None,
            'productionInventory': production, 'descriptiveWorkload': descriptive}


def verify_check_evidence(checks, required, path, cli):
    if checks['status'] != 'passed' or checks['buildInputs'] != cli.build_input_snapshot(Path(EXECUTION['workspace'])):
        raise ValueError('Check evidence does not match selected compiler inputs')
    actual = run_checks.passed_tests(path / 'validation.log')
    run_checks.require_test_coverage(required, checks['tests'], actual)
    if 'executedTests' in checks and checks['executedTests'] != actual:
        raise ValueError('Check execution record no longer matches its log')


def verify_completed(report, manifest, checks, admission=None):
    if manifest.get('buildInputs') != checks['buildInputs']:
        raise ValueError('Benchmark compiler inputs differ from passed checks')
    if (manifest.get('build', {}).get('sourceSHA256') != checks['buildInputs']['sourceSHA256']
            or manifest['build'].get('reused') is not False):
        raise ValueError('Benchmark requires a fresh build of the checked source')
    if report['metadata']['configuration'].get('modelSHA256') != ROUND['modelSHA256']:
        raise ValueError('Executed model differs from the frozen round model')
    if report['errorCount']:
        raise ValueError('Inference errors in completed report')
    if admission and admission.get('protectedCorpus'):
        expected = admission['protectedCorpus']
        corpus = manifest.get('corpusInput', {})
        if (manifest.get('corpusSHA256') != expected['sha256'] or corpus.get('sha256') != expected['sha256']
                or report['metadata'].get('corpusSHA256') != expected['sha256']
                or Path(corpus.get('sourcePath', '')).resolve() != Path(expected['path']).resolve()):
            raise ValueError('Executed protected corpus differs from the frozen admission')


def run(args):
    limit = min(DEADLINE - 1200, FREEZE) if args.phase == 'screening' else DEADLINE - 1200
    check_time(limit, args.estimated_seconds)
    if not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9._-]{0,99}', args.label):
        raise ValueError('Run label must be a simple unique filename component')
    components = [] if args.candidate == 'baseline' else args.candidate.split('+')
    if any(c not in {f'{family}{i}' for family in 'HFM' for i in range(1,5)} for c in components):
        raise ValueError('Unknown registered candidate')
    if len(set(components)) != len(components) or any(sum(c.startswith(f) for c in components) > 1 for f in 'HFM'):
        raise ValueError('At most one component from each candidate family is allowed')
    history = [c for c in components if c.startswith('H')]
    admission = validation_admission(args, components)
    host_launch = hidden_host.admission(args)
    if components and args.phase == 'screening':
        readiness = json.loads((HERE / 'fresh-readiness.json').read_text())
        if readiness['status'] != 'pass':
            raise ValueError('Fresh-data readiness required before candidate screening')
    output = HERE / args.label
    registration = HERE / (args.label + '-registration.json')
    if output.exists() or registration.exists():
        raise ValueError('Refusing to overwrite an existing benchmark attempt/registration')
    record = {'label': args.label, 'candidate': args.candidate, 'components': components, 'phase': args.phase,
              'startedUTC': now(), 'status': 'selecting', 'validationAdmission': admission,
              'phaseDeadlineUTC': datetime.datetime.fromtimestamp(limit, datetime.timezone.utc).isoformat(),
              'orchestrationSHA256': {name: digest(HERE / name) for name in ('run_experiment.py', 'run_checks.py')}}
    if host_launch:record['hostLaunch']=host_launch
    registration.write_text(json.dumps(record, indent=2) + '\n')
    started = None
    try:
        prompt = [c for c in components if c.startswith(('F','M'))]
        # The unchanged-selection path must verify actual bytes too, not trust a stale record.
        prior = prompt_variants.verify_current()
        prompt_record = prompt_variants.apply(prompt) if prior['components'] != prompt else prior
        native = load_module('round2_native_selector', HERE / 'native-history/history_variants.py')
        native_manifest, native_current = native.verify(NATIVE, HERE / 'native-history/variants')
        native_target = history[0] if history else 'baseline'
        native_record = native.select(NATIVE, HERE / 'native-history/variants', native_target) if native_current != native_target else {
            'before': native_current, 'after': native_current, 'sha256': native_manifest['variants'][native_current]['sha256']}
        targets = dict(prompt_record['hashes'], nativeEngine=native_manifest['variants'][native_target]['sha256'])
        if admission and targets != admission['targets']:
            raise ValueError('Selected target bytes differ from the frozen validation role')
        if admission and production_inventory.capture(ROOT, NATIVE) != admission['productionInventory']:
            raise ValueError('Current production inventory differs from the frozen validation role')
        record.update(promptSource=prompt_record, nativeSource=native_record, status='checking')
        registration.write_text(json.dumps(record, indent=2) + '\n')
        cli = load_module('round2_cli_identity', ROOT / 'scripts/phrase_eval.py')
        required = [run_checks.AUDIT_TEST] + (NATIVE_TESTS if history else [])
        checks_path = HERE / (args.reuse_checks or (args.label + '-checks'))
        record['checks'] = str(checks_path / 'validation.json')
        if args.reuse_checks:
            checks = json.loads((checks_path / 'validation.json').read_text())
        else:
            checks = run_checks.run(checks_path.name, required, deadline=limit)
        verify_check_evidence(checks, required, checks_path, cli)
        if admission and checks['buildInputs']['sourceSHA256'] != admission['sourceSHA256']:
            raise ValueError('Checked compiler inputs differ from the frozen validation role')
        record['promptAudit'] = audit_changes(checks_path / 'prompt-audit.json', components)
        # Re-check after resolution/build/tests. Spending the estimate in checks is not
        # permission to start a replay that cannot fit before the closure reserve.
        check_time(limit, args.estimated_seconds)
        verify_admission_artifacts(admission)
        command = [sys.executable, str(ROOT / 'scripts/phrase_eval.py'), 'run', '--model', EXECUTION['model'],
            '--workspace', EXECUTION['workspace'], '--output', str(output), '--label', args.label,
            '--mode', args.mode, '--context', 'paired', '--workers', str(args.workers),
            '--split', args.split, '--split-seed', '1337', '--screen-per-category', '20',
            '--seed', str(args.seed), '--temperature', '0.1', '--repetition-penalty', '1.025',
            '--top-k', '20', '--top-p', '0.7', '--min-p', '0.08']
        if args.corpus:
            # Pin the admitted canonical source even if a caller-provided symlink
            # changes later; its bytes are also rechecked around the replay.
            command += ['--corpus', admission['protectedCorpus']['path']]
        if args.per_category:
            command += ['--per-category', str(args.per_category)]
        original_command=list(command)
        hidden_host.recheck(host_launch)
        command=hidden_host.wrap_command(command,host_launch)
        record.update(command=command, status='running', inferenceStartedUTC=now())
        registration.write_text(json.dumps(record, indent=2) + '\n')
        (HERE / 'active.json').write_text(json.dumps(record, indent=2) + '\n')
        started = time.time()
        with (HERE / (args.label + '.console.log')).open('x') as stream:
            run_checks.bounded_command(command, stream, deadline=limit)
        report_path, manifest_path = output / 'report.json', output / 'manifest.json'
        report, manifest = json.loads(report_path.read_text()), json.loads(manifest_path.read_text())
        verify_completed(report, manifest, checks, admission)
        if prompt_variants.verify_current()['hashes'] != prompt_record['hashes']:
            raise ValueError('Prompt sources changed across checks/replay')
        if native.verify(NATIVE, HERE / 'native-history/variants')[1] != native_target:
            raise ValueError('Native source changed across checks/replay')
        verify_admission_artifacts(admission)
        if host_launch:record['hostLaunchEvidence']=hidden_host.verify_completed(host_launch,args.label,original_command)
        record.update(status='complete', scores={key: value['suite']['nextWord'] for key,value in report['conditions'].items()},
                      allScores={key: value['suite']['all'] for key,value in report['conditions'].items()},
                      evidenceSHA256={'checks': digest(checks_path / 'validation.json'),
                                      'manifest': digest(manifest_path), 'report': digest(report_path)})
    except BaseException as error:
        record.update(status='failed-or-interrupted', error=f'{type(error).__name__}: {error}')
        raise
    finally:
        record.update(finishedUTC=now(), replayWallSeconds=time.time()-started if started is not None else 0)
        registration.write_text(json.dumps(record, indent=2) + '\n')
        (HERE / 'active.json').write_text(json.dumps(record, indent=2) + '\n')
    with (HERE / 'completed.jsonl').open('a') as stream:
        stream.write(json.dumps(record, sort_keys=True) + '\n')
    print(json.dumps({'label': args.label, 'candidate': args.candidate, 'scores': record['scores'],
                      'replayWallSeconds': record['replayWallSeconds']}, indent=2), flush=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('label')
    parser.add_argument('--candidate', required=True)
    parser.add_argument('--phase', choices=('screening','validation'), default='screening')
    parser.add_argument('--split', choices=('screen','all','heldout'), default='screen')
    parser.add_argument('--mode', choices=('word','character'), default='word')
    parser.add_argument('--seed', type=int, default=42)
    parser.add_argument('--workers', type=int, default=3)
    parser.add_argument('--per-category', type=int)
    parser.add_argument('--corpus', type=Path)
    parser.add_argument('--estimated-seconds', type=int, default=300)
    parser.add_argument('--reuse-checks')
    parser.add_argument('--descriptive-workload', type=Path,
                        help='Hash-bound optional fresh-character workload for a frozen retained baseline only')
    parser.add_argument('--descriptive-workload-sha256')
    parser.add_argument('--launch-plan',type=Path,help='Explicit registered test-host UI isolation plan')
    parser.add_argument('--launch-plan-sha256')
    args = parser.parse_args()
    with (HERE / 'experiment.lock').open('a') as lock:
        fcntl.flock(lock.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        run(args)
