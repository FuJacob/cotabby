# Descriptive evidence for the retained baseline

`characterize_baseline.py` is separate from the immutable adoption assessor. It requires a
validated `finalist-freeze.json` selecting `baseline` with no qualified alternative. It
never applies adoption gates or chooses another candidate. It validates complete runs using
the existing source, harness, corpus, model, configuration, checkpoint, test and hash checks.

An artifact reference is `{"path":"relative-or-absolute-path", "sha256":"64 lowercase hex"}`.
The command is:

```sh
python3 build/eval/round2-20260917/characterize_baseline.py \
  --evidence baseline-evidence.json \
  --output build/eval/round2-20260917/baseline-characterization.json
```

The evidence map uses these exact keys. Entries for unrun workloads may be omitted from
`runs`, but their registered status stays visible in `plannedWorkloads` and attempt inventory.
Names are identifiers used by comparisons; labels name existing ordinary run artifacts.

```json
{
  "schemaVersion": 1,
  "checkpointExporter": {"path":"checkpoint-manifests/provenance.json", "sha256":"..."},
  "sourceBindings": [],
  "plannedWorkloads": [{"path":"baseline-workloads.json", "sha256":"..."}],
  "runs": [
    {"name":"fresh42", "label":"baseline-fresh42", "kind":"freshWord", "seed":42,
     "checkpoints":{"path":"checkpoint-manifests/fresh-word-all.json", "sha256":"..."},
     "workload":{"path":"baseline-workloads.json", "sha256":"..."}}
  ],
  "focusedTests": [{"path":"baseline-checks/validation.json", "sha256":"..."}],
  "seedPairs": [{"name":"fresh42-vs-1337", "reference":"fresh42", "comparison":"fresh1337"}],
  "parityPairs": [{"name":"current-main-production-parity", "reference":"old-production", "currentMain":"main-production",
    "snapshotProof":{"path":"main-parity-snapshot.json", "sha256":"..."}}],
  "latencyRuns": [{"name":"latency-one", "isolation":{"path":"latency-one-isolation.json", "sha256":"..."}}],
  "latencyPairs": [{"name":"latency-repeat", "first":"latency-one", "second":"latency-two"}]
}
```

A workload registration is written before the run starts. One record can contain several
planned runs; later timing-only extensions get a new record, preserving the original hash.

```json
{
  "schemaVersion":1,
  "registeredUTC":"2026-09-17T...+00:00",
  "candidate":"baseline",
  "freezeSHA256":"...",
  "purpose":"Descriptive characterization of the retained baseline; no candidate tuning or adoption gates.",
  "runs":[
    {"name":"fresh42", "label":"baseline-fresh42", "kind":"freshWord", "seed":42,
     "workerCount":3, "mode":"word", "corpusSHA256":"...", "selection":"all",
     "perCategory":0, "estimatedSeconds":600, "guardException":null}
  ]
}
```

Supported kinds are `freshWord` (all700), `historicalWord` (all1337),
`historicalCharacter` (first50/category, first150/category, or all1337), `freshCharacter`
(all700, only under an explicitly recorded baseline-only guard exception), and `latency`
(historical word-mode screen cohort or all1337, one worker). Seeds are42,1337,12648430.
Every run retains paired none/screen conditions and the frozen baseline sampling settings.
Historical full-character uses `perCategory:0`, not191, to make its all-case scope explicit.

A fresh-character exception is an artifact reference to a schema1 record with
`candidate:"baseline"`, `descriptiveOnly:true`, `registeredUTC`, `freezeSHA256`,
`allowedKind:"freshCharacter"`, and a nonempty `reason`. It must predate the run. It does
not authorize a changed scorer, fixture, product, sampler or alternative candidate.
The orchestration guard remains responsible for admitting that workload before inference.

Source bindings use the immutable assessor's existing schema: `label`, `role:"baseline"`,
`sourceSHA256`, `targets`, and `productionInventory` artifact reference. The complete
production inventory and validation harness must remain identical to the frozen baseline.
This permits a relocated current-main integration with a separately recorded compiler hash.

A parity snapshot proof is schema1/status `passed`, with identical nonempty `mainBefore`
and `mainAfter` logical-path/hash maps, plus `productionInventory` equal to the frozen
baseline inventory. Both runs must have identical corpus, checkpoints, seed, effective
configuration, and worker count. Exact comparisons cover raw text, displayed text, shown
and correct flags, checkpoint inputs and suppression; latency is excluded from parity.
Any mismatches are reported as evidence, not rescored or treated as a new candidate search.

Latency isolation uses the assessor's existing schema1/status `passed`, exact `labels`,
`intervals` matching run registration inference start/finish, `noOverlappingBuildOrInference:true`,
and an `evidence` artifact reference. A single-run proof can name just that run. A pair of
baseline repeats describes run-to-run timing variability; it is not a baseline/finalist
order counterbalance. P95 excludes pre-generation gates using the unchanged Swift rule.

For each complete run, output includes separate word-boundary, partial-only and all-checkpoint
metrics as appropriate, paired screen-minus-none counts and20,000-resample seed1337 intervals.
Fresh uncertainty keeps authored families together and stratifies by category; context kinds
are reported separately. Seed comparisons preserve matched phrase/checkpoint identities.
These are descriptive synthetic-corpus results; the output status can be `descriptive-only`
or `incomplete-or-invalid`, never an adoption status. Failed or missing registered attempts
remain visible. No prompts, references, raw completions or other case-level text are emitted.

## Narrow current-main compatibility exception

A descriptive-only baseline `sourceBindings` entry may add `compatibilityDifference` as an
artifact reference. This is limited to the separately root-reviewed
`app/Cotabby/Support/Focus/Applications/BrowserAppDetector.swift` edit adding explicit
`com.openai.codex` classification. The certificate binds exact before/after hashes, complete
frozen/current inventories, the frozen decision, a reviewed diff and a proof that neither
exact corpus contains that bundle identifier. All other production files, target bytes and
the full evaluation harness remain unchanged. The certificate must be reviewed before the
run starts. This exception exists only in the descriptive characterizer; it does not modify
or relax the immutable adoption assessor or the frozen candidate definition.

Certificate fields are `schemaVersion:1`, `status:"reviewed"`, `reviewer:"/root"`,
`reviewedUTC`, `rationale`, `baselineFreezeSHA256`, `allOtherProductionInputsEqual:true`,
`differences:[{path,beforeSHA256,afterSHA256}]`, plus `frozenInventory`, `currentInventory`,
`diff`, and `fixtureScopeProof` artifact references. The scope proof is schema1/status passed,
`affectedBundleIdentifiers:["com.openai.codex"]`, and `sources` for `historical`/`fresh`
with exact corpus hashes, phrase counts1337/700 and `matchingScenarioCount:0`.

## Launching the optional fresh character workload

This route is prepared, not automatically registered or executed. If its complete workload
fits the remaining window and closure reserve, write the exception first, then a separate
workload-extension record using the schemas above. Both timestamps must be at or after the
retained-baseline freeze; exception registration must precede workload registration, which
must precede launch. Preserve the original `baseline-workloads.json` hash.

The round runner requires both explicit flags. Replace the names and estimate below with
the exact preregistered row; the supplied estimate, seed, workers and label must match it.

```sh
python3 build/eval/round2-20260917/run_experiment.py fresh-character-baseline \
  --candidate baseline --phase validation --split all --mode character \
  --corpus /Users/jmcasler/Documents/GitHub/mchamster/cotabby/build/eval/round2-20260917/protected-fresh/corpus.json \
  --seed 42 --workers 3 --estimated-seconds <registered-estimate> \
  --reuse-checks baseline-checks \
  --descriptive-workload <absolute-workload-extension-path> \
  --descriptive-workload-sha256 <sha256-of-workload-extension>
```

The workload row has `kind:"freshCharacter"`, `mode:"character"`, `selection:"all"`,
`perCategory:0`, the frozen exact fresh corpus hash and the exception artifact reference.
Do not pass `--per-category` (even0). The runner records the descriptive admission in the
ordinary run registration and rechecks the freeze, workload and exception hashes after
checks and after replay. Production inventory, full compiler hash, model, sampling,
protected corpus, actual passed tests and deadline guards continue to apply.

For analysis, append the extension artifact to `baseline-evidence.json.plannedWorkloads`
and, after completion, add its run entry with the existing fresh-character-all opaque
manifest. The characterizer requires the actual registration's admission hashes and
settings to match that workload. No alternative candidate or adoption gate is authorized.

## Refreshing completed descriptive evidence

`refresh_baseline_evidence.py` assembles the map from `baseline-workloads.json`, previously
admitted hash-bound extensions, and any explicitly supplied `--workload` extension. It
does not discover or authorize new workload files. The default command only checks
registration/manifest/test-log identities and artifact hashes; report bytes are streamed
for hashing without parsing examples. It writes `baseline-evidence.json` atomically and
records every missing, active, failed or completed planned attempt in
`baseline-evidence-refresh.json`. Its `refreshed-metadata-only` status does not replace
the full characterizer's report/scorer/provenance checks.

```sh
python3 build/eval/round2-20260917/refresh_baseline_evidence.py
python3 build/eval/round2-20260917/refresh_baseline_evidence.py \
  --workload <explicit-workload-extension.json> --analyze
```

`--analyze` explicitly runs the existing characterizer and writes
`baseline-characterization.json`. Both modes hold the nonblocking
`descriptive-analysis.lock`, also held throughout the latency wrapper's collection and
replay; retry after latency finishes if the lock is busy. Direct characterizer invocations
do not acquire this lock, so use this wrapper for subsequent scheduled refreshes.

Completed labels use ordinary `<label>-registration.json`, `<label>/manifest.json`,
`<label>/report.json`, and the registration's `checks` path. Optional canonical artifacts
are `<label>-source-binding.json`, `<label>-snapshot-proof.json` and
`<label>-isolation.json`; explicit registration references must agree with canonical
paths if both exist. Integration emits the first two; the latency wrapper emits the third.
Seed comparisons use the seed42 anchor only when cohort, kind, workers and frozen source
roles match. Current-main parity requires the same seed/cohort/workers and a bound snapshot
proof. Latency repeats require two matching completed runs with passed isolation proofs.
Missing/failed isolation remains visible and cannot produce an accepted latency repeat.
No comparison depends on a score. Completed runs or prior workload hashes cannot silently
disappear or change on refresh.

Failed latency preflights are separate from benchmark attempts. If the collector refuses
the machine before creating an ordinary run registration, the workload remains
`registeredStatus:"not-started"`. The optional map field pins its original immutable proof:

```json
{"attemptDiagnostics":[
  {"name":"latency-one", "label":"latency-baseline-1", "kind":"latency-preflight",
   "status":"failed-before-benchmark",
   "isolation":{"path":"latency-baseline-1-isolation.json", "sha256":"..."}}
]}
```

The refresher and characterizer discover these receipts only for explicitly registered
latency workloads. They require no benchmark registration/output directory, failed
isolation with an empty inference interval, a summary with `registration:null`, and a
hash-bound plan matching the original workload, frozen decision, fixed one-worker
screen-cohort seed42 controls and preflight timestamps. The output's `attemptDiagnostics`
contains timestamps, collector issues, sample count and artifact references; it contains
no score or process-detail dump. The proof, summary, plan and sampled process log are
rehashed. Previously pinned receipts cannot silently change or acquire a benchmark run.

A separately authorized latency retry has its own name/label and immutable workload
extension, whose `originalAttempt:{label,isolation}` points to the original failed proof.
The latency driver owns retry admission. This visibility layer does not authorize a retry
or convert preflight failure into a completed/failed benchmark registration.

The latency wrapper's non-consuming observation is read-only and does not reserve a run:

```sh
python3 build/eval/round2-20260917/run_latency_baseline.py --preflight
```

It reports `quiet-now`, `busy`, or `observation-failed` and exits 2 when not quiet. A quiet
observation is not future isolation proof; the eventual run still performs all admission
and ongoing collection checks. If root separately registers a retry extension, launch it
using the exact row's label and artifact hash:

```sh
python3 build/eval/round2-20260917/run_latency_baseline.py \
  --label latency-baseline-1-retry1 \
  --workload <absolute-registered-extension-path> \
  --workload-sha256 <sha256-of-that-extension>
```

The retry label is `latency-baseline-[12]-retryN`, with positive N and a unique workload
name. The row retains kind `latency`, word mode, the historical screen cohort of 140 cases,
one worker, seed 42 and the 600-second estimate. Its `originalAttempt` must contain exactly the original base
`label` and failed `isolation` artifact reference. Existing original-label files are never
overwritten. This route only supports an original failure before benchmark registration;
post-inference retries require separate review. No retry is registered by this document.

Completed runs may have an optional `hostLaunch` admission and `hostLaunchEvidence` sidecar
reference in their ordinary registration. These bind a separately registered, baseline-only
test-host launch plan that appends exactly `-cotabbyMenuBarIconVisible NO` to the temporary
CotabbyTests target. The characterizer and refresher validate the plan, original frozen CLI
and round wrapper bytes, exact forwarded command, sidecar timing/status, and single argument
mutation. Per-run summaries expose those references. Earlier runs with neither field retain
their original launch procedure; an orphan sidecar, missing/tampered referenced artifact or
an extra mutation is rejected. This is process-local UI isolation, not a new model setting,
product patch, scorer change, or persistent preference write.
