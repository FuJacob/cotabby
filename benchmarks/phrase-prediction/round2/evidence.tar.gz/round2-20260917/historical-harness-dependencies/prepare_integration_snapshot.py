#!/usr/bin/env python3
"""Create the round's independent current-main integration snapshot without preserving xattrs."""
import datetime
import hashlib
import json
import os
import pathlib
import stat
import subprocess
import xml.etree.ElementTree as ET

MAIN = pathlib.Path(__file__).resolve().parents[3]
ROUND = pathlib.Path(__file__).resolve().parent
EXPERIMENT = pathlib.Path('/Users/jmcasler/.codex/experiments/cotabby-1337-20260917')
DESTINATION = EXPERIMENT / 'integration'
BASE = '342a76d002b534d13d3a9689768d13fda12f8609'
NATIVE_BASE = '7574a21516c65fc31f5cf8ef7380a03412eed480'
GIT_ENV = dict(os.environ, GIT_OPTIONAL_LOCKS='0')
EXCLUDED = {'.git', 'build', 'DerivedData', '.build', '__pycache__', '.venv', 'xcuserdata'}
RELEVANT_UNTRACKED = {'Cotabby', 'CotabbyTests', 'scripts', 'Config', 'assets', 'patches', 'Cotabby.xcodeproj'}


def git(root, *arguments):
    return subprocess.check_output(['git', '-C', str(root), *arguments], env=GIT_ENV)


def names(root, *arguments):
    return set(filter(None, git(root, 'ls-files', '-z', *arguments).decode().split('\0')))


def selection(root, native=False):
    tracked = names(root, '--cached')
    untracked = names(root, '--others', '--exclude-standard')
    relevant = {name for name in untracked if native or pathlib.PurePosixPath(name).parts[0] in RELEVANT_UNTRACKED}
    extra = set()
    if not native:
        extra.update(str(path.relative_to(root)) for path in (root / 'Config').glob('*.xcconfig'))
        lock = root / 'Cotabby.xcodeproj/project.xcworkspace/xcshareddata/swiftpm/Package.resolved'
        if lock.is_file():
            extra.add(str(lock.relative_to(root)))
    else:
        if (root / 'Package.resolved').is_file():
            extra.add('Package.resolved')
    selected = {name for name in tracked | relevant | extra
                if not EXCLUDED.intersection(pathlib.PurePosixPath(name).parts)
                and not name.endswith(('.pyc', '.pyo', '.DS_Store'))}
    return selected, sorted(untracked - relevant), sorted((tracked | relevant | extra) - selected)


def capture(root, native=False):
    head_before = git(root, 'rev-parse', 'HEAD').decode().strip()
    status_before = git(root, 'status', '--short').decode()
    selected, omitted, excluded = selection(root, native)
    entries, contents = {}, {}
    for name in sorted(selected):
        path = root / name
        if path.is_symlink():
            target = os.readlink(path)
            data = target.encode()
            entries[name] = {'kind': 'symlink', 'target': target, 'sha256': hashlib.sha256(data).hexdigest()}
            contents[name] = data
        elif path.is_file():
            before = path.stat()
            data = path.read_bytes()
            after = path.stat()
            if (before.st_size, before.st_mtime_ns) != (after.st_size, after.st_mtime_ns):
                raise RuntimeError(f'Source changed while reading: {name}')
            entries[name] = {'kind': 'file', 'sha256': hashlib.sha256(data).hexdigest(),
                             'size': len(data), 'mode': stat.S_IMODE(after.st_mode)}
            contents[name] = data
        elif not path.exists():
            entries[name] = {'kind': 'deleted'}
        else:
            raise RuntimeError(f'Unexpected source input kind: {name}')
    if selected != selection(root, native)[0] or head_before != git(root, 'rev-parse', 'HEAD').decode().strip():
        raise RuntimeError('Source inventory or HEAD changed while reading')
    identity = hashlib.sha256(json.dumps(entries, sort_keys=True, separators=(',', ':')).encode()).hexdigest()
    return {'root': str(root), 'head': head_before, 'gitStatus': status_before, 'files': entries,
            'sourceSHA256': identity, 'omittedUntracked': omitted, 'excludedArtifacts': excluded}, contents


def initialize(root, source, commit, log):
    root.mkdir()
    with log.open('w') as stream:
        for command in (['git', 'init', str(root)],
                        ['git', '-C', str(root), 'fetch', '--no-tags', '--update-shallow', str(source), commit],
                        ['git', '-C', str(root), 'checkout', '--detach', 'FETCH_HEAD']):
            subprocess.run(command, check=True, env=GIT_ENV, stdout=stream, stderr=subprocess.STDOUT)


def overlay(target, snapshot, contents, previous):
    for name in previous - snapshot['files'].keys():
        path = target / name
        if path.is_file() or path.is_symlink():
            path.unlink()
    for name, entry in snapshot['files'].items():
        path = target / name
        if entry['kind'] == 'deleted':
            if path.is_file() or path.is_symlink():
                path.unlink()
            continue
        path.parent.mkdir(parents=True, exist_ok=True)
        if path.is_symlink():
            path.unlink()
        if entry['kind'] == 'symlink':
            if path.exists():
                path.unlink()
            path.symlink_to(entry['target'])
        else:
            path.write_bytes(contents[name])
            path.chmod(entry['mode'])
    for name, entry in snapshot['files'].items():
        path = target / name
        if entry['kind'] == 'deleted':
            assert not path.exists(), name
        elif entry['kind'] == 'symlink':
            assert path.is_symlink() and os.readlink(path) == entry['target'], name
        else:
            assert hashlib.sha256(path.read_bytes()).hexdigest() == entry['sha256'], name
            assert stat.S_IMODE(path.stat().st_mode) == entry['mode'], name


def stable_overlay(source, target, native=False):
    attempts, previous = [], set()
    for attempt in range(1, 6):
        before, contents = capture(source, native)
        overlay(target, before, contents, previous)
        previous = set(before['files'])
        after, _ = capture(source, native)
        attempts.append({'attempt': attempt, 'beforeSHA256': before['sourceSHA256'], 'afterSHA256': after['sourceSHA256']})
        if before['sourceSHA256'] == after['sourceSHA256'] and before['head'] == after['head']:
            return {'before': before, 'after': after, 'attempts': attempts,
                    'destination': str(target), 'destinationMatchesSourceBytesAndModes': True}
    raise RuntimeError('Source kept changing during five integration snapshot attempts')


def main(resume_initialized=False):
    if DESTINATION.exists() and not resume_initialized:
        raise RuntimeError('Refusing to overwrite an existing integration directory')
    if not resume_initialized:
        DESTINATION.mkdir()
    execution = json.loads((ROUND / 'execution.json').read_text())
    workspace_xml = pathlib.Path(execution['workspace']) / 'contents.xcworkspacedata'
    frozen_native = next(pathlib.Path(item.attrib['location'].split(':', 1)[1])
                         for item in ET.parse(workspace_xml).iter('FileRef')
                         if (pathlib.Path(item.attrib['location'].split(':', 1)[1]) / 'Package.swift').is_file())
    app, native = DESTINATION / 'cotabby', DESTINATION / 'cotabbyinference'
    if resume_initialized:
        assert git(app, 'rev-parse', 'HEAD').decode().strip() == BASE
        assert git(native, 'rev-parse', 'HEAD').decode().strip() == NATIVE_BASE
        assert not (ROUND / 'integration-snapshot.json').exists()
    else:
        initialize(app, MAIN, BASE, ROUND / 'integration-app-git-setup.log')
        initialize(native, frozen_native, NATIVE_BASE, ROUND / 'integration-native-git-setup.log')
    app_record = stable_overlay(MAIN, app)
    native_record = stable_overlay(frozen_native, native, native=True)
    expected_native = json.loads((ROUND / 'native-frozen-manifest.json').read_text())['files']
    assert all(native_record['after']['files'][name]['sha256'] == digest for name, digest in expected_native.items())
    workspace = app / 'build/CotabbyDevelopment.xcworkspace'
    workspace.mkdir(parents=True)
    document = ET.Element('Workspace', version='1.0')
    for path in (app / 'Cotabby.xcodeproj', native):
        ET.SubElement(document, 'FileRef', location='absolute:' + str(path))
    ET.ElementTree(document).write(workspace / 'contents.xcworkspacedata', encoding='UTF-8', xml_declaration=True)
    model = pathlib.Path(execution['model'])
    digest = hashlib.sha256()
    with model.open('rb') as stream:
        while chunk := stream.read(1_048_576):
            digest.update(chunk)
    expected_model = json.loads((ROUND / 'round.json').read_text())['modelSHA256']
    assert digest.hexdigest() == expected_model, 'Model does not match verified round model'
    model_link = DESTINATION / model.name
    model_link.symlink_to(model)
    # Recheck main after native/model/workspace setup as well, before publishing ready provenance.
    final_main, _ = capture(MAIN)
    if final_main['sourceSHA256'] != app_record['after']['sourceSHA256']:
        app_record = stable_overlay(MAIN, app)
        final_main, _ = capture(MAIN)
    assert final_main['sourceSHA256'] == app_record['after']['sourceSHA256']
    target_files = ['Cotabby/Support/Context/SurfaceContextComposer.swift',
                    'Cotabby/Models/Suggestion/Request/SuggestionConfiguration.swift',
                    'CotabbyTests/Support/Context/SurfaceContextComposerTests.swift',
                    'CotabbyTests/Support/Prompting/BaseCompletionPromptRendererTests.swift',
                    'CotabbyTests/Support/Suggestion/Request/SuggestionRequestFactoryTests.swift']
    baseline_files = {}
    for name in target_files:
        baseline_hash = hashlib.sha256(git(MAIN, 'show', BASE + ':' + name)).hexdigest()
        assert app_record['after']['files'][name]['sha256'] == baseline_hash, f'Adoption target changed: {name}'
        baseline_files[name] = baseline_hash
    manifest = {'preparedUTC': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'status': 'ready-not-built',
                'baselineRevision': BASE, 'app': app_record, 'native': native_record,
                'finalMainSHA256': final_main['sourceSHA256'], 'baselineAdoptionFiles': baseline_files,
                'execution': {'root': str(app), 'workspace': str(workspace), 'model': str(model_link),
                              'derivedData': str(app / 'build/DerivedData')},
                'model': {'link': str(model_link), 'target': str(model), 'sha256': digest.hexdigest()},
                'copyMethod': 'Independent local Git fetch/detached checkout; working source overlaid with read_bytes/write_bytes, chmod, and explicit symlinks; no copied xattrs.',
                'potentialMissingInputs': ['Build directories, DerivedData, user Xcode state, caches and source .git metadata deliberately excluded.',
                    'Untracked orchestration documents and round result exports are omitted; exact names appear in omittedUntracked.',
                    'Gitignored inputs outside Config/*.xcconfig and canonical project/package lockfiles are not copied.',
                    'SwiftPM caches/binary artifacts are not copied; explicit package resolution must populate the new DerivedData.'],
                'mainWorkingFilesModified': False, 'mainGitMetadataModified': False, 'buildTestInferenceExecuted': False}
    (ROUND / 'integration-snapshot.json').write_text(json.dumps(manifest, indent=2, sort_keys=True) + '\n')
    (ROUND / 'integration-main.patch').write_bytes(git(MAIN, 'diff', 'HEAD', '--', '.', ':(exclude)build'))
    print(json.dumps({'status': manifest['status'], 'execution': manifest['execution'], 'appFiles': len(app_record['after']['files']),
                      'nativeFiles': len(native_record['after']['files']), 'sourceSHA256': final_main['sourceSHA256'],
                      'manifest': str(ROUND / 'integration-snapshot.json')}, indent=2))


if __name__ == '__main__':
    main()
