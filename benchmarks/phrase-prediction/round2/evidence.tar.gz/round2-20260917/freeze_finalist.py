#!/usr/bin/env python3
"""Freeze exactly one eligible development-screen winner before protected replay.

The decision is mechanical and immutable. It binds existing scored evidence and frozen
production bytes; it never reads supplementary reference cases or validation results.
"""
import datetime
import hashlib
import json
from pathlib import Path
import shutil

import production_inventory as inventory
from screening_evidence import validate_rows

HERE = Path(__file__).resolve().parent
MAIN = HERE.parents[2]


def read(path):
    return json.loads(path.read_text())


def write_new(path, data):
    with path.open('x') as stream:
        stream.write(json.dumps(data, indent=2) + '\n')


def targets(row):
    record = read(HERE / (row['label'] + '-registration.json'))
    return {**record['promptSource']['hashes'], 'nativeEngine': record['nativeSource']['sha256']}


def freeze():
    destination = HERE / 'finalist-freeze.json'
    if destination.exists():
        raise ValueError('The finalist is already frozen; no replacement is permitted')
    now = datetime.datetime.now(datetime.timezone.utc)
    deadline = datetime.datetime.fromisoformat(read(HERE / 'round.json')['freezeDeadlineUTC'].replace('Z', '+00:00'))
    if now >= deadline:
        raise ValueError('The registered finalist freeze deadline has elapsed')
    combination_record = read(HERE / 'combination-registration.json')
    ranking = read(HERE / 'screening-ranking.json')
    rows = validate_rows(ranking['rows'])
    indexed = {row['candidate']: row for row in rows}
    singles = [f'{family}{i}' for family in 'HFM' for i in range(1, 5)]
    expected = ['baseline', *singles] + [item['candidate'] for item in combination_record['combinations']]
    if set(indexed) != set(expected):
        raise ValueError('Registered candidate evidence is incomplete or includes unregistered combinations')
    baseline = indexed['baseline']
    qualified = [row for row in rows if row['candidate'] != 'baseline'
                 and row['screenCorrect'] > baseline['screenCorrect']
                 and row['noneCorrect'] >= baseline['noneCorrect']]
    winner = min(qualified, key=lambda row: (-row['screenCorrect'], -row['noneCorrect'],
                                            expected.index(row['candidate']))) if qualified else baseline
    for row in rows:
        for suffix, expected_hash in [(f"{row['label']}/report.json", row['reportSHA256']),
                                      (f"{row['label']}-registration.json", row['registrationSHA256'])]:
            if hashlib.sha256((HERE / suffix).read_bytes()).hexdigest() != expected_hash:
                raise ValueError('Screening evidence changed after ranking')
    # The currently selected source can be any completed candidate. Verify every production
    # input against the starting snapshot with only the registered targets substituted.
    execution = read(HERE / 'execution.json')
    base_inventory = inventory.baseline_from_snapshot()
    actual = inventory.capture(execution['root'], execution['native'])
    current_targets = {key: actual['files'][path] for key, path in inventory.TARGET_PATHS.items()}
    if actual != inventory.with_targets(base_inventory, current_targets):
        raise ValueError('Unregistered production source drift before finalist freeze')
    if current_targets not in [targets(row) for row in rows]:
        raise ValueError('Current production targets do not correspond to a completed candidate')
    baseline_targets, candidate_targets = targets(baseline), targets(winner)
    baseline_inventory = inventory.with_targets(base_inventory, baseline_targets)
    candidate_inventory = inventory.with_targets(base_inventory, candidate_targets)
    write_new(HERE / 'baseline-production-inventory.json', baseline_inventory)
    write_new(HERE / 'candidate-production-inventory.json', candidate_inventory)
    shutil.copyfile(HERE / 'screening-ranking.json', HERE / 'screening-at-freeze.json')
    shutil.copyfile(MAIN / 'IMPROVEMENT_BRAINSTORMING_ROUND_TWO.md', HERE / 'criteria-at-freeze.md')
    readiness = read(HERE / 'fresh-readiness.json')
    if readiness['status'] != 'pass':
        raise ValueError('Fresh readiness did not pass')
    baseline_manifest = read(HERE / baseline['label'] / 'manifest.json')
    winner_manifest = read(HERE / winner['label'] / 'manifest.json')
    app = Path(execution['root'])
    harness_paths = sorted((app / 'CotabbyTests/Evals').glob('*.swift')) + [
        app / 'CotabbyTests/TestSupport/CotabbyTestFixtures.swift',
        app / 'scripts/phrase_eval.py', app / 'scripts/analyze_phrase_experiments.py',
        app / 'scripts/analyze_completion_prefixes.py']
    harness_hashes = {'app/' + str(path.relative_to(app)): hashlib.sha256(path.read_bytes()).hexdigest()
                      for path in harness_paths}
    frozen = {
        'schemaVersion': 1, 'frozenUTC': now.isoformat(),
        'candidate': winner['candidate'], 'components': winner['components'],
        'candidateLabel': winner['label'], 'baselineLabel': baseline['label'],
        'selectionQualified': bool(qualified),
        'screeningEvidence': inventory.reference(HERE / 'screening-at-freeze.json'),
        'screeningEvidenceSHA256': hashlib.sha256((HERE / 'screening-at-freeze.json').read_bytes()).hexdigest(),
        'criteria': inventory.reference(HERE / 'criteria-at-freeze.md'),
        'combinationRegistration': inventory.reference(HERE / 'combination-registration.json'),
        'selectionClarification': inventory.reference(HERE / 'selection-clarification.json'),
        'freshReadiness': inventory.reference(HERE / 'fresh-readiness.json'),
        'freshCorpusSHA256': readiness['corpusSHA256'],
        'modelSHA256': read(HERE / 'round.json')['modelSHA256'],
        'baselineSourceSHA256': baseline_manifest['buildInputs']['sourceSHA256'],
        'candidateSourceSHA256': winner_manifest['buildInputs']['sourceSHA256'],
        'baselineTargets': baseline_targets, 'candidateTargets': candidate_targets,
        'validationHarnessHashes': harness_hashes,
        'prerequisiteHashes': {key: value for key, value in baseline_inventory['files'].items()
                               if key not in inventory.TARGET_PATHS.values()},
        'productionInventories': {
            'baseline': inventory.reference(HERE / 'baseline-production-inventory.json'),
            'finalist': inventory.reference(HERE / 'candidate-production-inventory.json')},
        'scope': 'One development-selected finalist; supplementary outcomes cannot change this choice.'
    }
    write_new(destination, frozen)
    for path in [destination, HERE / 'screening-at-freeze.json', HERE / 'criteria-at-freeze.md',
                 HERE / 'baseline-production-inventory.json', HERE / 'candidate-production-inventory.json']:
        path.chmod(0o444)
    print(json.dumps({key: frozen[key] for key in ('candidate', 'components', 'selectionQualified', 'frozenUTC')}, indent=2))


if __name__ == '__main__':
    freeze()
