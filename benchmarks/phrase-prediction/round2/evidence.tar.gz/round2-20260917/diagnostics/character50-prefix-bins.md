# Historical character-prefix diagnostic

Post-freeze descriptive diagnostic; no candidate selection, tuning, or rescoring.

Completed `character50-baseline-retry1`: 350 scenarios, first 50 per category, seed 42. Each condition has 8,830 checkpoints; the interrupted original attempt is excluded.

| Typed characters | Checkpoints/condition | None correct | Screen correct | None accuracy | Screen accuracy | Screen−none | Gains/losses | None shown | Screen shown |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| boundary | 1,894 | 626 | 764 | 33.05% | 40.34% | +7.29 pp | 234/96 | 99.95% | 100.00% |
| 1 | 1,827 | 1,122 | 1,346 | 61.41% | 73.67% | +12.26 pp | 285/61 | 98.30% | 99.56% |
| 2 | 1,580 | 1,115 | 1,296 | 70.57% | 82.03% | +11.46 pp | 224/43 | 97.66% | 99.49% |
| 3 | 1,230 | 850 | 974 | 69.11% | 79.19% | +10.08 pp | 150/26 | 95.12% | 97.15% |
| 4-5 | 1,481 | 747 | 854 | 50.44% | 57.66% | +7.22 pp | 151/44 | 85.01% | 86.02% |
| 6+ | 818 | 371 | 413 | 45.35% | 50.49% | +5.13 pp | 71/29 | 83.62% | 85.70% |
| partial-only | 6,936 | 4,205 | 4,883 | 60.63% | 70.40% | +9.78 pp | 881/203 | 93.02% | 94.59% |
| all | 8,830 | 4,831 | 5,647 | 54.71% | 63.95% | +9.24 pp | 1115/299 | 94.51% | 95.75% |

Suppression counts are recorded reasons among unshown observations:

| Typed characters | None not shown (reasons) | Screen not shown (reasons) |
|---|---|---|
| boundary | 1 (normalizer:1) | 0 (none) |
| 1 | 31 (normalizer:1, seam-guard:30) | 8 (normalizer:4, seam-guard:4) |
| 2 | 37 (normalizer:1, seam-guard:36) | 8 (seam-guard:8) |
| 3 | 60 (normalizer:2, seam-guard:58) | 35 (seam-guard:35) |
| 4-5 | 222 (normalizer:2, seam-guard:220) | 207 (seam-guard:207) |
| 6+ | 134 (normalizer:2, seam-guard:132) | 117 (seam-guard:117) |
| partial-only | 484 (normalizer:8, seam-guard:476) | 375 (normalizer:4, seam-guard:371) |

Per-category counts, matched display transitions, phrase counts per bin, source/report hashes, and full limitations are in the adjacent JSON. No prompts, references, or completions are exported.

Screen-context partial errors comprise 1,678 displayed-but-incorrect continuations and 375 unshown observations. The four-or-more-character bins contain 2,299 of 6,936 partial checkpoints and 324 of the 375 unshown observations. They also retain 708 displayed-but-incorrect continuations. This concentrates a useful future diagnostic, without establishing that the guard is wrong.

Prospective diagnostic priorities; no tuning is authorized by this memo:

- In a future round, separate target-word length and scenario composition from typed-offset effects using matched target positions; current bins alone cannot identify a causal mechanism.
- Examine why generated continuations at longer partial prefixes fail existing seam validation, while retaining the guard. Suppression counts do not justify displaying those hidden continuations.
- Keep displayed-but-incorrect partial completions as a separate outcome: their count exceeds suppression among remaining errors. Validate any future word-choice or partial-prefix hypothesis on independent scenarios.

- Correctness and display visibility use the stored Swift correct/wasShown flags without lexical rescoring.
- Bins use stored Swift typedCharacters offsets, not bytes or a reconstructed Python string length.
- Checkpoints are weighted equally. Several offsets/words from each scenario are dependent; these counts are not independent trials.
- Different bins contain different target-word and scenario populations; their accuracy slope is descriptive, not a causal typing-length effect.
- Only the historical first50/category subset is included; it is not the full1337 corpus or fresh validation data.
- No new confidence intervals or hypothesis tests are calculated; the existing scenario-clustered characterization retains its own scope.
- Suppression reasons come from the report. They do not determine whether the hidden raw continuation would have been correct.
- Three-worker timings are contended and omitted. This is not an end-to-end acceptance or keystroke-savings measurement.
- The interrupted original attempt contributes no observations.
