#!/usr/bin/env python3
"""Describe agreement across completed baseline seeds without changing scoring.

This round-only diagnostic joins the existing Swift checkpoint identities and correctness
flags. It owns no inference, text matching, candidate selection, or adoption decision.
Keeping it separate from the scorer makes the limits of repeated-seed evidence explicit.
"""
import hashlib
import json
from collections import Counter
from pathlib import Path

HERE = Path(__file__).resolve().parents[1]
LABELS = ('fresh-baseline', 'fresh1337-baseline', 'freshproduction-baseline')


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def collect():
    sources, runs = [], []
    frozen = json.loads((HERE / 'finalist-freeze.json').read_text())
    assert frozen['candidate'] == 'baseline' and frozen['selectionQualified'] is False
    for label, seed in zip(LABELS, (42, 1337, 12648430)):
        report_path = HERE / label / 'report.json'
        registration_path = HERE / (label + '-registration.json')
        registration = json.loads(registration_path.read_text())
        report = json.loads(report_path.read_text())
        assert registration['status'] == 'complete' and registration['candidate'] == 'baseline'
        assert registration['evidenceSHA256']['report'] == sha(report_path)
        assert report['errorCount'] == 0
        assert report['metadata']['seed'] == seed
        assert report['metadata']['corpusSHA256'] == frozen['freshCorpusSHA256']
        rows = {}
        for phrase in report['phrases']:
            for observation in phrase['observations']:
                assert type(observation['correct']) is bool
                key = (phrase['phrase']['id'], phrase['condition'],
                       json.dumps(observation['checkpoint'], sort_keys=True))
                assert key not in rows
                rows[key] = observation
        assert len(rows) == 5784
        runs.append(rows)
        sources.append({'label': label, 'reportSHA256': sha(report_path),
                        'registrationSHA256': sha(registration_path),
                        'seed': report['metadata']['seed']})
    assert all(set(run) == set(runs[0]) for run in runs[1:])
    result = {}
    for condition in ('none', 'screen'):
        keys = [key for key in runs[0] if key[1] == condition]
        correctness = Counter(sum(bool(run[key]['correct']) for run in runs) for key in keys)
        totals = [sum(bool(run[key]['correct']) for key in keys) for run in runs]
        result[condition] = {
            'checkpointCount': len(keys), 'correctCountsBySeed': totals,
            'correctInExactlyNSeeds': {str(n): correctness[n] for n in range(4)},
            'correctnessVariesAcrossSeeds': correctness[1] + correctness[2],
            'rawOutputEqualAcrossAllSeeds': sum(len({run[key]['raw'] for run in runs}) == 1 for key in keys),
            'displayedTextEqualAcrossAllSeeds': sum(len({run[key]['shown'] for run in runs}) == 1 for key in keys),
        }
        assert sum(correctness.values()) == len(keys)
        assert sum(n * count for n, count in correctness.items()) == sum(totals)
    context = Counter()
    for key in runs[0]:
        if key[1] != 'screen':
            continue
        no_screen = (key[0], 'none', key[2])
        effects = tuple(int(run[key]['correct']) - int(run[no_screen]['correct']) for run in runs)
        if all(effect == 1 for effect in effects):
            context['helpedInAllThreeSeeds'] += 1
        elif all(effect == -1 for effect in effects):
            context['harmedInAllThreeSeeds'] += 1
        elif all(effect == 0 for effect in effects):
            context['zeroDifferenceInAllThreeSeeds'] += 1
        else:
            context['differenceVariesAcrossSeeds'] += 1
    assert sum(context.values()) == 2892
    return {'schemaVersion': 1, 'status': 'descriptive-only', 'sources': sources,
            'conditions': result, 'contextCorrectnessDifference': dict(context),
            'limitations': [
                'Uses existing Swift correctness flags, not a new semantic score.',
                'Same 700 scenarios at three seeds; these are not independent new cases.',
                'Raw or displayed equality is not semantic correctness.',
                'No population interval or candidate gain is claimed.',
                'Context difference zero includes both correct and both incorrect checkpoints.',
            ]}


if __name__ == '__main__':
    result = collect()
    output = Path(__file__).with_suffix('.json')
    output.write_text(json.dumps(result, indent=2, sort_keys=True) + '\n')
    print(json.dumps(result, indent=2, sort_keys=True))
