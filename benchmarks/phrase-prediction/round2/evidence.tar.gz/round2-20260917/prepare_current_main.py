#!/usr/bin/env python3
"""Prepare a byte-verified current-main baseline snapshot without builds or xattrs.

Only the private integration checkout receives the frozen test harness. The one reviewed
main-production difference is retained explicitly; it does not revise the frozen decision.
"""
import datetime
import difflib
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import stat
import uuid
import xml.etree.ElementTree as ET

import production_inventory as production

ROUND=Path(__file__).resolve().parent
MAIN=ROUND.parents[2]
MAIN_NATIVE=MAIN.parent/'cotabbyinference'
DESTINATION=Path('/Users/jmcasler/.codex/experiments/cotabby-1337-round2-20260917/integration')
REVIEWED_PATH='app/Cotabby/Support/Focus/Applications/BrowserAppDetector.swift'
REVIEWED_FROZEN='7b1b5161af4be0d92ad95314db52b1a24c73ba7b40c9c8758531f742974bf3ce'
REVIEWED_CURRENT='a7e30348f9142b876cbafc66d20d03fc5871bec9ce1734e9e1f3c49aa7ef59c3'
EXTRA_HARNESS=('CotabbyTests/Support/Prompting/BaseCompletionPromptRendererTests.swift',
               'CotabbyTests/Services/Runtime/Llama/LlamaRuntimeCoreIntegrationTests.swift')


def module(name,path):
    spec=importlib.util.spec_from_file_location(name,path)
    value=importlib.util.module_from_spec(spec);spec.loader.exec_module(value);return value


def sha(data):return hashlib.sha256(data).hexdigest()
def file_sha(path):
    digest=hashlib.sha256()
    with path.open('rb') as stream:
        while chunk:=stream.read(1048576):digest.update(chunk)
    return digest.hexdigest()
def read(path):return json.loads(path.read_text())
def write(path,data):
    path.parent.mkdir(parents=True,exist_ok=True)
    temporary=path.with_name('.'+path.name+'.'+uuid.uuid4().hex)
    temporary.write_text(json.dumps(data,indent=2,sort_keys=True)+'\n');temporary.replace(path)
def reference(path):return {'path':str(path),'sha256':file_sha(path)}


def expected_production(frozen):
    ref=frozen['productionInventories']['baseline'];path=ROUND/ref['path']
    if file_sha(path)!=ref['sha256']:raise ValueError('Frozen baseline production artifact changed')
    expected=read(path)
    if len(expected['files'])!=344 or expected['files'].get(REVIEWED_PATH)!=REVIEWED_FROZEN:
        raise ValueError('Frozen production boundary differs from the reviewed344-input baseline')
    allowed=json.loads(json.dumps(expected));allowed['files'][REVIEWED_PATH]=REVIEWED_CURRENT
    return expected,allowed


def require_production(actual,allowed):
    differences=[{'path':name,'expected':allowed['files'].get(name),'actual':actual['files'].get(name)}
                 for name in sorted(actual['files'].keys()|allowed['files'].keys())
                 if actual['files'].get(name)!=allowed['files'].get(name)]
    if actual!=allowed:raise ValueError('Unreviewed production differences: '+json.dumps(differences))


def configure_capture(legacy):
    original=legacy.selection
    def selected(root,native=False):
        chosen,omitted,excluded=original(root,native)
        # Include physical source/config inputs even when Git ignores them. Cache/build
        # artifacts remain excluded, and symlink bytes are captured without following them.
        roots=['Sources','Tests'] if native else sorted(legacy.RELEVANT_UNTRACKED)
        for base in roots:
            start=root/base
            if not start.exists():continue
            for directory,folders,files in os.walk(start,followlinks=False):
                folders[:]=[name for name in folders if name not in legacy.EXCLUDED]
                for name in files+[value for value in folders if (Path(directory)/value).is_symlink()]:
                    path=Path(directory)/name;relative=str(path.relative_to(root))
                    if not legacy.EXCLUDED.intersection(Path(relative).parts) and not relative.endswith(('.pyc','.pyo','.DS_Store')):
                        chosen.add(relative)
        return chosen,sorted(set(omitted)-chosen),excluded
    legacy.selection=selected


def scenario_certificate(frozen,execution):
    old=Path(execution['root'])/'CotabbyTests/Fixtures/phrase-prediction-1337.json'
    readiness=read(ROUND/frozen['freshReadiness']['path']);fresh=Path(readiness['corpusPath'])
    if file_sha(ROUND/frozen['freshReadiness']['path'])!=frozen['freshReadiness']['sha256']:
        raise ValueError('Frozen readiness changed')
    sources=[]
    for kind,path,expected in [('historical',old,None),('fresh',fresh,frozen['freshCorpusSHA256'])]:
        digest=file_sha(path)
        if expected and digest!=expected:raise ValueError('Protected fixture identity changed')
        data=read(path)
        count=sum(phrase['scenario']['bundleIdentifier']=='com.openai.codex' for phrase in data['phrases'])
        if count:raise ValueError('Reviewed app-classification difference reaches a benchmark scenario')
        sources.append({'kind':kind,'corpusSHA256':digest,'phraseCount':len(data['phrases']),'matchingScenarioCount':count})
    return {'schemaVersion':1,'status':'passed',
            'operation':'Aggregate exact bundleIdentifier equality only; no reference/output examples inspected',
            'affectedBundleIdentifiers':['com.openai.codex'],'sources':sources}


def main():
    if DESTINATION.exists() or (ROUND/'integration-snapshot.json').exists():
        raise ValueError('Refusing to overwrite a prior integration snapshot or manifest')
    legacy=module('round1_snapshot_helpers',ROUND.parent/'round1-20260917/prepare_integration_snapshot.py')
    configure_capture(legacy)
    execution=read(ROUND/'execution.json');frozen_path=ROUND/'finalist-freeze.json';frozen=read(frozen_path)
    frozen_digest=file_sha(frozen_path)
    if frozen['candidate']!='baseline' or frozen['selectionQualified'] is not False:
        raise ValueError('This snapshot is scoped only to the retained-baseline descriptive comparison')
    expected,allowed=expected_production(frozen)
    record={'schemaVersion':1,'startedUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),
            'status':'preparing','scope':'Descriptive current-main retained-baseline parity; no adoption candidate',
            'frozenDecision':reference(frozen_path),'buildTestInferenceExecuted':False,
            'mainWorkingFilesModified':False,'mainGitMetadataModified':False}
    evidence=ROUND/'integration-preparation';evidence.mkdir(exist_ok=False)
    try:
        main_before,_=legacy.capture(MAIN);native_before,_=legacy.capture(MAIN_NATIVE,native=True)
        record['mainBefore']={'app':main_before,'native':native_before}
        current=production.capture(MAIN,MAIN_NATIVE);require_production(current,allowed)
        frozen_file=Path(execution['root'])/REVIEWED_PATH.removeprefix('app/')
        current_file=MAIN/REVIEWED_PATH.removeprefix('app/')
        if file_sha(frozen_file)!=REVIEWED_FROZEN or file_sha(current_file)!=REVIEWED_CURRENT:
            raise ValueError('Reviewed difference source bytes changed')
        diff=evidence/'reviewed-production-difference.patch'
        diff.write_text(''.join(difflib.unified_diff(frozen_file.read_text().splitlines(True),current_file.read_text().splitlines(True),fromfile='frozen/'+REVIEWED_PATH,tofile='current-main/'+REVIEWED_PATH)))
        write(evidence/'fixture-scope-proof.json',scenario_certificate(frozen,execution))
        write(evidence/'current-production-inventory.json',current)
        certificate={'schemaVersion':1,'status':'reviewed','baselineFreezeSHA256':frozen_digest,
                     'reviewedUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'reviewer':'/root',
                     'rationale':'Root reviewed only explicit com.openai.codex classification plus teaching comment; preserve the external edit.',
                     'differences':[{'path':REVIEWED_PATH,'beforeSHA256':REVIEWED_FROZEN,'afterSHA256':REVIEWED_CURRENT}],
                     'frozenInventory':reference(ROUND/frozen['productionInventories']['baseline']['path']),
                     'currentInventory':reference(evidence/'current-production-inventory.json'),
                     'frozenInputCount':344,'currentInputCount':344,'allOtherProductionInputsEqual':True,
                     'diff':reference(diff),'fixtureScopeProof':reference(evidence/'fixture-scope-proof.json'),
                     'scope':'Explicit common difference for descriptive current-main baseline parity only; frozen assessment unchanged.'}
        write(evidence/'production-difference-certificate.json',certificate)
        record['productionDifferenceCertificate']=reference(evidence/'production-difference-certificate.json')
        record['frozenBaselineProduction']=expected;record['expectedCurrentMainProduction']=allowed
        cli=module('round2_preserved_fixture_cli',Path(execution['root'])/'scripts/phrase_eval.py')
        harness_source=cli.build_input_snapshot(Path(execution['workspace']))
        if harness_source['sourceSHA256']!=frozen['baselineSourceSHA256']:
            raise ValueError('Frozen harness checkout compiler identity changed')
        harness={name.removeprefix('app/'):digest for name,digest in frozen['validationHarnessHashes'].items() if name.startswith('app/')}
        if len(harness)!=len(frozen['validationHarnessHashes']):raise ValueError('Unexpected non-app harness overlay')
        for name in EXTRA_HARNESS:harness[name]=file_sha(Path(execution['root'])/name)
        for name,digest in harness.items():
            if not (name.startswith('CotabbyTests/') or name.startswith('scripts/')) or '..' in Path(name).parts:
                raise ValueError('Harness overlay escaped test/script scope')
            if file_sha(Path(execution['root'])/name)!=digest:raise ValueError('Frozen harness bytes changed: '+name)
        DESTINATION.mkdir()
        app,native=DESTINATION/'cotabby',DESTINATION/'cotabbyinference'
        legacy.initialize(app,MAIN,main_before['head'],evidence/'app-git-setup.log')
        legacy.initialize(native,MAIN_NATIVE,native_before['head'],evidence/'native-git-setup.log')
        app_record=legacy.stable_overlay(MAIN,app)
        native_record=legacy.stable_overlay(MAIN_NATIVE,native,native=True)
        if app_record['after']['head']!=main_before['head'] or native_record['after']['head']!=native_before['head']:
            raise ValueError('Main HEAD changed during snapshot')
        copied_app,_=legacy.capture(app);copied_native,_=legacy.capture(native,native=True)
        if copied_app['files']!=app_record['after']['files'] or copied_native['files']!=native_record['after']['files']:
            raise ValueError('Private snapshot bytes/modes differ from main sources')
        require_production(production.capture(app,native),allowed)
        overlays=[]
        for name,digest in sorted(harness.items()):
            source=Path(execution['root'])/name;target=app/name
            before={'sha256':file_sha(target) if target.is_file() else None,
                    'mode':stat.S_IMODE(target.stat().st_mode) if target.exists() else None}
            data=source.read_bytes();mode=stat.S_IMODE(source.stat().st_mode)
            if sha(data)!=digest:raise ValueError('Harness changed while copying: '+name)
            target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data);target.chmod(mode)
            if file_sha(target)!=digest or stat.S_IMODE(target.stat().st_mode)!=mode:raise ValueError('Harness copy verification failed')
            overlays.append({'path':name,'source':str(source),'before':before,'after':{'sha256':digest,'mode':mode},
                             'frozenValidationHarness':('app/'+name) in frozen['validationHarnessHashes']})
        if cli.build_input_snapshot(Path(execution['workspace']))!=harness_source:
            raise ValueError('Frozen harness compiler inputs changed across copying')
        post_app,_=legacy.capture(app);post_native,_=legacy.capture(native,native=True)
        changed={name for name in set(copied_app['files'])|set(post_app['files']) if copied_app['files'].get(name)!=post_app['files'].get(name)}
        if not changed<=set(harness) or post_native['files']!=copied_native['files']:
            raise ValueError('Unexpected non-harness snapshot mutation')
        require_production(production.capture(app,native),allowed)
        workspace=app/'build/CotabbyDevelopment.xcworkspace';workspace.mkdir(parents=True)
        document=ET.Element('Workspace',version='1.0')
        for path in (app/'Cotabby.xcodeproj',native):ET.SubElement(document,'FileRef',location='absolute:'+str(path))
        ET.ElementTree(document).write(workspace/'contents.xcworkspacedata',encoding='UTF-8',xml_declaration=True)
        model=Path(execution['model']).resolve();model_digest=file_sha(model)
        if model_digest!=frozen['modelSHA256']:raise ValueError('Local model identity differs from frozen model')
        model_link=DESTINATION/model.name;model_link.symlink_to(model)
        main_after,_=legacy.capture(MAIN);native_after,_=legacy.capture(MAIN_NATIVE,native=True)
        # A current-main snapshot is not allowed to silently mix two externally edited states.
        if (main_before['files']!=main_after['files'] or main_before['head']!=main_after['head']
                or native_before['files']!=native_after['files'] or native_before['head']!=native_after['head']):
            raise ValueError('Main source inventory changed during preparation; preserve this attempt and review')
        require_production(production.capture(MAIN,MAIN_NATIVE),allowed)
        if file_sha(frozen_path)!=frozen_digest:raise ValueError('Frozen decision changed during preparation')
        private_execution={'root':str(app),'native':str(native),'workspace':str(workspace),'model':str(model_link),
                           'derivedData':str(app/'build/DerivedData'),'main':str(MAIN),'mainNative':str(MAIN_NATIVE),
                           'round':str(ROUND),'scope':record['scope']}
        write(DESTINATION/'execution.json',private_execution)
        write(ROUND/'integration-execution.json',private_execution)
        record.update(status='ready-not-built',app=app_record,native=native_record,
                      mainAfter={'app':main_after,'native':native_after},mainBeforeAfterEqual=True,
                      snapshotBeforeOverlay={'app':copied_app,'native':copied_native},
                      snapshotAfterOverlay={'app':post_app,'native':post_native},
                      validationHarnessSourceInputs=harness_source,harnessOverlays=overlays,
                      actualOverlayChangedPaths=sorted(changed),execution=private_execution,
                      model={'link':str(model_link),'target':str(model),'sha256':model_digest},
                      workspace={'path':str(workspace/'contents.xcworkspacedata'),'sha256':file_sha(workspace/'contents.xcworkspacedata')},
                      copyMethod='Independent local Git fetch/detached current HEADs; read_bytes/write_bytes/chmod overlay; explicit symlinks; no copied xattrs',
                      potentialMissingInputs=['Build/DerivedData/cache trees and source Git metadata are excluded; private Git metadata is initialized independently.',
                        'Untracked files outside relevant source/config/assets roots are omitted and individually listed in source inventories.',
                        'SwiftPM downloaded binary/cache artifacts are not copied; later package resolution must populate the private DerivedData.'])
        (evidence/'main-working-tree.patch').write_bytes(legacy.git(MAIN,'diff','HEAD','--','.',' :(exclude)build'.strip()))
        (evidence/'native-working-tree.patch').write_bytes(legacy.git(MAIN_NATIVE,'diff','HEAD','--','.',' :(exclude)build'.strip()))
    except BaseException as error:
        record.update(status='blocked-or-failed',error=f'{type(error).__name__}: {error}')
        raise
    finally:
        record['finishedUTC']=datetime.datetime.now(datetime.timezone.utc).isoformat()
        write(ROUND/'integration-snapshot.json',record)
    print(json.dumps({'status':record['status'],'appHEAD':main_before['head'],'nativeHEAD':native_before['head'],
                      'appFiles':len(post_app['files']),'nativeFiles':len(post_native['files']),
                      'overlayFiles':len(overlays),'changedOverlayFiles':len(changed),'execution':record['execution']},indent=2))

if __name__=='__main__':main()
