#!/usr/bin/env python3
"""Round-only fake admission fixtures; no application builds, models, or real corpus reads."""
import argparse
import copy
import datetime
import hashlib
import json
from pathlib import Path
import tempfile
import time
import unittest
from unittest import mock

import run_experiment as subject


def utc(value):
    return datetime.datetime.fromtimestamp(value, datetime.timezone.utc).isoformat()


class FreshCharacterAdmissionTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory(prefix='fresh-character-guard-')
        self.addCleanup(self.temporary.cleanup)
        self.root = Path(self.temporary.name)
        self.clock = time.time()
        self.corpus = self.root / 'protected.json'
        self.corpus.write_text('Only fake bytes; no reference data.')
        self.corpus_sha = subject.digest(self.corpus)
        ready = self.write('ready.json', {'status':'pass','readyUTC':utc(self.clock-110),
                           'corpusSHA256':self.corpus_sha,'corpusPath':str(self.corpus),
                           'phraseCount':700,'familyCount':140})
        screen = self.write('screen.json', {})
        self.frozen = {'schemaVersion':1,'frozenUTC':utc(self.clock-100),'candidate':'baseline','components':[],
            'selectionQualified':False,'modelSHA256':subject.ROUND['modelSHA256'],'freshCorpusSHA256':self.corpus_sha,
            'criteria':self.write('criteria.json',{}),'freshReadiness':ready,'screeningEvidence':screen,
            'screeningEvidenceSHA256':screen['sha256'],'productionInventories':{
                'baseline':self.write('baseline.json',{}),'finalist':self.write('finalist.json',{})},
            'baselineSourceSHA256':'a'*64,'candidateSourceSHA256':'a'*64,
            'baselineTargets':{'renderer':'b'*64,'composer':'c'*64,'nativeEngine':'d'*64},
            'candidateTargets':{'renderer':'b'*64,'composer':'c'*64,'nativeEngine':'d'*64}}
        freeze_ref = self.write('finalist-freeze.json', self.frozen)
        self.exception = {'schemaVersion':1,'candidate':'baseline','descriptiveOnly':True,
            'registeredUTC':utc(self.clock-80),'freezeSHA256':freeze_ref['sha256'],
            'allowedKind':'freshCharacter','reason':'Optional complete baseline characterization.'}
        exception_ref = self.write('exception.json', self.exception)
        self.row = {'name':'fresh-character42','label':'fresh-character-baseline','kind':'freshCharacter','seed':42,
            'workerCount':3,'mode':'character','corpusSHA256':self.corpus_sha,'selection':'all','perCategory':0,
            'estimatedSeconds':1200,'guardException':exception_ref}
        self.workload = {'schemaVersion':1,'registeredUTC':utc(self.clock-60),'candidate':'baseline',
            'freezeSHA256':freeze_ref['sha256'],'purpose':'Baseline descriptive characterization only.','runs':[self.row]}
        workload_ref = self.write('workload.json', self.workload)
        self.args = argparse.Namespace(label=self.row['label'],candidate='baseline',phase='validation',
            corpus=self.corpus,split='all',mode='character',per_category=None,seed=42,workers=3,estimated_seconds=1200,
            descriptive_workload=self.root/'workload.json',descriptive_workload_sha256=workload_ref['sha256'])
        for patch in (mock.patch.object(subject,'HERE',self.root),
                      mock.patch.object(subject,'FREEZE',self.clock+100),
                      mock.patch.object(subject,'ROUND',dict(subject.ROUND,freshReadinessDeadlineUTC=utc(self.clock+100))),
                      mock.patch.object(subject.time,'time',return_value=self.clock)):
            patch.start();self.addCleanup(patch.stop)

    def write(self, name, value):
        path = self.root / name
        path.write_text(json.dumps(value, sort_keys=True))
        return {'path':name,'sha256':subject.digest(path)}

    def refresh_workload(self):
        self.args.descriptive_workload_sha256 = self.write('workload.json',self.workload)['sha256']

    def refresh_exception(self):
        self.row['guardException'] = self.write('exception.json',self.exception)
        self.refresh_workload()

    def admit(self, args=None, components=None):
        return subject.validation_admission(args or self.args, [] if components is None else components)

    def test_exact_registered_baseline_character_admitted_and_preserves_source_binding(self):
        record = self.admit()
        self.assertEqual(record['role'],'baseline')
        self.assertEqual(record['sourceSHA256'],self.frozen['baselineSourceSHA256'])
        self.assertEqual(record['targets'],self.frozen['baselineTargets'])
        self.assertEqual(record['freshCorpusSHA256'],self.corpus_sha)
        self.assertEqual(record['protectedCorpus'],{'path':str(self.corpus.resolve()),'sha256':self.corpus_sha})
        self.assertTrue(record['descriptiveWorkload']['descriptiveOnly'])
        self.assertEqual(record['descriptiveWorkload']['kind'],'freshCharacter')
        subject.verify_admission_artifacts(record)

    def test_missing_or_half_specified_explicit_flags_rejected(self):
        for fields in ({'descriptive_workload':None},{'descriptive_workload_sha256':None},
                       {'descriptive_workload':None,'descriptive_workload_sha256':None},
                       {'descriptive_workload_sha256':'invalid'}):
            args = copy.copy(self.args)
            for key,value in fields.items():setattr(args,key,value)
            with self.subTest(fields=fields),self.assertRaises(ValueError):self.admit(args)

    def test_nonbaseline_candidate_and_frozen_finalist_rejected(self):
        other = copy.copy(self.args);other.candidate='H1'
        with self.assertRaises(ValueError):self.admit(other,['H1'])
        self.frozen.update(candidate='H1',components=['H1'],selectionQualified=True)
        self.write('finalist-freeze.json',self.frozen)
        with self.assertRaisesRegex(ValueError,'no-qualifier'):self.admit()
        with self.assertRaisesRegex(ValueError,'no-qualifier'):self.admit(other,['H1'])

    def test_inconsistent_or_nonfrozen_selection_rejected(self):
        self.frozen['components']=['H1'];self.write('finalist-freeze.json',self.frozen)
        with self.assertRaises(ValueError):self.admit()
        (self.root/'finalist-freeze.json').unlink()
        with self.assertRaises(FileNotFoundError):self.admit()

    def test_word_screening_historical_or_subset_cannot_use_exception(self):
        for fields in ({'mode':'word'},{'phase':'screening'},{'corpus':None},{'split':'screen'},
                       {'split':'heldout'},{'per_category':50},{'per_category':0}):
            args=copy.copy(self.args)
            for key,value in fields.items():setattr(args,key,value)
            with self.subTest(fields=fields),self.assertRaises(ValueError):self.admit(args)

    def test_fresh_word_path_still_works_without_exception(self):
        args=copy.copy(self.args);args.mode='word';args.descriptive_workload=None;args.descriptive_workload_sha256=None
        admission=self.admit(args)
        self.assertEqual(admission['role'],'baseline')
        self.assertIsNone(admission['descriptiveWorkload'])

    def test_workload_kind_seed_worker_estimate_label_and_corpus_are_exact(self):
        for key,value in [('kind','freshWord'),('seed',1337),('workerCount',1),('estimatedSeconds',1199),
                          ('label','other'),('mode','word'),('corpusSHA256','0'*64),('selection','screen'),
                          ('perCategory',1),('seed',True),('estimatedSeconds',float('inf'))]:
            old=self.row[key];self.row[key]=value;self.refresh_workload()
            with self.subTest(key=key),self.assertRaises(ValueError):self.admit()
            self.row[key]=old;self.refresh_workload()

    def test_workload_or_exception_hash_change_rejected(self):
        self.args.descriptive_workload_sha256='0'*64
        with self.assertRaisesRegex(ValueError,'artifact changed'):self.admit()
        self.refresh_workload();self.row['guardException']['sha256']='0'*64;self.refresh_workload()
        with self.assertRaisesRegex(ValueError,'artifact changed'):self.admit()

    def test_exact_protected_path_and_bytes_required(self):
        duplicate=self.root/'same-bytes.json';duplicate.write_bytes(self.corpus.read_bytes())
        args=copy.copy(self.args);args.corpus=duplicate
        with self.assertRaisesRegex(ValueError,'exact protected'):self.admit(args)
        self.corpus.write_text('changed')
        with self.assertRaisesRegex(ValueError,'exact protected'):self.admit()

    def test_wrong_workload_or_exception_freeze_hash_rejected(self):
        self.workload['freezeSHA256']='0'*64;self.refresh_workload()
        with self.assertRaises(ValueError):self.admit()
        self.workload['freezeSHA256']=subject.digest(self.root/'finalist-freeze.json')
        self.exception['freezeSHA256']='0'*64;self.refresh_exception()
        with self.assertRaises(ValueError):self.admit()

    def test_exception_is_only_explicit_descriptive_baseline_fresh_character(self):
        for key,value in [('candidate','H1'),('descriptiveOnly',False),('allowedKind','freshWord'),('reason','')]:
            old=self.exception[key];self.exception[key]=value;self.refresh_exception()
            with self.subTest(key=key),self.assertRaises(ValueError):self.admit()
            self.exception[key]=old;self.refresh_exception()

    def test_registration_timing_order_and_timezone_required(self):
        for timestamp in (utc(self.clock+1),utc(self.clock-101),'2026-09-17T00:00:00'):
            self.workload['registeredUTC']=timestamp;self.refresh_workload()
            with self.subTest(timestamp=timestamp),self.assertRaises(ValueError):self.admit()
        self.workload['registeredUTC']=utc(self.clock-60)
        self.exception['registeredUTC']=utc(self.clock-59);self.refresh_exception()
        with self.assertRaises(ValueError):self.admit()

    def test_duplicate_workload_identity_rejected(self):
        self.workload['runs'].append(copy.deepcopy(self.row));self.refresh_workload()
        with self.assertRaisesRegex(ValueError,'duplicated'):self.admit()

    def test_artifact_rechecks_detect_freeze_workload_and_exception_mutation(self):
        for name in ('finalist-freeze.json','workload.json','exception.json','protected.json'):
            admission=self.admit();path=self.root/name;before=path.read_bytes();path.write_bytes(before+b' ')
            with self.subTest(name=name),self.assertRaises(ValueError):subject.verify_admission_artifacts(admission)
            path.write_bytes(before)
        subject.verify_admission_artifacts(None)

    def test_executed_report_and_manifest_must_match_admitted_protected_corpus(self):
        admission=self.admit();state={'sourceSHA256':'source'};checks={'buildInputs':state}
        report={'metadata':{'configuration':{'modelSHA256':subject.ROUND['modelSHA256']},
                            'corpusSHA256':self.corpus_sha},'errorCount':0}
        manifest={'buildInputs':state,'build':{'sourceSHA256':'source','reused':False},
                  'corpusSHA256':self.corpus_sha,'corpusInput':{'sha256':self.corpus_sha,'sourcePath':str(self.corpus)}}
        subject.verify_completed(report,manifest,checks,admission)
        for field in ('report','manifest','input_hash','input_path'):
            a,b=copy.deepcopy(report),copy.deepcopy(manifest)
            if field=='report':a['metadata']['corpusSHA256']='0'*64
            elif field=='manifest':b['corpusSHA256']='0'*64
            elif field=='input_hash':b['corpusInput']['sha256']='0'*64
            else:b['corpusInput']['sourcePath']=str(self.root/'other.json')
            with self.subTest(field=field),self.assertRaisesRegex(ValueError,'frozen admission'):
                subject.verify_completed(a,b,checks,admission)


if __name__=='__main__':
    unittest.main()
