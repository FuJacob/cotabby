#!/usr/bin/env python3
"""Compare only registered old-corpus single alternatives, emitting aggregate diagnostics.

Exact output comparisons describe behavioral changes; correctness comes exclusively from
Swift's recorded flags. This helper never opens supplementary reports or chooses candidates.
"""
import collections
import datetime
import hashlib
import json
from pathlib import Path

from screening_evidence import validate_rows

HERE=Path(__file__).resolve().parent
CANDIDATES=[f'{family}{number}' for family in 'HFM' for number in range(1,5)]
CONDITIONS=('screen','none')
FIELDS=('checkpoints','baselineCorrect','candidateCorrect','rawChanged','shownChanged',
        'predictedWordChanged','wrongToCorrect','correctToWrong','bothCorrect','bothWrong',
        'rawChangedShownUnchanged','shownChangedCorrectnessUnchanged','shownChangedBothWrong',
        'shownChangedBothCorrect','shownStateChanged')


def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def read(path):return json.loads(path.read_text())


def completed(candidate):
    label='screen-'+candidate
    registration=HERE/(label+'-registration.json')
    if not registration.exists():return None
    record=read(registration)
    if record['status']!='complete':return None
    if record['candidate']!=candidate or record['phase']!='screening' or record['label']!=label:
        raise ValueError('Diagnostic input is not a registered historical single-screen run')
    report_path=HERE/label/'report.json'
    report=read(report_path)
    row={'candidate':candidate,'label':label,'components':record['components'],
         'screenCorrect':report['conditions']['screen']['suite']['nextWord']['correct'],
         'noneCorrect':report['conditions']['none']['suite']['nextWord']['correct'],
         'checkpointsPerCondition':770,'reportSHA256':sha(report_path),
         'registrationSHA256':sha(registration)}
    return row,report,{'report':{'path':str(report_path.relative_to(HERE)),'sha256':sha(report_path)},
                       'registration':{'path':registration.name,'sha256':sha(registration)},
                       'manifest':{'path':label+'/manifest.json','sha256':sha(HERE/label/'manifest.json')}}


def index(report):
    indexed={}
    for phrase in report['phrases']:
        for observation in phrase['observations']:
            point=observation['checkpoint']
            key=(phrase['phrase']['id'],phrase['condition'],point['wordIndex'],point['typedCharacters'])
            if key in indexed:raise ValueError('Duplicate diagnostic checkpoint')
            indexed[key]=(phrase['phrase']['category'],observation)
    return indexed


def boundaries(point):
    prefix=point['prefix'].rstrip()
    last=prefix[-1:] if prefix else ''
    if not last:previous='empty_prefix'
    elif last in '.!?':previous='after_period_question_exclamation'
    elif last==',':previous='after_comma'
    elif last in ':;':previous='after_colon_semicolon'
    elif last in '-–—':previous='after_dash'
    elif last.isalnum():previous='after_letter_or_digit'
    else:previous='after_other_punctuation'
    target=point['expectedWord']
    if target.isdigit():form='number'
    elif any(character.isdigit() for character in target):form='alphanumeric'
    elif any(character in '-–—' for character in target):form='hyphenated'
    elif any(character in "'’" for character in target):form='apostrophe'
    elif target[:1].isupper():form='initial_capital'
    else:form='plain_word'
    return {'checkpointKind':'word_boundary' if point['typedCharacters']==0 else 'partial_word',
            'prefixEnding':previous,'targetForm':form,
            'phrasePosition':'first_checkpoint' if point['wordIndex']==1 else 'later_checkpoint'}


def delta(old,new):
    raw=old['raw']!=new['raw'];shown=old.get('shown')!=new.get('shown')
    a,b=old['correct'],new['correct']
    return {'checkpoints':1,'baselineCorrect':int(a),'candidateCorrect':int(b),
            'rawChanged':int(raw),'shownChanged':int(shown),
            'predictedWordChanged':int(old.get('predictedWord')!=new.get('predictedWord')),
            'wrongToCorrect':int(not a and b),'correctToWrong':int(a and not b),
            'bothCorrect':int(a and b),'bothWrong':int(not a and not b),
            'rawChangedShownUnchanged':int(raw and not shown),
            'shownChangedCorrectnessUnchanged':int(shown and a==b),
            'shownChangedBothWrong':int(shown and not a and not b),
            'shownChangedBothCorrect':int(shown and a and b),
            'shownStateChanged':int(old['wasShown']!=new['wasShown'])}


def finish(counter):
    data={field:counter[field] for field in FIELDS}
    data['netCorrect']=data['candidateCorrect']-data['baselineCorrect']
    data['accuracyDeltaPercentagePoints']=100*data['netCorrect']/data['checkpoints']
    if data['netCorrect']!=data['wrongToCorrect']-data['correctToWrong']:
        raise ValueError('Correctness transitions do not reconcile')
    return data


def compare(before,after):
    old,new=index(before),index(after)
    if old.keys()!=new.keys():raise ValueError('Mismatched diagnostic checkpoints')
    sums=collections.defaultdict(collections.Counter)
    for key,(category,a) in old.items():
        new_category,b=new[key]
        if category!=new_category or a['checkpoint']!=b['checkpoint']:
            raise ValueError('Diagnostic case inputs differ')
        condition=key[1];counts=delta(a,b)
        sums[(condition,'summary','all')].update(counts)
        sums[(condition,'category',category)].update(counts)
        for axis,label in boundaries(a['checkpoint']).items():sums[(condition,axis,label)].update(counts)
    result={condition:{'summary':{},'categories':{},'boundaries':{}} for condition in CONDITIONS}
    for (condition,axis,label),counts in sorted(sums.items()):
        data=finish(counts)
        if axis=='summary':result[condition]['summary']=data
        elif axis=='category':result[condition]['categories'][label]=data
        else:result[condition]['boundaries'].setdefault(axis,{})[label]=data
    return result


def rendered(data):
    lines=['# Historical screening diagnostics','',data['scope'],'',
           f"Completed alternatives: {data['completedAlternatives']}/12. Pending: {', '.join(data['pending']) or 'none'}.",'',
           'Accuracy uses recorded Swift correctness flags. Raw and shown changes compare exact strings; a wording change may leave exact-next-word correctness unchanged.','',
           '| Candidate | Context | Raw changed | Shown changed | Wrong → correct | Correct → wrong | Net correct |',
           '| --- | --- | ---: | ---: | ---: | ---: | ---: |']
    for candidate in (value for value in CANDIDATES if value in data['comparisons']):
        for condition in CONDITIONS:
            s=data['comparisons'][candidate]['conditions'][condition]['summary']
            lines.append(f"| {candidate} | {condition} | {s['rawChanged']}/770 | {s['shownChanged']}/770 | {s['wrongToCorrect']} | {s['correctToWrong']} | {s['netCorrect']:+d} |")
    lines+=['','## H3 tie','',data['h3Interpretation'],'','## Category changes','',
            'Each cell lists net correct (wrong → correct / correct → wrong), followed by the number of changed shown outputs. Denominators and all zero-change cells are retained in JSON.','',
            '| Candidate | Context | Category | Net (wins / losses) | Shown changed |',
            '| --- | --- | --- | ---: | ---: |']
    for candidate,item in ((value,data['comparisons'][value]) for value in CANDIDATES if value in data['comparisons']):
        for condition in CONDITIONS:
            for category,s in item['conditions'][condition]['categories'].items():
                if s['shownChanged'] or s['wrongToCorrect'] or s['correctToWrong']:
                    lines.append(f"| {candidate} | {condition} | {category} | {s['netCorrect']:+d} ({s['wrongToCorrect']} / {s['correctToWrong']}) | {s['shownChanged']}/{s['checkpoints']} |")
    lines+=['','## Boundary changes','',
            'Every current observation is a word boundary before the target’s first letter. Prefix-ending labels describe literal punctuation, not a semantic sentence-boundary judgment. Target-form labels are descriptive reference-token shapes. These sparse groups are not separate validation sets.','',
            '| Candidate | Context | Boundary axis / label | Checkpoints | Shown changed | Wins / losses |',
            '| --- | --- | --- | ---: | ---: | ---: |']
    for candidate,item in ((value,data['comparisons'][value]) for value in CANDIDATES if value in data['comparisons']):
        for condition in CONDITIONS:
            for axis,groups in item['conditions'][condition]['boundaries'].items():
                if axis=='checkpointKind':continue
                for label,s in groups.items():
                    if s['shownChanged'] or s['wrongToCorrect'] or s['correctToWrong']:
                        lines.append(f"| {candidate} | {condition} | {axis} / {label} | {s['checkpoints']} | {s['shownChanged']} | {s['wrongToCorrect']} / {s['correctToWrong']} |")
    lines+=['','## Evidence-limited notes for a later round','']
    lines += ['- '+note for note in data['limitationsAndHypotheses']]
    lines+=['','This artifact does not change the registered selection, propose additional current-round candidates, or use protected validation results.','']
    return '\n'.join(lines)


def main():
    baseline=completed('baseline')
    if baseline is None:raise ValueError('Completed historical baseline is required')
    available={candidate:completed(candidate) for candidate in CANDIDATES}
    validate_rows([baseline[0]]+[item[0] for item in available.values() if item is not None])
    comparisons={candidate:{'evidence':item[2],'conditions':compare(baseline[1],item[1])}
                 for candidate,item in available.items() if item is not None}
    h3=comparisons.get('H3')
    if h3:
        a,b=(h3['conditions'][condition]['summary'] for condition in CONDITIONS)
        interpretation=(f"H3 screen has {a['rawChanged']} raw and {a['shownChanged']} shown changes, "
                        f"with {a['wrongToCorrect']} wins and {a['correctToWrong']} losses; "
                        f"no-screen has {b['rawChanged']} raw and {b['shownChanged']} shown changes, "
                        f"with {b['wrongToCorrect']} wins and {b['correctToWrong']} losses. "
                        f"Recorded predicted-word changes: screen {a['predictedWordChanged']}, no-screen {b['predictedWordChanged']}. "
                        f"Changed screen continuations retain incorrect outcomes at {a['shownChangedBothWrong']} checkpoints and correct outcomes at {a['shownChangedBothCorrect']}. "
                        'A tied score therefore must be interpreted using these transitions, not assumed to mean identical outputs.')
    else:interpretation='H3 is still pending.'
    data={'schemaVersion':1,'generatedUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'scope':'Descriptive diagnostics from the already-inspected140-case historical screening subset; no protected-fresh reports are read.',
          'scriptSHA256':sha(Path(__file__)),'baselineEvidence':baseline[2],
          'completedAlternatives':len(comparisons),'pending':[candidate for candidate,item in available.items() if item is None],
          'comparisons':comparisons,'h3Interpretation':interpretation,
          'limitationsAndHypotheses':[
              'This is a development subset used to compare many alternatives. Category and boundary patterns are hypotheses for later experiments, not unbiased generalization estimates.',
              'H3’s detailed transitions distinguish a mostly inactive history-length change from offsetting gains and losses; output changes that remain incorrect do not establish improved word choice.',
              'Screen-format variants should leave no-screen generation unchanged. Any observed no-screen output change deserves a reproducibility/input audit before a causal explanation.',
              'Surface metadata enters both conditions, so metadata variants can change no-screen predictions. Their condition contrast alone cannot isolate visual-context quality.',
              'Raw and shown change counts match in the available runs, so these comparisons show no raw-change absorption by display processing. Many changed continuation strings retain the same recorded predicted word; total output churn should not be treated as first-word improvement.',
              'All observations here are word boundaries. They provide no direct evidence about partial-word typing behavior, latency in normal interactive use, or subjective acceptability of alternative continuations.' ]}
    if 'M2' in comparisons:
        screen=comparisons['M2']['conditions']['screen']['summary']['netCorrect']
        none=comparisons['M2']['conditions']['none']['summary']['netCorrect']
        data['limitationsAndHypotheses'].append(
            f'M2 removed Format unconditionally: screen {screen:+d}/770 net correct and no-screen {none:+d}/770. '
            'A prospective next-round hypothesis is to omit Format only when valid OCR is available. '
            'That conditional policy is unimplemented and untested; the unconditional result does not establish its effect, '
            'and it would require independently prepared validation data.')
    if 'M4' in comparisons:
        screen=comparisons['M4']['conditions']['screen']['summary']['netCorrect']
        none=comparisons['M4']['conditions']['none']['summary']['netCorrect']
        data['limitationsAndHypotheses'].append(
            f'M4 removed Field unconditionally: screen {screen:+d}/770 net correct and no-screen {none:+d}/770. '
            'A prospective next-round hypothesis is to omit Field only when OCR is unavailable. '
            'That conditional policy is unimplemented and untested; it must not be treated as a current-round candidate '
            'or selected using protected outcomes from this round.')
    (HERE/'screening-diagnostics.json').write_text(json.dumps(data,indent=2,sort_keys=True)+'\n')
    (HERE/'screening-diagnostics.md').write_text(rendered(data))
    print(json.dumps({'completedAlternatives':len(comparisons),'pending':data['pending'],'h3':interpretation},indent=2))

if __name__=='__main__':main()
