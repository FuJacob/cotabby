// Model-free contract tests against the same llama binary used by the application.
// These cover the builtin's history boundary and selective reset semantics; the
// app integration suite separately covers engine wiring, KV reuse and healing.
#include <llama/llama.h>

#include <cmath>
#include <cstdlib>
#include <iostream>
#include <memory>
#include <vector>

using Sampler = std::unique_ptr<llama_sampler, decltype(&llama_sampler_free)>;

static void require(bool condition, const char* description) {
    if (!condition) {
        std::cerr << "FAIL: " << description << '\n';
        std::exit(1);
    }
}

static std::vector<llama_token_data> apply(llama_sampler* sampler) {
    std::vector<llama_token_data> entries = {{0, 8.0f, 0.0f}, {1, -4.0f, 0.0f}, {2, 6.0f, 0.0f}};
    llama_token_data_array candidates = {entries.data(), entries.size(), -1, false};
    llama_sampler_apply(sampler, &candidates);
    return entries;
}

static bool near(float actual, float expected) { return std::abs(actual - expected) < 0.00001f; }

static void testWindowBoundary(int window) {
    constexpr float penalty = 1.025f;
    Sampler sampler(llama_sampler_init_penalties(window, penalty, 0, 0), llama_sampler_free);
    require(bool(sampler), "penalties sampler exists");
    llama_sampler_accept(sampler.get(), 0);
    for (int i = 1; i < window; ++i) llama_sampler_accept(sampler.get(), 1);
    auto inside = apply(sampler.get());
    require(near(inside[0].logit, 8.0f / penalty), "oldest in-window token remains penalized");
    require(near(inside[1].logit, -4.0f * penalty), "negative logit uses multiplicative penalty");
    require(near(inside[2].logit, 6.0f), "unseen token stays unchanged");
    llama_sampler_accept(sampler.get(), 2);
    auto outside = apply(sampler.get());
    require(near(outside[0].logit, 8.0f), "token immediately outside history is unpenalized");
    require(near(outside[1].logit, -4.0f * penalty), "repeated in-window token retains its penalty");
    llama_sampler_reset(sampler.get());
    auto reset = apply(sampler.get());
    require(near(reset[0].logit, 8.0f) && near(reset[1].logit, -4.0f) && near(reset[2].logit, 6.0f),
            "reset removes all previous prompt and generated history");
}

static void testSelectiveResetAndGeneratedAcceptance() {
    Sampler chain(llama_sampler_chain_init(llama_sampler_chain_default_params()), llama_sampler_free);
    auto* otherStatefulChild = llama_sampler_init_penalties(64, 1.2f, 0, 0);
    auto* repetition = llama_sampler_init_penalties(64, 1.025f, 0, 0);
    require(bool(chain) && otherStatefulChild && repetition, "chain and children exist");
    // Both children are chain-owned; resetting the second must neither free it nor
    // erase the first child's prompt history. Chain destruction frees them once.
    llama_sampler_chain_add(chain.get(), otherStatefulChild);
    llama_sampler_chain_add(chain.get(), repetition);
    llama_sampler_reset(chain.get());
    llama_sampler_accept(chain.get(), 0);
    llama_sampler_reset(repetition);
    auto afterPrompt = apply(chain.get());
    require(near(afterPrompt[0].logit, 8.0f / 1.2f), "other chain components retain prompt acceptance");
    require(near(afterPrompt[2].logit, 6.0f), "no sampled-token history before first sample");
    llama_sampler_accept(chain.get(), 2);
    auto afterGenerated = apply(chain.get());
    require(near(afterGenerated[2].logit, 6.0f / 1.2f / 1.025f), "sampled tokens enter both children normally");
    llama_sampler_reset(chain.get());
    llama_sampler_accept(chain.get(), 1);
    llama_sampler_reset(repetition);
    auto edited = apply(chain.get());
    require(near(edited[0].logit, 8.0f) && near(edited[2].logit, 6.0f), "edited request excludes old prompt/generated tokens");
    require(near(edited[1].logit, -4.0f * 1.2f), "edited prompt still reaches other components");
}

static int draw(llama_sampler* sampler) {
    // These token IDs were never accepted into repetition history, so this test
    // isolates RNG progression without changing the categorical distribution.
    std::vector<llama_token_data> entries = {{10, 1.0f, 0.0f}, {11, 1.0f, 0.0f}, {12, 1.0f, 0.0f}};
    llama_token_data_array candidates = {entries.data(), entries.size(), -1, false};
    llama_sampler_apply(sampler, &candidates);
    require(candidates.selected >= 0, "distribution sampler selects a token");
    return candidates.data[candidates.selected].id;
}

static void testSelectiveResetPreservesRandomStream() {
    Sampler chain(llama_sampler_chain_init(llama_sampler_chain_default_params()), llama_sampler_free);
    Sampler reference(llama_sampler_init_dist(42), llama_sampler_free);
    auto* repetition = llama_sampler_init_penalties(64, 1.025f, 0, 0);
    llama_sampler_chain_add(chain.get(), repetition);
    llama_sampler_chain_add(chain.get(), llama_sampler_init_dist(42));
    for (int i = 0; i < 16; ++i) require(draw(chain.get()) == draw(reference.get()), "seeded streams start identically");
    llama_sampler_accept(chain.get(), 0);
    llama_sampler_reset(repetition);
    for (int i = 0; i < 32; ++i) require(draw(chain.get()) == draw(reference.get()), "penalty reset does not rewind or advance RNG");
    llama_sampler_reset(chain.get());
    llama_sampler_reset(reference.get());
    for (int i = 0; i < 16; ++i) require(draw(chain.get()) == draw(reference.get()), "full request reset restores seeded stream");
}

int main() {
    for (int window : {16, 32, 64, 128}) testWindowBoundary(window);
    testSelectiveResetAndGeneratedAcceptance();
    testSelectiveResetPreservesRandomStream();
    std::cout << "PASS: 4 history boundaries, selective reset/history isolation, RNG preservation\n";
}
