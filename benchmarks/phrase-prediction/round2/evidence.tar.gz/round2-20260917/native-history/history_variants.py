#!/usr/bin/env python3
"""Freeze/select native history experiments without a public or persistent setting.

Only the isolated engine CPP may be replaced. Every other native source input is
checked against the initial snapshot before replacement; unknown current CPP
bytes are rejected too. A fresh benchmark host/build is required after selection.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import tempfile

CPP = Path("Sources/CotabbyInferenceEngine/CotabbyInferenceEngine.cpp")
HERE = Path(__file__).resolve().parent


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def replace_once(text: str, old: str, new: str) -> str:
    if text.count(old) != 1:
        raise ValueError(f"Expected exactly one source anchor: {old[:90]!r}")
    return text.replace(old, new, 1)


def variants(baseline: bytes) -> dict[str, bytes]:
    source = baseline.decode("utf-8")
    output = {"baseline": baseline}
    for label, window in (("H1", 16), ("H2", 32), ("H3", 128)):
        output[label] = replace_once(
            source, "64, cfg.repetition_penalty, 0.0f, 0.0f",
            f"{window}, cfg.repetition_penalty, 0.0f, 0.0f"
        ).encode("utf-8")
    generated = replace_once(source,
        "    llama_sampler* sampler = nullptr;\n",
        "    llama_sampler* sampler = nullptr;\n"
        "    // Nonowning child handle: the sampler chain owns and frees this object.\n"
        "    // Generated-only history resets this child after the full chain sees the prompt.\n"
        "    llama_sampler* repetition_sampler = nullptr;\n")
    generated = replace_once(generated,
        "    llama_sampler* buildSampler(const SamplingConfig& cfg) const {\n",
        "    llama_sampler* buildSampler(const SamplingConfig& cfg, llama_sampler*& repetition_sampler) const {\n"
        "        repetition_sampler = nullptr;\n")
    generated = replace_once(generated,
        "            if (pen) llama_sampler_chain_add(chain, pen);\n",
        "            if (pen) {\n"
        "                llama_sampler_chain_add(chain, pen);\n"
        "                repetition_sampler = pen;\n"
        "            }\n")
    generated = replace_once(generated,
        "    llama_sampler* sampler = impl_->buildSampler(config);\n",
        "    llama_sampler* repetition_sampler = nullptr;\n"
        "    llama_sampler* sampler = impl_->buildSampler(config, repetition_sampler);\n")
    generated = replace_once(generated,
        "    state->sampler = sampler;\n",
        "    state->sampler = sampler;\n"
        "    state->repetition_sampler = repetition_sampler;\n")
    generated = replace_once(generated,
        "    for (const llama_token token : seq->decoded_tokens) {\n"
        "        llama_sampler_accept(seq->sampler, token);\n"
        "    }\n",
        "    for (const llama_token token : seq->decoded_tokens) {\n"
        "        llama_sampler_accept(seq->sampler, token);\n"
        "    }\n"
        "    // The chain still receives the complete prompt for any other stateful component.\n"
        "    // Only repetition history excludes prompt tokens; each sampled token is then\n"
        "    // accepted by llama_sampler_sample as usual. Resetting this child leaves RNG\n"
        "    // and the rest of the chain untouched, including on a reused or edited prompt.\n"
        "    if (seq->repetition_sampler) llama_sampler_reset(seq->repetition_sampler);\n")
    output["H4"] = generated.encode("utf-8")
    return output


def inventory(native: Path) -> dict[str, str]:
    paths = [native / "Package.swift"]
    for folder in ("Sources", "Tests"):
        paths.extend(p for p in (native / folder).rglob("*") if p.is_file())
    return {str(p.relative_to(native)): sha(p.read_bytes()) for p in sorted(paths)}


def write_atomic(path: Path, data: bytes) -> None:
    mode = path.stat().st_mode & 0o777 if path.exists() else 0o644
    fd, temporary = tempfile.mkstemp(prefix=f".{path.name}.", dir=path.parent)
    try:
        with os.fdopen(fd, "wb") as handle:
            handle.write(data)
            handle.flush()
            os.fsync(handle.fileno())
        os.chmod(temporary, mode)
        os.replace(temporary, path)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)


def freeze(native: Path, destination: Path) -> dict:
    if (destination / "manifest.json").exists():
        raise ValueError("Manifest already exists; never overwrite frozen variants")
    all_variants = variants((native / CPP).read_bytes())
    destination.mkdir(parents=True, exist_ok=True)
    manifest = {
        "schemaVersion": 1, "nativeRoot": str(native.resolve()), "enginePath": str(CPP),
        "nativeInputs": inventory(native),
        "variants": {name: {"path": f"{name}.cpp", "sha256": sha(data),
            "window": {"baseline": 64, "H1": 16, "H2": 32, "H3": 128, "H4": 64}[name],
            "promptHistory": name != "H4"} for name, data in all_variants.items()},
    }
    for name, data in all_variants.items():
        path = destination / f"{name}.cpp"
        if path.exists():
            raise ValueError(f"Refusing to overwrite {path}")
        path.write_bytes(data)
    (destination / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
    return manifest


def verify(native: Path, destination: Path) -> tuple[dict, str]:
    manifest = json.loads((destination / "manifest.json").read_text())
    if native.resolve() != Path(manifest["nativeRoot"]):
        raise ValueError("Native root is not the frozen isolated checkout")
    expected = dict(manifest["nativeInputs"])
    actual = inventory(native)
    expected.pop(str(CPP))
    current = actual.pop(str(CPP))
    if actual != expected:
        changed = sorted(k for k in actual.keys() | expected.keys() if actual.get(k) != expected.get(k))
        raise ValueError(f"Other native inputs changed: {changed}")
    for item in manifest["variants"].values():
        if sha((destination / item["path"]).read_bytes()) != item["sha256"]:
            raise ValueError("Frozen candidate bytes changed")
    names = [name for name, item in manifest["variants"].items() if item["sha256"] == current]
    if len(names) != 1:
        raise ValueError("Current engine is not a recognized frozen candidate")
    return manifest, names[0]


def select(native: Path, destination: Path, name: str) -> dict:
    manifest, before = verify(native, destination)
    item = manifest["variants"][name]
    write_atomic(native / CPP, (destination / item["path"]).read_bytes())
    _, after = verify(native, destination)
    if after != name:
        raise ValueError("Post-write candidate verification failed")
    return {"before": before, "after": after, "sha256": item["sha256"],
            "requiresRebuildAndFreshHost": True}


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("action", choices=("freeze", "verify", "select"))
    parser.add_argument("--native-root", type=Path, required=True)
    parser.add_argument("--destination", type=Path, default=HERE / "variants")
    parser.add_argument("--variant", choices=("baseline", "H1", "H2", "H3", "H4"))
    args = parser.parse_args()
    if args.action == "freeze":
        result = freeze(args.native_root, args.destination)
    elif args.action == "verify":
        manifest, current = verify(args.native_root, args.destination)
        result = {"current": current, "sha256": manifest["variants"][current]["sha256"]}
    else:
        if not args.variant:
            parser.error("select requires --variant")
        result = select(args.native_root, args.destination, args.variant)
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
