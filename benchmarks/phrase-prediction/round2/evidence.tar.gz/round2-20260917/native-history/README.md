# Round 2 native repetition-history experiments

These are immutable **experiment sources**, not new app preferences or public native APIs.
The isolated engine remains the original source until the round runner selects a variant.
The strength stays **1.025** in the round's requests; temperature, filters, seed, token
healing, confidence/display guards, KV restoration, and cancellation remain unchanged.

| Variant | Penalty history | Source change |
| --- | --- | --- |
| baseline | Last 64 accepted prompt/sampled tokens | Exact original CPP bytes |
| H1 | Last 16 accepted prompt/sampled tokens | One integer literal |
| H2 | Last 32 accepted prompt/sampled tokens | One integer literal |
| H3 | Last 128 accepted prompt/sampled tokens | One integer literal |
| H4 | Last 64 tokens sampled during this request | Preserve full prompt acceptance, then reset only the penalties child |

H4's sampled-token history **includes token-healing replay tokens**, even where their
already-typed bytes are hidden from visible output. It excludes decoded prompt tokens;
it does not claim to exclude every already-typed byte. Its first native sample has no
penalty history and is equivalent to disabling repetition penalties for that sample.
Subsequent samples accumulate ordinary history, so it is not an all-token penalty1.0 variant.

The chain owns the H4 penalties child. `SequenceState.repetition_sampler` is a nonowning
handle, assigned when the chain is created and used only while that same chain is alive.
The existing sequence destructor frees the chain and its children once. When penalties
are disabled, the handle is null. No new lifecycle, allocation, or shared ownership exists.
The full chain is reset and accepts every actual prompt token exactly as before; resetting
just the penalties child then preserves any other component's prompt state and RNG state.
`llama_sampler_sample` continues accepting every sampled token itself.

## Selection and provenance

`history_variants.py` freezes the original CPP plus four complete candidate CPP files.
`variants/manifest.json` records their hashes and every native `Package.swift`, `Sources/`,
and `Tests/` file. Selection refuses another checkout, unknown engine bytes, other source
drift, added source inputs, or modified frozen variants. It replaces only the engine CPP,
using a same-directory atomic replacement and retaining its mode. The round runner should
capture the selector's JSON output in its own durable run journal.

From the main repository, the round runner selects a variant with:

```sh
python3 build/eval/round2-20260917/native-history/history_variants.py select \
  --native-root /Users/jmcasler/.codex/experiments/cotabby-1337-round2-20260917/cotabbyinference \
  --variant H1
```

Use `--variant baseline` to restore the original bytes. `verify` instead of `select`
reports the current recognized candidate without mutation. **Always rebuild and start a
fresh test host after a switch.** The policy is immutable in a binary, so it does not need
a mutable `SamplingConfig` field or runtime cache-key field. The existing benchmark's native
source/binary fingerprints must bind each run; skip-build reuse across variants is invalid.
Never select a variant while a host is running or while the source is being fingerprinted.

## Completed model-free checks

`model-free-validation.json` records compiler/framework/source identities and results:

- Baseline and all four CPP variants passed C++17 syntax checking with `-Wall -Wextra -Werror`.
- Eight temporary-fixture selector tests passed, including unknown/new inputs, tampered
  artifacts, wrong checkout, failed replacement, and exact restoration of original bytes.
- `SamplerHistoryTests.cpp` compiled and passed against the resolved llama **b9310** framework.
  It checks history boundaries16/32/64/128, expiry at the next token, positive and negative
  logit behavior, reset removal of old history, selective reset preserving another stateful
  child, new sampled-token acceptance, edited-request isolation, and RNG progression.

The C++ checks exercise actual builtin sampler semantics with synthetic logits, without
a model. They do not claim to validate engine wiring, tokenization, KV restoration, or
real-model predictions. Those require the opt-in integration checks below.

## Required app integration before candidate inference

Only the isolated app's `LlamaRuntimeCoreIntegrationTests.swift` was updated. Its sampled
matrix now includes production1.025 while retaining earlier1.05, disabled penalties, and
the broader RNG diagnostic. The added long-history case crosses all experimental windows
and edits a partial word after discarded generation. Each compares cached versus cold
generation with identical seed/configuration; it makes no lexical correctness assertion.

Run these existing opt-in test methods for baseline and each compiled H variant, supplying
the registered model via `COTABBY_TEST_MODEL_PATH` (or existing eval model fallback):

1. `testSampledRestoredRequestResetsRandomStreamAndRepetitionHistory`
2. `testSampledEditedPromptMatchesFreshStateAfterDiscardedGeneration`
3. `testSampledHistorySensitiveMidwordEditsMatchFreshState`
4. `testHealingStreamsOnlyValidCumulativeContinuation`
5. `testCancelledRetainedTailCanBeRestoredByNextRequest`

These preserve the existing environment opt-in and do not read or change app preferences.
The isolated test edit should be identical for all candidates and included in source
fingerprints. No model inference or app build was run by the native-history preparation step.
