"""No model, compiler, or production mutation: exercise selector safety in temp copies."""
import importlib.util
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location("history_variants", HERE / "history_variants.py")
history = importlib.util.module_from_spec(spec)
spec.loader.exec_module(history)


class NativeVariantSelectionTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name) / "native"
        self.artifacts = Path(self.temp.name) / "variants"
        (self.root / history.CPP).parent.mkdir(parents=True)
        (self.root / "Tests").mkdir()
        (self.root / "Package.swift").write_text("// temporary package input\n")
        self.baseline = (HERE / "variants/baseline.cpp").read_bytes()
        (self.root / history.CPP).write_bytes(self.baseline)
        (self.root / "Sources/retained.h").write_text("// retained native source\n")
        history.freeze(self.root, self.artifacts)

    def test_every_variant_restores_original_bytes_and_preserves_other_inputs(self):
        retained = (self.root / "Sources/retained.h").read_bytes()
        for name in ("H1", "H2", "H3", "H4", "baseline"):
            result = history.select(self.root, self.artifacts, name)
            self.assertEqual(result["after"], name)
            self.assertEqual(history.verify(self.root, self.artifacts)[1], name)
        self.assertEqual((self.root / history.CPP).read_bytes(), self.baseline)
        self.assertEqual((self.root / "Sources/retained.h").read_bytes(), retained)

    def test_unknown_current_engine_is_rejected_without_overwrite(self):
        path = self.root / history.CPP
        changed = self.baseline + b"\n// external edit\n"
        path.write_bytes(changed)
        with self.assertRaisesRegex(ValueError, "not a recognized"):
            history.select(self.root, self.artifacts, "H1")
        self.assertEqual(path.read_bytes(), changed)

    def test_new_native_source_is_rejected(self):
        (self.root / "Sources/new.cpp").write_text("// new compiler input\n")
        with self.assertRaisesRegex(ValueError, "Other native inputs changed"):
            history.select(self.root, self.artifacts, "H1")
        self.assertEqual((self.root / history.CPP).read_bytes(), self.baseline)

    def test_modified_test_or_package_is_rejected(self):
        for relative in ("Tests/new.swift", "Package.swift"):
            with self.subTest(relative=relative):
                path = self.root / relative
                old = path.read_bytes() if path.exists() else None
                path.write_text("// changed input\n")
                with self.assertRaisesRegex(ValueError, "Other native inputs changed"):
                    history.select(self.root, self.artifacts, "H1")
                path.unlink() if old is None else path.write_bytes(old)

    def test_modified_candidate_is_rejected(self):
        path = self.artifacts / "H1.cpp"
        path.write_bytes(path.read_bytes() + b"\n// altered candidate\n")
        with self.assertRaisesRegex(ValueError, "Frozen candidate bytes changed"):
            history.select(self.root, self.artifacts, "H1")

    def test_failed_replace_preserves_original(self):
        with patch.object(history.os, "replace", side_effect=OSError("simulated failure")):
            with self.assertRaisesRegex(OSError, "simulated failure"):
                history.select(self.root, self.artifacts, "H4")
        self.assertEqual((self.root / history.CPP).read_bytes(), self.baseline)
        self.assertEqual(list((self.root / history.CPP).parent.glob(".CotabbyInferenceEngine.cpp.*")), [])

    def test_cannot_apply_to_another_checkout(self):
        manifest_path = self.artifacts / "manifest.json"
        manifest = json.loads(manifest_path.read_text())
        manifest["nativeRoot"] = str(self.root.parent / "other")
        manifest_path.write_text(json.dumps(manifest))
        with self.assertRaisesRegex(ValueError, "not the frozen isolated"):
            history.select(self.root, self.artifacts, "H1")

    def test_freeze_never_replaces_existing_manifest(self):
        original = (self.artifacts / "manifest.json").read_bytes()
        with self.assertRaisesRegex(ValueError, "never overwrite"):
            history.freeze(self.root, self.artifacts)
        self.assertEqual((self.artifacts / "manifest.json").read_bytes(), original)


if __name__ == "__main__":
    unittest.main()
