#!/usr/bin/env python3
"""Publish observed screening counts and update only registered table status cells.

The document remains a decision record, not a controller. This helper never selects or
applies a winner and never reads protected fresh-data results.
"""
import datetime
import hashlib
import json
from pathlib import Path
import re

HERE = Path(__file__).resolve().parent
MAIN = HERE.parents[2]
DOC = MAIN / 'IMPROVEMENT_BRAINSTORMING_ROUND_TWO.md'


def summarize():
    rows = []
    for path in sorted(HERE.glob('screen-*-registration.json')):
        item = json.loads(path.read_text())
        if item['status'] != 'complete' or item['phase'] != 'screening':
            continue
        report_path = HERE / item['label'] / 'report.json'
        report = json.loads(report_path.read_text())
        if report['errorCount'] or report['metadata']['seed'] != 42:
            raise ValueError('Invalid completed screening record')
        counts = {condition: report['conditions'][condition]['suite']['nextWord'] for condition in ('screen','none')}
        if any(v['checkpoints'] != 770 or v['errors'] for v in counts.values()):
            raise ValueError('Screening denominator/errors differ')
        rows.append({'label':item['label'], 'candidate':item['candidate'], 'components':item['components'],
            'screenCorrect':counts['screen']['correct'], 'noneCorrect':counts['none']['correct'],
            'checkpointsPerCondition':770, 'reportSHA256':hashlib.sha256(report_path.read_bytes()).hexdigest(),
            'registrationSHA256':hashlib.sha256(path.read_bytes()).hexdigest(),
            'replayWallSeconds':item['replayWallSeconds']})
    single_order = [f'{family}{i}' for family in 'HFM' for i in range(1, 5)]
    def fixed_order(row):
        if row['candidate'] == 'baseline':
            return -1
        if row['candidate'] in single_order:
            return single_order.index(row['candidate'])
        families = '+'.join(component[0] for component in row['components'])
        return len(single_order) + ['H+F', 'H+M', 'F+M', 'H+F+M'].index(families)
    rows.sort(key=lambda r:(-r['screenCorrect'], -r['noneCorrect'], fixed_order(r)))
    result={'updatedUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'rows':rows,
            'completedAlternatives':sum(r['candidate']!='baseline' for r in rows),
            'scope':'Development screening; this ranking is not protected validation or an adoption decision.'}
    (HERE/'screening-ranking.json').write_text(json.dumps(result,indent=2)+'\n')
    lines=['# Round-two screening — observed results','','| Candidate | Screen correct / 770 | No-screen correct / 770 |',
           '| --- | ---: | ---: |']
    lines += [f"| {r['candidate']} | {r['screenCorrect']} | {r['noneCorrect']} |" for r in rows]
    lines += ['',result['scope'],'']
    (HERE/'screening-ranking.md').write_text('\n'.join(lines))
    before=DOC.read_bytes()
    text=before.decode()
    for row in rows:
        if not re.fullmatch(r'[HFM][1-4]',row['candidate']):
            continue
        pattern=r'(?m)^(\| '+re.escape(row['candidate'])+r' \| [^\n|]+ \| )[^\n|]+( \|)$'
        replacement=rf"\g<1>Complete: screen {row['screenCorrect']}/770; none {row['noneCorrect']}/770\g<2>"
        text,count=re.subn(pattern,replacement,text)
        if count!=1:
            raise ValueError('Expected one candidate row in the working document')
    if DOC.read_bytes()!=before:
        raise ValueError('Working document changed during status update')
    if text.encode()!=before:
        DOC.write_text(text)
    print(json.dumps(result,indent=2))
    return result


if __name__=='__main__':
    summarize()
