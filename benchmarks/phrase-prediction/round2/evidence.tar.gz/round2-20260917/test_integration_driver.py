"""Model-free integration-driver tests; fake processes and temporary source/evidence only."""
import copy, datetime, json, tempfile, time, types, unittest
from pathlib import Path
from unittest import mock
import run_integration_baseline as driver


def snapshots():
 return {'app':{'head':'app-head','files':{'Cotabby/app.swift':{'kind':'file','sha256':'a','mode':420}}},
         'native':{'head':'native-head','files':{'Sources/native.cpp':{'kind':'file','sha256':'n','mode':420}}}}


class IntegrationDriver(unittest.TestCase):
 def test_private_checker_rebinding_restored_after_failure(self):
  before={name:getattr(driver.run_checks,name) for name in ('EXECUTION','ROOT','DERIVED')}
  execution={'root':'/private/app','native':'/private/native','derivedData':'/private/app/build/DerivedData'}
  with self.assertRaisesRegex(RuntimeError,'synthetic'):
   with driver.check_execution(execution):
    self.assertEqual(driver.run_checks.EXECUTION,execution);self.assertEqual(driver.run_checks.ROOT,Path(execution['root']));self.assertEqual(driver.run_checks.DERIVED,Path(execution['derivedData']));raise RuntimeError('synthetic')
  for name,value in before.items():self.assertIs(getattr(driver.run_checks,name),value)
 def test_command_is_full_historical_production_seed_fresh_build(self):
  plan={'execution':{'root':'/private/app','workspace':'/private/app/build/dev.xcworkspace','model':'/private/model.gguf'}}
  command=driver.benchmark_command(plan)
  for flag,value in [('--seed','12648430'),('--split','all'),('--mode','word'),('--workers','3'),('--context','paired'),('--repetition-penalty','1.025')]:self.assertEqual(command[command.index(flag)+1],value)
  self.assertNotIn('--skip-build',command);self.assertNotIn('--corpus',command);self.assertNotIn('--per-category',command)
  self.assertEqual(command[1],'/private/app/scripts/phrase_eval.py')
 def test_deadline_reserves_until_exact_1801(self):
  with mock.patch.object(driver,'read',return_value={'deadlineUTC':'2026-09-17T18:21:09Z'}):
   self.assertEqual(datetime.datetime.fromtimestamp(driver.deadline(),datetime.timezone.utc).isoformat(),'2026-09-17T18:01:00+00:00')
 def test_admission_includes_initial_build_allowance(self):
  with mock.patch.object(driver.time,'time',return_value=100):
   driver.admit(2224,1823+300)
   with self.assertRaises(TimeoutError):driver.admit(2223,1823+300)
 def test_main_preservation_checks_bytes_modes_and_heads(self):
  before=snapshots();self.assertTrue(driver.same_sources(before,copy.deepcopy(before)))
  for edit in ('sha256','mode','head'):
   after=copy.deepcopy(before)
   if edit=='head':after['app']['head']='changed'
   else:after['app']['files']['Cotabby/app.swift'][edit]='changed'
   self.assertFalse(driver.same_sources(before,after))
 def test_private_inventory_allows_only_canonical_generated_locks(self):
  original=snapshots();snapshot={'snapshotAfterOverlay':original};execution={'root':'/fake/app','native':'/fake/native'}
  new=copy.deepcopy(original);new['app']['files']['Cotabby.xcodeproj/project.xcworkspace/xcshareddata/swiftpm/Package.resolved']={'kind':'file','sha256':'new','mode':420};new['native']['files']['Package.resolved']={'kind':'file','sha256':'new','mode':420}
  helper=types.SimpleNamespace(capture=lambda path,native=False:(new['native' if native else 'app'],{}))
  self.assertEqual(driver.verify_private_sources(helper,execution,snapshot),new)
 def test_private_inventory_rejects_added_ignored_sources_and_lock_named_fixtures(self):
  original=snapshots();execution={'root':'/fake/app','native':'/fake/native'}
  for role,path in [('app','Cotabby/ignored.swift'),('native','Sources/ignored.cpp'),('app','CotabbyTests/Package.resolved'),('native','Sources/Package.resolved')]:
   with self.subTest(role=role,path=path):
    changed=copy.deepcopy(original);changed[role]['files'][path]={'kind':'file','sha256':'new','mode':420}
    helper=types.SimpleNamespace(capture=lambda path,native=False:(changed['native' if native else 'app'],{}))
    with self.assertRaisesRegex(ValueError,'source drift'):driver.verify_private_sources(helper,execution,{'snapshotAfterOverlay':original})
 def test_report_guard_rejects_mismatched_source_product_and_reuse(self):
  inputs={'sourceSHA256':'source'};checks={'status':'passed','buildInputs':inputs,'productSHA256':'product'}
  manifest={'buildInputs':inputs,'build':{'sourceSHA256':'source','productSHA256':'product','reused':False}}
  for mutation in ('source','product','reuse'):
   changed=copy.deepcopy(manifest)
   if mutation=='source':changed['buildInputs']['sourceSHA256']='other'
   if mutation=='product':changed['build']['productSHA256']='other'
   if mutation=='reuse':changed['build']['reused']=None
   with self.subTest(mutation=mutation),self.assertRaisesRegex(ValueError,'build/check'):driver.verify_run({},changed,checks,{})
 def test_browser_supplement_preserves_only_already_copied_test(self):
  with tempfile.TemporaryDirectory() as folder:
   root=Path(folder);execution={'main':str(root/'main'),'root':str(root/'private')}
   for value in execution.values():
    path=Path(value)/driver.BROWSER_TEST;path.parent.mkdir(parents=True);path.write_bytes(b'synthetic test');path.chmod(0o644)
   entry={'kind':'file','mode':420,'sha256':driver.sha(path),'size':14}
   sources=snapshots();sources['app']['files'][driver.BROWSER_TEST]=entry
   snapshot={key:copy.deepcopy(sources) for key in ('mainBefore','mainAfter','snapshotBeforeOverlay','snapshotAfterOverlay')}
   original=root/'integration-snapshot.json';driver.snapshot_tools.write(original,snapshot)
   evidence=root/'integration-preparation';evidence.mkdir();before=evidence/'before.json';driver.snapshot_tools.write(before,sources)
   patch=evidence/'test.patch';patch.write_text('synthetic diff')
   certificate={'schemaVersion':1,'status':'verified-already-preserved','path':driver.BROWSER_TEST,'sourceWritesPerformed':False,'additionalChangesAfterSnapshot':False,'entry':entry,'snapshot':driver.ref(original),'diffFromHEAD':driver.ref(patch),'mainBefore':driver.ref(before),'mainAfter':driver.ref(before)}
   target=evidence/'preserved-browser-test.json';driver.snapshot_tools.write(target,certificate)
   with mock.patch.object(driver,'HERE',root):
    self.assertEqual(driver.verify_preserved_browser_test(snapshot,execution),driver.ref(target))
    for mutation in ('path','sourceWritesPerformed','additionalChangesAfterSnapshot'):
     changed=copy.deepcopy(certificate);changed[mutation]='other' if mutation=='path' else True;driver.snapshot_tools.write(target,changed)
     with self.subTest(mutation=mutation),self.assertRaisesRegex(ValueError,'certificate disagrees'):driver.verify_preserved_browser_test(snapshot,execution)
    driver.snapshot_tools.write(target,certificate)
    (Path(execution['root'])/driver.BROWSER_TEST).write_bytes(b'changed test')
    with self.assertRaisesRegex(ValueError,'changed after its snapshot'):driver.verify_preserved_browser_test(snapshot,execution)
 def test_check_failure_records_failure_preserves_main_and_restores_bindings(self):
  with tempfile.TemporaryDirectory() as folder:
   root=Path(folder);before=snapshots();execution={'root':str(root/'private-app'),'native':str(root/'private-native'),'derivedData':str(root/'private-app/build/DerivedData'),'workspace':str(root/'private-app/build/dev.xcworkspace'),'main':'/synthetic/main','mainNative':'/synthetic/native','model':'/synthetic/model'}
   plan={'execution':execution,'workload':{'estimatedSeconds':1823},'snapshot':{'mainAfter':before},'expectedMain':before,'currentMainRevision':{},'frozen':{'baselineTargets':{'renderer':'r','composer':'c','nativeEngine':'n'}},'certificate':{},'productionInventory':{},'evidence':{},'checkpointManifest':{},'tests':['Synthetic/testCase']}
   previous=driver.run_checks.ROOT;cli=types.SimpleNamespace(build_input_snapshot=lambda _: {'sourceSHA256':'source','nonLockSourceSHA256':'source'})
   with mock.patch.object(driver,'HERE',root),mock.patch.object(driver,'prepare_plan',return_value=plan),mock.patch.object(driver,'deadline',return_value=time.time()+5000),mock.patch.object(driver,'capture_helper',return_value=object()),mock.patch.object(driver,'capture_main',return_value=before),mock.patch.object(driver,'verify_private_sources'),mock.patch.object(driver,'load_module',return_value=cli),mock.patch.object(driver,'sha',return_value='a'*64),mock.patch.object(driver.run_checks,'run',side_effect=RuntimeError('synthetic check failure')),mock.patch.object(driver.run_checks,'bounded_command') as benchmark:
    with self.assertRaisesRegex(RuntimeError,'synthetic check failure'):driver.run()
    benchmark.assert_not_called();self.assertIs(driver.run_checks.ROOT,previous)
    record=json.loads((root/(driver.LABEL+'-registration.json')).read_text());self.assertEqual(record['status'],'failed-or-interrupted');self.assertEqual(record['replayWallSeconds'],0)
    self.assertTrue((root/(driver.LABEL+'-driver-evidence/main-after.json')).exists());self.assertFalse((root/(driver.LABEL+'-snapshot-proof.json')).exists())
 def test_revision_certificate_accepts_exact_head_only_change_and_rejects_consistent_source_tampering(self):
  with tempfile.TemporaryDirectory() as folder:
   root=Path(folder);original=snapshots();original['app']['head']=driver.ORIGINAL_MAIN_HEAD
   snapshot={'mainAfter':original};snapshot_path=root/'integration-snapshot.json';driver.snapshot_tools.write(snapshot_path,snapshot)
   evidence=root/'integration-preparation';evidence.mkdir();before_path=evidence/'before.json';after_path=evidence/'after.json';commit_path=evidence/'commit.json'
   driver.snapshot_tools.write(commit_path,{'head':driver.CERTIFIED_MAIN_HEAD,'parent':driver.ORIGINAL_MAIN_HEAD,'changedPaths':[driver.snapshot_tools.REVIEWED_PATH.removeprefix('app/')],'workingSourceChanged':False})
   current=copy.deepcopy(original);current['app']['head']=driver.CERTIFIED_MAIN_HEAD
   def save(value):
    driver.snapshot_tools.write(before_path,value);driver.snapshot_tools.write(after_path,value)
    certificate={'schemaVersion':1,'status':'verified-head-only','authorizedBy':'/root','allSourceEntriesIdentical':True,'mainBeforeAfterEqual':True,'sourceWritesPerformed':False,'privateSnapshotModified':False,
     'originalSnapshot':driver.ref(snapshot_path),'currentMainBefore':driver.ref(before_path),'currentMainAfter':driver.ref(after_path),'commit':driver.ref(commit_path),
     'originalMainHeads':{role:v['head'] for role,v in original.items()},'currentMainHeads':{role:v['head'] for role,v in value.items()},'fileCounts':{role:len(v['files']) for role,v in original.items()}}
    driver.snapshot_tools.write(root/driver.REVISION_CERTIFICATE,certificate)
   with mock.patch.object(driver,'HERE',root):
    save(current);expected,reference=driver.verify_main_revision(snapshot);self.assertTrue(driver.same_sources(expected,current));self.assertEqual(reference,driver.ref(root/driver.REVISION_CERTIFICATE))
    for child in (before_path,after_path,commit_path):
     original_child=child.read_bytes();data=driver.read(child);data['unexpectedPostPlanMutation']=True;driver.snapshot_tools.write(child,data)
     with self.subTest(child=child.name),self.assertRaisesRegex(ValueError,'Evidence artifact changed'):driver.verify_main_revision(snapshot)
     child.write_bytes(original_child)
    for mutation in ('bytes','mode','added-app','added-native','deleted','app-head','native-head'):
     changed=copy.deepcopy(current)
     if mutation=='bytes':changed['app']['files']['Cotabby/app.swift']['sha256']='changed'
     if mutation=='mode':changed['app']['files']['Cotabby/app.swift']['mode']=493
     if mutation=='added-app':changed['app']['files']['Cotabby/new.swift']={'kind':'file','sha256':'new','mode':420}
     if mutation=='added-native':changed['native']['files']['Sources/new.cpp']={'kind':'file','sha256':'new','mode':420}
     if mutation=='deleted':del changed['app']['files']['Cotabby/app.swift']
     if mutation=='app-head':changed['app']['head']='unregistered-head'
     if mutation=='native-head':changed['native']['head']='unregistered-head'
     save(changed)
     with self.subTest(mutation=mutation),self.assertRaisesRegex(ValueError,'unregistered HEAD drift'):driver.verify_main_revision(snapshot)
    save(current);certificate=driver.read(root/driver.REVISION_CERTIFICATE);certificate['sourceWritesPerformed']=True;driver.snapshot_tools.write(root/driver.REVISION_CERTIFICATE,certificate)
    with self.assertRaisesRegex(ValueError,'metadata-only'):driver.verify_main_revision(snapshot)
    (root/driver.REVISION_CERTIFICATE).unlink()
    with self.assertRaises(FileNotFoundError):driver.verify_main_revision(snapshot)
 def test_main_drift_before_launch_rejects_without_registration(self):
  with tempfile.TemporaryDirectory() as folder:
   root=Path(folder);before=snapshots();changed=copy.deepcopy(before);changed['app']['head']='new'
   plan={'execution':{},'workload':{'estimatedSeconds':1823},'snapshot':{'mainAfter':before},'expectedMain':before}
   with mock.patch.object(driver,'HERE',root),mock.patch.object(driver,'prepare_plan',return_value=plan),mock.patch.object(driver,'deadline',return_value=time.time()+5000),mock.patch.object(driver,'capture_helper'),mock.patch.object(driver,'capture_main',return_value=changed),mock.patch.object(driver.run_checks,'run') as checks:
    with self.assertRaisesRegex(ValueError,'Current main changed'):driver.run()
    checks.assert_not_called();self.assertFalse((root/(driver.LABEL+'-registration.json')).exists())

if __name__=='__main__':unittest.main()
