#!/usr/bin/env python3
"""Execute an explicit, hash-bound sequence of registered baseline workloads.

The root scheduler owns workload order and time admission. This small queue only
translates existing records into the guarded runner's arguments and stops on failure;
it never overwrites attempts, chooses candidates, scores results or launches latency.
"""
import argparse
import datetime
import fcntl
import hashlib
import json
from pathlib import Path
import subprocess
import sys

HERE = Path(__file__).resolve().parent


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(path):
    return json.loads(path.read_text())


def run(plan_path):
    plan = read(plan_path)
    plan_hash = sha(plan_path)
    freeze = read(HERE / 'finalist-freeze.json')
    if (plan['schemaVersion'] != 1 or plan['candidate'] != 'baseline'
            or plan['freezeSHA256'] != sha(HERE / 'finalist-freeze.json')
            or freeze['candidate'] != 'baseline' or freeze['selectionQualified'] is not False):
        raise ValueError('Sequence must retain the frozen no-qualifier baseline decision')
    for entry in plan['order']:
        if sha(plan_path) != plan_hash:
            raise ValueError('Sequence changed while running')
        path = Path(entry['workload']['path'])
        path = path if path.is_absolute() else HERE / path
        if sha(path) != entry['workload']['sha256']:
            raise ValueError('Registered workload changed')
        workload = read(path)
        if workload['candidate'] != 'baseline' or workload['freezeSHA256'] != plan['freezeSHA256']:
            raise ValueError('Workload decision differs from sequence')
        selected = [row for row in workload['runs'] if row['name'] == entry['name']]
        if len(selected) != 1:
            raise ValueError('Sequence has an absent or ambiguous workload identity')
        item = selected[0]
        if item['kind'] not in ('freshWord', 'historicalWord', 'freshCharacter', 'historicalCharacter'):
            raise ValueError('Use the separate integration or latency driver for that workload')
        label = item['label']
        registration = HERE / (label + '-registration.json')
        if registration.exists():
            if read(registration)['status'] == 'complete':
                continue
            raise ValueError('Prior incomplete attempt must remain intact: ' + label)
        command = [sys.executable, str(HERE / 'run_experiment.py'), label, '--candidate', 'baseline',
                   '--phase', 'validation', '--split', item['selection'], '--mode', item['mode'],
                   '--seed', str(item['seed']), '--workers', str(item['workerCount']),
                   '--estimated-seconds', str(item['estimatedSeconds'])]
        if item['perCategory']:
            command += ['--per-category', str(item['perCategory'])]
        if item['kind'].startswith('fresh'):
            command += ['--corpus', str(HERE / 'protected-fresh/corpus.json')]
        if item['kind'] == 'freshCharacter':
            command += ['--descriptive-workload', str(path.resolve()),
                        '--descriptive-workload-sha256', entry['workload']['sha256']]
        print(datetime.datetime.now(datetime.timezone.utc).isoformat() + ' Starting ' + label, flush=True)
        with (HERE / (label + '.orchestrator.log')).open('x') as stream:
            subprocess.run(command, cwd=HERE, stdout=stream, stderr=subprocess.STDOUT, check=True)
        print('Completed ' + label, flush=True)
    print('Registered baseline sequence complete.', flush=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--plan', type=Path, required=True)
    args = parser.parse_args()
    with (HERE / 'baseline-sequence.lock').open('a') as lock:
        fcntl.flock(lock.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        run(args.plan.resolve())
