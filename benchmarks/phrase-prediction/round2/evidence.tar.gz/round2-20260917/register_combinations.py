#!/usr/bin/env python3
"""Apply the registered combination rule to completed single-variant evidence.

This decision is based only on the old development corpus. The resulting immutable queue
contains at most the three qualified family-winner pairs and their triple; it cannot use
fresh validation results or launch a second search grid.
"""
import datetime
import hashlib
import itertools
import json
from pathlib import Path
from screening_evidence import validate_rows

HERE = Path(__file__).resolve().parent
SINGLES = [f'{family}{i}' for family in 'HFM' for i in range(1, 5)]


def register():
    destination = HERE / 'combination-registration.json'
    if destination.exists() or (HERE / 'finalist-freeze.json').exists():
        raise ValueError('Combination decisions are immutable once registered')
    ranking_path = HERE / 'screening-ranking.json'
    ranking = json.loads(ranking_path.read_text())
    rows = {row['candidate']: row for row in validate_rows(ranking['rows'])}
    if set(rows) != {'baseline', *SINGLES}:
        raise ValueError('All 12 single alternatives and baseline must be complete first')
    baseline = rows['baseline']
    families = {}
    for family in 'HFM':
        members = [rows[candidate] for candidate in SINGLES if candidate.startswith(family)]
        winner = min(members, key=lambda row: (-row['screenCorrect'], -row['noneCorrect'],
                                              SINGLES.index(row['candidate'])))
        qualified = (winner['screenCorrect'] > baseline['screenCorrect']
                     and winner['noneCorrect'] >= baseline['noneCorrect'])
        families[family] = {'winner': winner['candidate'], 'qualified': qualified,
                            'screenCorrect': winner['screenCorrect'],
                            'noneCorrect': winner['noneCorrect']}
    combinations = []
    for size in (2, 3):
        for group in itertools.combinations('HFM', size):
            if all(families[family]['qualified'] for family in group):
                components = [families[family]['winner'] for family in group]
                combinations.append({'candidate': '+'.join(components), 'components': components})
    result = {
        'schemaVersion': 1,
        'registeredUTC': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'screeningEvidenceSHA256': hashlib.sha256(ranking_path.read_bytes()).hexdigest(),
        'singleEvidence': ranking['rows'], 'families': families, 'combinations': combinations,
        'policy': 'One best component per family; screen > baseline and none >= baseline. '
                  'Only qualified pairs and triple, at most four, subject to phase admission.'
    }
    destination.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    register()
