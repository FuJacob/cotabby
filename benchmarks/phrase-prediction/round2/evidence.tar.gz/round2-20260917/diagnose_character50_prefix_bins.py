#!/usr/bin/env python3
"""Aggregate the completed character50 retry by authoritative typed-character offsets.

This post-freeze diagnostic never changes scoring, tokenization, sampling, or candidates.
It deliberately excludes the interrupted original attempt and emits no case-level text.
"""
import collections
import datetime as dt
import fcntl
import importlib.util
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
SPEC = importlib.util.spec_from_file_location('round2_prefix_bin_validation', HERE / 'assess_round2.py')
BASE = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(BASE)
LABEL = 'character50-baseline-retry1'
NAME = 'character50-retry1'
BIN_ORDER = ('boundary', '1', '2', '3', '4-5', '6+')


def bucket(offset):
    BASE.require(type(offset) is int and offset >= 0, 'Invalid Swift typedCharacters value')
    return 'boundary' if offset == 0 else str(offset) if offset <= 3 else '4-5' if offset <= 5 else '6+'


def tally(observations):
    count = len(observations)
    correct = sum(o['correct'] for o in observations)
    shown = sum(o['wasShown'] for o in observations)
    reasons = collections.Counter(o.get('suppression') or 'unrecorded' for o in observations if not o['wasShown'])
    BASE.require(sum(reasons.values()) == count - shown, 'Suppression reason accounting mismatch')
    return {'checkpoints': count, 'correct': correct, 'shown': shown, 'shownWrong': shown - correct,
            'notShown': count - shown, 'accuracy': correct / count if count else None,
            'shownCoverage': shown / count if count else None,
            'precisionWhenShown': correct / shown if shown else None,
            'suppressionReasons': dict(sorted(reasons.items()))}


def summarize(pairs):
    none = tally([a for _, _, a, _ in pairs])
    screen = tally([b for _, _, _, b in pairs])
    count = len(pairs)
    gained = sum(not a['correct'] and b['correct'] for _, _, a, b in pairs)
    lost = sum(a['correct'] and not b['correct'] for _, _, a, b in pairs)
    shown_gained = sum(not a['wasShown'] and b['wasShown'] for _, _, a, b in pairs)
    shown_lost = sum(a['wasShown'] and not b['wasShown'] for _, _, a, b in pairs)
    BASE.require(gained - lost == screen['correct'] - none['correct'], 'Matched correctness accounting mismatch')
    BASE.require(shown_gained - shown_lost == screen['shown'] - none['shown'], 'Matched display accounting mismatch')
    return {'phraseCount': len({identifier for identifier, _, _, _ in pairs}), 'conditions': {'none': none, 'screen': screen},
            'screenMinusNone': {'pairedCheckpoints': count, 'accuracyDelta': (gained - lost) / count if count else None,
                                'correctGained': gained, 'correctLost': lost,
                                'shownCoverageDelta': (shown_gained - shown_lost) / count if count else None,
                                'shownGained': shown_gained, 'shownLost': shown_lost}}


def aggregate(indexed):
    bins = {name: [] for name in BIN_ORDER}
    for identifier, condition in sorted(indexed):
        if condition != 'none':
            continue
        none, screen = indexed[(identifier, 'none')], indexed[(identifier, 'screen')]
        BASE.require(none['phrase'] == screen['phrase'], 'Paired scenario identity differs')
        BASE.require(len(none['observations']) == len(screen['observations']), 'Paired observation count differs')
        for a, b in zip(none['observations'], screen['observations']):
            BASE.require(a['checkpoint'] == b['checkpoint'], 'Paired checkpoint identity differs')
            bins[bucket(a['checkpoint']['typedCharacters'])].append((identifier, none['phrase']['category'], a, b))
    result = {}
    for name, pairs in bins.items():
        result[name] = summarize(pairs)
        result[name]['categories'] = {category: summarize([row for row in pairs if row[1] == category])
                                      for category in sorted(BASE.CATEGORIES)}
    partial = [row for name, rows in bins.items() if name != 'boundary' for row in rows]
    result['partial-only'] = summarize(partial)
    result['all'] = summarize([row for rows in bins.values() for row in rows])
    return result


def main():
    with (HERE / 'descriptive-analysis.lock').open('a') as lock:
        fcntl.flock(lock.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        reader = BASE.Assessment(HERE)
        frozen = reader.read_json('finalist-freeze.json')
        BASE.require(frozen['candidate'] == 'baseline' and frozen['selectionQualified'] is False,
                     'Requires a frozen retained baseline')
        registered = reader.read_json(LABEL + '-registration.json')
        BASE.require(registered['status'] == 'complete' and registered['candidate'] == 'baseline'
                     and registered['phase'] == 'validation', 'Only the completed retry may be diagnosed')
        analysis = reader.read_json('baseline-characterization.json')
        BASE.require(analysis['status'] == 'descriptive-only' and analysis['runs'][NAME]['label'] == LABEL,
                     'Completed retry lacks successful authoritative characterization')
        evidence = reader.read_json('baseline-evidence.json')
        specs = [row for row in evidence['runs'] if row['name'] == NAME and row['label'] == LABEL]
        BASE.require(len(specs) == 1, 'Retry evidence identity is ambiguous')
        plan = reader.artifact(specs[0]['checkpoints'])
        BASE.require(plan['corpusSHA256'] == BASE.OLD_CORPUS_SHA and plan['mode'] == 'character'
                     and plan['perCategory'] == 50 and plan['selection'] == 'all'
                     and plan['phraseCount'] == 350 and plan['checkpointsPerCondition'] == 8830,
                     'Diagnostic cohort must remain the registered historical first50/category')
        for name, path in [('report', LABEL + '/report.json'), ('manifest', LABEL + '/manifest.json'),
                           ('checks', registered['checks'])]:
            actual = BASE.digest(reader.read_bytes(path))
            BASE.require(actual == registered['evidenceSHA256'][name]
                         == analysis['artifactSHA256'][str(reader.path(path).resolve())],
                         'Completed report, checks, or manifest changed after full characterization')
        report = reader.read_json(LABEL + '/report.json')
        manifest = reader.read_json(LABEL + '/manifest.json')
        BASE.require(report['metadata']['runLabel'] == LABEL and report['metadata']['seed'] == 42
                     and report['metadata']['workerCount'] == 3
                     and manifest['buildInputs']['sourceSHA256'] == frozen['baselineSourceSHA256']
                     == analysis['runs'][NAME]['sourceSHA256'], 'Retry runtime/source identity differs')
        indexed = BASE.validate_report(report, plan)
        result = {'schemaVersion': 1, 'scope': 'Post-freeze descriptive diagnostic; no candidate selection, tuning, or rescoring.',
                  'label': LABEL, 'mode': 'character', 'seed': 42, 'workerCount': 3,
                  'phraseCount': 350, 'cohort': 'Historical corpus-order first50/category, seven categories',
                  'checkpointsPerCondition': 8830, 'sourceSHA256': manifest['buildInputs']['sourceSHA256'],
                  'corpusSHA256': plan['corpusSHA256'], 'modelSHA256': frozen['modelSHA256'],
                  'bins': aggregate(indexed), 'limitations': [
                      'Correctness and display visibility use the stored Swift correct/wasShown flags without lexical rescoring.',
                      'Bins use stored Swift typedCharacters offsets, not bytes or a reconstructed Python string length.',
                      'Checkpoints are weighted equally. Several offsets/words from each scenario are dependent; these counts are not independent trials.',
                      'Different bins contain different target-word and scenario populations; their accuracy slope is descriptive, not a causal typing-length effect.',
                      'Only the historical first50/category subset is included; it is not the full1337 corpus or fresh validation data.',
                      'No new confidence intervals or hypothesis tests are calculated; the existing scenario-clustered characterization retains its own scope.',
                      'Suppression reasons come from the report. They do not determine whether the hidden raw continuation would have been correct.',
                      'Three-worker timings are contended and omitted. This is not an end-to-end acceptance or keystroke-savings measurement.',
                      'The interrupted original attempt contributes no observations.']}
        partial = result['bins']['partial-only']['conditions']['screen']
        late = [result['bins'][name]['conditions']['screen'] for name in ('4-5', '6+')]
        result['descriptiveFindings'] = {
            'screenPartialErrors': {'shownWrong': partial['shownWrong'], 'notShown': partial['notShown'],
                                    'totalIncorrect': partial['checkpoints'] - partial['correct']},
            'fourOrMoreTypedCharacters': {'checkpoints': sum(row['checkpoints'] for row in late),
                                         'screenNotShown': sum(row['notShown'] for row in late),
                                         'screenShownWrong': sum(row['shownWrong'] for row in late)},
            'interpretation': 'Screen context has a positive aggregate point estimate in each typed-character bin in this completed cohort; no additional statistical or real-world generalization is claimed.'}
        result['prospectiveDiagnosticPriorities'] = [
            'In a future round, separate target-word length and scenario composition from typed-offset effects using matched target positions; current bins alone cannot identify a causal mechanism.',
            'Examine why generated continuations at longer partial prefixes fail existing seam validation, while retaining the guard. Suppression counts do not justify displaying those hidden continuations.',
            'Keep displayed-but-incorrect partial completions as a separate outcome: their count exceeds suppression among remaining errors. Validate any future word-choice or partial-prefix hypothesis on independent scenarios.']
        existing = Path(reader.read_json('execution.json')['root']) / 'scripts/analyze_completion_prefixes.py'
        reader.read_bytes(existing)
        result['existingToolAssessment'] = 'analyze_completion_prefixes.py records() excludes typedCharacters!=0 and lexically evaluates later words; it does not provide the requested authoritative partial-offset bins.'
        result['analyzedUTC'] = dt.datetime.now(dt.timezone.utc).isoformat()
        result['scriptSHA256'] = BASE.digest(Path(__file__).read_bytes())
        result['validatorSHA256'] = BASE.digest((HERE / 'assess_round2.py').read_bytes())
        result['artifactSHA256'] = reader.stable_artifacts()
        directory = HERE / 'diagnostics'
        directory.mkdir(exist_ok=True)
        (directory / 'character50-prefix-bins.json').write_text(json.dumps(result, indent=2) + '\n')
        lines = ['# Historical character-prefix diagnostic', '', result['scope'], '',
                 'Completed `character50-baseline-retry1`: 350 scenarios, first 50 per category, seed 42. '
                 'Each condition has 8,830 checkpoints; the interrupted original attempt is excluded.', '',
                 '| Typed characters | Checkpoints/condition | None correct | Screen correct | None accuracy | Screen accuracy | Screen−none | Gains/losses | None shown | Screen shown |',
                 '|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|']
        for name in (*BIN_ORDER, 'partial-only', 'all'):
            item = result['bins'][name]; a, b = item['conditions']['none'], item['conditions']['screen']; d = item['screenMinusNone']
            lines.append(f'| {name} | {a["checkpoints"]:,} | {a["correct"]:,} | {b["correct"]:,} | {a["accuracy"]:.2%} | {b["accuracy"]:.2%} | {d["accuracyDelta"]*100:+.2f} pp | {d["correctGained"]}/{d["correctLost"]} | {a["shownCoverage"]:.2%} | {b["shownCoverage"]:.2%} |')
        lines += ['', 'Suppression counts are recorded reasons among unshown observations:', '',
                  '| Typed characters | None not shown (reasons) | Screen not shown (reasons) |', '|---|---|---|']
        for name in (*BIN_ORDER, 'partial-only'):
            row = result['bins'][name]['conditions']
            def reason(condition):
                x = row[condition]
                return str(x['notShown']) + ' (' + (', '.join(f'{k}:{v}' for k, v in x['suppressionReasons'].items()) or 'none') + ')'
            lines.append(f'| {name} | {reason("none")} | {reason("screen")} |')
        lines += ['', 'Per-category counts, matched display transitions, phrase counts per bin, source/report hashes, '
                  'and full limitations are in the adjacent JSON. No prompts, references, or completions are exported.', '']
        lines += ['Screen-context partial errors comprise 1,678 displayed-but-incorrect continuations and 375 unshown '
                  'observations. The four-or-more-character bins contain 2,299 of 6,936 partial checkpoints and '
                  '324 of the 375 unshown observations. They also retain 708 displayed-but-incorrect continuations. '
                  'This concentrates a useful future diagnostic, without establishing that the guard is wrong.', '',
                  'Prospective diagnostic priorities; no tuning is authorized by this memo:', '']
        lines += ['- ' + item for item in result['prospectiveDiagnosticPriorities']]
        lines.append('')
        lines += ['- ' + item for item in result['limitations']]
        (directory / 'character50-prefix-bins.md').write_text('\n'.join(lines) + '\n')
        print(json.dumps({'status': 'complete-descriptive-diagnostic', 'label': LABEL, 'phraseCount': 350,
                          'checkpointsPerCondition': 8830, 'output': str(directory / 'character50-prefix-bins.json')}, sort_keys=True))


if __name__ == '__main__':
    main()
