#!/usr/bin/env python3
"""Temporary, invented metadata fixtures; no app/model or benchmark reports opened."""
import copy
import fcntl
import importlib.util
import json
from pathlib import Path
import tempfile
import unittest
from unittest import mock

HERE = Path(__file__).resolve().parent
SPEC = importlib.util.spec_from_file_location('refresh_subject', HERE / 'refresh_baseline_evidence.py')
S = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(S)


class RefreshTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix='round2-refresh-unit-')
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.targets = {name: str(i) * 64 for i, name in enumerate(S.BASE.TARGET_PATHS, 1)}
        self.inventory = self.write('inventory.json', {'schemaVersion': 1, 'scope': S.BASE.PRODUCTION_SCOPE,
            'files': {path: self.targets[name] for name, path in S.BASE.TARGET_PATHS.items()}})
        scorer = self.write('scorer.json', {})
        self.frozen = {'schemaVersion': 1, 'candidate': 'baseline', 'components': [], 'selectionQualified': False,
            'frozenUTC': '2020-01-01T09:00:00Z', 'baselineTargets': self.targets,
            'baselineSourceSHA256': 'a' * 64, 'productionInventories': {'baseline': self.inventory},
            'validationHarnessHashes': {'app/CotabbyTests/Evals/PhrasePredictionScoring.swift': scorer['sha256']}}
        self.freeze_ref = self.write('finalist-freeze.json', self.frozen)
        self.write('round.json', {'deadlineUTC': '2020-01-01T15:00:00Z'})
        self.plans = []
        for selection, count in [('all', 191), ('screen', 20)]:
            plan = {'schemaVersion': 1, 'corpusSHA256': S.BASE.OLD_CORPUS_SHA, 'corpusVersion': 2,
                'scorerSourceSHA256': scorer['sha256'], 'mode': 'word', 'perCategory': 0, 'selection': selection,
                'phraseCount': 7 * count, 'checkpointsPerCondition': 7 * count,
                'phrases': [{'phraseID': f'{category}-{i}', 'category': category,
                            'checkpoints': [{'wordIndex': 1, 'typedCharacters': 0}]}
                            for category in sorted(S.BASE.CATEGORIES) for i in range(count)]}
            self.plans.append((self.write(f'plan-{selection}.json', plan), plan))
        self.write('checkpoint-exporter.json', {'schemaVersion': 1, 'compilerVersion': 'invented',
            'scorerSource': scorer, 'helperSource': scorer, 'binary': scorer,
            'manifests': [ref for ref, _ in self.plans]})
        self.checks('baseline-checks/validation.json')
        self.rows = [self.row('seed42'), self.row('seed1337', seed=1337), self.row('missing'), self.row('failed')]
        self.plan_record(self.rows)
        self.complete(self.rows[0])
        self.write('failed-registration.json', {'label': 'failed', 'candidate': 'baseline', 'components': [],
                                               'phase': 'validation', 'status': 'failed-or-interrupted'})

    def write(self, name, value):
        path = self.root / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(value, sort_keys=True) + '\n')
        return {'path': name, 'sha256': S.sha(path)}

    def row(self, name, seed=42, latency=False):
        return {'name': name, 'label': name, 'kind': 'latency' if latency else 'historicalWord', 'seed': seed,
                'workerCount': 1 if latency else 3, 'mode': 'word', 'corpusSHA256': S.BASE.OLD_CORPUS_SHA,
                'selection': 'screen' if latency else 'all', 'perCategory': 0, 'estimatedSeconds': 600, 'guardException': None}

    def plan_record(self, rows, name='baseline-workloads.json'):
        return self.write(name, {'schemaVersion': 1, 'candidate': 'baseline', 'purpose': 'Invented descriptive plan.',
            'registeredUTC': '2020-01-01T09:05:00Z', 'freezeSHA256': self.freeze_ref['sha256'], 'runs': rows})

    def checks(self, name, source='a' * 64):
        value = {'status': 'passed', 'productSHA256': 'b' * 64, 'buildInputs': {'sourceSHA256': source},
            'startedUTC': '2020-01-01T09:01:00Z', 'finishedUTC': '2020-01-01T09:02:00Z',
            'tests': ['BaseCompletionPromptRendererTests/testRoundTwoScreeningPromptAudit']}
        self.write(name, value)
        (self.root / name).with_name('validation.log').write_text(
            "Test Case '-[CotabbyTests.BaseCompletionPromptRendererTests testRoundTwoScreeningPromptAudit]' passed\n"
            '** TEST EXECUTE SUCCEEDED **\n')
        return value

    def complete(self, row, at='09:10', source='a' * 64):
        label = row['label']
        plan = next(p for _, p in self.plans if p['selection'] == row['selection'])
        self.checks(f'{label}-checks/validation.json', source)
        manifest = {'label': label, 'buildInputs': {'sourceSHA256': source},
            'build': {'sourceSHA256': source, 'productSHA256': 'b' * 64, 'reused': False},
            'corpusSHA256': row['corpusSHA256'], 'mode': row['mode'], 'contextMode': 'paired',
            'workerCount': row['workerCount'], 'phraseIDs': [p['phraseID'] for p in plan['phrases']],
            'selection': {'split': row['selection'], 'perCategory': 0, 'limit': None, 'splitSeed': 1337, 'screenPerCategory': 20},
            'samplingOverrides': dict(S.BASE.SAMPLING, seed=row['seed'])}
        manifest_ref = self.write(f'{label}/manifest.json', manifest)
        # Intentionally not JSON: refresh must hash this stream, never inspect examples.
        path = self.root / label / 'report.json'
        path.write_bytes(b'opaque invented report bytes')
        registration = {'label': label, 'candidate': 'baseline', 'components': [], 'phase': 'validation', 'status': 'complete',
            'startedUTC': f'2020-01-01T{at}:00Z', 'inferenceStartedUTC': f'2020-01-01T{at}:10Z',
            'finishedUTC': f'2020-01-01T{at}:50Z', 'checks': f'{label}-checks/validation.json',
            'promptSource': {'hashes': {k: v for k, v in self.targets.items() if k != 'nativeEngine'}},
            'nativeSource': {'sha256': self.targets['nativeEngine']},
            'evidenceSHA256': {'checks': S.sha(self.root / f'{label}-checks/validation.json'),
                              'manifest': manifest_ref['sha256'], 'report': S.sha(path)}}
        self.write(f'{label}-registration.json', registration)
        return registration

    def refresh(self, extensions=()):
        return S.Refresh(self.root).refresh(extensions=extensions)

    def test_only_complete_runs_enter_map_and_missing_failed_attempts_stay_visible(self):
        evidence, receipt = self.refresh()
        self.assertEqual([r['name'] for r in evidence['runs']], ['seed42'])
        statuses = {r['name']: r['registeredStatus'] for r in receipt['plannedWorkloads']}
        self.assertEqual(statuses['missing'], 'not-started')
        self.assertEqual(statuses['failed'], 'failed-or-interrupted')
        self.assertEqual(evidence['seedPairs'], [])

    def test_seed_pair_added_only_after_matching_registered_seed_completes(self):
        self.complete(self.rows[1], at='09:12')
        evidence, _ = self.refresh()
        self.assertEqual(evidence['seedPairs'], [{'name': 'seed42-vs-seed1337', 'reference': 'seed42', 'comparison': 'seed1337'}])

    def test_worker_mismatch_is_not_a_seed_comparison(self):
        self.rows[1]['workerCount'] = 2
        self.plan_record(self.rows)
        self.complete(self.rows[1])
        self.assertEqual(self.refresh()[0]['seedPairs'], [])

    def test_explicit_extension_is_required_then_its_hash_persists(self):
        extra = self.row('extra', seed=12648430)
        self.plan_record([extra], 'extension.json')
        self.complete(extra, at='09:14')
        with self.assertRaisesRegex(S.BASE.EvidenceError, 'explicitly supplied'):
            self.refresh()
        evidence, _ = self.refresh(['extension.json'])
        self.write('baseline-evidence.json', evidence)
        self.assertEqual(len(self.refresh()[0]['plannedWorkloads']), 2)
        (self.root / 'extension.json').write_text('{}')
        with self.assertRaisesRegex(S.BASE.EvidenceError, 'changed'):
            self.refresh()

    def test_wrong_completed_identity_seed_and_report_hash_are_rejected(self):
        for mutation in ('candidate', 'seed', 'report'):
            with self.subTest(mutation=mutation):
                record = self.complete(self.rows[0])
                if mutation == 'candidate':
                    record['candidate'] = 'F1'
                    self.write('seed42-registration.json', record)
                elif mutation == 'seed':
                    path = self.root / 'seed42/manifest.json'
                    manifest = json.loads(path.read_text())
                    manifest['samplingOverrides']['seed'] = 1337
                    reference = self.write('seed42/manifest.json', manifest)
                    record['evidenceSHA256']['manifest'] = reference['sha256']
                    self.write('seed42-registration.json', record)
                else:
                    (self.root / 'seed42/report.json').write_bytes(b'changed')
                with self.assertRaises(S.BASE.EvidenceError):
                    self.refresh()

    def test_unknown_opaque_cohort_is_rejected_even_before_launch(self):
        self.rows[2]['perCategory'] = 3
        self.plan_record(self.rows)
        with self.assertRaisesRegex(S.BASE.EvidenceError, 'exactly one known'):
            self.refresh()

    def test_old_completed_run_cannot_silently_disappear(self):
        self.write('baseline-evidence.json', self.refresh()[0])
        (self.root / 'seed42-registration.json').unlink()
        with self.assertRaisesRegex(S.BASE.EvidenceError, 'disappeared'):
            self.refresh()

    def test_current_main_parity_requires_completed_bound_matching_run_and_snapshot(self):
        current = self.row('current')
        self.plan_record([*self.rows, current])
        self.complete(current, at='09:14', source='c' * 64)
        self.write('current-source-binding.json', {'label': 'current', 'role': 'baseline', 'sourceSHA256': 'c' * 64,
                                                 'targets': self.targets, 'productionInventory': self.inventory})
        self.write('current-snapshot-proof.json', {'schemaVersion': 1, 'status': 'passed'})
        evidence, _ = self.refresh()
        self.assertEqual(evidence['parityPairs'][0]['currentMain'], 'current')
        self.assertEqual(evidence['parityPairs'][0]['reference'], 'seed42')
        self.assertEqual(evidence['sourceBindings'][0]['sourceSHA256'], 'c' * 64)

    def isolation(self, row, record, passed=True):
        log = self.write(row['label'] + '-observations.json', {'invented': True})
        return self.write(row['label'] + '-isolation.json', {'schemaVersion': 1,
            'status': 'passed' if passed else 'failed', 'labels': [row['label']],
            'noOverlappingBuildOrInference': passed, 'evidence': log,
            'intervals': [{'label': row['label'], 'startedUTC': record['inferenceStartedUTC'], 'finishedUTC': record['finishedUTC']}]})

    def test_latency_repeat_requires_both_complete_matching_proofs(self):
        one, two = self.row('latency-one', latency=True), self.row('latency-two', latency=True)
        self.plan_record([*self.rows, one, two])
        a, b = self.complete(one, at='09:20'), self.complete(two, at='09:22')
        self.isolation(one, a)
        evidence, _ = self.refresh()
        self.assertEqual(len(evidence['latencyRuns']), 1)
        self.assertEqual(evidence['latencyPairs'], [])
        self.isolation(two, b, passed=False)
        evidence, _ = self.refresh()
        self.assertEqual(len(evidence['latencyRuns']), 2)
        self.assertEqual(evidence['latencyPairs'], [])
        self.isolation(two, b)
        self.assertEqual(len(self.refresh()[0]['latencyPairs']), 1)

    def test_shared_latency_lock_rejects_refresh_before_any_evidence_read(self):
        with (self.root / 'descriptive-analysis.lock').open('a') as lock:
            fcntl.flock(lock.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
            with mock.patch.object(S.Refresh, 'refresh', side_effect=AssertionError('must not read')), self.assertRaises(SystemExit):
                S.main(['--round', str(self.root)])

    def test_analysis_is_explicit_and_map_refresh_is_atomic(self):
        with mock.patch.object(S.subprocess, 'run') as analysis:
            self.assertEqual(S.main(['--round', str(self.root)]), 0)
            analysis.assert_not_called()
            analysis.return_value.returncode = 0
            self.assertEqual(S.main(['--round', str(self.root), '--analyze']), 0)
            self.assertIn('--evidence', analysis.call_args.args[0])
        receipt = json.loads((self.root / 'baseline-evidence-refresh.json').read_text())
        self.assertNotIn(str(self.root / 'baseline-evidence.json'), receipt['artifactSHA256'])
        self.assertIn('previousEvidenceSHA256', receipt)
        self.assertEqual(receipt['evidence']['sha256'], S.sha(self.root / 'baseline-evidence.json'))
        original = (self.root / 'baseline-evidence.json').read_bytes()
        with mock.patch.object(S.os, 'replace', side_effect=OSError('invented failure')), self.assertRaises(OSError):
            S.atomic_json(self.root / 'baseline-evidence.json', {})
        self.assertEqual((self.root / 'baseline-evidence.json').read_bytes(), original)

    def test_evidence_output_cannot_overwrite_frozen_input_or_symlink_alias(self):
        original = (self.root / 'finalist-freeze.json').read_bytes()
        (self.root / 'freeze-alias.json').symlink_to(self.root / 'finalist-freeze.json')
        for name in ('finalist-freeze.json', 'freeze-alias.json'):
            with self.subTest(name=name), self.assertRaisesRegex(S.BASE.EvidenceError, 'not a generated'):
                S.main(['--round', str(self.root), '--evidence', name])
            self.assertEqual((self.root / 'finalist-freeze.json').read_bytes(), original)

    def preflight(self):
        row = self.row('latency-preflight', latency=True)
        workload = self.plan_record([*self.rows, row])
        folder = row['label'] + '-isolation-evidence/'
        args = {'label': row['label'], 'candidate': 'baseline', 'phase': 'validation', 'mode': 'word',
                'split': 'screen', 'corpus': None, 'per_category': None, 'seed': 42, 'workers': 1, 'estimated_seconds': 600}
        plan = self.write(folder + 'plan.json', {'schemaVersion': 1, 'label': row['label'],
            'preparedUTC': '2020-01-01T09:30:00Z', 'arguments': args, 'workload': workload, 'freeze': self.freeze_ref})
        observations = self.write(folder + 'process-observations.json', {'invented': 'external work'})
        summary = self.write(folder + 'summary.json', {'schemaVersion': 1, 'label': row['label'],
            'finishedUTC': '2020-01-01T09:30:01Z', 'plan': plan, 'observations': observations,
            'registration': None, 'sampleCount': 2, 'issues': ['Pre-run isolation is not quiet; benchmark was not launched']})
        proof = {'schemaVersion': 1, 'status': 'failed', 'labels': [row['label']], 'intervals': [],
                 'noOverlappingBuildOrInference': False, 'evidence': summary}
        reference = self.write(row['label'] + '-isolation.json', proof)
        return row, proof, reference

    def test_failed_preflight_is_visible_without_fabricating_started_benchmark(self):
        row, _, reference = self.preflight()
        evidence, receipt = self.refresh()
        self.assertEqual(evidence['attemptDiagnostics'][0]['status'], 'failed-before-benchmark')
        self.assertEqual(evidence['attemptDiagnostics'][0]['isolation']['sha256'], reference['sha256'])
        self.assertEqual(receipt['attemptDiagnostics'][0]['benchmarkRegistrationStatus'], 'not-started')
        planned = next(item for item in receipt['plannedWorkloads'] if item['label'] == row['label'])
        self.assertEqual(planned['registeredStatus'], 'not-started')
        self.assertNotIn(row['name'], {item['name'] for item in evidence['runs']})
        self.assertFalse((self.root / (row['label'] + '-registration.json')).exists())
        self.write('baseline-evidence.json', evidence)
        self.assertEqual(self.refresh()[0]['attemptDiagnostics'], evidence['attemptDiagnostics'])

    def test_preflight_proof_cannot_claim_passed_or_an_inference_interval(self):
        for change in ({'status': 'passed'}, {'intervals': [{'label': 'latency-preflight'}]}):
            row, proof, _ = self.preflight()
            self.write(row['label'] + '-isolation.json', dict(proof, **change))
            with self.subTest(change=change), self.assertRaisesRegex(S.BASE.EvidenceError, 'failed admission'):
                self.refresh()

    def test_preflight_changed_plan_settings_or_registration_claim_are_rejected(self):
        for change in ('settings', 'registration'):
            row, proof, _ = self.preflight()
            summary = json.loads((self.root / proof['evidence']['path']).read_text())
            if change == 'settings':
                plan = json.loads((self.root / summary['plan']['path']).read_text())
                plan['arguments']['workers'] = 3
                summary['plan'] = self.write(summary['plan']['path'], plan)
            else:
                summary['registration'] = {'path': 'imaginary.json', 'sha256': 'f' * 64}
            proof['evidence'] = self.write(proof['evidence']['path'], summary)
            self.write(row['label'] + '-isolation.json', proof)
            with self.subTest(change=change), self.assertRaises(S.BASE.EvidenceError):
                self.refresh()

    def test_preflight_artifacts_and_no_registration_state_cannot_be_redefined(self):
        row, proof, _ = self.preflight()
        evidence, _ = self.refresh()
        self.write('baseline-evidence.json', evidence)
        proof['claimScope'] = 'changed after admission'
        self.write(row['label'] + '-isolation.json', proof)
        with self.assertRaisesRegex(S.BASE.EvidenceError, 'changed'):
            self.refresh()
        del proof['claimScope']
        self.write(row['label'] + '-isolation.json', proof)
        self.complete(row, at='09:31')
        with self.assertRaisesRegex(S.BASE.EvidenceError, 'registration/output'):
            self.refresh()


if __name__ == '__main__':
    unittest.main()
