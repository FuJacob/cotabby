import Foundation
import SwiftUI

// This standalone probe reads only one argument-domain preference. It neither
// starts Cotabby nor calls a persistent UserDefaults setter.
let key = "cotabbyMenuBarIconVisible"
let defaults = UserDefaults.standard
let domains = [ProcessInfo.processInfo.processName, "com.cotabby.app"]
let before = domains.map { defaults.persistentDomain(forName: $0) ?? [:] }
struct MenuVisibilityProbe {
    @AppStorage("cotabbyMenuBarIconVisible") var value = true
}
let object = defaults.object(forKey: key)
let argumentObject = defaults.volatileDomain(forName: UserDefaults.argumentDomain)[key]
let viewStorage = MenuVisibilityProbe()
let appStorageValue = viewStorage.value
let after = domains.map { defaults.persistentDomain(forName: $0) ?? [:] }
let result: [String: Any] = [
    "arguments": Array(CommandLine.arguments.dropFirst()),
    "objectPresent": object != nil,
    "objectType": object.map { String(reflecting: type(of: $0)) } ?? "nil",
    "objectAsBool": (object as? Bool).map { String($0) } ?? "nil",
    "settingsStoreFallback": (object as? Bool) ?? true,
    "boolForKey": defaults.bool(forKey: key),
    "argumentDomainPresent": argumentObject != nil,
    "argumentDomainType": argumentObject.map { String(reflecting: type(of: $0)) } ?? "nil",
    "argumentDomainValue": argumentObject.map { String(describing: $0) } ?? "nil",
    "appStorageBoolWrappedValue": appStorageValue,
    "persistentDomainsUnchanged": zip(before, after).allSatisfy { NSDictionary(dictionary: $0).isEqual(to: $1) },
    "persistentKeyPresenceBefore": before.map { $0[key] != nil },
    "persistentKeyPresenceAfter": after.map { $0[key] != nil }
]
let data = try JSONSerialization.data(withJSONObject: result, options: [.sortedKeys, .prettyPrinted])
print(String(decoding: data, as: UTF8.self))
