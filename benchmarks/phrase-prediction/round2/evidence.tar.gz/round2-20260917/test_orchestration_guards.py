"""Synthetic orchestration checks; never launches Xcode or reads protected results."""
import argparse, copy, datetime, hashlib, io, json, subprocess, tempfile, time, types, unittest
from pathlib import Path
from unittest import mock
import run_checks as c
import run_experiment as r

def args(**kw):
 d=dict(label='fake',candidate='baseline',phase='screening',estimated_seconds=0,corpus=None,split='all',mode='word',per_category=None,workers=3,seed=42,reuse_checks=None);d.update(kw);return argparse.Namespace(**d)
def utc(t):return datetime.datetime.fromtimestamp(t,datetime.timezone.utc).isoformat()

class Guards(unittest.TestCase):
 def test_expired_command_never_launches(self):
  with mock.patch.object(c.subprocess,'Popen') as start:
   with self.assertRaises(TimeoutError):c.bounded_command(['fake'],io.StringIO(),deadline=time.time()-1)
   start.assert_not_called()
 def test_inflight_deadline_cleans_group(self):
  proc=mock.Mock(pid=234,returncode=None)
  with mock.patch.object(c.subprocess,'Popen',return_value=proc),mock.patch.object(c.time,'time',side_effect=[0,2]),mock.patch.object(c,'stop_process_group') as stop:
   with self.assertRaises(TimeoutError):c.bounded_command(['fake'],io.StringIO(),deadline=1)
   stop.assert_called_once_with(proc)
 def test_interrupt_cleans_group(self):
  proc=mock.Mock(pid=234,returncode=None);proc.wait.side_effect=KeyboardInterrupt()
  with mock.patch.object(c.subprocess,'Popen',return_value=proc),mock.patch.object(c,'stop_process_group') as stop:
   with self.assertRaises(KeyboardInterrupt):c.bounded_command(['fake'],io.StringIO())
   stop.assert_called_once_with(proc)
 def test_cleanup_escalates_and_reaps(self):
  proc=mock.Mock(pid=234);proc.wait.side_effect=[subprocess.TimeoutExpired('fake',1),subprocess.TimeoutExpired('fake',1),0,0]
  with mock.patch.object(c.os,'killpg') as kill:
   c.stop_process_group(proc)
   self.assertEqual([x.args[1] for x in kill.call_args_list[:3]],[c.signal.SIGINT,c.signal.SIGTERM,c.signal.SIGKILL]);self.assertEqual(proc.wait.call_count,4)
 def test_coverage_needs_actual_and_requested_tests(self):
  required=[c.AUDIT_TEST,'NativeTests/testCache']
  with self.assertRaisesRegex(ValueError,'actually pass'):c.require_test_coverage(required,required,[c.AUDIT_TEST])
  with self.assertRaisesRegex(ValueError,'request'):c.require_test_coverage(required,[c.AUDIT_TEST],required)
  c.require_test_coverage(required,['BaseCompletionPromptRendererTests','NativeTests'],required)
 def test_reuse_rejects_missing_native_execution(self):
  with tempfile.TemporaryDirectory() as folder:
   root=Path(folder);(root/'validation.log').write_text("Test Case '-[CotabbyTests.BaseCompletionPromptRendererTests testRoundTwoScreeningPromptAudit]' passed (0.1 seconds).\n")
   state={'sourceSHA256':'same'};cli=types.SimpleNamespace(build_input_snapshot=lambda _:state)
   evidence={'status':'passed','buildInputs':state,'tests':[c.AUDIT_TEST,'NativeTests/testCache']}
   with self.assertRaisesRegex(ValueError,'actually pass'):r.verify_check_evidence(evidence,evidence['tests'],root,cli)
 def test_replay_binds_full_inputs_fresh_build_model_and_errors(self):
  state={'sourceSHA256':'s','packageLocks':{}};checks={'buildInputs':state}
  report={'metadata':{'configuration':{'modelSHA256':r.ROUND['modelSHA256']}},'errorCount':0}
  manifest={'buildInputs':state,'build':{'sourceSHA256':'s','reused':False}}
  r.verify_completed(report,manifest,checks)
  for case in ('source','build','model','errors'):
   a,b=copy.deepcopy(report),copy.deepcopy(manifest)
   if case=='source':b['buildInputs']['packageLocks']={'new':'lock'}
   if case=='build':b['build']['reused']='false'
   if case=='model':a['metadata']['configuration']['modelSHA256']='wrong'
   if case=='errors':a['errorCount']=1
   with self.subTest(case=case),self.assertRaises(ValueError):r.verify_completed(a,b,checks)
 def test_time_requires_remaining_estimate(self):
  with mock.patch.object(r.time,'time',return_value=50):
   r.check_time(100,49)
   with self.assertRaises(TimeoutError):r.check_time(100,50)
 def test_check_failure_and_unchanged_source_drift_are_registered(self):
  for stage in ('checks','source'):
   with self.subTest(stage=stage),tempfile.TemporaryDirectory() as folder:
    root=Path(folder)
    for name in ('run_checks.py','run_experiment.py'):(root/name).write_text('synthetic')
    native=types.SimpleNamespace(verify=lambda *_:({'variants':{'baseline':{'sha256':'n'}}},'baseline'))
    def load(name,path):return native if 'native' in name else types.SimpleNamespace()
    with mock.patch.object(r,'HERE',root),mock.patch.object(r,'FREEZE',time.time()+3600),mock.patch.object(r,'DEADLINE',time.time()+7200),mock.patch.object(r,'load_module',side_effect=load),mock.patch.object(r.prompt_variants,'verify_current') as current,mock.patch.object(r.run_checks,'run',side_effect=TimeoutError('fake check failure')) as run:
     current.return_value={'components':[],'hashes':{'renderer':'r','composer':'c'}}
     if stage=='source':current.side_effect=ValueError('fake source drift')
     with self.assertRaises((TimeoutError,ValueError)):r.run(args())
     record=json.loads((root/'fake-registration.json').read_text());self.assertEqual(record['status'],'failed-or-interrupted');self.assertIn('finishedUTC',record);self.assertEqual(record['replayWallSeconds'],0);current.assert_called_once()
     if stage=='source':run.assert_not_called()
 def test_resolution_uses_same_deadline_and_restores_cli_adapter(self):
  with tempfile.TemporaryDirectory() as folder:
   root=Path(folder);original=mock.Mock();cli=types.SimpleNamespace(logged_command=original)
   def prepare(*_,**kw):cli.logged_command(['fake-resolve'],root/'checks'/'resolution.log')
   cli.prepare_build_inputs=prepare
   spec=types.SimpleNamespace(loader=types.SimpleNamespace(exec_module=lambda _:None))
   with mock.patch.object(c,'HERE',root),mock.patch.object(c.importlib.util,'spec_from_file_location',return_value=spec),mock.patch.object(c.importlib.util,'module_from_spec',return_value=cli),mock.patch.object(c,'bounded_command',side_effect=TimeoutError('fake resolution timeout')) as command:
    with self.assertRaises(TimeoutError):c.run('checks',[c.AUDIT_TEST],deadline=123)
    self.assertEqual(command.call_args.kwargs['deadline'],123)
    self.assertIs(cli.logged_command,original)
    self.assertEqual(json.loads((root/'checks'/'validation.json').read_text())['status'],'failed-or-interrupted')
 def fixture(self,root):
  corpus=root/'protected.json';corpus.write_text('synthetic only');digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
  def ref(name,data):
   p=root/name;p.write_text(json.dumps(data));return {'path':name,'sha256':digest(p)}
  ready=ref('ready.json',{'status':'pass','readyUTC':utc(time.time()-30),'corpusSHA256':digest(corpus),'corpusPath':str(corpus)});screen=ref('screen.json',{})
  frozen={'schemaVersion':1,'frozenUTC':utc(time.time()-20),'candidate':'H1','components':['H1'],'selectionQualified':True,'modelSHA256':r.ROUND['modelSHA256'],'freshCorpusSHA256':digest(corpus),'criteria':ref('criteria.json',{}),'freshReadiness':ready,'screeningEvidence':screen,'screeningEvidenceSHA256':screen['sha256'],'productionInventories':{'baseline':ref('baseline.json',{}),'finalist':ref('finalist.json',{})},'baselineSourceSHA256':'b','candidateSourceSHA256':'c','baselineTargets':{},'candidateTargets':{}}
  (root/'finalist-freeze.json').write_text(json.dumps(frozen));return corpus,frozen
 def test_fresh_requires_exact_frozen_candidate_corpus_and_selection(self):
  with tempfile.TemporaryDirectory() as folder:
   root=Path(folder);corpus,_=self.fixture(root);round_data=dict(r.ROUND,freshReadinessDeadlineUTC=utc(time.time()+30))
   with mock.patch.object(r,'HERE',root),mock.patch.object(r,'FREEZE',time.time()+30),mock.patch.object(r,'ROUND',round_data):
    a=args(candidate='H1',phase='validation',corpus=corpus);self.assertEqual(r.validation_admission(a,['H1'])['role'],'candidate');self.assertEqual(r.validation_admission(args(phase='validation'),[])['role'],'baseline')
    for change in (dict(candidate='H2'),dict(split='screen'),dict(mode='character'),dict(per_category=1)):
     bad=copy.copy(a)
     for key,value in change.items():setattr(bad,key,value)
     with self.subTest(change=change),self.assertRaises(ValueError):r.validation_admission(bad,bad.candidate.split('+'))
    corpus.write_text('changed synthetic bytes')
    with self.assertRaisesRegex(ValueError,'exact protected'):r.validation_admission(a,['H1'])
 def test_requires_freeze_and_rejects_screen_sidecar(self):
  with tempfile.TemporaryDirectory() as folder,mock.patch.object(r,'HERE',Path(folder)):
   with self.assertRaises(FileNotFoundError):r.validation_admission(args(phase='validation'),[])
   with self.assertRaisesRegex(ValueError,'validation-only'):r.validation_admission(args(corpus=Path(folder)/'fixture.json'),[])

if __name__=='__main__':unittest.main()
