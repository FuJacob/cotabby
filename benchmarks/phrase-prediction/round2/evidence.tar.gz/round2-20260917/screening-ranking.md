# Round-two screening — observed results

| Candidate | Screen correct / 770 | No-screen correct / 770 |
| --- | ---: | ---: |
| M2 | 294 | 225 |
| baseline | 288 | 235 |
| H3 | 288 | 235 |
| H2 | 286 | 235 |
| F1 | 285 | 235 |
| H1 | 284 | 235 |
| F2 | 284 | 235 |
| M4 | 282 | 241 |
| M1 | 281 | 237 |
| H4 | 280 | 236 |
| F3 | 280 | 235 |
| F4 | 274 | 235 |
| M3 | 264 | 210 |

Development screening; this ranking is not protected validation or an adoption decision.
