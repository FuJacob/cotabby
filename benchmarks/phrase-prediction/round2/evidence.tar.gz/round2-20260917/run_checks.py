#!/usr/bin/env python3
"""Build and run narrow checks with recorded source identity before experiment inference.

This is a round-local validation boundary. It neither chooses candidates nor changes product
settings; its temporary xctestrun supplies only explicit test-process inputs and is then removed.
"""
import argparse
import datetime
import importlib.util
import json
import os
from pathlib import Path
import plistlib
import re
import signal
import subprocess
import time
import uuid

HERE = Path(__file__).resolve().parent
EXECUTION = json.loads((HERE / 'execution.json').read_text())
ROOT = Path(EXECUTION['root'])
DERIVED = ROOT / 'build/DerivedData'
AUDIT_TEST = 'BaseCompletionPromptRendererTests/testRoundTwoScreeningPromptAudit'


def stop_process_group(process):
    """Reap only the group created by this invocation, including build/test children."""
    for sig, grace in ((signal.SIGINT, 10), (signal.SIGTERM, 5), (signal.SIGKILL, 3)):
        try:
            os.killpg(process.pid, sig)
        except ProcessLookupError:
            break
        try:
            process.wait(timeout=grace)
        except subprocess.TimeoutExpired:
            continue
        # The leader can exit before its children; kill the remaining owned group too.
        try:
            os.killpg(process.pid, signal.SIGKILL)
        except ProcessLookupError:
            pass
        break
    process.wait(timeout=3)


def bounded_command(command, stream, *, deadline=None, cwd=None):
    """Own the whole child group so a deadline cannot leave an abandoned Xcode host."""
    if deadline is not None and time.time() >= deadline:
        raise TimeoutError('Check/build deadline reached before launch')
    process = subprocess.Popen(list(map(str, command)), cwd=cwd or ROOT, stdout=stream,
                               stderr=subprocess.STDOUT, start_new_session=True)
    try:
        while True:
            remaining = None if deadline is None else deadline - time.time()
            if remaining is not None and remaining <= 0:
                raise TimeoutError('Check/build deadline reached; partial log retained')
            try:
                process.wait(timeout=0.25 if remaining is None else min(0.25, remaining))
                break
            except subprocess.TimeoutExpired:
                pass
        if process.returncode:
            raise subprocess.CalledProcessError(process.returncode, command)
    except BaseException:
        stop_process_group(process)
        raise


def passed_tests(log):
    """Read actual XCTest successes; requested selectors alone do not prove execution."""
    return sorted(set(f'{group}/{method}' for group, method in re.findall(
        r"Test Case '-\[CotabbyTests\.([^ ]+) ([^\]]+)\]' passed", log.read_text(errors='replace'))))


def require_test_coverage(required, recorded, executed):
    def covered(test, choices):
        return test in choices or test.split('/')[0] in choices
    if any(not covered(test, recorded) for test in required):
        raise ValueError('Check evidence does not request every required test')
    for test in required:
        if '/' in test and test not in executed:
            raise ValueError('Required test did not actually pass: ' + test)
        if '/' not in test and not any(value.startswith(test + '/') for value in executed):
            raise ValueError('Required test group did not actually execute: ' + test)


def run(label, tests, *, build=True, deadline=None):
    destination = HERE / label
    destination.mkdir(exist_ok=False)
    spec = importlib.util.spec_from_file_location('round2_cli_checks', ROOT / 'scripts/phrase_eval.py')
    cli = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(cli)
    workspace = Path(EXECUTION['workspace'])
    record = {'label': label, 'startedUTC': datetime.datetime.now(datetime.timezone.utc).isoformat(),
              'tests': tests, 'execution': EXECUTION, 'status': 'started'}
    prepared = None
    original_logged_command = cli.logged_command
    def bounded_logged_command(command, log, progress=None):
        with log.open('x') as stream:
            bounded_command(command, stream, deadline=deadline)
    # Dependency resolution uses the same deadline/child cleanup as compilation. This is
    # an in-process adapter only; the preserved CLI source and its fingerprint stay intact.
    cli.logged_command = bounded_logged_command
    try:
        inputs = cli.prepare_build_inputs(workspace, ['-workspace', workspace], destination, skip_build=not build)
        record['buildInputs'] = inputs
        with (destination / 'validation.log').open('x') as stream:
            if build:
                command = ['xcodebuild', 'build-for-testing', '-workspace', str(workspace),
                    '-scheme', 'Cotabby', '-configuration', 'Release', '-destination', 'platform=macOS',
                    '-derivedDataPath', str(DERIVED), 'CODE_SIGNING_ALLOWED=NO', 'ENABLE_TESTABILITY=YES',
                    'ONLY_ACTIVE_ARCH=YES', 'SWIFT_ACTIVE_COMPILATION_CONDITIONS=$(inherited) RUN_LLAMA_EVAL',
                    '-skipPackageUpdates']
                record['buildCommand'] = command
                bounded_command(command, stream, deadline=deadline)
            if cli.build_input_fingerprint(workspace) != inputs['sourceSHA256']:
                raise ValueError('Source drift during check build')
            candidates = [p for p in (DERIVED / 'Build/Products').glob('Cotabby_*.xctestrun')
                          if 'phrase-eval-' not in p.name]
            source = max(candidates, key=lambda p: p.stat().st_mtime_ns)
            record['productSHA256'] = cli.build_product_fingerprint(source)
            if not build:
                marker = json.loads((DERIVED / 'phrase-eval-build.json').read_text())
                if marker.get('sourceSHA256') != inputs['sourceSHA256'] or marker.get('productSHA256') != record['productSHA256']:
                    raise ValueError('Reused check binary does not match recorded source/product inputs')
            configuration = plistlib.loads(source.read_bytes())
            environment = {'COTABBY_PHRASE_EVAL': '0', 'COTABBY_EVAL_MODEL_PATH': EXECUTION['model'],
                'COTABBY_ROUND2_PROMPT_AUDIT': str(destination / 'prompt-audit.json'),
                'COTABBY_ROUND2_SCREEN_IDS': str(HERE / 'screening-ids.json')}
            if cli.inject_environment(configuration, environment) != 1:
                raise ValueError('Expected one CotabbyTests target')
            prepared = source.parent / ('Cotabby_phrase-eval-round2-check-' + uuid.uuid4().hex + '.xctestrun')
            prepared.write_bytes(plistlib.dumps(configuration))
            command = ['xcodebuild', 'test-without-building', '-xctestrun', str(prepared),
                '-destination', 'platform=macOS', '-derivedDataPath', str(DERIVED),
                '-parallel-testing-enabled', 'NO', '-test-timeouts-enabled', 'NO']
            command += ['-only-testing:CotabbyTests/' + test for test in tests]
            record['testCommand'] = command
            bounded_command(command, stream, deadline=deadline)
            if cli.build_input_fingerprint(workspace) != inputs['sourceSHA256']:
                raise ValueError('Source drift during tests')
            if cli.build_product_fingerprint(source) != record['productSHA256']:
                raise ValueError('Product drift during tests')
            if AUDIT_TEST in tests or 'BaseCompletionPromptRendererTests' in tests:
                data = json.loads((destination / 'prompt-audit.json').read_text())
                if len(data) != 1540:
                    raise ValueError('Prompt audit is missing expected checkpoints')
            record['executedTests'] = passed_tests(destination / 'validation.log')
            require_test_coverage(tests, tests, record['executedTests'])
            record['status'] = 'passed'
    except BaseException as error:
        record.update(status='failed-or-interrupted', error=f'{type(error).__name__}: {error}')
        raise
    finally:
        cli.logged_command = original_logged_command
        if prepared:
            prepared.unlink(missing_ok=True)
        record['finishedUTC'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
        (destination / 'validation.json').write_text(json.dumps(record, indent=2) + '\n')
    print('Checks passed: ' + label, flush=True)
    return record


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('label')
    parser.add_argument('--tests', nargs='+', default=[AUDIT_TEST])
    args = parser.parse_args()
    run(args.label, args.tests)
