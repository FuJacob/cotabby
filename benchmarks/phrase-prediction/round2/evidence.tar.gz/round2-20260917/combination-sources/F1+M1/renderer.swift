import Foundation

/// File overview:
/// Renders the prompt for Cotabby's base-model completion pipeline (the Open Source / llama path).
///
/// Design: a *base* model has no instruction-following channel and will happily continue a bare
/// "Task:" line as if it were the document, so an instruction-blob prompt would leak scaffolding into
/// the ghost text. This renderer treats the model as a pure text continuer: persona, style, language,
/// and supporting context are folded into a short conditioning preface (a base model conditions on
/// description, it does not obey commands), and the exact caret prefix is the LAST thing in the
/// prompt. Spaces, line breaks, and indentation remain part of the text the model continues.
///
/// Sections are character-budgeted via `PromptSectionBudget` so a large glossary, clipboard, or
/// screen capture can never crowd out the caret text: the prefix gets top priority and a guaranteed
/// minimum, and context fills the remaining budget by priority.
enum BaseCompletionPromptRenderer {
    /// Total character budget for the preface plus caret prefix. The prefix arrives already windowed
    /// by `SuggestionRequestFactory`, so this mainly caps how much optional context rides along.
    static let defaultContextBudget = 6400

    static func prompt(
        prefixText: String,
        applicationName: String,
        userName: String?,
        trailingText: String = "",
        maxSuffixCharacters: Int = 192,
        customRules: [String] = [],
        extendedContext: String? = nil,
        languageInstruction: String? = nil,
        clipboardContext: String? = nil,
        visualContextSummary: String? = nil,
        surfaceContext: SurfaceContext? = nil,
        contextBudget: Int = defaultContextBudget,
        maxScreenCharacters: Int = 4000,
        screenPriority: Int = 45,
        tokenBudget: Int? = nil
    ) -> String {
        var sections: [PromptSection] = []
        // The surface description leads the preface: knowing the writing surface (email in Mail,
        // a chat in Slack, a document title) is the strongest situational cue a base model gets,
        // and the composer already omits it for the app classes where metadata would hurt. The
        // value is frozen per field session upstream, so these bytes stay stable across keystrokes
        // and the llama KV prefix reuse keeps amortizing them.
        if let surface = surfaceContext {
            let lines = SurfaceContextComposer.prefaceLines(for: surface)
            if !lines.isEmpty {
                sections.append(
                    Self.contextSection("surface", lines.joined(separator: " "), priority: 70, maxChars: 240)
                )
            }
        }
        if let persona = Self.personaLine(userName) {
            sections.append(Self.contextSection("persona", persona, priority: 60, maxChars: 200))
        }
        if let style = Self.styleLine(customRules) {
            sections.append(Self.contextSection("style", style, priority: 55, maxChars: 300))
        }
        if let language = Self.nonEmpty(languageInstruction) {
            sections.append(Self.contextSection("language", language, priority: 50, maxChars: 300))
        }
        if let notes = Self.nonEmpty(extendedContext) {
            // `maxChars` must stay at or above `SuggestionSettingsModel.maximumExtendedContextCharacters`
            // plus this label (~32 chars) so the full user-entered Extended Context survives here instead
            // of being silently clipped far under the advertised cap. It still competes for the total
            // total budget below (priority 40), so an unusually long prefix can trim it, but in normal use
            // the whole blob lands.
            sections.append(Self.contextSection("notes", "Notes the writer keeps in mind: \(notes)", priority: 40, maxChars: 1300))
        }
        if let clip = Self.nonEmpty(clipboardContext) {
            sections.append(Self.contextSection("clipboard", "On the clipboard: \(clip)", priority: 35, maxChars: 400))
        }
        if let screen = Self.nonEmpty(visualContextSummary) {
            sections.append(Self.contextSection(
                "screen", "Context: \(screen)", priority: screenPriority, maxChars: maxScreenCharacters
            ))
        }
        let followingText = String(trailingText.prefix(max(0, maxSuffixCharacters)))
        if !followingText.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
            // Base models do not share a universal fill-in-the-middle token format. Describe the
            // existing ending as quoted reference material, then leave the actual caret prefix
            // last. Keep this changing field context after the stable preface to retain cache reuse.
            // The whole bounded section is optional: dropping it under pressure keeps the quote
            // delimiters intact and prevents an unfinished label from becoming completion text.
            let followingSection = "Later in the same passage:\n“\(followingText)”"
            sections.append(PromptSection(
                name: "following",
                content: followingSection,
                priority: 80,
                minChars: followingSection.count,
                maxChars: followingSection.count,
                truncation: .preserveStart,
                preservesWhitespace: true
            ))
        }
        // The caret prefix: top priority so it is never starved, kept by its END (the text nearest
        // the caret), and rendered last with no label so the model continues from where the user
        // stopped. `applicationName` is intentionally not stated; app/window metadata biases a base
        // model toward code/numbers over prose.
        sections.append(
            PromptSection(
                name: "prefix",
                content: prefixText,
                priority: 100,
                minChars: 1,
                maxChars: max(1, prefixText.count),
                truncation: .preserveEnd,
                preservesWhitespace: true
            )
        )

        // Token-aware budgeting (opt-in): when a token budget is supplied, fill sections against an
        // estimated-token window instead of the character approximation. Defaults to the character
        // path so shipped behavior is unchanged.
        let kept: [PromptSection]
        if let tokenBudget {
            kept = PromptSectionBudget.allocate(
                sections,
                totalTokens: tokenBudget,
                estimate: TokenCountEstimator.estimate
            )
        } else {
            kept = PromptSectionBudget.allocate(sections, totalChars: contextBudget)
        }
        let prefix = kept.first { $0.name == "prefix" }?.content ?? ""
        let preface = kept.filter { $0.name != "prefix" }.map(\.content)

        guard !preface.isEmpty else {
            // No context to condition on: hand the model the bare text and let it continue.
            return prefix
        }
        // A blank line separates the conditioning preface from the live text without a label the
        // model could copy. The prefix remains the final bytes of the prompt.
        return preface.joined(separator: "\n") + "\n\n" + prefix
    }

    private static func contextSection(
        _ name: String,
        _ content: String,
        priority: Int,
        maxChars: Int
    ) -> PromptSection {
        PromptSection(name: name, content: content, priority: priority, minChars: 0, maxChars: maxChars, truncation: .preserveStart)
    }

    /// "Written by <name>." or nil. Conditions the voice via authorship framing.
    private static func personaLine(_ userName: String?) -> String? {
        guard let name = Self.nonEmpty(userName) else { return nil }
        return "Written by \(name)."
    }

    /// "Writing style: <rules>." or nil. Rendered as its own line rather than jammed into an
    /// "in a <rules> style" clause, so multi-word and sentence-shaped rules read correctly and
    /// condition cleanly (the old clause produced broken prose like "in a Use British spelling style").
    private static func styleLine(_ customRules: [String]) -> String? {
        let rules = customRules
            .map { $0.trimmingCharacters(in: .whitespacesAndNewlines) }
            .filter { !$0.isEmpty }
        guard !rules.isEmpty else { return nil }
        return "Writing style: \(rules.joined(separator: ", "))."
    }

    private static func nonEmpty(_ text: String?) -> String? {
        let trimmed = (text ?? "").trimmingCharacters(in: .whitespacesAndNewlines)
        return trimmed.isEmpty ? nil : trimmed
    }
}
