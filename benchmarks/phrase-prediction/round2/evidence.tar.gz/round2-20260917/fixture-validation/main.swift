import Foundation

// This executable compiles the benchmark's actual pure scorer/fixture contract. It only
// emits aggregate counts, keeping the protected references away from candidate selection.
let url = URL(fileURLWithPath: CommandLine.arguments[1])
let data = try Data(contentsOf: url)
let corpus = try JSONDecoder().decode(PhrasePredictionCorpus.self, from: data)
try corpus.validate()
let counts = Dictionary(grouping: corpus.phrases, by: \.category).mapValues(\.count)
let families = Set(corpus.phrases.compactMap(\.evaluationGroup))
let wordCheckpoints = corpus.phrases.reduce(0) { count, phrase in
    count + PhrasePredictionScorer.checkpoints(for: phrase, mode: .word).count
}
let summary: [String: Any] = [
    "status": "pass", "version": corpus.version, "phrases": corpus.phrases.count,
    "families": families.count, "categoryCounts": counts,
    "wordCheckpointsPerCondition": wordCheckpoints
]
let result = try JSONSerialization.data(withJSONObject: summary, options: [.prettyPrinted, .sortedKeys])
FileHandle.standardOutput.write(result)
FileHandle.standardOutput.write(Data("\n".utf8))
