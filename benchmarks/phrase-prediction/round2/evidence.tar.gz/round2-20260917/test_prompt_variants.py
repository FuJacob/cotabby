"""Exercise transitions only in disposable fixture trees; never touch the app snapshot."""
import importlib.util
import json
from pathlib import Path
import shutil
import tempfile
import unittest
from unittest.mock import patch

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('prompt_variants_test_subject', HERE / 'prompt_variants.py')
subject = importlib.util.module_from_spec(spec)
spec.loader.exec_module(subject)


class PromptTransitionTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name) / 'app'
        self.here = Path(self.temp.name) / 'round'
        self.here.mkdir()
        self.originals = {key: (HERE / 'prompt-sources/baseline' / (key + '.swift')).read_bytes()
                          for key in subject.PATHS}
        for key, relative in subject.PATHS.items():
            path = self.root / relative
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(self.originals[key])
        for name, value in [('ROOT', self.root), ('HERE', self.here)]:
            patcher = patch.object(subject, name, value)
            patcher.start()
            self.addCleanup(patcher.stop)
        subject.freeze()
        subject.freeze_combinations()
        self.initial_record = (self.here / 'applied-prompt.json').read_bytes()

    def assert_baseline_restored(self):
        self.assertEqual(subject.verify_current()['components'], [])
        self.assertEqual((self.here / 'applied-prompt.json').read_bytes(), self.initial_record)
        for key, relative in subject.PATHS.items():
            self.assertEqual((self.root / relative).read_bytes(), self.originals[key])

    def test_single_and_combination_apply_frozen_bytes_without_codegen(self):
        with patch.object(subject, 'transformed', side_effect=AssertionError('No runtime code generation')):
            subject.apply(['F1'])
            subject.apply(['M3', 'F4'])
        record = subject.verify_current()
        self.assertEqual(record['components'], ['F4', 'M3'])
        for key, relative in subject.PATHS.items():
            expected = (self.here / 'combination-sources/F4+M3' / (key + '.swift')).read_bytes()
            self.assertEqual((self.root / relative).read_bytes(), expected)
        self.assertEqual(subject.active_transition()[1]['state'], 'committed')

    def test_all_registered_combinations_are_exact_independent_components(self):
        catalog = subject.frozen_catalog()
        self.assertEqual(len(catalog), 25)
        for f in ('F1', 'F2', 'F3', 'F4'):
            for m in ('M1', 'M2', 'M3', 'M4'):
                self.assertEqual(catalog[(f, m)]['renderer'], catalog[(f,)]['renderer'])
                self.assertEqual(catalog[(f, m)]['composer'], catalog[(m,)]['composer'])

    def test_second_source_write_failure_rolls_back_and_reports_failure(self):
        original = subject.atomic_write
        fail_path = self.root / subject.PATHS['composer']
        failed = False
        def fail_once(path, data):
            nonlocal failed
            if path == fail_path and not failed:
                failed = True
                raise OSError('second source write failed')
            original(path, data)
        with patch.object(subject, 'atomic_write', side_effect=fail_once):
            with self.assertRaisesRegex(RuntimeError, 'rolled_back'):
                subject.apply(['F1', 'M1'])
        self.assert_baseline_restored()
        self.assertEqual(subject.active_transition()[1]['state'], 'rolled_back')
        subject.apply(['F2'])  # A clean later transition is allowed after confirmed rollback.

    def test_state_record_write_failure_rolls_back_both_sources(self):
        original = subject.atomic_write
        failed = False
        def fail_once(path, data):
            nonlocal failed
            if path == self.here / 'applied-prompt.json' and not failed:
                failed = True
                raise OSError('state record write failed')
            original(path, data)
        with patch.object(subject, 'atomic_write', side_effect=fail_once):
            with self.assertRaisesRegex(RuntimeError, 'rolled_back'):
                subject.apply(['F2', 'M2'])
        self.assert_baseline_restored()

    def test_progress_journal_failure_rolls_back(self):
        original = subject.save_journal
        failed = False
        def fail_once(path, journal):
            nonlocal failed
            if journal['state'] == 'applying' and not failed:
                failed = True
                raise OSError('progress journal write failed')
            original(path, journal)
        with patch.object(subject, 'save_journal', side_effect=fail_once):
            with self.assertRaisesRegex(RuntimeError, 'rolled_back'):
                subject.apply(['F1', 'M4'])
        self.assert_baseline_restored()

    def test_commit_journal_failure_rolls_back_sources_and_record(self):
        original = subject.save_journal
        def fail_commit(path, journal):
            if journal['state'] == 'committed':
                raise OSError('commit marker failed')
            original(path, journal)
        with patch.object(subject, 'save_journal', side_effect=fail_commit):
            with self.assertRaisesRegex(RuntimeError, 'rolled_back'):
                subject.apply(['F3', 'M3'])
        self.assert_baseline_restored()

    def test_repeated_journal_failure_leaves_explicit_recovery_path(self):
        original = subject.save_journal
        def fail_after_prepared(path, journal):
            if journal['state'] != 'prepared':
                raise OSError('journal unavailable')
            original(path, journal)
        with patch.object(subject, 'save_journal', side_effect=fail_after_prepared):
            with self.assertRaises(RuntimeError):
                subject.apply(['F1', 'M1'])
        self.assert_baseline_restored()
        self.assertEqual(subject.active_transition()[1]['state'], 'prepared')
        with self.assertRaisesRegex(ValueError, 'Unfinished'):
            subject.apply(['F2'])
        self.assertEqual(subject.recover()['state'], 'recovered')
        subject.apply(['F2'])

    def test_post_replace_failure_still_rolls_back_actual_bytes(self):
        original = subject.atomic_write
        failed = False
        def fail_after_replace(path, data):
            nonlocal failed
            original(path, data)
            if path == self.root / subject.PATHS['renderer'] and not failed:
                failed = True
                raise OSError('failure after successful replace')
        with patch.object(subject, 'atomic_write', side_effect=fail_after_replace):
            with self.assertRaisesRegex(RuntimeError, 'rolled_back'):
                subject.apply(['F4', 'M4'])
        self.assert_baseline_restored()

    def test_rollback_failure_blocks_apply_until_recover(self):
        original = subject.atomic_write
        def fail_composer_and_rollback(path, data):
            if path == self.root / subject.PATHS['composer']:
                raise OSError('second source write failed')
            if path == self.root / subject.PATHS['renderer'] and data == self.originals['renderer']:
                raise OSError('rollback write failed')
            original(path, data)
        with patch.object(subject, 'atomic_write', side_effect=fail_composer_and_rollback):
            with self.assertRaisesRegex(RuntimeError, 'recovery_required'):
                subject.apply(['F1', 'M1'])
        self.assertEqual(subject.active_transition()[1]['state'], 'recovery_required')
        with self.assertRaisesRegex(ValueError, 'Unfinished'):
            subject.apply([])
        subject.recover()
        self.assert_baseline_restored()

    def test_unknown_external_edit_is_not_overwritten_during_rollback(self):
        original = subject.atomic_write
        foreign = b'// unrelated external edit\n'
        def fail_with_external_edit(path, data):
            if path == self.root / subject.PATHS['composer']:
                (self.root / subject.PATHS['renderer']).write_bytes(foreign)
                raise OSError('external mutation during transition')
            original(path, data)
        with patch.object(subject, 'atomic_write', side_effect=fail_with_external_edit):
            with self.assertRaisesRegex(RuntimeError, 'recovery_required'):
                subject.apply(['F2', 'M2'])
        with self.assertRaisesRegex(RuntimeError, 'Unknown current source bytes'):
            subject.recover()
        self.assertEqual((self.root / subject.PATHS['renderer']).read_bytes(), foreign)

    def test_unknown_current_source_or_record_is_rejected_before_transition(self):
        path = self.root / subject.PATHS['renderer']
        path.write_bytes(b'// external edit\n')
        with self.assertRaisesRegex(ValueError, 'Unexpected source'):
            subject.apply(['F1'])
        self.assertFalse((self.here / 'active-prompt-transition.json').exists())
        path.write_bytes(self.originals['renderer'])
        record = json.loads(self.initial_record)
        record['hashes']['renderer'] = '0' * 64
        (self.here / 'applied-prompt.json').write_text(json.dumps(record))
        with self.assertRaisesRegex(ValueError, 'not a recognized frozen'):
            subject.apply(['F1'])

    def test_frozen_single_or_combo_hash_tamper_is_rejected(self):
        for relative in ('prompt-sources/F1/renderer.swift', 'combination-sources/F2+M2/composer.swift'):
            with self.subTest(relative=relative):
                path = self.here / relative
                original = path.read_bytes()
                path.write_bytes(original + b'\n// tamper\n')
                with self.assertRaisesRegex(ValueError, 'Frozen prompt bytes changed'):
                    subject.apply(['M1'])
                path.write_bytes(original)
        self.assert_baseline_restored()

    def test_invalid_component_lists_rejected(self):
        for components in (['F1', 'F2'], ['M1', 'M2'], ['F1', 'F1'], ['H1'], ['unknown']):
            with self.subTest(components=components), self.assertRaises(ValueError):
                subject.apply(components)
        self.assert_baseline_restored()

    def test_foreign_recovery_journal_does_not_restore_sources(self):
        subject.apply(['F1'])
        before = subject.current_hashes()
        path, journal = subject.active_transition()
        journal['state'] = 'prepared'
        journal['root'] = str(self.root.parent / 'other-app')
        subject.save_journal(path, journal)
        with self.assertRaisesRegex(RuntimeError, 'another checkout'):
            subject.recover()
        self.assertEqual(subject.current_hashes(), before)

    def test_combo_freeze_rejects_changed_transform_before_creating_sources(self):
        shutil.rmtree(self.here / 'combination-sources')
        with patch.object(subject, 'transformed', side_effect=lambda baseline, _: dict(baseline)):
            with self.assertRaisesRegex(ValueError, 'no longer matches frozen single'):
                subject.freeze_combinations()
        self.assertFalse((self.here / 'combination-sources').exists())


if __name__ == '__main__':
    unittest.main()
