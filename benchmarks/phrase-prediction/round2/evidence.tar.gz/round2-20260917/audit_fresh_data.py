#!/usr/bin/env python3
"""Audit fixture identity/overlap while emitting aggregates only to candidate selection.

The independent author sees and reviews text. This mechanical boundary can compare old/new
files without printing fresh reference examples or inviting output-based dataset revisions.
"""
import collections
import datetime
import hashlib
import json
from pathlib import Path
import re
import unicodedata

HERE = Path(__file__).resolve().parent
EXECUTION = json.loads((HERE / 'execution.json').read_text())
SOURCE = HERE / 'fresh-data/corpus.json'
OLD = Path(EXECUTION['root']) / 'CotabbyTests/Fixtures/phrase-prediction-1337.json'


def words(value):
    value = unicodedata.normalize('NFC', value).casefold().replace('’', "'")
    return re.findall(r"[^\W_]+(?:['\-][^\W_]+)*", value)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def main():
    raw = SOURCE.read_bytes()
    data = json.loads(raw)
    phrases = data['phrases']
    old_raw = OLD.read_bytes()
    old = json.loads(old_raw)['phrases']
    folded_old = {' '.join(words(p['text'])) for p in old}
    folded_new = [' '.join(words(p['text'])) for p in phrases]
    categories = collections.Counter(p['category'] for p in phrases)
    contexts = collections.Counter(p['contextKind'] for p in phrases)
    groups = collections.defaultdict(list)
    for phrase in phrases:
        groups[phrase['evaluationGroup']].append(phrase)
    assert data['version'] == 3 and data['language'] == 'en'
    assert len(phrases) == 700 and set(categories.values()) == {100} and len(categories) == 7
    assert len(groups) >= 140
    assert len(set(p['id'] for p in phrases)) == len(phrases)
    assert len(set(folded_new)) == len(phrases)
    assert not set(folded_new).intersection(folded_old), 'Exact old/new reference overlap'
    assert set(contexts) == {'useful','distracting','neutral'}
    assert min(contexts.values()) >= 140, 'Context conditions are inadequately represented'
    group_categories = collections.Counter()
    for family in groups.values():
        assert len(set(p['category'] for p in family)) == 1
        assert len(set(p['contextKind'] for p in family)) == 1
        group_categories[family[0]['category']] += 1
    assert min(group_categories.values()) >= 20
    for phrase, answer in zip(phrases, folded_new):
        scene = phrase['scenario']
        assert 3 <= len(words(phrase['text'])) <= 45
        assert 40 <= len(scene['screenText']) <= 4000
        assert scene['documentPrefix'] and scene['documentPrefix'][-1].isspace()
        context = ' '.join(words(scene['screenText'] + ' ' + scene['documentPrefix']))
        assert answer not in context, 'Complete reference appears in context'
    old_5grams = set()
    for phrase in old:
        sequence = words(phrase['text'])
        old_5grams.update(tuple(sequence[i:i+5]) for i in range(len(sequence)-4))
    overlap = 0
    for phrase in phrases:
        sequence = words(phrase['text'])
        overlap += any(tuple(sequence[i:i+5]) in old_5grams for i in range(len(sequence)-4))
    result = {'status':'pass', 'checkedUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),
              'corpusSHA256':sha(raw), 'oldCorpusSHA256':sha(old_raw), 'phraseCount':len(phrases),
              'categoryCounts':dict(sorted(categories.items())), 'contextCounts':dict(sorted(contexts.items())),
              'familyCount':len(groups), 'familyCountsByCategory':dict(sorted(group_categories.items())),
              'familySizeCounts':dict(collections.Counter(len(x) for x in groups.values())),
              'exactReferenceOverlapWithOld':0, 'referencesSharingAnyOldFiveWordSequence':overlap,
              'screenCharacterRange':[min(len(p['scenario']['screenText']) for p in phrases), max(len(p['scenario']['screenText']) for p in phrases)],
              'prefixCharacterRange':[min(len(p['scenario']['documentPrefix']) for p in phrases), max(len(p['scenario']['documentPrefix']) for p in phrases)],
              'referenceWordRange':[min(len(words(p['text'])) for p in phrases), max(len(words(p['text'])) for p in phrases)],
              'limits':'Structural and exact-overlap checks do not establish semantic independence or human writing quality; authored source families define bootstrap clusters.',
              'helperSHA256':sha(Path(__file__).read_bytes())}
    assert SOURCE.read_bytes() == raw, 'Fresh data changed during audit'
    (HERE / 'fresh-data-root-audit.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))


if __name__ == '__main__':
    main()
