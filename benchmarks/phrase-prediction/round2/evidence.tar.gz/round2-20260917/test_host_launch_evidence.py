"""Invented launch-plan artifacts only; no wrapper execution or app/model access."""
import copy
import importlib.util
import json
from pathlib import Path
import tempfile
import unittest

HERE = Path(__file__).resolve().parent
SPEC = importlib.util.spec_from_file_location('host_evidence_subject', HERE / 'characterize_baseline.py')
M = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(M)


class HostEvidenceTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix='host-evidence-unit-')
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name).resolve()
        self.reader = M.BaselineCharacterization(self.root)
        original = self.write('app/scripts/phrase_eval.py', 'invented frozen source')
        wrapper = self.write('phrase_eval_hidden_host.py', 'invented wrapper source')
        self.write('execution.json', {'root': str(self.root / 'app')})
        self.frozen = {'candidate': 'baseline', 'selectionQualified': False, 'frozenUTC': '2020-01-01T09:00:00Z',
                       'validationHarnessHashes': {'app/scripts/phrase_eval.py': original['sha256']}}
        self.reader.frozen = self.frozen
        freeze = self.write('finalist-freeze.json', self.frozen)
        self.plan = {'schemaVersion': 1, 'status': 'registered', 'candidate': 'baseline', 'target': 'CotabbyTests',
            'commandLineArguments': ['-cotabbyMenuBarIconVisible', 'NO'], 'persistentPreferenceWrites': False,
            'sourceOrBinaryChanges': False, 'registeredUTC': '2020-01-01T09:01:00Z', 'freezeSHA256': freeze['sha256'],
            'wrapper': wrapper, 'originalCLI': original}
        plan_ref = self.write('host-launch-plan.json', self.plan)
        self.admission = {key: self.plan[key] for key in ['wrapper', 'originalCLI', 'commandLineArguments', 'freezeSHA256', 'registeredUTC']}
        self.admission['plan'] = plan_ref
        self.forwarded = ['run', '--label', 'test', '--output', str(self.root / 'test'), '--seed', '42']
        self.command = ['python3', wrapper['path'], '--launch-plan', plan_ref['path'], '--launch-plan-sha256', plan_ref['sha256'], '--', *self.forwarded]
        self.sidecar = {'schemaVersion': 1, 'status': 'passed', 'label': 'test', 'launchAdmission': self.admission,
            'forwardedArguments': self.forwarded, 'output': str(self.root / 'test'), 'persistentPreferenceWrites': False,
            'startedUTC': '2020-01-01T09:03:01Z', 'finishedUTC': '2020-01-01T09:03:09Z',
            'mutations': [{'target': 'CotabbyTests', 'argumentsBefore': [], 'argumentsAfter': self.plan['commandLineArguments'],
                'configurationBeforeSHA256': 'a' * 64, 'configurationAfterSHA256': 'b' * 64, 'onlyCommandLineArgumentsChanged': True}]}
        sidecar_ref = self.write('test-host-launch.json', self.sidecar)
        self.registration = {'label': 'test', 'candidate': 'baseline', 'phase': 'validation', 'status': 'complete',
            'hostLaunch': self.admission, 'hostLaunchEvidence': sidecar_ref, 'command': self.command,
            'startedUTC': '2020-01-01T09:02:00Z', 'inferenceStartedUTC': '2020-01-01T09:03:00Z',
            'finishedUTC': '2020-01-01T09:03:10Z'}

    def write(self, name, value):
        path = self.root / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(value if isinstance(value, str) else json.dumps(value, sort_keys=True))
        return {'path': str(path), 'sha256': M.BASE.digest(path.read_bytes())}

    def check(self, registration=None):
        reader = M.BaselineCharacterization(self.root)
        reader.frozen = self.frozen
        return reader.validate_host_launch(registration or self.registration)

    def test_legacy_run_remains_valid_and_exact_new_chain_is_bound(self):
        self.assertIsNone(self.check({'candidate': 'baseline'}))
        result = self.check()
        self.assertEqual(result['commandLineArguments'], ['-cotabbyMenuBarIconVisible', 'NO'])
        self.assertEqual(result['evidence'], self.registration['hostLaunchEvidence'])

    def test_tampered_plan_wrapper_cli_or_sidecar_is_rejected(self):
        for name in ['host-launch-plan.json', 'phrase_eval_hidden_host.py', 'app/scripts/phrase_eval.py', 'test-host-launch.json']:
            path = self.root / name
            before = path.read_bytes()
            path.write_bytes(before + b' ')
            with self.subTest(name=name), self.assertRaisesRegex(M.EvidenceError, 'changed'):
                self.check()
            path.write_bytes(before)

    def test_forwarded_command_candidate_and_late_registration_are_rejected(self):
        for mutation in ['forwarded', 'candidate', 'late']:
            registration = copy.deepcopy(self.registration)
            if mutation == 'forwarded':
                registration['command'][-1] = '1337'
            elif mutation == 'candidate':
                registration['candidate'] = 'F1'
            else:
                registration['startedUTC'] = '2020-01-01T09:00:30Z'
            with self.subTest(mutation=mutation), self.assertRaises(M.EvidenceError):
                self.check(registration)

    def test_failed_or_extra_mutation_and_wrong_pair_are_rejected(self):
        for mutation in ['failed', 'twice', 'pair', 'hash', 'interval']:
            sidecar = copy.deepcopy(self.sidecar)
            if mutation == 'failed': sidecar['status'] = 'failed'
            elif mutation == 'twice': sidecar['mutations'] *= 2
            elif mutation == 'pair': sidecar['mutations'][0]['argumentsAfter'] = ['-unrelated', 'YES']
            elif mutation == 'hash': sidecar['mutations'][0]['configurationAfterSHA256'] = 'a' * 64
            else: sidecar['finishedUTC'] = '2020-01-01T10:00:00Z'
            registration = dict(self.registration, hostLaunchEvidence=self.write('test-host-launch.json', sidecar))
            with self.subTest(mutation=mutation), self.assertRaises(M.EvidenceError):
                self.check(registration)

    def test_orphan_proof_and_other_sidecar_path_are_rejected(self):
        orphan = dict(self.registration)
        del orphan['hostLaunch']
        with self.assertRaisesRegex(M.EvidenceError, 'lacks'):
            self.check(orphan)
        registration = dict(self.registration, hostLaunchEvidence=self.write('other-host-launch.json', self.sidecar))
        with self.assertRaisesRegex(M.EvidenceError, 'exact label'):
            self.check(registration)

    def coherent_plan_change(self, plan):
        plan_ref = self.write('host-launch-plan.json', plan)
        admission = {key: plan[key] for key in ['wrapper', 'originalCLI', 'commandLineArguments', 'freezeSHA256', 'registeredUTC']}
        admission['plan'] = plan_ref
        command = ['python3', plan['wrapper']['path'], '--launch-plan', plan_ref['path'],
                   '--launch-plan-sha256', plan_ref['sha256'], '--', *self.forwarded]
        sidecar = dict(self.sidecar, launchAdmission=admission)
        return dict(self.registration, hostLaunch=admission, command=command,
                    hostLaunchEvidence=self.write('test-host-launch.json', sidecar))

    def test_hash_consistent_plan_cannot_broaden_mutation_scope(self):
        for change in [{'persistentPreferenceWrites': True}, {'sourceOrBinaryChanges': True},
                       {'target': 'OtherTests'}, {'commandLineArguments': ['-cotabbyMenuBarIconVisible', 'YES']}]:
            registration = self.coherent_plan_change(dict(self.plan, **change))
            with self.subTest(change=change), self.assertRaisesRegex(M.EvidenceError, 'UI scope'):
                self.check(registration)

    def test_equal_source_bytes_at_unapproved_paths_are_rejected(self):
        for key in ['wrapper', 'originalCLI']:
            plan = copy.deepcopy(self.plan)
            source = Path(plan[key]['path']).read_text()
            plan[key] = self.write('other-' + key + '.py', source)
            registration = self.coherent_plan_change(plan)
            with self.subTest(key=key), self.assertRaisesRegex(M.EvidenceError, 'path/hash'):
                self.check(registration)


if __name__ == '__main__':
    unittest.main()
