#!/usr/bin/env python3
"""Compile the actual pure Swift scorer and preserve opaque cohort-completeness plans."""
import datetime
import hashlib
import json
from pathlib import Path
import subprocess

HERE = Path(__file__).resolve().parent
EXECUTION = json.loads((HERE / 'execution.json').read_text())
ROOT = Path(EXECUTION['root'])
DESTINATION = HERE / 'checkpoint-manifests'


def reference(path):
    return {'path': str(path), 'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}


def main():
    proof = HERE / 'checkpoint-exporter.json'
    if proof.exists():
        raise ValueError('Existing exporter provenance must not be overwritten')
    scorer = ROOT / 'CotabbyTests/Evals/PhrasePredictionScoring.swift'
    helper, binary = DESTINATION / 'main.swift', DESTINATION / 'export-checkpoints'
    old = ROOT / 'CotabbyTests/Fixtures/phrase-prediction-1337.json'
    fresh = HERE / 'protected-fresh/corpus.json'
    plans = [
        ('old-word-all', old, 'word', 0, []),
        ('old-word-screen', old, 'word', 0, [str(HERE / 'screening-ids.json')]),
        ('old-character-50', old, 'character', 50, []),
        ('old-character-150', old, 'character', 150, []),
        ('old-character-all', old, 'character', 0, []),
        ('fresh-word-all', fresh, 'word', 0, []),
        ('fresh-character-all', fresh, 'character', 0, []),
    ]
    if any((DESTINATION / (name + '.json')).exists() for name, *_ in plans):
        raise ValueError('Refusing to overwrite an existing checkpoint plan')
    compiler = subprocess.check_output(['xcrun', 'swiftc', '--version'], text=True, timeout=30)
    command = ['xcrun', 'swiftc', '-O', '-module-cache-path',
               str(ROOT / 'build/DerivedData/ModuleCache.noindex'), str(scorer), str(helper), '-o', str(binary)]
    before = {'scorerSource': reference(scorer), 'helperSource': reference(helper)}
    with (DESTINATION / 'compile.log').open('x') as stream:
        subprocess.run(command, cwd=ROOT, stdout=stream, stderr=subprocess.STDOUT, check=True, timeout=120)
    manifests, counts = [], {}
    for name, corpus, mode, limit, extra in plans:
        output = DESTINATION / (name + '.json')
        subprocess.run([str(binary), str(corpus), mode, str(limit), str(output), str(scorer), *extra],
                       cwd=ROOT, check=True, timeout=30)
        data = json.loads(output.read_text())
        if data['scorerSourceSHA256'] != before['scorerSource']['sha256']:
            raise ValueError('Checkpoint plan used a changed scorer')
        manifests.append(reference(output))
        counts[name] = {'phrases': data['phraseCount'], 'checkpointsPerCondition': data['checkpointsPerCondition']}
    if before != {'scorerSource': reference(scorer), 'helperSource': reference(helper)}:
        raise ValueError('Exporter source changed while generating plans')
    record = {'schemaVersion': 1, 'status': 'passed',
              'generatedUTC': datetime.datetime.now(datetime.timezone.utc).isoformat(),
              **before, 'binary': reference(binary), 'compilerVersion': compiler,
              'compilerCommand': command, 'manifests': manifests, 'counts': counts}
    proof.write_text(json.dumps(record, indent=2) + '\n')
    print(json.dumps(counts, indent=2))


if __name__ == '__main__':
    main()
