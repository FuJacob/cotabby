#!/usr/bin/env python3
"""Assess the registered frozen finalist from complete, hash-bound evidence.

No model execution and no lexical rescoring. Swift observation flags are authoritative.
Fresh reports/fixtures are opened only after the finalist-freeze record is validated.
Only aggregates, identities, gate outcomes, and explicit limitations are emitted.
"""
from __future__ import annotations

import argparse
import collections
import datetime as dt
from fractions import Fraction
import hashlib
import importlib.util
import json
import math
from pathlib import Path
import re
import sys

HERE = Path(__file__).resolve().parent
CATEGORIES = {'conversation', 'science', 'entertainment', 'work', 'technology', 'everyday', 'travel'}
CONDITIONS = {'none', 'screen'}
KINDS = {'useful', 'distracting', 'neutral'}
TARGETS = {'renderer', 'composer', 'nativeEngine'}
NATIVE_TESTS = (
    'testSampledRestoredRequestResetsRandomStreamAndRepetitionHistory',
    'testSampledEditedPromptMatchesFreshStateAfterDiscardedGeneration',
    'testSampledHistorySensitiveMidwordEditsMatchFreshState',
    'testHealingStreamsOnlyValidCumulativeContinuation',
    'testCancelledRetainedTailCanBeRestoredByNextRequest',
)
FINAL_TEST_SUITES = ('SurfaceContextComposerTests', 'BaseCompletionPromptRendererTests',
                     'SuggestionRequestFactoryTests', 'PhrasePredictionScoringTests',
                     'PhrasePredictionScreenContextTests')


class EvidenceError(ValueError):
    pass


def require(condition, message):
    if not condition:
        raise EvidenceError(message)


def digest(data):
    return hashlib.sha256(data).hexdigest()


def is_hash(value):
    return isinstance(value, str) and re.fullmatch('[0-9a-f]{64}', value) is not None


def timestamp(value):
    result = dt.datetime.fromisoformat(value.replace('Z', '+00:00'))
    require(result.tzinfo is not None, 'Evidence timestamp requires a timezone')
    return result


def normalize_object(value):
    # Codable omits nil optional properties. This normalization does not remove
    # unknown fields, alter strings, or reinterpret any reference/score.
    if isinstance(value, dict):
        return {key: normalize_object(item) for key, item in value.items() if item is not None}
    if isinstance(value, list):
        return [normalize_object(item) for item in value]
    return value


def counts(observations):
    return {'checkpoints': len(observations), 'correct': sum(o['correct'] for o in observations),
            'shown': sum(o['wasShown'] for o in observations),
            'errors': sum(o.get('error') is not None for o in observations)}


def ratio(numerator, denominator):
    return numerator / denominator if denominator else None


def percentile(values, probability):
    if not values:
        return None
    values = sorted(values)
    return values[max(0, math.ceil(len(values) * probability) - 1)]


def metrics(observations):
    result = counts(observations)
    result.update(accuracy=ratio(result['correct'], result['checkpoints']),
                  coverage=ratio(result['shown'], result['checkpoints']),
                  precisionWhenShown=ratio(result['correct'], result['shown']))
    latencies = [o['latencyMilliseconds'] for o in observations
                 if o.get('suppression') != 'pre-generation-gate' and o.get('error') is None]
    result.update(latencyP50Milliseconds=percentile(latencies, .5),
                  latencyP95Milliseconds=percentile(latencies, .95))
    return result


def check_metrics(actual, observations):
    expected = metrics(observations)
    for key, value in expected.items():
        observed = actual.get(key)
        if key in ('checkpoints', 'correct', 'shown', 'errors'):
            require(type(observed) is int and observed == value, 'Metric count differs from authoritative Swift flags: ' + key)
        elif value is None:
            require(observed is None, 'Empty-denominator metric is not null: ' + key)
        else:
            require(type(observed) in (int, float) and math.isfinite(observed)
                    and math.isclose(observed, value, abs_tol=1e-10, rel_tol=1e-10),
                    'Metric differs from authoritative flags or latency samples: ' + key)


def validate_checkpoint_manifest(manifest):
    require(manifest.get('schemaVersion') == 1, 'Unsupported checkpoint manifest')
    require(is_hash(manifest.get('corpusSHA256')) and is_hash(manifest.get('scorerSourceSHA256')),
            'Checkpoint manifest lacks corpus/scorer fingerprints')
    require(manifest.get('mode') in ('word', 'character'), 'Unsupported checkpoint mode')
    indexed = {}
    for row in manifest['phrases']:
        identifier = row['phraseID']
        require(isinstance(identifier, str) and identifier and identifier not in indexed, 'Duplicate/invalid checkpoint phrase identity')
        require(row['category'] in CATEGORIES, 'Unknown checkpoint category')
        keys = [(p['wordIndex'], p['typedCharacters']) for p in row['checkpoints']]
        require(keys and len(keys) == len(set(keys)), 'Empty or duplicate checkpoint identities')
        require(all(type(word) is int and word > 0 and type(offset) is int and offset >= 0 for word, offset in keys),
                'Invalid checkpoint coordinates')
        require(keys == sorted(keys), 'Checkpoint identity order changed')
        if manifest['mode'] == 'word':
            require(all(offset == 0 for _, offset in keys), 'Word manifest contains partial checkpoints')
        indexed[identifier] = row
    require(len(indexed) == manifest['phraseCount'], 'Checkpoint manifest phrase count is inconsistent')
    require(sum(len(row['checkpoints']) for row in indexed.values()) == manifest['checkpointsPerCondition'],
            'Checkpoint manifest denominator is inconsistent')
    return indexed


def validate_report(report, checkpoint_manifest, fixture=None):
    """Prove completeness and accounting before asking the existing analyzer for intervals."""
    expected = validate_checkpoint_manifest(checkpoint_manifest)
    require(report.get('schemaVersion') == 2, 'Expected a full version-2 report')
    metadata = report['metadata']
    for key in ('corpusSHA256', 'corpusVersion', 'mode'):
        require(metadata.get(key) == checkpoint_manifest[key], 'Report/checkpoint manifest identity mismatch: ' + key)
    require(metadata.get('contextMode') == 'paired' and set(report['conditions']) == CONDITIONS,
            'A complete paired none/screen report is required')
    require(type(report.get('errorCount')) is int and report['errorCount'] == 0, 'Inference errors in report')
    fixture_by_id = {p['id']: p for p in fixture['phrases']} if fixture is not None else None
    indexed = {}
    for row in report['phrases']:
        phrase, condition = row['phrase'], row['condition']
        key = (phrase['id'], condition)
        require(condition in CONDITIONS and key not in indexed and phrase['id'] in expected,
                'Unexpected or duplicate phrase-condition identity')
        plan = expected[phrase['id']]
        require(phrase['category'] == plan['category'], 'Phrase category changed')
        if fixture_by_id is not None:
            require(phrase['id'] in fixture_by_id and normalize_object(phrase) == normalize_object(fixture_by_id[phrase['id']]),
                    'Report phrase differs from the hash-bound fixture')
        observations = row['observations']
        actual_keys = []
        for observation in observations:
            checkpoint = observation['checkpoint']
            require(type(checkpoint.get('wordIndex')) is int and type(checkpoint.get('typedCharacters')) is int,
                    'Checkpoint coordinates must be integers, not Boolean equivalents')
            actual_keys.append({'wordIndex': checkpoint['wordIndex'], 'typedCharacters': checkpoint['typedCharacters']})
            require(type(observation.get('correct')) is bool and type(observation.get('wasShown')) is bool,
                    'Missing/non-Boolean authoritative Swift flags; compact exports are insufficient')
            require(observation.get('error') is None, 'Observation has an inference error')
            latency = observation.get('latencyMilliseconds')
            require(type(latency) in (int, float) and math.isfinite(latency) and latency >= 0,
                    'Invalid observation latency')
            require(not observation['correct'] or observation['wasShown'], 'Correct observation cannot be unshown')
            require(isinstance(observation.get('raw'), str), 'Full raw observation fields are required')
            require(all(isinstance(checkpoint.get(name), str) for name in ('prefix', 'typedWordPrefix', 'expectedWord')),
                    'Incomplete checkpoint text identity')
        require(actual_keys == plan['checkpoints'], 'Missing, extra, reordered, or duplicate checkpoint')
        check_metrics(row['all'], observations)
        check_metrics(row['nextWord'], [o for o in observations if o['checkpoint']['typedCharacters'] == 0])
        indexed[key] = row
    require(set(indexed) == {(identifier, condition) for identifier in expected for condition in CONDITIONS},
            'Report does not contain the complete registered phrase/condition selection')
    for identifier in expected:
        a, b = (indexed[(identifier, condition)] for condition in ('none', 'screen'))
        require(a['phrase'] == b['phrase'] and [o['checkpoint'] for o in a['observations']] ==
                [o['checkpoint'] for o in b['observations']], 'None/screen task identities differ within one run')
    for condition in CONDITIONS:
        rows = [row for (identifier, current), row in indexed.items() if current == condition]
        categories = {row['phrase']['category'] for row in rows}
        aggregate = report['conditions'][condition]
        require(set(aggregate['categories']) == categories, 'Category aggregates differ from selected categories')
        for category in ('suite', *sorted(categories)):
            selected = [row for row in rows if category == 'suite' or row['phrase']['category'] == category]
            observations = [o for row in selected for o in row['observations']]
            summary = aggregate['suite'] if category == 'suite' else aggregate['categories'][category]
            require(summary['phraseCount'] == len(selected), 'Aggregate phrase count differs from observations')
            check_metrics(summary['all'], observations)
            check_metrics(summary['nextWord'], [o for o in observations if o['checkpoint']['typedCharacters'] == 0])
    if metadata['corpusVersion'] == 3:
        families = collections.defaultdict(list)
        for identifier in expected:
            phrase = indexed[(identifier, 'none')]['phrase']
            group = phrase.get('evaluationGroup')
            require(isinstance(group, str) and group and phrase.get('contextKind') in KINDS,
                    'Fresh report is missing valid family/context identities')
            families[group].append(phrase)
        require(len(families) >= 140, 'Fresh report lacks 140 authored families')
        require(all(len(rows) <= 5 and len({(p['category'], p['contextKind']) for p in rows}) == 1
                    for rows in families.values()), 'Fresh family crosses category/context identities or has too many siblings')
        require(metadata.get('evaluationGroupIDs') == sorted(families), 'Fresh metadata family IDs disagree')
    return indexed


def subset_index(indexed, subset='word', context_kind=None):
    predicates = {'word': lambda offset: offset == 0, 'partial': lambda offset: offset > 0,
                  'all': lambda offset: True}
    require(subset in predicates, 'Unknown checkpoint subset')
    result = {}
    for key, row in indexed.items():
        if context_kind is not None and row['phrase'].get('contextKind') != context_kind:
            continue
        observations = [o for o in row['observations'] if predicates[subset](o['checkpoint']['typedCharacters'])]
        require(observations, 'Registered subset has a zero-checkpoint phrase; explicit handling is required')
        result[key] = dict(row, observations=observations, all=metrics(observations))
    require(result, 'Empty checkpoint/context subset')
    return result


def aggregate_delta(old, new):
    result = {}
    for condition in sorted(CONDITIONS):
        categories = sorted({row['phrase']['category'] for (_, c), row in old.items() if c == condition})
        result[condition] = {}
        for category in ('suite', *categories):
            keys = [key for key, row in old.items() if key[1] == condition
                    and (category == 'suite' or row['phrase']['category'] == category)]
            a = [o for key in keys for o in old[key]['observations']]
            b = [o for key in keys for o in new[key]['observations']]
            require(len(a) == len(b) and a, 'Paired subset denominators differ or are empty')
            before, after = metrics(a), metrics(b)
            change = Fraction(after['correct'] - before['correct'], len(a))
            result[condition][category] = {'baseline': before, 'finalist': after,
                'accuracyDelta': float(change), 'deltaNumerator': change.numerator,
                'deltaDenominator': change.denominator,
                'gains': sum(not x['correct'] and y['correct'] for x, y in zip(a, b)),
                'losses': sum(x['correct'] and not y['correct'] for x, y in zip(a, b))}
    return result


def compare_indices(old, new, analyzer, subset='word', context_kind=None):
    require(old.keys() == new.keys(), 'Different paired phrase/condition identities')
    for key in old:
        require(old[key]['phrase'] == new[key]['phrase'] and [o['checkpoint'] for o in old[key]['observations']] ==
                [o['checkpoint'] for o in new[key]['observations']], 'Baseline/finalist checkpoint text identity differs')
    a, b = subset_index(old, subset, context_kind), subset_index(new, subset, context_kind)
    bootstrap = analyzer.paired_statistics(a, b, samples=20000, seed=1337, metric='all')
    return {'subset': subset, 'contextKind': context_kind, 'deltas': aggregate_delta(a, b), 'bootstrap': bootstrap}


def exact_delta(comparison, condition, category='suite'):
    row = comparison['deltas'][condition][category]
    return Fraction(row['deltaNumerator'], row['deltaDenominator'])


def quality_gates(comparison, kind):
    if kind == 'character':
        require(comparison.get('subset') == 'partial', 'Character gates require partial-only evidence')
    gates = {}
    if kind in ('fresh', 'freshSeed'):
        bootstrap = comparison['bootstrap']
        require(bootstrap['samples'] == 20000 and bootstrap['seed'] == 1337 and bootstrap['clusterUnit'] == 'evaluationGroup',
                'Fresh uncertainty must use the registered family bootstrap')
        intervals = bootstrap['accuracyDeltaIntervals']
        gates['fresh-screen-effect'] = exact_delta(comparison, 'screen') >= Fraction(1, 200)
        gates['fresh-screen-interval'] = intervals['screen/suite'][0] > 0
        gates['fresh-none-effect'] = exact_delta(comparison, 'none') >= -Fraction(1, 200)
        gates['fresh-none-interval'] = intervals['none/suite'][0] > -.01
        gates['fresh-screen-categories'] = all(exact_delta(comparison, 'screen', c) >= -Fraction(3, 100)
                                                for c in comparison['deltas']['screen'] if c != 'suite')
    elif kind in ('historical', 'character'):
        gates[kind + '-screen-noninferiority'] = exact_delta(comparison, 'screen') >= 0
        gates[kind + '-none-noninferiority'] = exact_delta(comparison, 'none') >= 0
    elif kind in ('productionSeed', 'integration'):
        gates[kind + '-screen-positive'] = exact_delta(comparison, 'screen') > 0
        gates[kind + '-none-floor'] = exact_delta(comparison, 'none') >= -Fraction(1, 200)
    else:
        require(kind == 'latency', 'Unknown evidence gate kind')
    return gates


def latency_changes(comparison):
    changes = {}
    for condition in sorted(CONDITIONS):
        row = comparison['deltas'][condition]['suite']
        before, after = (row[key]['latencyP95Milliseconds'] for key in ('baseline', 'finalist'))
        require(before is not None and after is not None, 'Latency evidence contains no latency samples')
        threshold = max(.1 * before, 20.0)
        changes[condition] = {'baselineP95Milliseconds': before, 'finalistP95Milliseconds': after,
                              'deltaMilliseconds': after - before, 'thresholdMilliseconds': threshold,
                              'requiresInvestigation': after - before > threshold}
    return changes


TARGET_PATHS = {
    'renderer': 'app/Cotabby/Support/Prompting/BaseCompletionPromptRenderer.swift',
    'composer': 'app/Cotabby/Support/Context/SurfaceContextComposer.swift',
    'nativeEngine': 'native/Sources/CotabbyInferenceEngine/CotabbyInferenceEngine.cpp',
}
PRODUCTION_SCOPE = {'app': ['Cotabby', 'Config', 'Cotabby.xcodeproj', 'project.yml', 'CotabbyInfo.plist'],
                    'native': ['Package.swift', 'Sources']}
OLD_CORPUS_SHA = 'b41c8089a58ae1e0ee84b95ac9283cf71db4e713e25bd8fed47220be69d8b0f6'
FRESH_CORPUS_SHA = '2529c17f21b276eecafe7859853b1aafeba967346f205fa9f378631aa2dda828'
SAMPLING = {'temperature': .1, 'repetition_penalty': 1.025, 'top_k': 20, 'top_p': .7, 'min_p': .08}
HARNESS_FIXED = {'CotabbyTests/TestSupport/CotabbyTestFixtures.swift', 'scripts/phrase_eval.py',
                 'scripts/analyze_phrase_experiments.py', 'scripts/analyze_completion_prefixes.py'}
HARNESS_REQUIRED_EVALS = {'PhrasePredictionEvalTests.swift', 'PhrasePredictionScoring.swift',
                          'PhrasePredictionScreenContext.swift', 'LlamaEvalScoring.swift'}


class Assessment:
    """A short-lived reader of one immutable selection and its subsequent evidence.

    Artifact bytes are hashed at read time and rechecked at completion. This object
    does not operate the app, select candidates, or change source and benchmark files.
    """
    def __init__(self, root):
        self.root = Path(root).resolve()
        self.artifacts = {}
        self.bindings = {}
        self.integration = None
        self.frozen = None

    def path(self, value):
        path = Path(value)
        return path if path.is_absolute() else self.root / path

    def read_bytes(self, value):
        path = self.path(value).resolve()
        data = path.read_bytes()
        sha = digest(data)
        require(str(path) not in self.artifacts or self.artifacts[str(path)] == sha,
                'Evidence changed between reads')
        self.artifacts[str(path)] = sha
        return data

    def read_json(self, value):
        return json.loads(self.read_bytes(value))

    def artifact_path(self, reference):
        require(isinstance(reference, dict) and set(reference) == {'path', 'sha256'}
                and is_hash(reference['sha256']), 'Malformed artifact reference')
        path = self.path(reference['path'])
        require(digest(self.read_bytes(path)) == reference['sha256'], 'Hash-bound evidence artifact changed')
        return path

    def artifact(self, reference):
        return self.read_json(self.artifact_path(reference))

    def inventory(self, reference):
        data = self.artifact(reference)
        require(data.get('schemaVersion') == 1 and data.get('scope') == PRODUCTION_SCOPE,
                'Production inventory scope is incomplete or changed')
        require(isinstance(data.get('files'), dict) and all(is_hash(v) for v in data['files'].values())
                and all(path in data['files'] for path in TARGET_PATHS.values()),
                'Production inventory hashes/targets are incomplete')
        return data

    def verify_harness(self, app_root, expected=None):
        expected = expected if expected is not None else self.frozen['validationHarnessHashes']
        app = Path(app_root)
        evals = {str(path.relative_to(app)) for path in (app / 'CotabbyTests/Evals').glob('*.swift')}
        paths = evals | HARNESS_FIXED
        require(HARNESS_REQUIRED_EVALS <= {Path(p).name for p in evals}
                and set(expected) == {'app/' + path for path in paths},
                'Validation harness inventory is incomplete or gained unregistered files')
        for path in paths:
            self.artifact_path({'path': str(app / path), 'sha256': expected['app/' + path]})

    def validate_freeze(self):
        # This is deliberately the first report-related operation. An absent freeze
        # prevents loading even baseline fresh outputs, not merely their comparison.
        frozen = self.read_json('finalist-freeze.json')
        round_record = self.read_json('round.json')
        require(frozen.get('schemaVersion') == 1, 'Unsupported finalist freeze')
        at = timestamp(frozen['frozenUTC'])
        require(timestamp(round_record['startUTC']) <= at <= timestamp(round_record['freezeDeadlineUTC'])
                and at <= dt.datetime.now(dt.timezone.utc), 'Finalist was not frozen in the registered window')
        components = frozen['components']
        require(isinstance(components, list) and all(c in {f'{family}{i}' for family in 'HFM' for i in range(1, 5)}
                for c in components) and len({c[0] for c in components}) == len(components),
                'Frozen candidate components are not in the finite registered family set')
        require(frozen['candidate'] == ('+'.join(components) or 'baseline')
                and frozen['selectionQualified'] is bool(components), 'Frozen candidate qualification disagrees')
        require(frozen['modelSHA256'] == round_record['modelSHA256'] and is_hash(frozen['modelSHA256'])
                and frozen['freshCorpusSHA256'] == FRESH_CORPUS_SHA, 'Frozen model/corpus differs from registration')
        self.artifact_path(frozen['criteria'])
        self.artifact_path(frozen['selectionClarification'])
        combinations = self.artifact(frozen['combinationRegistration'])
        ranking = self.artifact(frozen['screeningEvidence'])
        require(frozen['screeningEvidence']['sha256'] == frozen['screeningEvidenceSHA256'],
                'Screening evidence fingerprints disagree')
        # This verifies the already-frozen mechanical selection; it never substitutes
        # another candidate based on protected outcomes.
        rows = ranking['rows']
        indexed = {row['candidate']: row for row in rows}
        order = ['baseline', *[f'{family}{i}' for family in 'HFM' for i in range(1, 5)],
                 *[item['candidate'] for item in combinations['combinations']]]
        require(len(rows) == len(indexed) and set(indexed) == set(order), 'Frozen screening queue is incomplete')
        baseline = indexed['baseline']
        qualified = [row for row in rows if row['candidate'] != 'baseline'
                     and row['screenCorrect'] > baseline['screenCorrect'] and row['noneCorrect'] >= baseline['noneCorrect']]
        selected = min(qualified, key=lambda row: (-row['screenCorrect'], -row['noneCorrect'], order.index(row['candidate']))) if qualified else baseline
        require(selected['candidate'] == frozen['candidate'] and selected['label'] == frozen['candidateLabel']
                and baseline['label'] == frozen['baselineLabel'], 'Frozen selection disagrees with registered development rule')
        for row in rows:
            for suffix, hash_key in [('report.json', 'reportSHA256'), ('registration', 'registrationSHA256')]:
                path = f"{row['label']}/report.json" if suffix == 'report.json' else f"{row['label']}-registration.json"
                self.artifact_path({'path': path, 'sha256': row[hash_key]})
            screening = self.read_json(f"{row['label']}/report.json")
            registration = self.read_json(f"{row['label']}-registration.json")
            require(screening.get('schemaVersion') == 2 and screening.get('errorCount') == 0
                    and set(screening['conditions']) == CONDITIONS, 'Ranked screening report is incomplete or has errors')
            require(registration.get('label') == row['label'] and registration.get('candidate') == row['candidate']
                    and registration.get('status') == 'complete' and registration.get('phase') == 'screening',
                    'Ranked screening attempt was not completed for the named candidate')
            for condition, count_key in [('none', 'noneCorrect'), ('screen', 'screenCorrect')]:
                score = screening['conditions'][condition]['suite']['nextWord']
                require(type(row[count_key]) is int and row[count_key] == score['correct']
                        and score['checkpoints'] == 770 and score['errors'] == 0,
                        'Frozen ranking counts differ from authoritative screening totals')
        readiness = self.artifact(frozen['freshReadiness'])
        require(readiness['status'] == 'pass' and readiness['corpusSHA256'] == FRESH_CORPUS_SHA
                and readiness['phraseCount'] == 700 and readiness['familyCount'] >= 140
                and readiness['wordCheckpointsPerCondition'] == 2892
                and timestamp(readiness['readyUTC']) <= min(at, timestamp(round_record['freshReadinessDeadlineUTC'])),
                'Fresh readiness did not satisfy the registered deadline/size/identity')
        inventories = {role: self.inventory(ref) for role, ref in frozen['productionInventories'].items()}
        require(set(inventories) == {'baseline', 'finalist'}, 'Missing frozen role inventory')
        snapshot = self.read_json('starting-snapshot.json')
        snapshot_files = {}
        for owner in ('app', 'native'):
            for relative, item in snapshot[owner]['after']['files'].items():
                parts = Path(relative).parts
                included = any(relative == base or relative.startswith(base + '/') for base in PRODUCTION_SCOPE[owner])
                if included and 'xcuserdata' not in parts and Path(relative).name not in ('.DS_Store', 'Package.resolved') and item['kind'] != 'deleted':
                    snapshot_files[f'{owner}/{relative}'] = item['sha256']
        require(snapshot_files, 'Starting production snapshot is empty')
        for role, inventory in inventories.items():
            prefix = 'baseline' if role == 'baseline' else 'candidate'
            targets = frozen[prefix + 'Targets']
            require(set(targets) == TARGETS and all(is_hash(v) for v in targets.values()), 'Invalid frozen target map')
            require({key: inventory['files'][path] for key, path in TARGET_PATHS.items()} == targets,
                    'Frozen production target hashes disagree')
            expected_inventory = dict(snapshot_files)
            expected_inventory.update({TARGET_PATHS[key]: value for key, value in targets.items()})
            require(inventory['files'] == expected_inventory, 'Frozen inventory omits or changes starting production inputs')
            require({key: value for key, value in inventory['files'].items() if key not in TARGET_PATHS.values()}
                    == frozen['prerequisiteHashes'], 'Frozen prerequisite inventory differs between roles')
            require(is_hash(frozen[prefix + 'SourceSHA256']), 'Frozen source fingerprint is missing')
            label = frozen['baselineLabel'] if role == 'baseline' else frozen['candidateLabel']
            manifest = self.read_json(f'{label}/manifest.json')
            registration = self.read_json(f'{label}-registration.json')
            require(manifest['buildInputs']['sourceSHA256'] == frozen[prefix + 'SourceSHA256']
                    and registration['status'] == 'complete'
                    and {**registration['promptSource']['hashes'], 'nativeEngine': registration['nativeSource']['sha256']} == targets,
                    'Frozen source identity does not bind to its completed screening run')
        # Check target bytes against catalogs authored before screening.
        singles = self.read_json('prompt-sources/manifest.json')['variants']
        combined = self.read_json('combination-sources/manifest.json')['variants']
        native = self.read_json('native-history/variants/manifest.json')['variants']
        for role, chosen in [('baseline', []), ('candidate', components)]:
            prompt = [c for c in chosen if c[0] in 'FM']
            history = next((c for c in chosen if c[0] == 'H'), 'baseline')
            prompt_key = '+'.join(prompt) or 'baseline'
            expected_targets = dict((combined if len(prompt) == 2 else singles)[prompt_key]['hashes'],
                                    nativeEngine=native[history]['sha256'])
            require(frozen[role + 'Targets'] == expected_targets, 'Frozen target is outside the premeasurement catalogs')
            directory = 'combination-sources' if len(prompt) == 2 else 'prompt-sources'
            for key in ('renderer', 'composer'):
                self.artifact_path({'path': f'{directory}/{prompt_key}/{key}.swift', 'sha256': expected_targets[key]})
            self.artifact_path({'path': f"native-history/variants/{native[history]['path']}",
                                'sha256': expected_targets['nativeEngine']})
        self.verify_harness(self.read_json('execution.json')['root'], frozen['validationHarnessHashes'])
        self.frozen, self.round_record, self.inventories = frozen, round_record, inventories
        self.readiness = readiness
        return frozen

    def add_binding(self, item):
        role, label = item['role'], item['label']
        require(role in ('baseline', 'finalist') and is_hash(item['sourceSHA256']), 'Invalid source binding')
        prefix = 'baseline' if role == 'baseline' else 'candidate'
        require(item['targets'] == self.frozen[prefix + 'Targets'], 'Source binding changed selected production targets')
        require(self.inventory(item['productionInventory']) == self.inventories[role],
                'Source binding changed production inputs outside registered targets')
        require(label not in self.bindings or self.bindings[label] == item, 'Conflicting explicit source bindings')
        self.bindings[label] = item

    def expected_source(self, label, role):
        if label in self.bindings:
            binding = self.bindings[label]
            require(binding['role'] == role, 'Source binding has the wrong baseline/finalist role')
            return binding['sourceSHA256']
        return self.frozen[('baseline' if role == 'baseline' else 'candidate') + 'SourceSHA256']

    def check_tests(self, reference_or_path, source=None, required=()):
        path = self.artifact_path(reference_or_path) if isinstance(reference_or_path, dict) else self.path(reference_or_path)
        record = self.read_json(path)
        require(record.get('status') == 'passed' and is_hash(record.get('productSHA256')), 'Checks/build did not pass')
        if source is not None:
            require(record['buildInputs']['sourceSHA256'] == source, 'Tests used a different compiler fingerprint')
        log = self.read_bytes(path.parent / 'validation.log').decode(errors='replace')
        actual = sorted(set(f'{group}/{method}' for group, method in re.findall(
            r"Test Case '-\[CotabbyTests\.([^ ]+) ([^\]]+)\]' passed", log)))
        require(actual and '** TEST EXECUTE SUCCEEDED **' in log, 'Check log does not prove successful XCTest execution')
        if 'executedTests' in record:
            require(actual == record['executedTests'], 'Recorded successful tests disagree with original log')
        for name in required:
            require(name in record['tests'] or name.split('/')[0] in record['tests'], 'Required tests were not selected')
            require(name in actual if '/' in name else any(t.startswith(name + '/') for t in actual),
                    'Required test did not actually pass')
        require(timestamp(record['startedUTC']) <= timestamp(record['finishedUTC']), 'Reversed check interval')
        return record, actual

    def load_run(self, label, role, plan, kind):
        require(self.frozen is not None, 'Freeze must validate before any protected result is read')
        require(isinstance(label, str) and re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9._-]{0,99}', label), 'Unsafe run label')
        registration = self.read_json(f'{label}-registration.json')
        require(registration['label'] == label and registration['phase'] == 'validation'
                and registration['status'] == 'complete', 'Validation run is incomplete or failed')
        start, finish = timestamp(registration['inferenceStartedUTC']), timestamp(registration['finishedUTC'])
        require(timestamp(self.frozen['frozenUTC']) <= timestamp(registration['startedUTC']) <= start <= finish
                <= timestamp(self.round_record['deadlineUTC']), 'Validation timing violates freeze/round boundaries')
        prefix = 'baseline' if role == 'baseline' else 'candidate'
        expected_candidate = 'baseline' if role == 'baseline' else self.frozen['candidate']
        require(registration['candidate'] == expected_candidate, 'Validation candidate differs from frozen role')
        require({**registration['promptSource']['hashes'], 'nativeEngine': registration['nativeSource']['sha256']}
                == self.frozen[prefix + 'Targets'], 'Run did not use frozen production targets')
        source = self.expected_source(label, role)
        manifest = self.read_json(f'{label}/manifest.json')
        require(manifest['label'] == label and manifest['buildInputs']['sourceSHA256'] == source
                and manifest['build']['sourceSHA256'] == source and is_hash(manifest['build']['productSHA256']),
                'Run compiler/product evidence does not match frozen/bound source')
        required = ['BaseCompletionPromptRendererTests/testRoundTwoScreeningPromptAudit']
        if any(c.startswith('H') for c in self.frozen['components']) and role == 'finalist':
            required += ['LlamaRuntimeCoreIntegrationTests/' + name for name in NATIVE_TESTS]
        checks, actual_tests = self.check_tests(registration['checks'], source, required)
        self.verify_harness(checks['execution']['root'])
        require(checks['buildInputs'] == manifest['buildInputs']
                and checks['productSHA256'] == manifest['build']['productSHA256']
                and timestamp(checks['finishedUTC']) <= start, 'Benchmark/check binary, inputs or timing disagree')
        require(manifest['build'].get('reused') is False, 'Registered validation requires its own completed build')
        frozen_manifest = self.read_json(f"{self.frozen['baselineLabel']}/manifest.json")
        locks = lambda item: sorted(str(v) for v in item['buildInputs']['packageLocks'].values())
        require(locks(manifest) == locks(frozen_manifest), 'Resolved dependency locks differ from frozen baseline')
        require(manifest['corpusSHA256'] == plan['corpusSHA256'] and manifest['mode'] == plan['mode']
                and manifest['contextMode'] == 'paired' and manifest['phraseIDs'] == [p['phraseID'] for p in plan['phrases']],
                'Manifest selection/corpus/mode differs from opaque checkpoint cohort')
        selection = manifest['selection']
        require(selection['split'] == plan['selection'] and (selection.get('perCategory') or 0) == plan['perCategory']
                and selection.get('limit') is None and selection['splitSeed'] == 1337 and selection['screenPerCategory'] == 20,
                'Manifest uses an unregistered narrowed/reordered cohort')
        sampling = manifest['samplingOverrides']
        require({key: sampling.get(key) for key in SAMPLING} == SAMPLING, 'Sampler differs from registered round settings')
        expected_seed = 12648430 if kind in ('productionSeed', 'integration') else 1337 if kind == 'freshSeed' else 42
        if kind != 'latency':
            require(sampling.get('seed') == expected_seed, 'Wrong registered inference seed')
        require(type(manifest['workerCount']) is int and manifest['workerCount'] > 0, 'Invalid worker count')
        if kind == 'latency':
            require(manifest['workerCount'] == 1, 'Latency requires one worker')
        expected_evaluation = digest(json.dumps({'compilerInputsSHA256': source, 'corpusSHA256': plan['corpusSHA256']},
                                              sort_keys=True).encode())
        require(manifest['evaluationInputsSHA256'] == expected_evaluation, 'Evaluation input fingerprint disagrees')
        corpus = manifest['corpusInput']
        require(corpus['sha256'] == plan['corpusSHA256'] and corpus['version'] == plan['corpusVersion'], 'Corpus input identity disagrees')
        fixture_path = corpus.get('replayPath') or corpus['sourcePath']
        self.artifact_path({'path': corpus['sourcePath'], 'sha256': plan['corpusSHA256']})
        fixture = self.artifact({'path': fixture_path, 'sha256': plan['corpusSHA256']})
        if plan['corpusVersion'] == 3:
            require(plan['corpusSHA256'] == self.frozen['freshCorpusSHA256'], 'Fresh corpus was replaced')
        report = self.read_json(f'{label}/report.json')
        metadata = report['metadata']
        if plan['corpusVersion'] == 3:
            require(metadata['corpusPath'] == corpus['replayPath'], 'Fresh report was not produced from its immutable replay copy')
        require(metadata['runLabel'] == label and metadata['seed'] == sampling['seed']
                and metadata['workerCount'] == manifest['workerCount'], 'Executed run metadata differs from CLI identity')
        configuration = metadata['configuration']
        anchor = self.read_json(f"{self.frozen['baselineLabel']}/report.json")['metadata']['configuration']
        allowed_configuration_changes = {'randomSeed', 'selectionSplit'}
        require({key: value for key, value in configuration.items() if key not in allowed_configuration_changes} ==
                {key: value for key, value in anchor.items() if key not in allowed_configuration_changes},
                'Effective configuration drifted from the frozen screening baseline')
        require(configuration['selectionSplit'] == selection['split'], 'Executed split differs from registered selection')
        require(configuration['modelSHA256'] == self.frozen['modelSHA256'], 'Executed model differs from frozen model')
        for key, expected in {'temperature': .1, 'repetitionPenalty': 1.025, 'topK': 20, 'topP': .7, 'minP': .08}.items():
            require(float(configuration[key]) == expected, 'Executed sampler differs from registered CLI values')
        require(configuration['randomSeed'] == f"Optional({sampling['seed']})"
                and configuration['confidenceFloor'] == '-inf' and configuration['stopAtArgmaxEOG'] == 'true'
                and configuration['maxPredictionTokens'] == '5', 'Executed runtime controls differ from registered defaults')
        index = validate_report(report, plan, fixture)
        result = {'label': label, 'role': role, 'registration': registration, 'manifest': manifest,
                  'metadata': metadata, 'index': index, 'sourceSHA256': source, 'tests': actual_tests}
        return result

    def validate_cohort(self, plan, kind, optional=False):
        validate_checkpoint_manifest(plan)
        require(plan['scorerSourceSHA256'] == self.checkpoint_exporter['scorerSource']['sha256'],
                'Checkpoint plan uses a different Swift scorer')
        require({row['category'] for row in plan['phrases']} == CATEGORIES, 'Cohort must retain all seven categories')
        categories = collections.Counter(row['category'] for row in plan['phrases'])
        if kind in ('fresh', 'freshSeed'):
            require(plan['corpusVersion'] == 3 and plan['corpusSHA256'] == FRESH_CORPUS_SHA
                    and plan['mode'] == 'word' and plan['selection'] == 'all' and plan['perCategory'] == 0
                    and plan['phraseCount'] == 700 and plan['checkpointsPerCondition'] == 2892
                    and set(categories.values()) == {100}, 'Fresh cohort differs from complete registered 700 cases')
        else:
            require(plan['corpusVersion'] == 2 and plan['corpusSHA256'] == OLD_CORPUS_SHA, 'Historical corpus changed')
            if kind in ('historical', 'productionSeed', 'integration'):
                require(plan['mode'] == 'word' and plan['selection'] == 'all' and plan['perCategory'] == 0
                        and plan['phraseCount'] == 1337 and set(categories.values()) == {191},
                        'Required historical/production comparison must use all1337 word cases')
            elif kind == 'character':
                size = 150 if optional else 50
                require(plan['mode'] == 'character' and plan['selection'] == 'all' and plan['perCategory'] == size
                        and plan['phraseCount'] == 7 * size and set(categories.values()) == {size},
                        'Character cohort differs from the preregistered firstN/category selection')
            else:
                require(kind == 'latency', 'Unknown evidence cohort kind')

    def pair(self, spec, kind, analyzer, optional=False):
        require(spec['baseline'] != spec['finalist'], 'A paired comparison requires distinct completed runs')
        plan = self.artifact(spec['checkpoints'])
        require(spec['checkpoints'] in self.checkpoint_exporter['manifests'],
                'Checkpoint cohort is absent from the hash-bound Swift exporter record')
        self.validate_cohort(plan, kind, optional)
        a = self.load_run(spec['baseline'], 'baseline', plan, kind)
        b = self.load_run(spec['finalist'], 'finalist', plan, kind)
        require(a['metadata']['configuration'] == b['metadata']['configuration'],
                'Paired effective runtime/preferences differ')
        require(a['manifest']['samplingOverrides'] == b['manifest']['samplingOverrides']
                and a['metadata']['workerCount'] == b['metadata']['workerCount'], 'Paired sampling/workers differ')
        subset = 'partial' if kind == 'character' else 'word' if plan['mode'] == 'word' else 'all'
        comparison = compare_indices(a['index'], b['index'], analyzer, subset)
        result = {'baseline': a['label'], 'finalist': b['label'], 'kind': kind,
                  'sourceSHA256': {r['role']: r['sourceSHA256'] for r in (a, b)},
                  'modelSHA256': self.frozen['modelSHA256'], 'corpusSHA256': plan['corpusSHA256'],
                  'phraseCount': plan['phraseCount'], 'checkpointsPerCondition': plan['checkpointsPerCondition'],
                  'seed': a['metadata']['seed'], 'workerCount': a['metadata']['workerCount'],
                  'comparison': comparison, 'gates': quality_gates(comparison, kind)}
        if kind in ('fresh', 'freshSeed'):
            result['contextKinds'] = {group: compare_indices(a['index'], b['index'], analyzer, 'word', group)
                                      for group in sorted(KINDS)}
        if kind == 'character':
            result['wordBoundaries'] = compare_indices(a['index'], b['index'], analyzer, 'word')
            result['allCheckpoints'] = compare_indices(a['index'], b['index'], analyzer, 'all')
        if kind == 'latency':
            self.validate_isolation(spec['isolation'], [a, b])
            result['latency'] = latency_changes(comparison)
        return result

    def validate_isolation(self, reference, runs):
        evidence = self.artifact(reference)
        labels = {r['label'] for r in runs}
        require(evidence.get('schemaVersion') == 1 and evidence.get('status') == 'passed'
                and set(evidence['labels']) == labels and evidence.get('noOverlappingBuildOrInference') is True,
                'Latency isolation evidence is missing or invalid')
        self.artifact_path(evidence['evidence'])
        intervals = {item['label']: item for item in evidence['intervals']}
        require(set(intervals) == labels and len(intervals) == len(evidence['intervals']), 'Latency interval labels disagree')
        active = []
        for run in runs:
            interval, registration = intervals[run['label']], run['registration']
            require(timestamp(interval['startedUTC']) == timestamp(registration['inferenceStartedUTC'])
                    and timestamp(interval['finishedUTC']) == timestamp(registration['finishedUTC']),
                    'Latency isolation interval does not match executed inference')
            active.append((run['label'], timestamp(interval['startedUTC']), timestamp(interval['finishedUTC'])))
        for label, start, finish in active:
            for path in self.root.glob('*-registration.json'):
                record = self.read_json(path)
                if record.get('label') == label or 'inferenceStartedUTC' not in record:
                    continue
                other_start = timestamp(record['inferenceStartedUTC'])
                other_finish = timestamp(record['finishedUTC']) if record.get('finishedUTC') else dt.datetime.now(dt.timezone.utc)
                require(max(start, other_start) >= min(finish, other_finish), 'Latency overlapped another registered inference run')
            for path in self.root.glob('*/validation.json'):
                record = self.read_json(path)
                if 'startedUTC' not in record or 'finishedUTC' not in record:
                    continue
                require(max(start, timestamp(record['startedUTC'])) >= min(finish, timestamp(record['finishedUTC'])),
                        'Latency overlapped a registered build/test interval')

    def bind_integration(self, reference):
        record = self.artifact(reference)
        require(record.get('schemaVersion') == 1 and record.get('status') == 'passed'
                and record.get('preservedUnrelatedEdits') is True, 'Current-main integration/preservation is incomplete')
        proof = self.artifact(record['snapshotProof'])
        require(proof.get('schemaVersion') == 1 and proof.get('status') == 'passed'
                and isinstance(proof.get('mainBefore'), dict) and proof['mainBefore']
                and proof['mainBefore'] == proof.get('mainAfter')
                and all(is_hash(value) for value in proof['mainBefore'].values()),
                'Integration snapshot proof does not establish unchanged main files')
        for role in ('baseline', 'finalist'):
            item = dict(record[role], role=role)
            require(item.get('prerequisiteHashes') == self.frozen['prerequisiteHashes'],
                    'Current-main integration changed frozen prerequisites')
            self.add_binding({key: item[key] for key in ('label', 'role', 'sourceSHA256', 'targets', 'productionInventory')})
            require(self.inventory(proof[role + 'Inventory']) == self.inventory(item['productionInventory']),
                    'Integration snapshot and run inventory records disagree')
        self.integration = record
        return record

    def final_tests(self, references, allowed_sources):
        actual = set()
        for ref in references:
            record, executed = self.check_tests(ref)
            require(record['buildInputs']['sourceSHA256'] in allowed_sources,
                    'Final focused tests are not bound to the finalist source')
            actual.update(executed)
        for suite in (*FINAL_TEST_SUITES, 'PromptSectionBudgetTests'):
            require(any(value.startswith(suite + '/') for value in actual), 'Final focused test suite has not executed')
        for name in NATIVE_TESTS:
            require('LlamaRuntimeCoreIntegrationTests/' + name in actual, 'Required cache/healing/cancellation regression did not pass')
        require('PhrasePredictionEvalTests/testBenchmarkOptionsPreserveSplitAndSamplingIdentity' in actual
                and 'PhrasePredictionEvalTests/testSupplementaryFixtureOptionsRequireFingerprintAndFullSelection' in actual,
                'Required benchmark identity/fixture-path tests did not pass')
        return {'status': 'passed', 'executedTests': sorted(actual), 'count': len(actual)}

    def visible_attempts(self, evidence):
        """Prevent omitted completed robustness runs from appearing as 'not run'."""
        mandatory_labels = {spec[role] for spec in evidence['pairs'].values() for role in ('baseline', 'finalist')}
        if self.integration:
            mandatory_labels.update(self.integration[role]['label'] for role in ('baseline', 'finalist'))
        attempts, optional_labels = [], collections.defaultdict(set)
        for path in self.root.glob('*-registration.json'):
            registration = self.read_json(path)
            if registration.get('phase') != 'validation':
                continue
            label = registration['label']
            attempts.append({key: registration.get(key) for key in ('label', 'candidate', 'status', 'startedUTC', 'finishedUTC')})
            command = registration.get('command', [])
            def option(name, default=None):
                return command[command.index(name) + 1] if name in command else default
            manifest_path = self.root / label / 'manifest.json'
            manifest = self.read_json(manifest_path) if manifest_path.exists() else None
            seed = str(manifest['samplingOverrides']['seed']) if manifest else option('--seed', '42')
            mode = manifest['mode'] if manifest else option('--mode', 'word')
            per_category = str(manifest['selection'].get('perCategory')) if manifest else option('--per-category')
            workers = str(manifest['workerCount']) if manifest else option('--workers')
            fresh = manifest['corpusInput']['version'] == 3 if manifest else '--corpus' in command
            if fresh and seed == '1337':
                optional_labels['fresh-seed1337'].add(label)
            elif mode == 'character' and per_category == '150':
                optional_labels['character150'].add(label)
            elif workers == '1' and label not in mandatory_labels:
                optional_labels['latency-counterbalanced'].add(label)
        by_label = {item['label']: item for item in attempts}
        for entry in evidence['optionalPairs']:
            inferred = optional_labels[entry['name']]
            listed = set(entry.get('attemptLabels', []))
            pair = entry.get('pair')
            if pair:
                listed.update(pair[role] for role in ('baseline', 'finalist'))
            require(inferred <= listed, 'Registered optional attempts were omitted from their visible evidence entry')
            existing = {label for label in listed if label in by_label}
            if entry['status'] == 'not-run':
                require(not existing, 'An attempted optional workload cannot be labeled not-run')
            if entry['status'] == 'complete':
                require(pair is not None and all(by_label.get(pair[role], {}).get('status') == 'complete'
                                               for role in ('baseline', 'finalist')),
                        'Complete optional status requires two completed registered runs')
            if entry['status'] in ('failed', 'incomplete'):
                require(existing, 'Failed/incomplete optional workload lacks a preserved attempt registration')
                if pair:
                    require(not all(by_label.get(pair[role], {}).get('status') == 'complete' for role in ('baseline', 'finalist')),
                            'A completed optional pair cannot be hidden as failed/incomplete')
                require(not all(by_label[label]['status'] == 'complete' for label in existing) or len(existing) < 2,
                        'Completed optional attempts require their paired analysis')
        return sorted(attempts, key=lambda row: row['label'])

    def assess(self, evidence_path):
        frozen = self.validate_freeze()
        if frozen['candidate'] == 'baseline':
            return {'schemaVersion': 1, 'status': 'retained-baseline', 'candidate': 'baseline',
                    'reason': 'No development candidate qualified; no protected replacement is permitted.'}
        evidence = self.read_json(evidence_path)
        require(evidence.get('schemaVersion') == 1, 'Unsupported decision evidence schema')
        for item in evidence.get('sourceBindings', []):
            self.add_binding(item)
        execution = self.read_json('execution.json')
        exporter = self.artifact(evidence['checkpointExporter'])
        require(exporter.get('schemaVersion') == 1 and isinstance(exporter.get('compilerVersion'), str)
                and exporter['compilerVersion'].strip() and isinstance(exporter.get('manifests'), list)
                and exporter['manifests'], 'Checkpoint exporter provenance is incomplete')
        for key in ('scorerSource', 'helperSource', 'binary'):
            self.artifact_path(exporter[key])
        scorer = Path(execution['root']) / 'CotabbyTests/Evals/PhrasePredictionScoring.swift'
        require(digest(self.read_bytes(scorer)) == exporter['scorerSource']['sha256'],
                'Checkpoint exporter did not use the current frozen Swift scorer')
        for reference in exporter['manifests']:
            self.artifact_path(reference)
        self.checkpoint_exporter = exporter
        analyzer_path = Path(execution['root']) / 'scripts/analyze_phrase_experiments.py'
        self.read_bytes(analyzer_path)
        spec = importlib.util.spec_from_file_location('round2_registered_analyzer', analyzer_path)
        analyzer = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(analyzer)
        result = {'schemaVersion': 1, 'candidate': frozen['candidate'], 'frozenUTC': frozen['frozenUTC'],
                  'pairs': {}, 'gates': {}, 'issues': [], 'optionalPairs': [],
                  'limitations': [
                      'One local model and synthetic writing; family intervals do not establish population writing quality.',
                      'Correctness uses unchanged Swift reference scoring, which can reject other reasonable wording.',
                      'Character cohort is the registered corpus-order subset, with category uncertainty shown separately.',
                      'Latency excludes focus tracking, debounce and overlays; isolation evidence cannot rule out unlogged machine activity.',
                      'Fresh repeated UI noise may be removed by deduplication and is not sustained long-context validation.']}
        def attempt(name, operation):
            try:
                return operation()
            except FileNotFoundError:
                result['issues'].append({'area': name, 'status': 'incomplete', 'reason': 'Required evidence artifact is absent'})
            except (EvidenceError, KeyError, TypeError, ValueError) as error:
                reason = str(error) if isinstance(error, EvidenceError) else 'Malformed evidence structure'
                result['issues'].append({'area': name, 'status': 'invalid', 'reason': reason})
            return None
        integration = attempt('currentMainIntegration', lambda: self.bind_integration(evidence['currentMainIntegration']))
        required = ('fresh', 'historical', 'character', 'productionSeed', 'latency')
        for kind in required:
            item = attempt(kind, lambda kind=kind: self.pair(evidence['pairs'][kind], kind, analyzer))
            if item is not None:
                result['pairs'][kind] = item
                result['gates'].update(item['gates'])
        if integration is not None:
            integration_spec = {role: integration[role]['label'] for role in ('baseline', 'finalist')}
            integration_spec['checkpoints'] = integration['checkpoints']
            item = attempt('integration', lambda: self.pair(integration_spec, 'integration', analyzer))
            if item is not None:
                result['pairs']['integration'] = item
                result['gates'].update(item['gates'])
            allowed = {integration['finalist']['sourceSHA256']}
            tests = attempt('integrationTests', lambda: self.final_tests(integration['focusedTests'], allowed))
            result['integrationTests'] = tests
        allowed = {frozen['candidateSourceSHA256']} | {b['sourceSHA256'] for b in self.bindings.values() if b['role'] == 'finalist'}
        result['focusedTests'] = attempt('focusedTests', lambda: self.final_tests(evidence['focusedTests'], allowed))
        optional = evidence.get('optionalPairs', [])
        expected_optional = {'fresh-seed1337': 'freshSeed', 'character150': 'character', 'latency-counterbalanced': 'latency'}
        require(len(optional) == len(expected_optional) and {r['name']: r['kind'] for r in optional} == expected_optional,
                'Optional robustness attempts must all remain visible')
        result['registeredValidationAttempts'] = attempt('optionalAttemptVisibility', lambda: self.visible_attempts(evidence))
        optional_contradiction = False
        for entry in optional:
            status = entry['status']
            require(status in ('not-run', 'failed', 'incomplete', 'complete'), 'Unknown optional attempt status')
            item = {key: entry.get(key) for key in ('name', 'kind', 'status', 'reason')}
            if status == 'complete':
                comparison = attempt(entry['name'], lambda entry=entry: self.pair(entry['pair'], entry['kind'], analyzer, True))
                item['result'] = comparison
                if comparison is not None:
                    item['contradiction'] = any(value is False for value in comparison['gates'].values())
                    optional_contradiction |= item['contradiction']
            else:
                require(isinstance(entry.get('reason'), str) and entry['reason'].strip(), 'Unrun/failed optional attempt requires a visible reason')
            result['optionalPairs'].append(item)
        latency = result['pairs'].get('latency')
        investigations = []
        if latency is not None:
            if any(row['requiresInvestigation'] for row in latency['latency'].values()):
                investigations.append([latency['baseline'], latency['finalist']])
        for entry in result['optionalPairs']:
            comparison = entry.get('result')
            if comparison and entry['kind'] == 'latency' and any(row['requiresInvestigation'] for row in comparison['latency'].values()):
                investigations.append([comparison['baseline'], comparison['finalist']])
        if investigations:
            def resolve_latency():
                record = self.artifact(evidence['latencyInvestigation'])
                require(record.get('status') == 'resolved' and record.get('acceptableForAdoption') is True
                        and isinstance(record.get('conclusion'), str) and record['conclusion'].strip()
                        and {tuple(p) for p in record['pairs']} == {tuple(p) for p in investigations},
                        'Latency threshold breach has no explicit evidence-bound resolution')
                self.artifact_path(record['evidence'])
                return record
            result['latencyInvestigation'] = attempt('latencyInvestigation', resolve_latency)
        result['optionalContradiction'] = optional_contradiction
        if result['issues']:
            result['status'] = 'incomplete-or-invalid'
        elif any(value is False for value in result['gates'].values()):
            result['status'] = 'retain-baseline'
        elif optional_contradiction:
            result['status'] = 'needs-review-optional-contradiction'
        else:
            result['status'] = 'eligible-for-adoption'
        result['allRequiredGatesPassed'] = not result['issues'] and all(result['gates'].values())
        return result

    def stable_artifacts(self):
        for path, sha in self.artifacts.items():
            require(digest(Path(path).read_bytes()) == sha, 'Evidence changed during assessment')
        return dict(sorted(self.artifacts.items()))


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--round', type=Path, default=HERE)
    parser.add_argument('--evidence', default='decision-evidence.json')
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args(argv)
    reader = Assessment(args.round)
    try:
        result = reader.assess(args.evidence)
        result['artifactSHA256'] = reader.stable_artifacts()
        result['assessorSHA256'] = digest(Path(__file__).read_bytes())
        result['assessedUTC'] = dt.datetime.now(dt.timezone.utc).isoformat()
    except FileNotFoundError:
        result = {'schemaVersion': 1, 'status': 'incomplete-or-invalid', 'reason': 'Required freeze/evidence artifact is absent'}
    except (EvidenceError, KeyError, TypeError, ValueError) as error:
        result = {'schemaVersion': 1, 'status': 'incomplete-or-invalid',
                  'reason': str(error) if isinstance(error, EvidenceError) else 'Malformed evidence structure'}
    require(args.output.resolve() not in {Path(path) for path in reader.artifacts}, 'Output cannot overwrite evidence')
    args.output.write_text(json.dumps(result, indent=2, sort_keys=True) + '\n')
    print(json.dumps({key: result[key] for key in ('status', 'candidate') if key in result}, sort_keys=True))
    return 0 if result['status'] in ('eligible-for-adoption', 'retain-baseline', 'retained-baseline') else 2


if __name__ == '__main__':
    sys.exit(main())
