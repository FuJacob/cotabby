#!/usr/bin/env python3
"""Revalidate ranking rows against authoritative completed reports before decisions."""
import hashlib
import json
import math
from pathlib import Path

HERE = Path(__file__).resolve().parent


def case_inputs(report, ids):
    """Check complete paired cases and retain exact Swift inputs, without rescoring text."""
    if report.get('schemaVersion') != 2 or set(report['conditions']) != {'none', 'screen'}:
        raise ValueError('Screening needs the complete version2 paired report')
    cases = {}
    counters = {}
    for row in report['phrases']:
        key = (row['phrase']['id'], row['condition'])
        if key in cases:
            raise ValueError('Duplicate report phrase-condition identity')
        observations = row['observations']
        points = [item['checkpoint'] for item in observations]
        if (not points or any(point['typedCharacters'] != 0 for point in points)
                or [point['wordIndex'] for point in points] != list(range(1, len(points) + 1))):
            raise ValueError('Incomplete or non-word screening checkpoints')
        if any(type(item['correct']) is not bool or type(item['wasShown']) is not bool for item in observations):
            raise ValueError('Authoritative Swift outcome flags must be Boolean')
        count = {'checkpoints': len(points), 'correct': sum(item['correct'] for item in observations),
                 'shown': sum(item['wasShown'] for item in observations),
                 'errors': sum(item.get('error') is not None for item in observations)}
        for metric in ('all', 'nextWord'):
            if any(row[metric][name] != value for name, value in count.items()):
                raise ValueError('Phrase scores disagree with authoritative Swift flags')
        counters[key] = count
        cases[key] = (row['phrase'], points)
    expected = {(phrase_id, condition) for phrase_id in ids for condition in ('none', 'screen')}
    if set(cases) != expected:
        raise ValueError('Executed report IDs differ from registered screening cases')
    for phrase_id in ids:
        if cases[(phrase_id, 'none')] != cases[(phrase_id, 'screen')]:
            raise ValueError('Paired conditions changed reference/checkpoint inputs')
    for condition, aggregate in report['conditions'].items():
        selected = [key for key in cases if key[1] == condition]
        if aggregate['suite']['phraseCount'] != len(ids):
            raise ValueError('Suite phrase count differs from actual paired cases')
        for metric in ('all', 'nextWord'):
            if any(aggregate['suite'][metric][name] != sum(counters[key][name] for key in selected)
                   for name in ('checkpoints', 'correct', 'shown', 'errors')):
                raise ValueError('Suite scores disagree with authoritative Swift flags')
    return cases


def validate_rows(rows):
    def read(relative):
        return json.loads((HERE / relative).read_text())
    registered = read('candidate-source-registration.json')
    prompt_variants = dict(registered['promptVariants']['variants'])
    prompt_variants.update(read('combination-sources/manifest.json')['variants'])
    native_variants = registered['nativeVariants']['variants']
    model_hash = read('round.json')['modelSHA256']
    ids = set(read('screening-ids.json'))
    if len(ids) != 140:
        raise ValueError('Expected exactly140 registered screening cases')
    if len({row['candidate'] for row in rows}) != len(rows):
        raise ValueError('Duplicate ranked candidate')
    baseline_rows = [row for row in rows if row['candidate'] == 'baseline']
    if len(baseline_rows) != 1:
        raise ValueError('Ranking requires exactly one baseline')
    baseline = read(baseline_rows[0]['label'] + '/report.json')
    baseline_inputs = case_inputs(baseline, ids)
    corpus_hash = read('starting-snapshot.json')['app']['after']['files'][
        'CotabbyTests/Fixtures/phrase-prediction-1337.json']['sha256']
    for row in rows:
        label = row['label']
        if Path(label).name != label:
            raise ValueError('Ranking label is not a local artifact name')
        components = [] if row['candidate'] == 'baseline' else row['candidate'].split('+')
        if components != row['components']:
            raise ValueError('Ranking candidate/components disagree')
        registration = read(label + '-registration.json')
        report = read(label + '/report.json')
        manifest = read(label + '/manifest.json')
        for path, expected in [(label + '-registration.json', row['registrationSHA256']),
                               (label + '/report.json', row['reportSHA256'])]:
            if hashlib.sha256((HERE / path).read_bytes()).hexdigest() != expected:
                raise ValueError('Ranked evidence hash changed')
        if any(registration[key] != expected for key, expected in {
            'label': label, 'candidate': row['candidate'], 'components': components,
            'status': 'complete', 'phase': 'screening'}.items()):
            raise ValueError('Ranking disagrees with its completed registration')
        metadata = report['metadata']
        effective = {'temperature': .1, 'repetitionPenalty': 1.025, 'topK': 20, 'topP': .7, 'minP': .08}
        if any(not math.isclose(float(metadata['configuration'][name]), value, rel_tol=1e-12, abs_tol=1e-12)
               for name, value in effective.items()):
            raise ValueError('Effective report sampling differs from registered screening settings')
        if (metadata['seed'] != 42 or report['errorCount']
                or report['metadata']['configuration']['modelSHA256'] != model_hash
                or metadata['mode'] != 'word' or metadata['contextMode'] != 'paired'
                or metadata['workerCount'] != 3 or metadata['runLabel'] != label
                or metadata['corpusVersion'] != 2 or metadata['corpusSHA256'] != corpus_hash
                or manifest['corpusSHA256'] != corpus_hash
                or manifest['corpusInput']['sha256'] != corpus_hash or manifest['corpusInput']['version'] != 2
                or manifest['label'] != label
                or manifest['mode'] != 'word' or manifest['contextMode'] != 'paired'
                or manifest['workerCount'] != 3 or set(manifest['phraseIDs']) != ids
                or len(manifest['phraseIDs']) != len(ids)
                or manifest['samplingOverrides'] != {'temperature': .1, 'repetition_penalty': 1.025,
                    'top_k': 20, 'top_p': .7, 'min_p': .08, 'seed': 42}
                or manifest['selection'] != {'split': 'screen', 'splitSeed': 1337,
                    'screenPerCategory': 20, 'perCategory': None, 'limit': None}):
            raise ValueError('Ranked report/manifest changed the registered screening inputs')
        if case_inputs(report, ids) != baseline_inputs:
            raise ValueError('Ranked report changed full phrase or checkpoint inputs from baseline')
        checks = json.loads(Path(registration['checks']).read_text())
        if checks['status'] != 'passed' or checks['buildInputs'] != manifest['buildInputs']:
            raise ValueError('Ranked replay does not bind its passed correctness checks')
        if manifest['build']['sourceSHA256'] != checks['buildInputs']['sourceSHA256'] or manifest['build']['reused'] is not False:
            raise ValueError('Ranked replay lacks a fresh build of the checked source')
        prompt_key = '+'.join(c for c in components if c[0] in 'FM') or 'baseline'
        history_key = next((c for c in components if c.startswith('H')), 'baseline')
        if (registration['promptSource']['hashes'] != prompt_variants[prompt_key]['hashes']
                or registration['nativeSource']['sha256'] != native_variants[history_key]['sha256']):
            raise ValueError('Ranked source targets do not match the named registered alternative')
        for condition, key in [('screen', 'screenCorrect'), ('none', 'noneCorrect')]:
            score = report['conditions'][condition]['suite']['nextWord']
            if (score['checkpoints'] != 770 or score['errors'] or row[key] != score['correct']
                    or row['checkpointsPerCondition'] != 770
                    or registration['scores'][condition] != score):
                raise ValueError('Ranking aggregate differs from authoritative Swift report')
    return rows
