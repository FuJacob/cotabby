#!/usr/bin/env python3
"""Invented fixtures for descriptive baseline analysis; no benchmark data is opened.

The statistics double records cluster inputs without running a costly bootstrap. Disk
tests create only tiny registrations and opaque synthetic plans in temporary folders.
"""
import copy
import importlib.util
import json
from pathlib import Path
import tempfile
import unittest
from unittest import mock


HERE = Path(__file__).resolve().parent


def module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result


SUBJECT = module('baseline_characterization_subject', HERE / 'characterize_baseline.py')
FIXTURES = module('baseline_characterization_invented_fixtures', HERE / 'test_assess_round2.py')


class RecordingAnalyzer:
    """Expose exactly which conditions and families the characterizer resamples."""
    def __init__(self):
        self.calls = []

    def paired_statistics(self, old, new, **kwargs):
        self.calls.append((old, new, kwargs))
        conditions = {condition for _, condition in old}
        categories = {row['phrase']['category'] for row in old.values()}
        clusters = {category: {row['phrase'].get('evaluationGroup', row['phrase']['id'])
                              for row in old.values() if row['phrase']['category'] == category}
                    for category in categories}
        return {'samples': kwargs['samples'], 'seed': kwargs['seed'], 'clusterUnit': 'evaluationGroup',
                'clusterCounts': {category: len(groups) for category, groups in clusters.items()},
                'accuracyDeltaIntervals': {condition + '/' + category: [-.1, .1]
                    for condition in conditions for category in ('suite', *sorted(categories))}}


def invented_index(none=(False, True, False), screen=(True, False, True), categories=('science',)):
    report, plan, _ = FIXTURES.tiny_evidence(categories=categories)
    for row in report['phrases']:
        values = none if row['condition'] == 'none' else screen
        for observation, correct in zip(row['observations'], values):
            observation['correct'] = correct
        row['phrase'].update(evaluationGroup='family-' + row['phrase']['category'],
                            contextKind='useful' if row['phrase']['category'] == 'science' else 'distracting')
    FIXTURES.refresh_aggregates(report)
    return FIXTURES.SUBJECT.validate_report(report, plan)


def invented_run(indexed, seed=42, workers=3):
    return {'index': indexed, 'metadata': {'seed': seed,
                'configuration': {'randomSeed': f'Optional({seed})', 'temperature': '0.1'}},
            'manifest': {'workerCount': workers}}


def nested_keys(value):
    if isinstance(value, dict):
        return set(value) | set().union(*(nested_keys(item) for item in value.values()), set())
    if isinstance(value, list):
        return set().union(*(nested_keys(item) for item in value), set())
    return set()


class ContrastTests(unittest.TestCase):
    def test_context_effect_is_screen_minus_none_with_one_record_per_checkpoint(self):
        indexed = invented_index()
        analyzer = RecordingAnalyzer()
        result = SUBJECT.context_contrast(indexed, analyzer)
        row = result['deltas']['suite']
        self.assertEqual(row['accuracyDelta'], 1)
        self.assertEqual((row['helped'], row['harmed']), (2, 0))
        self.assertEqual(row['withoutScreen']['checkpoints'], 2)
        before, after, kwargs = analyzer.calls[0]
        self.assertEqual({condition for _, condition in before}, {'screenMinusNone'})
        self.assertEqual(set(before), set(after))
        self.assertEqual(len(before), 1)
        self.assertEqual(sum(len(row['observations']) for row in before.values()), 2)
        self.assertEqual(kwargs, {'samples': 20000, 'seed': 1337, 'metric': 'all'})

    def test_family_clusters_survive_projection_and_category_intervals_remain(self):
        indexed = invented_index(categories=('science', 'science', 'work'))
        analyzer = RecordingAnalyzer()
        result = SUBJECT.context_contrast(indexed, analyzer, 'partial')
        before, after, _ = analyzer.calls[0]
        self.assertEqual(len(before), 3)
        self.assertEqual(result['bootstrap']['clusterCounts'], {'science': 1, 'work': 1})
        self.assertTrue(all(row['phrase']['evaluationGroup'] == after[key]['phrase']['evaluationGroup']
                            for key, row in before.items()))
        self.assertIn('screenMinusNone/science', result['bootstrap']['accuracyDeltaIntervals'])
        self.assertIn('screenMinusNone/work', result['bootstrap']['accuracyDeltaIntervals'])

    def test_context_kind_filter_drops_other_groups_without_altering_families(self):
        analyzer = RecordingAnalyzer()
        result = SUBJECT.context_contrast(invented_index(categories=('science', 'work')), analyzer,
                                          context_kind='useful')
        self.assertEqual(set(result['deltas']), {'suite', 'science'})
        self.assertEqual(len(analyzer.calls[0][0]), 1)
        self.assertEqual(next(iter(analyzer.calls[0][0].values()))['phrase']['evaluationGroup'], 'family-science')

    def test_partial_loss_is_visible_despite_word_boundary_gain(self):
        indexed = invented_index()
        boundary = SUBJECT.context_contrast(indexed, RecordingAnalyzer(), 'word')
        partial = SUBJECT.context_contrast(indexed, RecordingAnalyzer(), 'partial')
        combined = SUBJECT.context_contrast(indexed, RecordingAnalyzer(), 'all')
        self.assertEqual(boundary['deltas']['suite']['accuracyDelta'], 1)
        self.assertEqual(partial['deltas']['suite']['accuracyDelta'], -1)
        self.assertGreater(combined['deltas']['suite']['accuracyDelta'], 0)
        metrics = SUBJECT.subset_metrics(indexed, 'partial')
        self.assertEqual(metrics['none']['suite']['correct'], 1)
        self.assertEqual(metrics['screen']['suite']['correct'], 0)
        self.assertEqual(metrics['screen']['science']['checkpoints'], 1)

    def test_context_contrast_rejects_different_condition_task_identity(self):
        indexed = invented_index()
        indexed[('invented-0', 'screen')]['observations'][0]['checkpoint']['prefix'] = 'Different task '
        with self.assertRaisesRegex(SUBJECT.EvidenceError, 'Context contrast inputs differ'):
            SUBJECT.context_contrast(indexed, RecordingAnalyzer())

    def test_seed_effect_and_context_effect_are_distinct_comparisons(self):
        first = invented_run(invented_index(none=(False, False, False), screen=(True, False, False)), 42)
        second = invented_run(invented_index(none=(True, False, False), screen=(True, False, True)), 12648430)
        for run in (first, second):
            result = SUBJECT.context_contrast(run['index'], RecordingAnalyzer())
            self.assertEqual(result['deltas']['suite']['accuracyDelta'], .5)
        sensitivity = SUBJECT.seed_comparison(first, second, RecordingAnalyzer())
        self.assertEqual(sensitivity['referenceSeed'], 42)
        self.assertEqual(sensitivity['comparisonSeed'], 12648430)
        for condition in ('none', 'screen'):
            self.assertEqual(sensitivity['deltas'][condition]['suite']['accuracyDelta'], .5)
            self.assertIn('reference', sensitivity['deltas'][condition]['suite'])
            self.assertIn('comparison', sensitivity['deltas'][condition]['suite'])
        self.assertFalse(any(key.startswith('latency') for key in nested_keys(sensitivity)))

    def test_seed_comparison_rejects_same_seed_worker_or_unrelated_config_changes(self):
        first = invented_run(invented_index(), 42)
        for mutation in ('same_seed', 'workers', 'configuration'):
            with self.subTest(mutation=mutation):
                second = invented_run(invented_index(), 1337)
                if mutation == 'same_seed':
                    second['metadata']['seed'] = 42
                elif mutation == 'workers':
                    second['manifest']['workerCount'] = 1
                else:
                    second['metadata']['configuration']['temperature'] = '.2'
                with self.assertRaises(SUBJECT.EvidenceError):
                    SUBJECT.seed_comparison(first, second, RecordingAnalyzer())

    def test_exact_parity_excludes_latency_but_detects_prompt_and_display_drift(self):
        first = invented_run(invented_index())
        second = copy.deepcopy(first)
        second['index'][('invented-0', 'screen')]['observations'][0]['latencyMilliseconds'] = 999
        self.assertTrue(SUBJECT.exact_parity(first, second)['identical'])
        observation = second['index'][('invented-0', 'screen')]['observations'][0]
        observation['prompt'] = 'Changed invented prompt'
        observation['shown'] = 'Changed invented display'
        result = SUBJECT.exact_parity(first, second)
        self.assertFalse(result['identical'])
        self.assertEqual(result['conditions']['screen']['anyMismatch'], 1)
        self.assertEqual(result['conditions']['screen']['fieldMismatches']['prompt'], 1)
        self.assertEqual(result['conditions']['screen']['fieldMismatches']['shown'], 1)

    def test_descriptive_outputs_contain_no_adoption_gate_or_finalist_fields(self):
        first, second = invented_run(invented_index(), 42), invented_run(invented_index(), 1337)
        with mock.patch.object(SUBJECT.BASE, 'quality_gates', side_effect=AssertionError('Adoption gate must not run')):
            outputs = [SUBJECT.context_contrast(first['index'], RecordingAnalyzer()),
                       SUBJECT.seed_comparison(first, second, RecordingAnalyzer()),
                       SUBJECT.exact_parity(first, copy.deepcopy(first)),
                       SUBJECT.subset_metrics(first['index'], 'partial')]
        for output in outputs:
            self.assertFalse({'gates', 'finalist', 'eligibleForAdoption', 'allRequiredGatesPassed'} & nested_keys(output))


class WorkloadTests(unittest.TestCase):
    def setUp(self):
        self.directory = tempfile.TemporaryDirectory(prefix='baseline-characterization-unit-')
        self.addCleanup(self.directory.cleanup)
        self.root = Path(self.directory.name)

    def write(self, name, value):
        path = self.root / name
        path.parent.mkdir(parents=True, exist_ok=True)
        data = (json.dumps(value, sort_keys=True) + '\n').encode()
        path.write_bytes(data)
        return {'path': name, 'sha256': SUBJECT.BASE.digest(data)}

    def workload(self, kind='historicalWord', *, exception_changes=None, record_changes=None):
        reader = SUBJECT.BaselineCharacterization(self.root)
        frozen = {'candidate': 'baseline', 'frozenUTC': '2020-01-01T09:00:00Z'}
        freeze_ref = self.write('finalist-freeze.json', frozen)
        reader.frozen = frozen
        reader.round_record = {'deadlineUTC': '2020-01-01T15:00:00Z'}
        fresh = kind in ('freshWord', 'freshCharacter')
        row = {'name': 'invented-' + kind, 'label': 'invented-run', 'kind': kind, 'seed': 42,
               'workerCount': 3, 'perCategory': 0, 'estimatedSeconds': 30,
               'mode': 'character' if 'Character' in kind else 'word', 'selection': 'all',
               'corpusSHA256': SUBJECT.BASE.FRESH_CORPUS_SHA if fresh else SUBJECT.BASE.OLD_CORPUS_SHA}
        if kind == 'freshCharacter':
            exception = {'schemaVersion': 1, 'candidate': 'baseline', 'descriptiveOnly': True,
                         'allowedKind': 'freshCharacter', 'freezeSHA256': freeze_ref['sha256'],
                         'reason': 'Invented registered descriptive guard exception.',
                         'registeredUTC': '2020-01-01T09:04:00Z'}
            exception.update(exception_changes or {})
            row['guardException'] = self.write('invented-exception.json', exception)
        record = {'schemaVersion': 1, 'candidate': 'baseline', 'purpose': 'Invented baseline-only characterization.',
                  'freezeSHA256': freeze_ref['sha256'], 'registeredUTC': '2020-01-01T09:05:00Z', 'runs': [row]}
        record.update(record_changes or {})
        reference = self.write('invented-workload.json', record)
        spec = {key: row[key] for key in ('name', 'label', 'kind', 'seed')}
        spec['workload'] = reference
        plan = {key: row[key] for key in ('mode', 'corpusSHA256', 'selection', 'perCategory')}
        registration = {'startedUTC': '2020-01-01T09:10:00Z', 'candidate': 'baseline'}
        if kind == 'freshCharacter':
            registration['validationAdmission'] = {'descriptiveWorkload': {
                'descriptiveOnly': True, 'kind': kind, 'name': row['name'], 'seed': row['seed'],
                'workerCount': row['workerCount'], 'estimatedSeconds': row['estimatedSeconds'],
                'workload': reference, 'guardException': row['guardException']}}
        return reader, reference, spec, plan, registration, record

    def test_registered_workload_must_precede_run_and_match_all_input_fields(self):
        reader, ref, spec, plan, registration, _ = self.workload()
        reader.register_workload(ref)
        self.assertEqual(reader.validate_workload(spec, plan, registration)['seed'], 42)
        for mutation in ('late', 'seed', 'cohort', 'artifact'):
            with self.subTest(mutation=mutation):
                changed_spec, changed_plan, changed_registration = copy.deepcopy(spec), copy.deepcopy(plan), copy.deepcopy(registration)
                if mutation == 'late':
                    changed_registration['startedUTC'] = '2020-01-01T09:04:00Z'
                elif mutation == 'seed':
                    changed_spec['seed'] = 1337
                elif mutation == 'cohort':
                    changed_plan['perCategory'] = 50
                else:
                    changed_spec['workload'] = {'path': 'different.json', 'sha256': 'a' * 64}
                with self.assertRaises(SUBJECT.EvidenceError):
                    reader.validate_workload(changed_spec, changed_plan, changed_registration)

    def test_candidate_or_wrong_freeze_workload_is_rejected(self):
        for changes in ({'candidate': 'F1'}, {'freezeSHA256': 'a' * 64}):
            with self.subTest(changes=changes):
                reader, ref, _, _, _, _ = self.workload(record_changes=changes)
                with self.assertRaises(SUBJECT.EvidenceError):
                    reader.register_workload(ref)

    def test_missing_workload_or_duplicate_planned_label_is_rejected(self):
        reader, ref, spec, plan, registration, record = self.workload()
        with self.assertRaisesRegex(SUBJECT.EvidenceError, 'lacks a hash-bound workload'):
            reader.validate_workload(spec, plan, registration)
        record['runs'].append(copy.deepcopy(record['runs'][0]))
        ref = self.write('invented-workload.json', record)
        with self.assertRaisesRegex(SUBJECT.EvidenceError, 'Duplicate/empty'):
            reader.register_workload(ref)

    def test_registration_outside_frozen_round_window_is_rejected(self):
        for stamp in ('2020-01-01T08:59:59Z', '2020-01-01T15:00:01Z'):
            with self.subTest(stamp=stamp):
                reader, ref, _, _, _, _ = self.workload(record_changes={'registeredUTC': stamp})
                with self.assertRaisesRegex(SUBJECT.EvidenceError, 'outside the frozen round window'):
                    reader.register_workload(ref)

    def test_fresh_character_exception_is_explicit_baseline_only_and_bounded(self):
        reader, ref, spec, plan, registration, _ = self.workload('freshCharacter')
        reader.register_workload(ref)
        self.assertEqual(reader.validate_workload(spec, plan, registration)['kind'], 'freshCharacter')
        for changes in ({'candidate': 'F1'}, {'descriptiveOnly': False}, {'allowedKind': 'freshWord'},
                        {'freezeSHA256': 'a' * 64}, {'registeredUTC': '2020-01-01T09:11:00Z'}):
            with self.subTest(changes=changes):
                reader, ref, spec, plan, registration, _ = self.workload('freshCharacter', exception_changes=changes)
                reader.register_workload(ref)
                with self.assertRaisesRegex(SUBJECT.EvidenceError, 'missing or overbroad'):
                    reader.validate_workload(spec, plan, registration)

    def test_guard_exception_cannot_be_attached_to_another_workload(self):
        reader, _, spec, plan, registration, record = self.workload('historicalWord')
        record['runs'][0]['guardException'] = {'path': 'not-opened.json', 'sha256': 'a' * 64}
        ref = self.write('invented-workload.json', record)
        spec['workload'] = ref
        reader.register_workload(ref)
        with self.assertRaisesRegex(SUBJECT.EvidenceError, 'Unexpected workload guard exception'):
            reader.validate_workload(spec, plan, registration)

    def test_fresh_character_requires_actual_runner_admission_bound_to_workload(self):
        reader, ref, spec, plan, registration, _ = self.workload('freshCharacter')
        reader.register_workload(ref)
        for mutation in ('missing', 'seed', 'workload_hash'):
            changed = copy.deepcopy(registration)
            if mutation == 'missing':
                changed.pop('validationAdmission')
            elif mutation == 'seed':
                changed['validationAdmission']['descriptiveWorkload']['seed'] = 1337
            else:
                changed['validationAdmission']['descriptiveWorkload']['workload']['sha256'] = '0' * 64
            with self.subTest(mutation=mutation), self.assertRaises(SUBJECT.EvidenceError):
                reader.validate_workload(spec, plan, changed)

    def opaque_fresh_character_plan(self):
        # These are opaque IDs and integer coordinates, with no corpus answers or text.
        rows = [{'phraseID': f'unit-{category}-{i}', 'category': category,
                 'checkpoints': [{'wordIndex': 1, 'typedCharacters': 0}, {'wordIndex': 1, 'typedCharacters': 1}]}
                for category in sorted(SUBJECT.BASE.CATEGORIES) for i in range(100)]
        return {'schemaVersion': 1, 'corpusSHA256': SUBJECT.BASE.FRESH_CORPUS_SHA, 'scorerSourceSHA256': 'b' * 64,
                'corpusVersion': 3, 'mode': 'character', 'selection': 'all', 'perCategory': 0,
                'phraseCount': 700, 'checkpointsPerCondition': 1400, 'phrases': rows}

    def test_fresh_character_cohort_is_full_and_does_not_relax_frozen_word_gate(self):
        reader = SUBJECT.BaselineCharacterization(self.root)
        reader.checkpoint_exporter = {'scorerSource': {'sha256': 'b' * 64}}
        plan = self.opaque_fresh_character_plan()
        reader.validate_descriptive_cohort(plan, 'freshCharacter')
        with self.assertRaises(SUBJECT.EvidenceError):
            SUBJECT.BASE.Assessment.validate_cohort(reader, plan, 'fresh')
        for key, value in [('selection', 'screen'), ('perCategory', 50), ('mode', 'word'), ('corpusVersion', 2)]:
            with self.subTest(key=key):
                changed = copy.deepcopy(plan)
                changed[key] = value
                with self.assertRaises(SUBJECT.EvidenceError):
                    reader.validate_descriptive_cohort(changed, 'freshCharacter')

    def test_late_workload_blocks_loader_before_any_report_is_opened(self):
        reader, ref, spec, plan, registration, _ = self.workload()
        reader.register_workload(ref)
        spec['checkpoints'] = self.write('invented-plan.json', plan)
        reader.checkpoint_exporter = {'manifests': [spec['checkpoints']]}
        registration['startedUTC'] = '2020-01-01T09:04:00Z'
        self.write(spec['label'] + '-registration.json', registration)
        with mock.patch.object(reader, 'validate_descriptive_cohort'), mock.patch.object(reader, 'load_run') as load:
            with self.assertRaisesRegex(SUBJECT.EvidenceError, 'registered after the run started'):
                reader.load_descriptive_run(spec)
        load.assert_not_called()

    def compatibility_fixture(self):
        reader = SUBJECT.BaselineCharacterization(self.root)
        frozen = {'candidate': 'baseline', 'frozenUTC': '2020-01-01T09:00:00Z',
                  'baselineTargets': {'renderer': '1' * 64, 'composer': '2' * 64, 'nativeEngine': '3' * 64}}
        freeze_ref = self.write('finalist-freeze.json', frozen)
        reader.frozen = frozen
        reader.round_record = {'deadlineUTC': '2020-01-01T15:00:00Z'}
        browser = 'app/Cotabby/Support/Focus/Applications/BrowserAppDetector.swift'
        files = {path: frozen['baselineTargets'][name] for name, path in SUBJECT.BASE.TARGET_PATHS.items()}
        files[browser] = 'b' * 64
        frozen_inventory = {'schemaVersion': 1, 'scope': SUBJECT.BASE.PRODUCTION_SCOPE, 'files': files}
        current_inventory = copy.deepcopy(frozen_inventory)
        current_inventory['files'][browser] = 'c' * 64
        reader.inventories = {'baseline': frozen_inventory}
        frozen_ref = self.write('invented-frozen-inventory.json', frozen_inventory)
        current_ref = self.write('invented-current-inventory.json', current_inventory)
        scope = {'schemaVersion': 1, 'status': 'passed', 'affectedBundleIdentifiers': ['com.openai.codex'],
                 'sources': [{'kind': kind, 'corpusSHA256': corpus, 'phraseCount': count, 'matchingScenarioCount': 0}
                     for kind, corpus, count in [('historical', SUBJECT.BASE.OLD_CORPUS_SHA, 1337),
                                                ('fresh', SUBJECT.BASE.FRESH_CORPUS_SHA, 700)]]}
        certificate = {'schemaVersion': 1, 'status': 'reviewed', 'reviewer': '/root',
            'rationale': 'Invented narrow fixture compatibility review.', 'allOtherProductionInputsEqual': True,
            'baselineFreezeSHA256': freeze_ref['sha256'], 'reviewedUTC': '2020-01-01T09:07:00Z',
            'frozenInventory': frozen_ref, 'currentInventory': current_ref,
            'differences': [{'path': browser, 'beforeSHA256': 'b' * 64, 'afterSHA256': 'c' * 64}],
            'diff': self.write('invented-reviewed-diff.json', {'diff': 'Invented reviewed patch bytes.'}),
            'fixtureScopeProof': self.write('invented-scope.json', scope)}
        item = {'role': 'baseline', 'label': 'current-main-unit-run', 'sourceSHA256': 'd' * 64,
                'targets': copy.deepcopy(frozen['baselineTargets']), 'productionInventory': current_ref,
                'compatibilityDifference': self.write('invented-certificate.json', certificate)}
        return reader, item, certificate, current_inventory, scope

    def test_narrow_compatibility_certificate_is_accepted_only_by_descriptive_reader(self):
        reader, item, _, _, _ = self.compatibility_fixture()
        reader.add_binding(item)
        self.assertIn(item['label'], reader.descriptive_bindings)
        self.assertEqual(reader.expected_source(item['label'], 'baseline'), item['sourceSHA256'])
        with self.assertRaises(SUBJECT.EvidenceError):
            SUBJECT.BASE.Assessment.add_binding(reader, item)

    def test_compatibility_rejects_extra_production_difference(self):
        reader, item, certificate, current, _ = self.compatibility_fixture()
        current['files']['app/Cotabby/InventedExtraBehavior.swift'] = 'e' * 64
        reference = self.write('invented-current-inventory.json', current)
        certificate['currentInventory'] = reference
        item['productionInventory'] = reference
        item['compatibilityDifference'] = self.write('invented-certificate.json', certificate)
        with self.assertRaisesRegex(SUBJECT.EvidenceError, 'additional production difference'):
            reader.add_binding(item)

    def test_compatibility_rejects_changed_target_or_wrong_role(self):
        for mutation in ('target', 'role'):
            with self.subTest(mutation=mutation):
                reader, item, _, _, _ = self.compatibility_fixture()
                if mutation == 'target':
                    item['targets']['renderer'] = 'e' * 64
                else:
                    item['role'] = 'finalist'
                with self.assertRaisesRegex(SUBJECT.EvidenceError, 'frozen baseline target bytes'):
                    reader.add_binding(item)

    def test_compatibility_rejects_another_path_even_if_reviewed(self):
        reader, item, certificate, _, _ = self.compatibility_fixture()
        certificate['differences'][0]['path'] = 'app/Cotabby/Support/Focus/InventedOtherDetector.swift'
        item['compatibilityDifference'] = self.write('invented-certificate.json', certificate)
        with self.assertRaisesRegex(SUBJECT.EvidenceError, 'limited to the reviewed BrowserAppDetector'):
            reader.add_binding(item)

    def test_compatibility_rejects_fixture_overlap_or_wrong_corpus(self):
        for mutation in ('affected_fixture', 'corpus'):
            with self.subTest(mutation=mutation):
                reader, item, certificate, _, scope = self.compatibility_fixture()
                if mutation == 'affected_fixture':
                    scope['sources'][1]['matchingScenarioCount'] = 1
                else:
                    scope['sources'][1]['corpusSHA256'] = 'e' * 64
                certificate['fixtureScopeProof'] = self.write('invented-scope.json', scope)
                item['compatibilityDifference'] = self.write('invented-certificate.json', certificate)
                with self.assertRaisesRegex(SUBJECT.EvidenceError, 'both exact corpora'):
                    reader.add_binding(item)

    def test_compatibility_review_after_run_blocks_report_loader(self):
        reader, item, certificate, _, _ = self.compatibility_fixture()
        certificate['reviewedUTC'] = '2020-01-01T09:11:00Z'
        item['compatibilityDifference'] = self.write('invented-certificate.json', certificate)
        reader.add_binding(item)
        row = {'name': 'current-main-unit', 'label': item['label'], 'kind': 'historicalWord', 'seed': 42,
               'workerCount': 3, 'perCategory': 0, 'estimatedSeconds': 30, 'mode': 'word', 'selection': 'all',
               'corpusSHA256': SUBJECT.BASE.OLD_CORPUS_SHA}
        record = {'schemaVersion': 1, 'candidate': 'baseline', 'purpose': 'Invented compatibility replay.',
                  'freezeSHA256': certificate['baselineFreezeSHA256'],
                  'registeredUTC': '2020-01-01T09:05:00Z', 'runs': [row]}
        workload_ref = self.write('invented-workload.json', record)
        reader.register_workload(workload_ref)
        plan = {key: row[key] for key in ('mode', 'corpusSHA256', 'selection', 'perCategory')}
        checkpoint_ref = self.write('invented-plan.json', plan)
        reader.checkpoint_exporter = {'manifests': [checkpoint_ref]}
        self.write(item['label'] + '-registration.json', {'startedUTC': '2020-01-01T09:10:00Z'})
        spec = {key: row[key] for key in ('name', 'label', 'kind', 'seed')}
        spec.update(workload=workload_ref, checkpoints=checkpoint_ref)
        with mock.patch.object(reader, 'validate_descriptive_cohort'), mock.patch.object(reader, 'load_run') as load:
            with self.assertRaisesRegex(SUBJECT.EvidenceError, 'reviewed after the run started'):
                reader.load_descriptive_run(spec)
        load.assert_not_called()

    def complete_characterization_fixture(self, kind='historicalCharacter'):
        reader, reference, spec, _, registration, record = self.workload(kind)
        if kind == 'latency':
            record['runs'][0]['workerCount'] = 1
            reference = self.write('invented-workload.json', record)
            spec['workload'] = reference
        reader.frozen.update(selectionQualified=False, modelSHA256='e' * 64, baselineSourceSHA256='c' * 64)
        reader.validate_freeze = mock.Mock(return_value=reader.frozen)
        reader.exporter = mock.Mock()
        reader.final_tests = mock.Mock(return_value={'status': 'passed'})
        run = invented_run(invented_index(), workers=1 if kind == 'latency' else 3)
        run.update(name=spec['name'], label=spec['label'], kind=spec['kind'], sourceSHA256='c' * 64,
            plan={'mode': 'character' if 'Character' in kind else 'word', 'corpusVersion': 2, 'corpusSHA256': SUBJECT.BASE.OLD_CORPUS_SHA,
                  'phraseCount': 1, 'checkpointsPerCondition': 3})
        reader.load_descriptive_run = mock.Mock(return_value=run)
        registration.update(label=spec['label'], phase='validation', status='complete')
        self.write(spec['label'] + '-registration.json', registration)
        self.write('execution.json', {'root': str(self.root)})
        analyzer_path = self.root / 'scripts/analyze_phrase_experiments.py'
        analyzer_path.parent.mkdir(parents=True, exist_ok=True)
        analyzer_path.write_text("def paired_statistics(old, new, **kwargs):\n"
            "    return dict(samples=kwargs['samples'], seed=kwargs['seed'], clusterUnit='evaluationGroup', accuracyDeltaIntervals={})\n")
        self.write('invented-characterization.json', {'schemaVersion': 1, 'checkpointExporter': {},
            'plannedWorkloads': [reference], 'runs': [spec], 'focusedTests': []})
        return reader, spec

    def test_complete_characterization_stays_descriptive_and_reports_partial_loss(self):
        reader, spec = self.complete_characterization_fixture()
        with mock.patch.object(SUBJECT.BASE, 'quality_gates', side_effect=AssertionError('No adoption gates')):
            result = reader.characterize('invented-characterization.json')
        self.assertEqual(result['status'], 'descriptive-only')
        self.assertEqual((result['completedRunCount'], result['plannedRunCount']), (1, 1))
        self.assertEqual(result['issues'], [])
        subsets = result['runs'][spec['name']]['subsets']
        self.assertEqual(set(subsets), {'word', 'partial', 'all'})
        self.assertEqual(subsets['partial']['contextContrast']['deltas']['suite']['accuracyDelta'], -1)
        self.assertFalse({'gates', 'finalist', 'eligibleForAdoption', 'allRequiredGatesPassed'} & nested_keys(result))
        self.assertFalse(any(key.startswith('latency') for key in nested_keys(result['runs'])))

    def test_latency_workload_cannot_report_complete_without_isolation_entry(self):
        reader, _ = self.complete_characterization_fixture('latency')
        result = reader.characterize('invented-characterization.json')
        self.assertEqual(result['status'], 'incomplete-or-invalid')
        self.assertTrue(result['issues'])

    def test_latency_timings_require_successful_isolation_validation(self):
        reader, spec = self.complete_characterization_fixture('latency')
        evidence = json.loads((self.root / 'invented-characterization.json').read_text())
        evidence['latencyRuns'] = [{'name': spec['name'], 'isolation': {'invented': True}}]
        self.write('invented-characterization.json', evidence)
        reader.validate_isolation = mock.Mock()
        result = reader.characterize('invented-characterization.json')
        self.assertEqual(result['status'], 'descriptive-only')
        reader.validate_isolation.assert_called_once()
        self.assertEqual(result['latency'][spec['name']]['conditions']['screen']['latencyP95Milliseconds'], 100)

    def test_characterization_rejects_candidate_freeze_before_opening_evidence(self):
        reader = SUBJECT.BaselineCharacterization(self.root)
        reader.validate_freeze = mock.Mock(return_value={'candidate': 'F1', 'selectionQualified': True})
        with mock.patch.object(reader, 'read_json', side_effect=AssertionError('Evidence must stay unopened')):
            with self.assertRaisesRegex(SUBJECT.EvidenceError, 'baseline-retention decision'):
                reader.characterize('never-opened.json')

    def test_loader_always_requests_baseline_role_and_checks_registered_workers(self):
        reader, ref, spec, plan, registration, _ = self.workload()
        reader.register_workload(ref)
        spec['checkpoints'] = self.write('invented-plan.json', plan)
        reader.checkpoint_exporter = {'manifests': [spec['checkpoints']]}
        self.write(spec['label'] + '-registration.json', registration)
        with mock.patch.object(reader, 'validate_descriptive_cohort'), mock.patch.object(reader, 'load_run',
                return_value={'manifest': {'workerCount': 3}}) as load:
            result = reader.load_descriptive_run(spec)
        self.assertEqual(load.call_args.args[1], 'baseline')
        self.assertEqual(result['kind'], 'historicalWord')
        with mock.patch.object(reader, 'validate_descriptive_cohort'), mock.patch.object(reader, 'load_run',
                return_value={'manifest': {'workerCount': 1}}):
            with self.assertRaisesRegex(SUBJECT.EvidenceError, 'workers differ from registered workload'):
                reader.load_descriptive_run(spec)


if __name__ == '__main__':
    unittest.main()
