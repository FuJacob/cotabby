#!/usr/bin/env python3
"""Opt-in test-host launch adapter around the byte-verified frozen phrase CLI.

Only one temporary CotabbyTests xctestrun target gains a process argument. No source,
product, sampler, scorer, corpus, environment, or persistent preference is changed by this adapter.
"""
import argparse,copy,datetime as dt,hashlib,importlib.util,json,plistlib,sys
from pathlib import Path
HERE=Path(__file__).resolve().parent
ROOT=Path(json.loads((HERE/'execution.json').read_text())['root'])
HOST_ARGS=['-cotabbyMenuBarIconVisible','NO']

def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def ref(path):return {'path':str(path.resolve()),'sha256':sha(path)}
def read(path):return json.loads(path.read_text())
def now():return dt.datetime.now(dt.timezone.utc).isoformat()
def stamp(value):
 parsed=dt.datetime.fromisoformat(value.replace('Z','+00:00'))
 if parsed.tzinfo is None:raise ValueError('Host launch timestamps require an explicit timezone')
 return parsed.timestamp()
def artifact(reference):
 path=Path(reference['path']);path=path if path.is_absolute() else HERE/path
 if sha(path)!=reference['sha256']:raise ValueError('Host launch artifact changed: '+str(path))
 return path

def load_plan(path,digest):
 path=artifact({'path':str(path),'sha256':digest});plan=read(path);frozen=read(HERE/'finalist-freeze.json')
 if (plan.get('schemaVersion')!=1 or plan.get('status')!='registered' or plan.get('candidate')!='baseline'
     or plan.get('commandLineArguments')!=HOST_ARGS or plan.get('target')!='CotabbyTests'
     or plan.get('persistentPreferenceWrites') is not False or plan.get('sourceOrBinaryChanges') is not False
     or frozen['candidate']!='baseline' or frozen['selectionQualified'] is not False
     or plan['freezeSHA256']!=sha(HERE/'finalist-freeze.json')
     or not stamp(frozen['frozenUTC'])<=stamp(plan['registeredUTC'])<=dt.datetime.now(dt.timezone.utc).timestamp()):
  raise ValueError('Host launch plan exceeds the registered retained-baseline UI scope')
 wrapper=artifact(plan['wrapper']);cli=artifact(plan['originalCLI'])
 if wrapper.resolve()!=Path(__file__).resolve() or cli.resolve()!=(ROOT/'scripts/phrase_eval.py').resolve():
  raise ValueError('Host launch plan points outside the exact wrapper/frozen CLI')
 expected=frozen['validationHarnessHashes']['app/scripts/phrase_eval.py']
 if plan['originalCLI']['sha256']!=expected:raise ValueError('Host launch does not use the frozen CLI bytes')
 return {'plan':ref(path),'wrapper':ref(wrapper),'originalCLI':ref(cli),'commandLineArguments':HOST_ARGS,
         'freezeSHA256':plan['freezeSHA256'],'registeredUTC':plan['registeredUTC']}

def admission(args):
 path=getattr(args,'launch_plan',None);digest=getattr(args,'launch_plan_sha256',None)
 if path is None and digest is None:return None
 if path is None or digest is None:raise ValueError('Host launch requires both plan path and SHA-256')
 if args.candidate!='baseline' or args.phase!='validation':raise ValueError('Host launch isolation is retained-baseline validation only')
 return load_plan(path,digest)

def recheck(value):
 if value and load_plan(value['plan']['path'],value['plan']['sha256'])!=value:
  raise ValueError('Host launch admission changed')

def wrap_command(command,value):
 if not value:return command
 if str(command[1])!=str(ROOT/'scripts/phrase_eval.py') or command[2]!='run':raise ValueError('Unexpected original benchmark CLI command')
 return [command[0],value['wrapper']['path'],'--launch-plan',value['plan']['path'],
         '--launch-plan-sha256',value['plan']['sha256'],'--',*command[2:]]

def targets(value):
 if isinstance(value,dict):
  if 'TestBundlePath' in value:
   if Path(str(value['TestBundlePath'])).name=='CotabbyTests.xctest':yield value
   return
  for item in value.values():yield from targets(item)
 elif isinstance(value,list):
  for item in value:yield from targets(item)

def configuration_hash(value):return hashlib.sha256(plistlib.dumps(value,sort_keys=True)).hexdigest()

def add_host_arguments(configuration):
 matches=list(targets(configuration))
 if len(matches)!=1:raise ValueError('Expected exactly one exact CotabbyTests target')
 target=matches[0];before=copy.deepcopy(configuration);arguments=target.get('CommandLineArguments',[])
 if not isinstance(arguments,list) or not all(isinstance(item,str) for item in arguments):raise ValueError('Host command arguments must be strings')
 if any(item.lstrip('-').startswith('cotabbyMenuBarIconVisible') for item in arguments):raise ValueError('Host visibility argument already exists')
 target['CommandLineArguments']=[*arguments,*HOST_ARGS]
 expected=copy.deepcopy(before);list(targets(expected))[0]['CommandLineArguments']=[*arguments,*HOST_ARGS]
 if configuration!=expected:raise ValueError('Unexpected temporary plist mutation')
 return {'target':'CotabbyTests','argumentsBefore':arguments,'argumentsAfter':target['CommandLineArguments'],
         'configurationBeforeSHA256':configuration_hash(before),'configurationAfterSHA256':configuration_hash(configuration),
         'onlyCommandLineArgumentsChanged':True}

def option(arguments,name):
 if arguments.count(name)!=1:raise ValueError('Expected exactly one '+name)
 return arguments[arguments.index(name)+1]

def write(path,value):
 temporary=path.with_name('.'+path.name+'.tmp')
 with temporary.open('x') as stream:json.dump(value,stream,indent=2,sort_keys=True);stream.write('\n')
 temporary.replace(path)

def execute(value,forwarded):
 recheck(value)
 if not forwarded or forwarded[0]!='run' or '--skip-build' in forwarded:raise ValueError('Host wrapper only supports fresh-build replay')
 label=option(forwarded,'--label');output=Path(option(forwarded,'--output')).resolve()
 if output!=(HERE/label).resolve() or Path(label).name!=label:raise ValueError('Host launch output must be the exact round label directory')
 destination=HERE/(label+'-host-launch.json')
 if destination.exists():raise ValueError('Refusing to overwrite host launch evidence')
 spec=importlib.util.spec_from_file_location('frozen_hidden_host_cli',value['originalCLI']['path']);cli=importlib.util.module_from_spec(spec);spec.loader.exec_module(cli)
 original=cli.inject_environment;argv=sys.argv;inside=False;mutations=[];failure=None
 record={'schemaVersion':1,'label':label,'status':'started','startedUTC':now(),'launchAdmission':value,
         'forwardedArguments':forwarded,'output':str(output),'persistentPreferenceWrites':False,'mutations':mutations}
 write(destination,record)
 def injected(configuration,environment):
  nonlocal inside
  if inside:return original(configuration,environment)
  inside=True
  try:count=original(configuration,environment)
  finally:inside=False
  if count!=1 or environment.get('COTABBY_PHRASE_EVAL')!='1' or environment.get('COTABBY_PHRASE_LABEL')!=label or Path(environment.get('COTABBY_PHRASE_OUTPUT','')).resolve()!=output:
   raise ValueError('Unexpected test target or replay environment at host injection')
  if mutations:raise ValueError('Host launch adapter was invoked more than once')
  recheck(value);mutations.append(add_host_arguments(configuration));write(destination,record);return count
 cli.inject_environment=injected;sys.argv=[value['originalCLI']['path'],*forwarded]
 try:cli.main()
 except BaseException as error:
  if not isinstance(error,SystemExit) or error.code not in (None,0):failure=error
 finally:
  cli.inject_environment=original;sys.argv=argv
  try:
   recheck(value)
   if len(mutations)!=1:raise ValueError('Exactly one host mutation must complete')
  except BaseException as error:
   if failure is None:failure=error
  record.update(status='passed' if failure is None else 'failed',finishedUTC=now())
  if failure is not None:record['error']=f'{type(failure).__name__}: {failure}'
  write(destination,record)
 if failure is not None:raise failure
 return record

def verify_completed(value,label,original_command):
 recheck(value);path=HERE/(label+'-host-launch.json');record=read(path)
 if (record.get('schemaVersion')!=1 or record.get('status')!='passed' or record.get('label')!=label
     or record.get('launchAdmission')!=value or record.get('forwardedArguments')!=original_command[2:]
     or record.get('output')!=str((HERE/label).resolve()) or record.get('persistentPreferenceWrites') is not False
     or len(record.get('mutations',[]))!=1):raise ValueError('Completed host launch evidence differs from registration')
 mutation=record['mutations'][0]
 if mutation.get('target')!='CotabbyTests' or mutation.get('onlyCommandLineArgumentsChanged') is not True or mutation['argumentsAfter']!=[*mutation['argumentsBefore'],*HOST_ARGS]:
  raise ValueError('Completed host mutation exceeded the exact argument pair')
 return ref(path)

def main():
 parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--launch-plan',type=Path,required=True);parser.add_argument('--launch-plan-sha256',required=True)
 parser.add_argument('forwarded',nargs=argparse.REMAINDER);args=parser.parse_args()
 forwarded=args.forwarded[1:] if args.forwarded[:1]==['--'] else args.forwarded
 execute(load_plan(args.launch_plan,args.launch_plan_sha256),forwarded)
if __name__=='__main__':main()
