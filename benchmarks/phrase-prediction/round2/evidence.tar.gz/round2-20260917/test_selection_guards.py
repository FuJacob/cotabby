"""Synthetic selection/evidence tests. All fixtures and decisions live in temporary folders."""
import contextlib, copy, datetime, hashlib, io, json, tempfile, unittest
from pathlib import Path
from unittest import mock
import screening_evidence as evidence
import register_combinations as combinations
import freeze_finalist as freezer
import production_inventory as inventory

SHA=lambda value:hashlib.sha256(value.encode()).hexdigest()
CATEGORIES=['conversation','science','entertainment','work','technology','everyday','travel']

class Fixture:
 def __init__(self,root):
  self.root=root;self.rows=[];self.ids=[f'case-{i:03d}' for i in range(140)]
  self.prompt={};self.native={key:{'sha256':SHA(key)} for key in ['baseline']+[f'H{i}' for i in range(1,5)]}
  for f in ['baseline']+[f'F{i}' for i in range(1,5)]:
   for m in ['baseline']+[f'M{i}' for i in range(1,5)]:
    key='+'.join(v for v in [f,m] if v!='baseline') or 'baseline'
    self.prompt[key]={'hashes':{'renderer':SHA('renderer'+f),'composer':SHA('composer'+m)}}
  self.write('candidate-source-registration.json',{'promptVariants':{'variants':self.prompt},'nativeVariants':{'variants':self.native}})
  self.write('combination-sources/manifest.json',{'variants':{}})
  self.write('round.json',{'modelSHA256':SHA('model'),'freezeDeadlineUTC':(datetime.datetime.now(datetime.timezone.utc)+datetime.timedelta(hours=1)).isoformat()})
  self.write('screening-ids.json',self.ids)
  self.write('starting-snapshot.json',{'app':{'after':{'files':{'CotabbyTests/Fixtures/phrase-prediction-1337.json':{'sha256':SHA('corpus')}}}}})
  self.write('execution.json',{'root':str(root/'app'),'native':str(root/'native')})
  for name in ['CotabbyTests/Evals/PhrasePredictionScoring.swift','CotabbyTests/Evals/PhrasePredictionEvalTests.swift',
               'CotabbyTests/TestSupport/CotabbyTestFixtures.swift','scripts/phrase_eval.py',
               'scripts/analyze_phrase_experiments.py','scripts/analyze_completion_prefixes.py']:
   self.write('app/'+name,{'syntheticHarnessInput':name})
  self.write('fresh-readiness.json',{'status':'pass','corpusSHA256':SHA('synthetic-fresh')})
  self.write('selection-clarification.json',{'synthetic':True})
  (root/'IMPROVEMENT_BRAINSTORMING_ROUND_TWO.md').write_text('Synthetic criteria only\n')
 def write(self,name,data):
  p=self.root/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(data));return p
 def hash(self,name):return hashlib.sha256((self.root/name).read_bytes()).hexdigest()
 def targets(self,candidate):
  parts=[] if candidate=='baseline' else candidate.split('+');prompt='+'.join(p for p in parts if p[0] in 'FM') or 'baseline';native=next((p for p in parts if p[0]=='H'),'baseline')
  return dict(self.prompt[prompt]['hashes'],nativeEngine=self.native[native]['sha256'])
 def add(self,candidate,screen=280,none=235):
  label='screen-'+candidate.replace('+','-');parts=[] if candidate=='baseline' else candidate.split('+');targets=self.targets(candidate)
  rows=[];conditions={}
  for condition,correct in [('screen',screen),('none',none)]:
   offset=0
   for i,pid in enumerate(self.ids):
    size=6 if i<70 else 5
    observations=[{'checkpoint':{'wordIndex':j+1,'typedCharacters':0,'typedWordPrefix':'','prefix':f'Synthetic prefix {i} {j}','expectedWord':f'word-{i}-{j}'},'correct':offset+j<correct,'wasShown':True} for j in range(size)]
    counts={'checkpoints':size,'correct':sum(o['correct'] for o in observations),'shown':size,'errors':0};offset+=size
    rows.append({'phrase':{'id':pid,'category':CATEGORIES[i//20],'text':f'Synthetic reference {i} only'},'condition':condition,'observations':observations,'all':dict(counts),'nextWord':dict(counts)})
   count={'checkpoints':770,'correct':correct,'shown':770,'errors':0}
   conditions[condition]={'suite':{'phraseCount':140,'all':dict(count),'nextWord':dict(count)}}
  metadata={'seed':42,'mode':'word','contextMode':'paired','workerCount':3,'runLabel':label,'corpusVersion':2,'corpusSHA256':SHA('corpus'),'configuration':{'modelSHA256':SHA('model'),'temperature':'0.1','repetitionPenalty':'1.025','topK':'20','topP':'0.7','minP':'0.08'}}
  report={'schemaVersion':2,'metadata':metadata,'errorCount':0,'conditions':conditions,'phrases':rows}
  inputs={'sourceSHA256':SHA('source'+candidate)}
  checks=self.write(label+'-checks/validation.json',{'status':'passed','buildInputs':inputs})
  manifest={'label':label,'corpusSHA256':SHA('corpus'),'corpusInput':{'sha256':SHA('corpus'),'version':2},'mode':'word','contextMode':'paired','workerCount':3,'phraseIDs':self.ids,'samplingOverrides':{'temperature':.1,'repetition_penalty':1.025,'top_k':20,'top_p':.7,'min_p':.08,'seed':42},'selection':{'split':'screen','splitSeed':1337,'screenPerCategory':20,'perCategory':None,'limit':None},'buildInputs':inputs,'build':{'sourceSHA256':inputs['sourceSHA256'],'reused':False}}
  registration={'label':label,'candidate':candidate,'components':parts,'status':'complete','phase':'screening','checks':str(checks),'promptSource':{'hashes':{k:targets[k] for k in ('renderer','composer')}},'nativeSource':{'sha256':targets['nativeEngine']},'scores':{k:v['suite']['nextWord'] for k,v in conditions.items()}}
  self.write(label+'/report.json',report);self.write(label+'/manifest.json',manifest);self.write(label+'-registration.json',registration)
  row={'label':label,'candidate':candidate,'components':parts,'screenCorrect':screen,'noneCorrect':none,'checkpointsPerCondition':770,'reportSHA256':self.hash(label+'/report.json'),'registrationSHA256':self.hash(label+'-registration.json')};self.rows.append(row);return row
 def save(self):self.write('screening-ranking.json',{'rows':self.rows})
 def singles(self,eligible=False):
  self.add('baseline',288,235)
  for candidate in combinations.SINGLES:self.add(candidate,300 if eligible and candidate in ('H1','H2','F1','M1') else 280,235)
  self.save()
 @contextlib.contextmanager
 def bound(self):
  base={'schemaVersion':1,'scope':inventory.SCOPE,'files':{path:self.targets('baseline')[key] for key,path in inventory.TARGET_PATHS.items()}}
  base['files']['app/Cotabby/Stable.swift']=SHA('stable')
  with mock.patch.object(evidence,'HERE',self.root),mock.patch.object(combinations,'HERE',self.root),mock.patch.object(freezer,'HERE',self.root),mock.patch.object(freezer,'MAIN',self.root),mock.patch.object(inventory,'HERE',self.root),mock.patch.object(inventory,'baseline_from_snapshot',return_value=base),mock.patch.object(inventory,'capture',return_value=base),contextlib.redirect_stdout(io.StringIO()):yield

class SelectionGuards(unittest.TestCase):
 def test_complete_synthetic_rows_pass(self):
  with tempfile.TemporaryDirectory() as d:
   f=Fixture(Path(d));f.singles()
   with f.bound():self.assertEqual(evidence.validate_rows(f.rows),f.rows)
 def test_tampered_ranking_rejected(self):
  with tempfile.TemporaryDirectory() as d:
   f=Fixture(Path(d));f.singles();f.rows[1]['screenCorrect']+=1
   with f.bound(),self.assertRaisesRegex(ValueError,'aggregate'):evidence.validate_rows(f.rows)
 def test_refreshed_report_hash_cannot_hide_changed_inputs_or_metadata(self):
  mutations={'id':lambda p:p['phrases'][0]['phrase'].update(id='wrong'),
             'mode':lambda p:p['metadata'].update(mode='character'),
             'worker':lambda p:p['metadata'].update(workerCount=1),
             'corpus':lambda p:p['metadata'].update(corpusSHA256='wrong'),
             'sampling':lambda p:p['metadata']['configuration'].update(temperature='0.9'),
             'outcome':lambda p:p['phrases'][0]['observations'][0].update(correct=False),
             'phrase':lambda p:[row['phrase'].update(text='Changed reference') for row in p['phrases'] if row['phrase']['id']=='case-000'],
             'checkpoint':lambda p:[row['observations'][0]['checkpoint'].update(prefix='Changed prefix') for row in p['phrases'] if row['phrase']['id']=='case-000']}
  for name,mutate in mutations.items():
   with self.subTest(name=name),tempfile.TemporaryDirectory() as d:
    f=Fixture(Path(d));f.add('baseline',288,235);row=f.add('H1',300,235);namepath=row['label']+'/report.json';data=json.loads((f.root/namepath).read_text());mutate(data);f.write(namepath,data);row['reportSHA256']=f.hash(namepath)
    with f.bound(),self.assertRaises(ValueError):evidence.validate_rows(f.rows)
 def test_fresh_build_flag_is_exact_false(self):
  with tempfile.TemporaryDirectory() as d:
   f=Fixture(Path(d));f.add('baseline',288,235);row=f.add('H1',300,235);name=row['label']+'/manifest.json';data=json.loads((f.root/name).read_text());data['build']['reused']=None;f.write(name,data)
   with f.bound(),self.assertRaisesRegex(ValueError,'fresh build'):evidence.validate_rows(f.rows)
 def test_family_fixed_tie_and_finalist_fixed_tie(self):
  with tempfile.TemporaryDirectory() as d:
   f=Fixture(Path(d));f.singles(eligible=True)
   with f.bound():
    combinations.register();record=json.loads((f.root/'combination-registration.json').read_text());self.assertEqual(record['families']['H']['winner'],'H1');self.assertEqual([x['candidate'] for x in record['combinations']],['H1+F1','H1+M1','F1+M1','H1+F1+M1'])
    for item in record['combinations']:f.add(item['candidate'],300,235)
    f.save();freezer.freeze();frozen=json.loads((f.root/'finalist-freeze.json').read_text());self.assertEqual(frozen['candidate'],'H1');self.assertTrue(frozen['selectionQualified'])
 def test_no_qualifier_freezes_baseline(self):
  with tempfile.TemporaryDirectory() as d:
   f=Fixture(Path(d));f.singles()
   with f.bound():
    combinations.register();self.assertEqual(json.loads((f.root/'combination-registration.json').read_text())['combinations'],[]);freezer.freeze();frozen=json.loads((f.root/'finalist-freeze.json').read_text());self.assertEqual(frozen['candidate'],'baseline');self.assertFalse(frozen['selectionQualified'])
 def test_missing_registered_combination_blocks_freeze(self):
  with tempfile.TemporaryDirectory() as d:
   f=Fixture(Path(d));f.singles(eligible=True)
   with f.bound():
    combinations.register()
    with self.assertRaisesRegex(ValueError,'incomplete'):freezer.freeze()
    self.assertFalse((f.root/'finalist-freeze.json').exists())

if __name__=='__main__':unittest.main()
