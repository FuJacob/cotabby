# Post-freeze decision evidence

`assess_round2.py` will open no result report until `finalist-freeze.json` exists and
validates. It assesses the one frozen candidate; it does not rank candidates or choose a
replacement. All paths below are relative to this round directory unless absolute.
An artifact reference is `{"path": "...", "sha256": "<64 lowercase hex>"}`.
The validator reads evidence and writes only its requested aggregate assessment output.

## Finalist freeze

Write this record once, before either fresh baseline or fresh finalist starts, and by
`round.json.freezeDeadlineUTC`. Bind the exact tested source fingerprints; do not infer
them from names or current checkout state. `prerequisiteHashes` describes critical native
and app runtime inputs retained by both the experiment and current-main integration.
Use logical keys such as `app/Cotabby/...` and `native/Sources/...` so checkout relocation
does not alter file identity. Include the complete set of prerequisites reviewed for
adoption. At minimum include the native package/header/TokenHealing inputs and the app's
sampling configuration, request factory, runtime core, and llama suggestion engine.

```json
{
  "schemaVersion": 1,
  "frozenUTC": "2026-09-17T...+00:00",
  "candidate": "H1+F2",
  "components": ["H1", "F2"],
  "selectionQualified": true,
  "screeningEvidence": {"path": "screening-at-freeze.json", "sha256": "..."},
  "screeningEvidenceSHA256": "...",
  "criteria": {"path": "criteria-at-freeze.md", "sha256": "..."},
  "freshReadiness": {"path": "fresh-readiness.json", "sha256": "..."},
  "freshCorpusSHA256": "2529c17f21b276eecafe7859853b1aafeba967346f205fa9f378631aa2dda828",
  "modelSHA256": "...",
  "baselineLabel": "screen-baseline",
  "candidateLabel": "screen-H1-F2",
  "baselineSourceSHA256": "...",
  "candidateSourceSHA256": "...",
  "baselineTargets": {"renderer": "...", "composer": "...", "nativeEngine": "..."},
  "candidateTargets": {"renderer": "...", "composer": "...", "nativeEngine": "..."},
  "productionInventories": {
    "baseline": {"path": "freeze/baseline-production.json", "sha256": "..."},
    "finalist": {"path": "freeze/finalist-production.json", "sha256": "..."}
  },
  "prerequisiteHashes": {"native/Package.swift": "...", "app/Cotabby/...": "..."}
}
```

Use `candidate: "baseline"`, `components: []`, and `selectionQualified: false` when no
candidate qualified. That records retention without authorizing fresh-data-driven selection.
Frozen target hashes must equal the premeasurement prompt/native variant manifests.
Production inventories have `schemaVersion: 1`, a `scope` dictionary, and a `files` mapping
from logical path to SHA-256. Scope is `app/Cotabby/**`, `app/Config/**`,
`app/Cotabby.xcodeproj/**`, `app/project.yml`, `app/CotabbyInfo.plist`,
`native/Package.swift`, and `native/Sources/**`. User-local `xcuserdata`, `.DS_Store`,
and dependency `Package.resolved` files are excluded from this narrower production map.
Include source, resources, plists, project, and configuration files. Package resolutions
and the resolved llama framework identity are bound separately by build/run evidence.

## Opaque checkpoint manifests

Export these with the actual Swift `PhrasePredictionScorer.checkpoints` for each cohort.
They contain no reference text. The order of phrases is the selected corpus order; each
checkpoint list is the exact generated order. They establish completeness independently of
two reports that could both omit the same checkpoint. Do not approximate Swift grapheme
counts with Python string length or regenerate lexical scores.

```json
{
  "schemaVersion": 1,
  "corpusSHA256": "...",
  "corpusVersion": 2,
  "scorerSourceSHA256": "...",
  "mode": "character",
  "selection": "all",
  "perCategory": 50,
  "phraseCount": 350,
  "checkpointsPerCondition": 12345,
  "phrases": [
    {"phraseID": "opaque-id", "category": "science", "checkpoints": [
      {"wordIndex": 1, "typedCharacters": 0},
      {"wordIndex": 1, "typedCharacters": 1}
    ]}
  ]
}
```

Required cohorts are fresh all700 word (2892 checkpoints per condition), historical
all1337 word, historical first50/category character (350 scenarios), and the registered
one-worker latency selection. Production-seed validation uses all1337 word. A manifest may
be reused between pairs with the same corpus, mode, and selection.

## Decision evidence map

Every pair uses existing `<label>-registration.json`, `<label>/manifest.json`,
`<label>/report.json`, and the check artifact named by the registration. Register labels
before inference as usual; fill this map with completed or planned label names. Missing
required evidence yields `incomplete`, never a pass. Failed optional attempts remain listed.

```json
{
  "schemaVersion": 1,
  "pairs": {
    "fresh": {"baseline": "fresh-baseline", "finalist": "fresh-finalist", "checkpoints": {"path": "checkpoints/fresh-word.json", "sha256": "..."}},
    "historical": {"baseline": "full42-baseline", "finalist": "full42-finalist", "checkpoints": {"path": "checkpoints/full-word.json", "sha256": "..."}},
    "character": {"baseline": "character50-baseline", "finalist": "character50-finalist", "checkpoints": {"path": "checkpoints/character50.json", "sha256": "..."}},
    "productionSeed": {"baseline": "production-baseline", "finalist": "production-finalist", "checkpoints": {"path": "checkpoints/full-word.json", "sha256": "..."}},
    "latency": {"baseline": "latency-baseline", "finalist": "latency-finalist", "checkpoints": {"path": "checkpoints/latency.json", "sha256": "..."}, "isolation": {"path": "latency-isolation.json", "sha256": "..."}}
  },
  "focusedTests": [{"path": "finalist-tests/validation.json", "sha256": "..."}],
  "sourceBindings": [],
  "currentMainIntegration": {"path": "current-main-integration.json", "sha256": "..."},
  "latencyInvestigation": null,
  "optionalPairs": [
    {"name": "fresh-seed1337", "kind": "freshSeed", "status": "not-run", "reason": "Timing reserve", "pair": null},
    {"name": "character150", "kind": "character", "status": "not-run", "reason": "Timing reserve", "pair": null},
    {"name": "latency-counterbalanced", "kind": "latency", "status": "not-run", "reason": "Timing reserve", "pair": null}
  ]
}
```

If test expectation updates change a compiler fingerprint, add a `sourceBindings` entry:
`{"label":"...","role":"finalist","sourceSHA256":"...","targets":{...},
"productionInventory":{"path":"...","sha256":"..."}}`.
Its complete production `files` must exactly equal the frozen role inventory; only then
can that run use a different full compiler fingerprint. Baseline overrides work likewise.

Optional entries use `status` of `not-run`, `failed`, `incomplete`, or `complete`. Complete
entries supply a pair in the same format. An unfavorable or contradictory optional result
is reported explicitly and cannot silently turn into a different finalist. Timing-only
admission of optional runs follows `optional-validation-registration.json`.

## Current-main integration record

The full compiler fingerprint differs legitimately between the experiment and another
checkout. An explicit integration record binds those new fingerprints and the same approved
target/prerequisite bytes. Both integration reports still need ordinary run registrations,
CLI manifests, complete paired observations, and matching check evidence.

```json
{
  "schemaVersion": 1,
  "status": "passed",
  "baseline": {"label": "integration-baseline", "sourceSHA256": "...", "targets": {"renderer": "...", "composer": "...", "nativeEngine": "..."}, "prerequisiteHashes": {}, "productionInventory": {"path":"...", "sha256":"..."}},
  "finalist": {"label": "integration-finalist", "sourceSHA256": "...", "targets": {"renderer": "...", "composer": "...", "nativeEngine": "..."}, "prerequisiteHashes": {}, "productionInventory": {"path":"...", "sha256":"..."}},
  "checkpoints": {"path": "checkpoints/full-word.json", "sha256": "..."},
  "snapshotProof": {"path": "integration-snapshot-proof.json", "sha256": "..."},
  "focusedTests": [{"path": "integration-tests/validation.json", "sha256": "..."}],
  "preservedUnrelatedEdits": true
}
```

The snapshot proof must record before/after complete source inventories, target and
prerequisite checks, and explained remaining differences. Empty prerequisite maps above
are placeholders, not accepted evidence. Integration uses seed12648430 and full1337.
The validator requires positive screen gain and no-screen delta at least−0.50pp, as for the
production-seed gate. If the integration pair also serves as `productionSeed`, list the same
labels there; the integration binding supplies its separately approved full fingerprints.

## Latency evidence

`latency-isolation.json` must contain `schemaVersion: 1`, `status: "passed"`, the exact
`labels`, and `intervals` (`label`, `startedUTC`, `finishedUTC`), plus
`noOverlappingBuildOrInference: true` and an artifact reference `evidence`. The evidence
must establish isolation during the run, not infer it from worker count. Registered run
intervals are checked for overlap with each other and with other round registrations.
This cannot prove the absence of arbitrary unlogged machine activity; disclose that limit.

If p95 rises by more than `max(0.1 * baselineP95, 20ms)` in either condition, the gate is
`needs-investigation`. A resolution record must identify the exact labels, bind its evidence,
set `status: "resolved"`, and provide a nonempty `conclusion` plus
`acceptableForAdoption: true`. This records an explicit judgment; it does not rewrite scores.

## Metric and decision rules

- Fresh: screen delta≥0.005 and bootstrap lower bound>0; none delta≥−0.005 and lower
  bound>−0.01; each screen category delta≥−0.03. Family bootstrap uses20,000 samples,
  seed1337, with categories stratified and sibling cases kept together. Context-kind
  results and category uncertainty are always included.
- Historical: both full1337 word deltas≥0.
- Character: both **partial-only** (`typedCharacters>0`) deltas≥0. Word-boundary and all
  checkpoint metrics remain separate; retain partial category intervals.
- Production/current-main: seed12648430, screen delta>0, none delta≥−0.005.
- Complete matching identities, zero errors, authoritative Swift flags, source/build/check
  coherence, frozen model/fixture identities, and actual required test execution are mandatory.

Fresh results are not opened until the frozen selection is validated. Missing, invalid,
failed, or unresolved evidence never yields an adoption pass. All conclusions are aggregate;
the validator emits no reference sentences, prompts, or model completions.

## Executable assessment

Run only after the selection is frozen:

```sh
python3 build/eval/round2-20260917/assess_round2.py --output build/eval/round2-20260917/decision-assessment.json
```

`eligible-for-adoption` requires all mandatory quality, identity, source, test and latency
evidence. Failed numerical gates return `retain-baseline`; missing or malformed evidence
returns `incomplete-or-invalid`. An unfavorable completed optional quality check returns
`needs-review-optional-contradiction`, with all counts and intervals preserved. Neither
state authorizes choosing a different candidate. Output contains aggregate metrics only.

The integration snapshot proof is schema1/status `passed`, with nonempty `mainBefore` and
`mainAfter` logical-path/hash maps that are identical, plus `baselineInventory` and
`finalistInventory` artifact references matching the role production inventories. These
record that staging the isolated integration preserved the user's actual main source.
All frozen prerequisites remain exact; differing full compiler hashes are explicit bindings.

A latency resolution uses `pairs: [[baselineLabel, finalistLabel], ...]` for every threshold
breach across required and completed optional latency runs, in addition to the conclusion,
evidence reference, resolved status and explicit adoption judgment described above.

The evidence map also requires `checkpointExporter` referencing a schema1 record with
`scorerSource`, `helperSource`, and `binary` artifact references, a nonempty `compilerVersion`,
and `manifests` containing the exact artifact references accepted by pair specs. The scorer
hash must match the frozen execution scorer. This binds opaque completeness manifests to
the actual Swift exporter, rather than trusting an arbitrary checkpoint-count file.

Optional entries may include `attemptLabels` for failed or interrupted attempts in addition
to the final `pair`. The validator scans round validation registrations and manifests;
every recognizable optional attempt must be visible. A started attempt cannot be labeled
`not-run`, and a completed pair cannot be labeled failed or incomplete to omit its outcome.

The freeze also requires `validationHarnessHashes`, mapping `app/` logical paths to hashes
for every `CotabbyTests/Evals/*.swift`, the shared `CotabbyTestFixtures.swift`, and
`phrase_eval.py`, `analyze_phrase_experiments.py`, and `analyze_completion_prefixes.py`.
The assessor checks the complete path set and bytes at the frozen execution root and each
check record's `execution.root`. Source bindings permit reviewed expectation updates
outside that harness; they do not permit changes to request construction, fixture handling,
replay, or scoring within the benchmark harness.

## Baseline retained

When the validated freeze selects `baseline`, the decision returns `retained-baseline`
without opening `decision-evidence.json` or requiring redundant identical adoption pairs.
It still validates the frozen development decision and source/harness evidence. Any later
baseline characterization is a separate descriptive report: it can measure context utility,
seed sensitivity, partial-word behavior, current-main parity and uncontended latency, but
cannot authorize another candidate or change the already-frozen selection.
