#!/usr/bin/env python3
"""Refresh the retained-baseline evidence map from registered metadata only.

This round-local coordinator never launches the app or selects observations by score.
The existing characterizer remains the authoritative report/test/scorer validator and
is invoked only with --analyze. A shared lock protects isolated latency collection.
"""
from __future__ import annotations

import argparse
import datetime as dt
import fcntl
import hashlib
import importlib.util
import itertools
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import tempfile

HERE = Path(__file__).resolve().parent
SPEC = importlib.util.spec_from_file_location('round2_refresh_characterizer', HERE / 'characterize_baseline.py')
CHAR = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(CHAR)
BASE, require = CHAR.BASE, CHAR.require
COHORT_KEYS = ('corpusSHA256', 'mode', 'selection', 'perCategory')
MAP_LISTS = ('sourceBindings', 'plannedWorkloads', 'runs', 'focusedTests', 'seedPairs',
             'parityPairs', 'latencyRuns', 'latencyPairs')


def sha(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(block)
    return digest.hexdigest()


def atomic_json(path, value):
    """Replace only a generated map/receipt after a durable complete write."""
    path = Path(path)
    descriptor, temporary = tempfile.mkstemp(prefix='.' + path.name + '.', dir=path.parent)
    try:
        with os.fdopen(descriptor, 'w') as stream:
            stream.write(json.dumps(value, indent=2) + '\n')
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)


class Refresh(CHAR.BaselineCharacterization):
    """Short-lived metadata reader; raw report bytes are hashed, never parsed."""
    def reference(self, value):
        path = self.path(value).resolve()
        try:
            name = str(path.relative_to(self.root))
        except ValueError:
            name = str(path)
        digest = sha(path)
        require(str(path) not in self.artifacts or self.artifacts[str(path)] == digest,
                'Evidence changed between reads')
        self.artifacts[str(path)] = digest
        return {'path': name, 'sha256': digest}

    def optional_reference(self, registration, key, fallback):
        declared = registration.get(key)
        path = self.root / fallback
        if declared is not None:
            self.artifact_path(declared)
            if path.exists():
                require(self.path(declared['path']).resolve() == path.resolve(),
                        'Declared auxiliary evidence differs from its canonical label artifact')
            return declared
        return self.reference(path) if path.exists() else None

    def completed_metadata(self, spec, row, plan, registration):
        label = spec['label']
        require(registration.get('label') == label and registration.get('phase') == 'validation'
                and registration.get('candidate') == 'baseline' and registration.get('components') == []
                and registration.get('status') == 'complete', 'Run is not an exact completed baseline validation')
        times = [self.frozen['frozenUTC'], registration['startedUTC'], registration['inferenceStartedUTC'],
                 registration['finishedUTC'], self.round_record['deadlineUTC']]
        require(all(a <= b for a, b in zip(map(BASE.timestamp, times), list(map(BASE.timestamp, times))[1:])),
                'Run timing violates the frozen round')
        self.validate_workload(spec, plan, registration)
        self.validate_host_launch(registration)
        require({**registration['promptSource']['hashes'], 'nativeEngine': registration['nativeSource']['sha256']}
                == self.frozen['baselineTargets'], 'Completed run changed frozen production targets')
        evidence = registration['evidenceSHA256']
        for name, path in [('checks', registration['checks']), ('manifest', f'{label}/manifest.json'),
                           ('report', f'{label}/report.json')]:
            require(self.reference(path)['sha256'] == evidence[name], 'Completed evidence hash differs from registration')
        manifest = self.read_json(f'{label}/manifest.json')
        source = self.expected_source(label, 'baseline')
        require(manifest['label'] == label and manifest['buildInputs']['sourceSHA256'] == source
                and manifest['build']['sourceSHA256'] == source and manifest['build'].get('reused') is False,
                'Completed run has a different source or reused build')
        require(manifest['corpusSHA256'] == plan['corpusSHA256'] and manifest['mode'] == plan['mode']
                and manifest['contextMode'] == 'paired' and manifest['workerCount'] == row['workerCount']
                and manifest['phraseIDs'] == [p['phraseID'] for p in plan['phrases']], 'Completed run cohort differs from workload')
        selection = manifest['selection']
        require(selection['split'] == row['selection'] and (selection.get('perCategory') or 0) == row['perCategory']
                and selection.get('limit') is None and selection['splitSeed'] == 1337
                and selection['screenPerCategory'] == 20, 'Completed run narrowed the registered selection')
        sampling = manifest['samplingOverrides']
        require(sampling.get('seed') == row['seed'] and all(sampling.get(k) == v for k, v in BASE.SAMPLING.items()),
                'Completed run changed registered seed/sampling')
        checks, _ = self.check_tests(registration['checks'], source,
                                    ['BaseCompletionPromptRendererTests/testRoundTwoScreeningPromptAudit'])
        require(checks['buildInputs'] == manifest['buildInputs']
                and checks['productSHA256'] == manifest['build']['productSHA256']
                and BASE.timestamp(checks['finishedUTC']) <= BASE.timestamp(registration['inferenceStartedUTC']),
                'Completed benchmark/checks used different inputs, product or timing')
        return manifest

    def refresh(self, evidence_path='baseline-evidence.json', extensions=()):
        self.frozen = self.read_json('finalist-freeze.json')
        require(self.frozen.get('schemaVersion') == 1 and self.frozen.get('candidate') == 'baseline' and self.frozen.get('components') == []
                and self.frozen.get('selectionQualified') is False, 'Refresh requires the frozen retained baseline')
        self.round_record = self.read_json('round.json')
        self.inventories = {'baseline': self.inventory(self.frozen['productionInventories']['baseline'])}
        existed = self.path(evidence_path).exists()
        old = self.read_json(evidence_path) if existed else {}
        require(not existed or (set(old) in ({'schemaVersion', 'checkpointExporter', *MAP_LISTS},
                                          {'schemaVersion', 'checkpointExporter', *MAP_LISTS, 'attemptDiagnostics'})
                           and old.get('schemaVersion') == 1 and isinstance(old['checkpointExporter'], dict)
                           and all(isinstance(old[key], list) for key in MAP_LISTS)
                           and isinstance(old.get('attemptDiagnostics', []), list)),
                'Existing output is not a generated descriptive evidence map')
        exporter_ref = old.get('checkpointExporter') or self.reference('checkpoint-exporter.json')
        self.exporter(exporter_ref)
        refs = list(old.get('plannedWorkloads', []))
        for reference in refs:
            self.artifact_path(reference)
        for path in ('baseline-workloads.json', *extensions):
            reference = self.reference(path)
            same = [r for r in refs if self.path(r['path']).resolve() == self.path(reference['path']).resolve()]
            require(not same or same[0]['sha256'] == reference['sha256'], 'A previously admitted workload changed')
            if not same:
                refs.append(reference)
        for reference in refs:
            self.register_workload(reference)
        require(len({item['row']['name'] for item in self.workloads.values()}) == len(self.workloads),
                'Run names collide across workload artifacts')
        known = [(reference, self.artifact(reference)) for reference in self.checkpoint_exporter['manifests']]
        old_bindings = {binding['label']: binding for binding in old.get('sourceBindings', [])}
        require(len(old_bindings) == len(old.get('sourceBindings', [])), 'Duplicate existing source bindings')
        for binding in old_bindings.values():
            require(binding['label'] in self.workloads, 'Existing source binding is outside registered workloads')
            self.add_binding(binding)
        result = dict(schemaVersion=1, checkpointExporter=exporter_ref, sourceBindings=[], plannedWorkloads=refs,
                      runs=[], focusedTests=[], seedPairs=[], parityPairs=[], latencyRuns=[], latencyPairs=[])
        tests = list(old.get('focusedTests', [])) or [self.reference('baseline-checks/validation.json')]
        for reference in tests:
            self.artifact_path(reference)
        complete, snapshots, isolated = {}, {}, set()
        for label, item in self.workloads.items():
            require(isinstance(label, str) and re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9._-]{0,99}', label), 'Unsafe workload label')
            row = item['row']
            matches = [(ref, plan) for ref, plan in known if all(plan[key] == row[key] for key in COHORT_KEYS)]
            require(len(matches) == 1, 'Workload does not identify exactly one known opaque checkpoint manifest')
            reference, plan = matches[0]
            self.validate_descriptive_cohort(plan, row['kind'])
            path = self.root / f'{label}-registration.json'
            if not path.exists():
                continue
            registration = self.read_json(path)
            require(registration.get('label') == label and registration.get('candidate') == 'baseline'
                    and registration.get('phase') == 'validation' and registration.get('components') == [],
                    'Registered descriptive attempt has a conflicting identity')
            if registration.get('status') != 'complete':
                continue
            binding_ref = self.optional_reference(registration, 'sourceBinding', f'{label}-source-binding.json')
            if binding_ref is not None:
                binding = self.artifact(binding_ref)
                require(binding.get('label') == label, 'Source binding names another run')
                self.add_binding(binding)
            spec = {key: row[key] for key in ('name', 'label', 'kind', 'seed')}
            spec.update(checkpoints=reference, workload=item['artifact'])
            manifest = self.completed_metadata(spec, row, plan, registration)
            result['runs'].append(spec)
            complete[row['name']] = {'spec': spec, 'row': row, 'registration': registration, 'manifest': manifest}
            test_ref = self.reference(registration['checks'])
            if not any(self.path(ref['path']).resolve() == self.path(test_ref['path']).resolve() for ref in tests):
                tests.append(test_ref)
            snapshot = self.optional_reference(registration, 'snapshotProof', f'{label}-snapshot-proof.json')
            if snapshot is not None:
                require(label in self.bindings, 'Snapshot proof lacks an explicit source binding')
                proof = self.artifact(snapshot)
                require(proof.get('schemaVersion') == 1 and proof.get('status') == 'passed', 'Snapshot proof did not pass')
                snapshots[row['name']] = snapshot
            isolation = self.optional_reference(registration, 'isolation', f'{label}-isolation.json')
            if row['kind'] == 'latency' and isolation is not None:
                result['latencyRuns'].append({'name': row['name'], 'isolation': isolation})
                proof = self.artifact(isolation)
                if proof.get('status') == 'passed':
                    self.validate_isolation(isolation, [{'label': label, 'registration': registration}])
                    isolated.add(row['name'])
            elif isolation is not None:
                require(False, 'Isolation proof attached to a non-latency workload')
        previously_complete = {run['name'] for run in old.get('runs', [])}
        require(previously_complete <= complete.keys(), 'A previously completed run disappeared or became incomplete')
        result['focusedTests'] = tests
        result['sourceBindings'] = [self.bindings[label] for label in sorted(self.bindings)]
        for a, b in itertools.combinations(complete.values(), 2):
            first, second = a['row'], b['row']
            same = all(first[k] == second[k] for k in (*COHORT_KEYS, 'kind', 'workerCount'))
            if not same:
                continue
            names = (first['name'], second['name'])
            if first['seed'] != second['seed'] and 42 in (first['seed'], second['seed']) \
                    and first['label'] not in self.bindings and second['label'] not in self.bindings:
                x, y = (names if first['seed'] == 42 else names[::-1])
                result['seedPairs'].append({'name': f'{x}-vs-{y}', 'reference': x, 'comparison': y})
            if first['seed'] != second['seed']:
                continue
            for baseline, current in ((a, b), (b, a)):
                x, y = baseline['row'], current['row']
                if x['label'] not in self.bindings and y['name'] in snapshots:
                    result['parityPairs'].append({'name': f'{x["name"]}-vs-{y["name"]}', 'reference': x['name'],
                                                 'currentMain': y['name'], 'snapshotProof': snapshots[y['name']]})
            if first['kind'] == 'latency' and set(names) <= isolated:
                result['latencyPairs'].append({'name': '-vs-'.join(names), 'first': names[0], 'second': names[1]})
        planned, attempts = self.planned_status(set(complete))
        result['attemptDiagnostics'], preflight = self.preflight_diagnostics(old.get('attemptDiagnostics', []))
        unregistered = [attempt['label'] for attempt in attempts if attempt['label'] not in self.workloads]
        require(not unregistered, 'Validation attempts lack an explicitly supplied workload extension: ' + ', '.join(unregistered))
        receipt = {'schemaVersion': 1, 'status': 'refreshed-metadata-only', 'plannedWorkloads': planned,
                   'registeredValidationAttempts': attempts, 'completedRunCount': len(complete),
                   'attemptDiagnostics': preflight,
                   'plannedRunCount': len(planned), 'analysisRequested': False,
                   'limitations': ['Full report/scorer/source validation and bootstrap require explicit --analyze.',
                                   'Missing or failed isolation remains visible; its timings are not accepted as isolated.']}
        # Hash the report streams a second time without loading or exposing examples.
        for path, digest in self.artifacts.items():
            require(sha(path) == digest, 'Evidence changed during metadata refresh')
        receipt['artifactSHA256'] = dict(self.artifacts)
        # The generated map is the sole input intentionally replaced. Its prior
        # digest is historical, not part of the re-verifiable immutable ledger.
        prior = receipt['artifactSHA256'].pop(str(self.path(evidence_path).resolve()), None)
        if prior is not None:
            receipt['previousEvidenceSHA256'] = prior
        return result, receipt


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--round', type=Path, default=HERE)
    parser.add_argument('--workload', action='append', default=[], help='Explicit workload extension; admitted refs persist on later refreshes')
    parser.add_argument('--evidence', default='baseline-evidence.json')
    parser.add_argument('--receipt', default='baseline-evidence-refresh.json')
    parser.add_argument('--analysis-output', default='baseline-characterization.json')
    parser.add_argument('--analyze', action='store_true', help='Run the authoritative characterizer under the isolated-latency lock')
    args = parser.parse_args(argv)
    reader = Refresh(args.round)
    # Even metadata refresh hashes report streams; sharing this lock avoids disk/CPU
    # contamination during latency collection and removes a check-then-start race.
    with (reader.root / 'descriptive-analysis.lock').open('a') as lock:
        try:
            fcntl.flock(lock.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            parser.error('An isolated latency run or another descriptive refresh/analysis holds the shared lock')
        evidence, receipt = reader.refresh(args.evidence, args.workload)
        destinations = [reader.path(args.evidence).resolve(), reader.path(args.receipt).resolve(),
                        reader.path(args.analysis_output).resolve()]
        require(len(set(destinations)) == 3, 'Output artifacts must be distinct')
        require(all(str(path) not in reader.artifacts for path in destinations[1:]), 'Output would overwrite input evidence')
        receipt.update(refreshedUTC=dt.datetime.now(dt.timezone.utc).isoformat(),
                       helperSHA256=sha(__file__), analysisRequested=args.analyze)
        atomic_json(destinations[0], evidence)
        receipt['evidence'] = {'path': str(destinations[0]), 'sha256': sha(destinations[0])}
        atomic_json(destinations[1], receipt)
        print(json.dumps({k: receipt[k] for k in ('status', 'completedRunCount', 'plannedRunCount', 'analysisRequested')}, sort_keys=True), flush=True)
        if args.analyze:
            return subprocess.run([sys.executable, str(HERE / 'characterize_baseline.py'), '--round', str(reader.root),
                                   '--evidence', str(destinations[0]), '--output', str(destinations[2])], check=False).returncode
    return 0


if __name__ == '__main__':
    sys.exit(main())
