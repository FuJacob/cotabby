#!/usr/bin/env python3
"""Collect sampled process-isolation evidence around one registered baseline latency repeat.

The scheduler runs each label separately. This wrapper owns the global experiment lock and
uses the unchanged experiment runner. Observation evidence is conservative: unknown relevant
processes fail isolation, and a passed proof still cannot exclude short or unobserved activity.
"""
import argparse
import contextlib
import datetime as dt
import fcntl
import hashlib
import json
import os
from pathlib import Path
import plistlib
import re
import shlex
import subprocess
import threading
import time

import run_experiment as runner

HERE=Path(__file__).resolve().parent
LABELS=('latency-baseline-1','latency-baseline-2')
OLD_CORPUS='b41c8089a58ae1e0ee84b95ac9283cf71db4e713e25bd8fed47220be69d8b0f6'
POLL_SECONDS=1.0
MAX_OBSERVATION_GAP_SECONDS=4.0
EXTERNAL_CPU_THRESHOLD=50.0
PS_COMMAND=['/bin/ps','-axo','pid=,ppid=,pgid=,lstart=,pcpu=,command=']
PS_EXECUTABLE_COMMAND=['/bin/ps','-axo','pid=,comm=']
PATTERNS={
 'build':re.compile(r'(?i)(?:^|[/\s])(?:xcodebuild|XCBBuildService|SWBBuildService|swift-frontend|swiftc|clang(?:\+\+)?|cmake|ninja|make)(?:\s|$)'),
 'inference-or-benchmark':re.compile(r'(?i)(?:xctest|Cotabby\.app/Contents/MacOS/Cotabby|(?:^|[/\s])(?:llama[-_\w.]*|ollama|lmstudio|mlx_lm)(?:\s|$)|(?:phrase_eval|run_experiment|run_candidates|run_integration_baseline|run_baseline_queue|run_core_queue|run_singles)\.py)'),
 'heavy-analysis':re.compile(r'(?i)(?:^|[/\s])(?:analyze\w*|analyse\w*|assess\w*|characterize\w*|summarize\w*|write_round_report|refresh_baseline_evidence|plot\w*)\.py(?:\s|$)'),
}
LIMITATION=('Process snapshots are sampled, not a machine-wide activity trace. They cannot rule out short-lived '
            'processes between observations, GPU work hidden in services, thermal/power changes, or unlogged machine activity. '
            'The registration interval includes this run\'s own CLI setup/build and final validation; measured report latencies '
            'remain the unchanged Swift generation timings. No focus, debounce or overlay latency is measured.')


def now():return dt.datetime.now(dt.timezone.utc).isoformat()
def read(path):return json.loads(path.read_text())
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def ref(path):return {'path':str(path.resolve()),'sha256':sha(path)}
def timestamp(value):return dt.datetime.fromisoformat(value.replace('Z','+00:00')).timestamp()
def write_new(path,value):
 with path.open('x') as stream:json.dump(value,stream,indent=2,sort_keys=True);stream.write('\n')


def phase_deadline():return int(runner.DEADLINE-1200)//60*60


def prepare(label):
 if label not in LABELS:raise ValueError('Only the two pre-registered baseline latency labels are allowed')
 workload=read(HERE/'baseline-workloads.json');freeze=read(HERE/'finalist-freeze.json')
 selected=[row for row in workload['runs'] if row['label']==label]
 expected={'kind':'latency','seed':42,'workerCount':1,'mode':'word','corpusSHA256':OLD_CORPUS,
           'selection':'screen','perCategory':0,'estimatedSeconds':600,'guardException':None}
 if (workload['schemaVersion']!=1 or workload['candidate']!='baseline'
     or workload['freezeSHA256']!=sha(HERE/'finalist-freeze.json') or len(selected)!=1
     or any(selected[0].get(key)!=value for key,value in expected.items())
     or freeze['candidate']!='baseline' or freeze['selectionQualified'] is not False
     or not timestamp(freeze['frozenUTC'])<=timestamp(workload['registeredUTC'])<=time.time()):
  raise ValueError('Latency workload differs from the prior retained-baseline registration')
 args=argparse.Namespace(label=label,candidate='baseline',phase='validation',split='screen',mode='word',seed=42,
                         workers=1,per_category=None,corpus=None,estimated_seconds=600,reuse_checks='baseline-checks',
                         descriptive_workload=None,descriptive_workload_sha256=None)
 return {'label':label,'args':args,'workload':selected[0],'deadline':phase_deadline(),
         'workloadArtifact':ref(HERE/'baseline-workloads.json'),'freezeArtifact':ref(HERE/'finalist-freeze.json')}


def parse_processes(output):
 result={}
 for line in output.splitlines():
  if not line.strip():continue
  fields=line.split(None,9)
  if len(fields)!=10:raise ValueError('Incomplete ps process observation; raw external arguments omitted')
  pid,ppid,pgid=map(int,fields[:3]);started=' '.join(fields[3:8]);cpu=float(fields[8]);command=fields[9]
  if pid in result:raise ValueError('Duplicate process ID in observation')
  result[pid]={'pid':pid,'ppid':ppid,'pgid':pgid,'startedLocal':started,'cpuPercent':cpu,'command':command}
 return result


def identity(process):return str(process['pid'])+'@'+process['startedLocal']


def retain_process(process):
 """External arguments never leave memory; owned launch commands retain audit detail."""
 if process['ownership']!='external':return process
 return {key:process[key] for key in ('pid','ppid','pgid','startedLocal','cpuPercent','categories','ownership','executable') if key in process}


def process_started(process):return dt.datetime.strptime(process['startedLocal'],'%a %b %d %H:%M:%S %Y').timestamp()


def expected_host_environment(label):
 return {'COTABBY_PHRASE_EVAL':'1','COTABBY_PHRASE_LABEL':label,'COTABBY_PHRASE_OUTPUT':str(HERE/label),
         'COTABBY_PHRASE_WORKERS':'1','COTABBY_PHRASE_SEED':'42','COTABBY_PHRASE_MODE':'word',
         'COTABBY_PHRASE_SPLIT':'screen','COTABBY_PHRASE_CONTEXT':'paired'}


def environment_matches(text,expected):
 # Never retain arbitrary environment values. This reports only the nonsecret eval keys.
 return {key:bool(re.search(r'(?:^|\s)'+re.escape(key+'='+value)+r'(?=\s|$)',text)) for key,value in expected.items()}


def plist_environments(value):
 if isinstance(value,dict):
  if isinstance(value.get('EnvironmentVariables'),dict):yield value['EnvironmentVariables']
  for item in value.values():yield from plist_environments(item)
 elif isinstance(value,list):
  for item in value:yield from plist_environments(item)


class HostedTestIdentity:
 """Bind a launchd-reparented host to one witnessed owned XCTest launcher and eval artifact."""
 def __init__(self,label,folder):
  self.label=label;self.folder=folder;self.expected=expected_host_environment(label)
  self.executable=str(runner.ROOT/'build/DerivedData/Build/Products/Release/Cotabby.app/Contents/MacOS/Cotabby')
  self.launchers={};self.authorized={};self.zero_host=None
 def exact_host(self,process):return process['command']==self.executable or process['command'].startswith(self.executable+' ')
 def baseline(self,processes,observed):
  if any(self.exact_host(process) for process in processes.values()):raise RuntimeError('Expected host was already present immediately before CLI launch')
  self.zero_host=observed
 def annotate(self,processes,relevant,observed):
  if self.zero_host is None:return
  registration_path=HERE/(self.label+'-registration.json')
  if not registration_path.exists():return
  try:registration=read(registration_path)
  except json.JSONDecodeError:return
  if 'inferenceStartedUTC' not in registration:return
  start=timestamp(registration['inferenceStartedUTC'])
  for row in relevant:
   if row['ownership']!='owned' or 'xcodebuild' not in row['command'] or 'test-without-building' not in row['command']:continue
   arguments=shlex.split(row['command'])
   if '-xctestrun' not in arguments:continue
   path=Path(arguments[arguments.index('-xctestrun')+1])
   if path.parent!=runner.ROOT/'build/DerivedData/Build/Products' or not path.name.startswith('Cotabby_phrase-eval-'):continue
   if identity(row) in self.launchers:continue
   try:data=path.read_bytes()
   except FileNotFoundError:continue
   matching=[env for env in plist_environments(plistlib.loads(data)) if all(env.get(key)==value for key,value in self.expected.items())]
   if len(matching)!=1:continue
   digest=hashlib.sha256(data).hexdigest();copy=self.folder/('launch-'+digest+'.json')
   if not copy.exists():
    write_new(copy,{'sourcePath':str(path),'sourceSHA256':digest,'matchingTargetCount':len(matching),
                    'selectedEvalEnvironment':self.expected,
                    'retention':'Only the eight expected nonsecret eval settings are retained; unrelated environment values are omitted.'})
   self.launchers[identity(row)]={'launcher':row,'artifact':ref(copy),'expectedEnvironment':self.expected,'observedUTC':observed}
  hosts=[p for p in processes.values() if self.exact_host(p)]
  host_ids={identity(host) for host in hosts}
  for row in relevant:
   if identity(row) in host_ids:row['ownership']='external'
  if len(hosts)>1:return
  for host in hosts:
   key=identity(host);existing=self.authorized.get(key)
   if existing is None:
    if self.authorized:continue
    launched=process_started(host)
    launchers=[value for value in self.launchers.values()
               if process_started(value['launcher'])<=launched and max(int(start),int(timestamp(self.zero_host)))<=launched<=timestamp(observed)
               and value['launcher']['pid'] in processes
               and identity(processes[value['launcher']['pid']])==identity(value['launcher'])]
    if len(launchers)!=1:continue
    # Query only the exact newly launched private host. Raw output never enters evidence.
    query=['/bin/ps','eww','-p',str(host['pid']),'-o','command=']
    environment=subprocess.run(query,capture_output=True,text=True,check=True,timeout=3).stdout
    matched=environment_matches(environment,self.expected)
    if not all(matched.values()):continue
    existing={'hostIdentity':key,'hostPID':host['pid'],'hostStartedLocal':host['startedLocal'],
              'zeroHostObservedUTC':self.zero_host,'launchEvidence':launchers[0],
              'environmentMatchedKeys':matched,'environmentQuery':query,
              'basis':'Exact private executable, absent before CLI, new start within owned launch interval, matching run artifact and selected live environment keys.'}
    self.authorized[key]=existing
   for row in relevant:
    if identity(row)==key:row.update(ownership='authorized-host',hostAuthorization=existing)


def observe_processes(processes,owner_pid,owner_identity,known_owned):
 """Ownership requires a PID/start identity plus a witnessed parent chain to this driver."""
 owner=processes.get(owner_pid)
 if owner is None or identity(owner)!=owner_identity:raise ValueError('Collector owner identity disappeared or changed')
 known_owned[owner_identity]=[dict(owner)]
 current_owned={pid for pid,process in processes.items() if identity(process) in known_owned}
 changed=True
 while changed:
  changed=False
  for pid,process in processes.items():
   if pid in current_owned or process['ppid'] not in current_owned:continue
   parent=processes[process['ppid']]
   known_owned[identity(process)]=[dict(process)]+known_owned[identity(parent)]
   current_owned.add(pid);changed=True
 relevant=[]
 for pid,process in processes.items():
  categories=[name for name,pattern in PATTERNS.items() if pattern.search(process['command'])]
  if process['cpuPercent']>=EXTERNAL_CPU_THRESHOLD:categories.append('high-cpu')
  if not categories and pid!=owner_pid:continue
  owned=pid in current_owned
  relevant.append(dict(process,categories=categories,ownership='owned' if owned else 'external',
                       ancestryEvidence=known_owned[identity(process)] if owned else []))
 return sorted(relevant,key=lambda item:item['pid'])


class Collector:
 """One wrapper-owned observation thread; failures remain evidence rather than silent gaps."""
 def __init__(self,path,label):
  self.path=path;self.samples=[];self.errors=[];self.known_owned={};self.owner_pid=os.getpid();self.owner_identity=None
  self.stop_event=threading.Event();self.thread=None;self.stream=path.open('x')
  self.host=HostedTestIdentity(label,path.parent);self.sample_lock=threading.RLock()
 def sample(self,phase):
  with self.sample_lock:return self._sample(phase)
 def _sample(self,phase):
  started=now();mono=time.monotonic()
  try:
   completed=subprocess.run(PS_COMMAND,capture_output=True,text=True,check=True,timeout=3)
   processes=parse_processes(completed.stdout)
   executable_output=subprocess.run(PS_EXECUTABLE_COMMAND,capture_output=True,text=True,check=True,timeout=3).stdout
   executables={int(fields[0]):fields[1] for line in executable_output.splitlines() if len(fields:=line.split(None,1))==2}
   for pid,process in processes.items():process['executable']=executables.get(pid,'unavailable-process-ended')
   if self.owner_identity is None:self.owner_identity=identity(processes[self.owner_pid])
   relevant=observe_processes(processes,self.owner_pid,self.owner_identity,self.known_owned)
   if phase=='before-cli-launch':self.host.baseline(processes,started)
   self.host.annotate(processes,relevant,started)
   sample={'observedUTC':started,'finishedUTC':now(),'monotonicSeconds':mono,'phase':phase,
           'processCount':len(processes),'processes':[retain_process(process) for process in relevant]}
   self.samples.append(sample);self.stream.write(json.dumps(sample,sort_keys=True)+'\n');self.stream.flush()
   return sample
  except BaseException as error:
   record={'observedUTC':started,'finishedUTC':now(),'phase':phase,'error':f'{type(error).__name__}: {error}'}
   self.errors.append(record);self.stream.write(json.dumps(record,sort_keys=True)+'\n');self.stream.flush()
   if isinstance(error,(KeyboardInterrupt,SystemExit)):raise
   return None
 def start(self):
  self.sample('before-run')
  def monitor():
   while not self.stop_event.wait(POLL_SECONDS):self.sample('monitoring')
  self.thread=threading.Thread(target=monitor,name='latency-process-observer',daemon=True);self.thread.start()
 def close(self):
  self.stop_event.set()
  if self.thread:self.thread.join(timeout=5)
  if self.thread and self.thread.is_alive():raise RuntimeError('Process collector did not stop')
  self.sample('after-run');self.stream.close()


def isolation_findings(samples,errors,registration):
 if errors:return ['Process observation failed'],[]
 if not registration or registration.get('status')!='complete':return ['Benchmark registration is not complete'],[]
 start=timestamp(registration['inferenceStartedUTC']);finish=timestamp(registration['finishedUTC'])
 if finish<start:return ['Reversed registration interval'],[]
 before=[s for s in samples if timestamp(s['finishedUTC'])<=start]
 after=[s for s in samples if timestamp(s['observedUTC'])>=finish]
 if not before or not after:return ['Observations do not bracket the exact registration interval'],[]
 first=before[-1];last=after[0];selected=samples[samples.index(first):samples.index(last)+1]
 issues=[]
 if len(selected)<3:issues.append('No during-interval process observation')
 if any(b['monotonicSeconds']-a['monotonicSeconds']>MAX_OBSERVATION_GAP_SECONDS for a,b in zip(selected,selected[1:])):
  issues.append('Observation gap exceeds the declared sampling tolerance')
 external=[{'observedUTC':sample['observedUTC'],'process':process}
           for sample in selected if start<=timestamp(sample['observedUTC'])<=finish
           for process in sample['processes'] if process['ownership']=='external']
 if external:issues.append('Unexpected build, inference, analyzer or high-CPU process observed')
 phases=activity_phases(selected)
 if phases['unexpectedOwnedWorkDuringHost']:issues.append('Additional owned compilation or analysis overlapped the observed test-host window')
 return issues,external


def activity_phases(samples):
 """Describe observed setup separately without changing the registered proof interval."""
 host_samples=[sample for sample in samples if any(row['ownership']=='authorized-host' for row in sample['processes'])]
 first=host_samples[0]['observedUTC'] if host_samples else None
 last=host_samples[-1]['observedUTC'] if host_samples else None
 setup=[];unexpected=[]
 for sample in samples:
  for row in sample['processes']:
   if row['ownership']!='owned':continue
   compiling='build' in row.get('categories',[]) and 'test-without-building' not in row.get('command','')
   analyzing='heavy-analysis' in row.get('categories',[])
   if not compiling and not analyzing:continue
   observation={'observedUTC':sample['observedUTC'],'process':row}
   if first and first<=sample['observedUTC']<=last:unexpected.append(observation)
   else:setup.append(observation)
 return {'firstHostObservedUTC':first,'lastHostObservedUTC':last,'ownedSetupOrPostprocessing':setup,
         'unexpectedOwnedWorkDuringHost':unexpected,
         'interpretation':'These are observed process phases, not exact model-generation timestamps. Unattributed shared build services remain external even during setup.'}


def assert_no_registered_overlap(label,registration):
 start=timestamp(registration['inferenceStartedUTC']);finish=timestamp(registration['finishedUTC'])
 for path in HERE.glob('*-registration.json'):
  other=read(path)
  if other.get('label')==label or 'inferenceStartedUTC' not in other:continue
  other_start=timestamp(other['inferenceStartedUTC']);other_finish=timestamp(other['finishedUTC']) if other.get('finishedUTC') else time.time()
  if max(start,other_start)<min(finish,other_finish):raise ValueError('Registered inference overlap: '+path.name)
 for path in HERE.glob('*/validation.json'):
  other=read(path)
  if 'startedUTC' in other and 'finishedUTC' in other and max(start,timestamp(other['startedUTC']))<min(finish,timestamp(other['finishedUTC'])):
   raise ValueError('Registered build/test overlap: '+str(path))


@contextlib.contextmanager
def exact_deadline(limit):
 previous=runner.DEADLINE;runner.DEADLINE=limit+1200
 try:yield
 finally:runner.DEADLINE=previous


@contextlib.contextmanager
def before_cli_observation(collector,label):
 """Take a fresh zero-host sample after checks at the unchanged runner's CLI boundary."""
 previous=runner.run_checks.bounded_command;count=0
 def wrapped(command,stream,**kwargs):
  nonlocal count
  if len(command)>2 and str(command[1])==str(runner.ROOT/'scripts/phrase_eval.py') and command[2]=='run':
   if '--label' not in command or command[command.index('--label')+1]!=label:raise ValueError('Unexpected benchmark label at monitored boundary')
   count+=1
   if count!=1:raise ValueError('Expected exactly one benchmark CLI launch')
   sample=collector.sample('before-cli-launch')
   if sample is None or any(p['ownership']=='external' for p in sample['processes']):
    raise RuntimeError('Immediate pre-inference isolation is not quiet; CLI was not launched')
  return previous(command,stream,**kwargs)
 runner.run_checks.bounded_command=wrapped
 try:yield
 finally:runner.run_checks.bounded_command=previous


def run(label):
 plan=prepare(label);runner.check_time(plan['deadline'],600)
 folder=HERE/(label+'-isolation-evidence');proof_path=HERE/(label+'-isolation.json')
 registration_path=HERE/(label+'-registration.json')
 if any(path.exists() for path in (folder,proof_path,registration_path,HERE/label)):
  raise ValueError('Refusing to overwrite a latency repeat or isolation artifact')
 folder.mkdir();plan_record={'schemaVersion':1,'label':label,'preparedUTC':now(),'arguments':vars(plan['args']),
      'phaseDeadlineUTC':dt.datetime.fromtimestamp(plan['deadline'],dt.timezone.utc).isoformat(),
      'workload':plan['workloadArtifact'],'freeze':plan['freezeArtifact'],'collectorSHA256':sha(Path(__file__)),
      'runnerSHA256':sha(HERE/'run_experiment.py'),'samplePeriodSeconds':POLL_SECONDS,
      'maximumObservationGapSeconds':MAX_OBSERVATION_GAP_SECONDS,'externalCPUThresholdPercent':EXTERNAL_CPU_THRESHOLD,
      'psCommand':PS_COMMAND,'executableCommand':PS_EXECUTABLE_COMMAND,
      'externalArgumentPolicy':'Retain executable/category/PID/start/CPU metadata only; full commands are restricted to owned experiment descendants and the exact authorized host.',
      'ownershipRule':'Observed PID/start identity and explicit ancestry; one host exception requires exact executable, zero-host boundary, owned launcher/artifact and selected eval environment matches.',
      'limitations':LIMITATION}
 write_new(folder/'plan.json',plan_record)
 collector=Collector(folder/'process-observations.jsonl',label);caught=None;registration=None
 try:
  collector.start()
  if collector.errors or any(p['ownership']=='external' for s in collector.samples for p in s['processes']):
   raise RuntimeError('Pre-run isolation is not quiet; benchmark was not launched')
  with exact_deadline(plan['deadline']),before_cli_observation(collector,label):runner.run(plan['args'])
 except BaseException as error:caught=error
 finally:
  try:collector.close()
  except BaseException as error:
   collector.errors.append({'error':f'{type(error).__name__}: {error}'})
   if caught is None:caught=error
  if registration_path.exists():registration=read(registration_path)
  issues,external=isolation_findings(collector.samples,collector.errors,registration)
  if collector.host.zero_host is None:issues.append('Missing immediate pre-CLI zero-host observation')
  if not collector.host.authorized:issues.append('No exact hosted XCTest identity was verified during replay')
  if caught:issues.append(f'Run failed: {type(caught).__name__}: {caught}')
  if registration and registration.get('status')=='complete':
   try:assert_no_registered_overlap(label,registration)
   except Exception as error:issues.append(str(error))
  if sha(HERE/'run_experiment.py')!=plan_record['runnerSHA256']:issues.append('Runner source changed during execution')
  if sha(Path(__file__))!=plan_record['collectorSHA256']:issues.append('Collector source changed during execution')
  for key,path in (('workload',HERE/'baseline-workloads.json'),('freeze',HERE/'finalist-freeze.json')):
   if sha(path)!=plan_record[key]['sha256']:issues.append(key+' artifact changed during execution')
  intervals=[] if not registration or 'inferenceStartedUTC' not in registration else [
      {'label':label,'startedUTC':registration['inferenceStartedUTC'],'finishedUTC':registration['finishedUTC']}]
  evidence={'schemaVersion':1,'label':label,'finishedUTC':now(),'plan':ref(folder/'plan.json'),
            'observations':ref(folder/'process-observations.jsonl'),'sampleCount':len(collector.samples),
            'observationErrors':collector.errors,'unexpectedObservations':external,'issues':issues,
            'authorizedHosts':list(collector.host.authorized.values()),
            'observedPhases':activity_phases(collector.samples),
            'registration':ref(registration_path) if registration_path.exists() else None,'limitations':LIMITATION}
  write_new(folder/'summary.json',evidence)
  proof={'schemaVersion':1,'status':'passed' if not issues else 'failed','labels':[label],'intervals':intervals,
         'noOverlappingBuildOrInference':not issues,'evidence':ref(folder/'summary.json'),
         'claimScope':'No unexpected relevant activity in sampled observations inside the registered interval; bracketing samples establish coverage only.',
         'limitations':LIMITATION}
  write_new(proof_path,proof)
 print(json.dumps({'label':label,'isolation':ref(proof_path),'status':proof['status'],'issues':issues},indent=2))
 if caught:raise caught
 if issues:raise RuntimeError('Latency isolation failed; results retained with failed proof')
 return proof


def main():
 parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--label',choices=LABELS,required=True)
 parser.add_argument('--plan',action='store_true',help='Validate registered workload only; no processes, build, tests or inference')
 args=parser.parse_args()
 if args.plan:
  plan=prepare(args.label)
  print(json.dumps({'arguments':vars(plan['args']),'workload':plan['workloadArtifact'],
                   'phaseDeadlineUTC':dt.datetime.fromtimestamp(plan['deadline'],dt.timezone.utc).isoformat(),
                   'limitations':LIMITATION},indent=2));return
 with (HERE/'experiment.lock').open('a') as lock, (HERE/'descriptive-analysis.lock').open('a') as analysis_lock:
  fcntl.flock(lock.fileno(),fcntl.LOCK_EX|fcntl.LOCK_NB)
  fcntl.flock(analysis_lock.fileno(),fcntl.LOCK_EX|fcntl.LOCK_NB)
  run(args.label)

if __name__=='__main__':main()
