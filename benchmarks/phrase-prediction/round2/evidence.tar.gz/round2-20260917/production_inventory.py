#!/usr/bin/env python3
"""Describe the complete production input boundary independently of test-only edits.

Compiler fingerprints still bind every actual build. This narrower inventory lets a later
current-main integration or corrected test expectation prove that production bytes match
the frozen baseline or finalist, even when its full compiler fingerprint legitimately differs.
"""
import hashlib
import json
import os
from pathlib import Path

HERE = Path(__file__).resolve().parent
TARGET_PATHS = {
    'renderer': 'app/Cotabby/Support/Prompting/BaseCompletionPromptRenderer.swift',
    'composer': 'app/Cotabby/Support/Context/SurfaceContextComposer.swift',
    'nativeEngine': 'native/Sources/CotabbyInferenceEngine/CotabbyInferenceEngine.cpp',
}
SCOPE = {
    'app': ['Cotabby', 'Config', 'Cotabby.xcodeproj', 'project.yml', 'CotabbyInfo.plist'],
    'native': ['Package.swift', 'Sources'],
}


def included(role, relative):
    # User-local Xcode state is not copied into experiment snapshots. Canonical dependency
    # lock bytes are bound separately by each compiler manifest and package-resolution proof.
    if 'xcuserdata' in Path(relative).parts or Path(relative).name in ('.DS_Store', 'Package.resolved'):
        return False
    return any(relative == base or relative.startswith(base + '/') for base in SCOPE[role])


def capture(app, native):
    files = {}
    for role, root in [('app', Path(app)), ('native', Path(native))]:
        for base in SCOPE[role]:
            path = root / base
            paths = sorted(path.rglob('*')) if path.is_dir() else [path]
            for item in paths:
                if item.is_dir() or not included(role, str(item.relative_to(root))):
                    continue
                if not item.exists() and not item.is_symlink():
                    raise ValueError(f'Missing production input: {item}')
                data = os.readlink(item).encode() if item.is_symlink() else item.read_bytes()
                files[f'{role}/{item.relative_to(root)}'] = hashlib.sha256(data).hexdigest()
    return {'schemaVersion': 1, 'scope': SCOPE, 'files': dict(sorted(files.items()))}


def baseline_from_snapshot():
    snapshot = json.loads((HERE / 'starting-snapshot.json').read_text())
    files = {}
    for role in ('app', 'native'):
        for relative, entry in snapshot[role]['after']['files'].items():
            if included(role, relative) and entry['kind'] != 'deleted':
                files[f'{role}/{relative}'] = entry['sha256']
    return {'schemaVersion': 1, 'scope': SCOPE, 'files': dict(sorted(files.items()))}


def with_targets(baseline, targets):
    result = json.loads(json.dumps(baseline))
    if set(targets) != set(TARGET_PATHS):
        raise ValueError('Expected exactly the registered production target identities')
    for key, logical in TARGET_PATHS.items():
        if logical not in result['files']:
            raise ValueError('Production target missing from source snapshot')
        result['files'][logical] = targets[key]
    return result


def reference(path):
    return {'path': str(path.relative_to(HERE)),
            'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}
