#!/usr/bin/env python3
"""Tiny invented evidence tests; never load benchmark reports or protected fixtures.

These fixtures exercise the decision boundary, especially inputs that ordinary paired
score comparisons could accept despite missing evidence. The production analyzer is
replaced by a recording double, so this suite performs no inference or large bootstrap.
"""
import copy
from fractions import Fraction
import importlib.util
import json
import math
from pathlib import Path
import tempfile
import unittest
from unittest import mock


SPEC = importlib.util.spec_from_file_location('round2_assessment_subject', Path(__file__).with_name('assess_round2.py'))
SUBJECT = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(SUBJECT)


def fixture_metrics(observations):
    """Construct the serialized Swift-shaped metrics independently of the subject."""
    count = len(observations)
    correct = sum(item['correct'] for item in observations)
    shown = sum(item['wasShown'] for item in observations)
    errors = sum(item.get('error') is not None for item in observations)
    latencies = sorted(item['latencyMilliseconds'] for item in observations
                       if item.get('error') is None and item.get('suppression') != 'pre-generation-gate')
    return {
        'checkpoints': count, 'correct': correct, 'shown': shown, 'errors': errors,
        'accuracy': correct / count if count else None,
        'coverage': shown / count if count else None,
        'precisionWhenShown': correct / shown if shown else None,
        'latencyP50Milliseconds': latencies[math.ceil(len(latencies) * .5) - 1] if latencies else None,
        'latencyP95Milliseconds': latencies[math.ceil(len(latencies) * .95) - 1] if latencies else None,
    }


def refresh_aggregates(report):
    """Rebuild fixture accounting after a mutation, leaving its opaque input plan fixed."""
    def summary(rows):
        observations = [item for row in rows for item in row['observations']]
        return {'phraseCount': len(rows), 'all': fixture_metrics(observations),
                'nextWord': fixture_metrics([item for item in observations if item['checkpoint']['typedCharacters'] == 0])}
    for row in report['phrases']:
        row.update({key: value for key, value in summary([row]).items() if key != 'phraseCount'})
    report['conditions'] = {}
    for condition in ('none', 'screen'):
        rows = [row for row in report['phrases'] if row['condition'] == condition]
        categories = sorted({row['phrase']['category'] for row in rows})
        report['conditions'][condition] = {
            'suite': summary(rows),
            'categories': {category: summary([row for row in rows if row['phrase']['category'] == category])
                           for category in categories},
        }
    return report


def tiny_evidence(correct=(False, True, False), *, mode='character', categories=('science',)):
    """Three checkpoints per phrase: two boundaries and one partial-word position."""
    checkpoints = [
        {'wordIndex': 1, 'typedCharacters': 0, 'prefix': 'The ', 'typedWordPrefix': '', 'expectedWord': 'ox'},
        {'wordIndex': 1, 'typedCharacters': 1, 'prefix': 'The o', 'typedWordPrefix': 'o', 'expectedWord': 'ox'},
        {'wordIndex': 2, 'typedCharacters': 0, 'prefix': 'The ox ', 'typedWordPrefix': '', 'expectedWord': 'I'},
    ]
    indices = (0, 2) if mode == 'word' else (0, 1, 2)
    manifest = {'schemaVersion': 1, 'corpusSHA256': 'a' * 64, 'scorerSourceSHA256': 'b' * 64,
                'corpusVersion': 2, 'mode': mode, 'phraseCount': len(categories),
                'checkpointsPerCondition': len(indices) * len(categories), 'phrases': []}
    report = {'schemaVersion': 2, 'metadata': {'corpusSHA256': 'a' * 64, 'corpusVersion': 2,
              'mode': mode, 'contextMode': 'paired', 'seed': 42, 'workerCount': 1},
              'errorCount': 0, 'phrases': []}
    fixture = {'phrases': []}
    for ordinal, category in enumerate(categories):
        identifier = f'invented-{ordinal}'
        phrase = {'id': identifier, 'category': category, 'text': 'The ox I'}
        fixture['phrases'].append(copy.deepcopy(phrase))
        manifest['phrases'].append({'phraseID': identifier, 'category': category,
            'checkpoints': [{key: checkpoints[index][key] for key in ('wordIndex', 'typedCharacters')} for index in indices]})
        for condition in ('none', 'screen'):
            observations = [{'checkpoint': copy.deepcopy(checkpoints[index]), 'correct': correct[index],
                             'wasShown': True, 'raw': 'invented continuation', 'shown': 'invented continuation',
                             'latencyMilliseconds': 100.0} for index in indices]
            report['phrases'].append({'phrase': copy.deepcopy(phrase), 'condition': condition, 'observations': observations})
    return refresh_aggregates(report), manifest, fixture


class RecordingAnalyzer:
    def __init__(self):
        self.calls = []

    def paired_statistics(self, old, new, **kwargs):
        self.calls.append((old, new, kwargs))
        categories = sorted({row['phrase']['category'] for row in old.values()})
        return {'samples': kwargs['samples'], 'seed': kwargs['seed'], 'clusterUnit': 'evaluationGroup',
                'accuracyDeltaIntervals': {f'{condition}/{category}': [.001, .1]
                    for condition in ('none', 'screen') for category in ('suite', *categories)}}


def gate_comparison(screen=Fraction(1, 200), none=-Fraction(1, 200), category=-Fraction(3, 100)):
    def row(value):
        value = Fraction(value)
        return {'deltaNumerator': value.numerator, 'deltaDenominator': value.denominator,
                'accuracyDelta': float(value)}
    return {'subset': 'word', 'deltas': {
        'screen': {'suite': row(screen), 'science': row(category)},
        'none': {'suite': row(none), 'science': row(none)}},
        'bootstrap': {'samples': 20000, 'seed': 1337, 'clusterUnit': 'evaluationGroup',
            'accuracyDeltaIntervals': {'screen/suite': [.000001, .03], 'none/suite': [-.009999, .02]}}}


class ReportEvidenceTests(unittest.TestCase):
    def test_valid_full_report_and_opaque_plan_pass(self):
        report, plan, fixture = tiny_evidence(categories=('science', 'work'))
        self.assertEqual(len(SUBJECT.validate_report(report, plan, fixture)), 4)

    def test_authoritative_flags_must_be_actual_booleans_and_present(self):
        for name, value in [('correct', 1), ('correct', 'true'), ('wasShown', 1), ('correct', None)]:
            with self.subTest(name=name, value=value):
                report, plan, _ = tiny_evidence()
                report['phrases'][0]['observations'][0][name] = value
                with self.assertRaises(SUBJECT.EvidenceError):
                    SUBJECT.validate_report(report, plan)
        report, plan, _ = tiny_evidence()
        del report['phrases'][0]['observations'][0]['correct']
        with self.assertRaises(SUBJECT.EvidenceError):
            SUBJECT.validate_report(report, plan)

    def test_matching_missing_or_duplicate_checkpoints_fail_even_with_consistent_totals(self):
        for mutation in ('missing', 'duplicate'):
            with self.subTest(mutation=mutation):
                report, plan, _ = tiny_evidence()
                for row in report['phrases']:
                    if mutation == 'missing':
                        row['observations'].pop(1)
                    else:
                        row['observations'].insert(1, copy.deepcopy(row['observations'][0]))
                refresh_aggregates(report)
                with self.assertRaises(SUBJECT.EvidenceError):
                    SUBJECT.validate_report(report, plan)

    def test_condition_checkpoint_and_phrase_identity_must_match(self):
        for mutation in ('checkpoint', 'phrase'):
            with self.subTest(mutation=mutation):
                report, plan, _ = tiny_evidence()
                screen = report['phrases'][1]
                if mutation == 'checkpoint':
                    screen['observations'][0]['checkpoint']['prefix'] = 'Different '
                else:
                    screen['phrase']['text'] = 'Different phrase'
                with self.assertRaises(SUBJECT.EvidenceError):
                    SUBJECT.validate_report(report, plan)

    def test_missing_condition_and_duplicate_phrase_row_fail(self):
        for duplicate in (False, True):
            with self.subTest(duplicate=duplicate):
                report, plan, _ = tiny_evidence()
                if duplicate:
                    report['phrases'].append(copy.deepcopy(report['phrases'][0]))
                else:
                    report['phrases'].pop()
                refresh_aggregates(report)
                with self.assertRaises(SUBJECT.EvidenceError):
                    SUBJECT.validate_report(report, plan)

    def test_phrase_and_category_accounting_cannot_disagree_with_flags(self):
        for level in ('phrase', 'category', 'suite'):
            with self.subTest(level=level):
                report, plan, _ = tiny_evidence()
                if level == 'phrase':
                    target = report['phrases'][0]
                elif level == 'category':
                    target = report['conditions']['none']['categories']['science']
                else:
                    target = report['conditions']['none']['suite']
                target['all']['correct'] += 1
                with self.assertRaises(SUBJECT.EvidenceError):
                    SUBJECT.validate_report(report, plan)

    def test_nonfinite_metrics_latency_errors_and_unshown_correct_fail(self):
        for mutation in ('accuracy', 'nan_latency', 'negative_latency', 'error', 'unshown_correct'):
            with self.subTest(mutation=mutation):
                report, plan, _ = tiny_evidence()
                observation = report['phrases'][0]['observations'][1]
                if mutation == 'accuracy':
                    report['phrases'][0]['all']['accuracy'] = float('nan')
                elif mutation == 'nan_latency':
                    observation['latencyMilliseconds'] = float('nan')
                elif mutation == 'negative_latency':
                    observation['latencyMilliseconds'] = -1
                elif mutation == 'error':
                    observation['error'] = 'invented failure'
                else:
                    observation['wasShown'] = False
                with self.assertRaises(SUBJECT.EvidenceError):
                    SUBJECT.validate_report(report, plan)

    def test_fixture_identity_is_checked_without_lexical_rescoring(self):
        report, plan, fixture = tiny_evidence()
        # The invented continuation does not lexically match the reference. Swift flags
        # remain authoritative; this Python boundary checks integrity, not word matching.
        SUBJECT.validate_report(report, plan, fixture)
        fixture['phrases'][0]['text'] = 'Another invented source'
        with self.assertRaises(SUBJECT.EvidenceError):
            SUBJECT.validate_report(report, plan, fixture)

    def test_checkpoint_plan_rejects_duplicates_invalid_coordinates_and_word_partials(self):
        for mutation in ('duplicate', 'negative', 'boolean', 'word_partial', 'count'):
            with self.subTest(mutation=mutation):
                _, plan, _ = tiny_evidence()
                if mutation == 'duplicate':
                    plan['phrases'][0]['checkpoints'][1] = copy.deepcopy(plan['phrases'][0]['checkpoints'][0])
                elif mutation == 'negative':
                    plan['phrases'][0]['checkpoints'][0]['typedCharacters'] = -1
                elif mutation == 'boolean':
                    plan['phrases'][0]['checkpoints'][0]['wordIndex'] = True
                elif mutation == 'word_partial':
                    plan['mode'] = 'word'
                else:
                    plan['checkpointsPerCondition'] += 1
                with self.assertRaises(SUBJECT.EvidenceError):
                    SUBJECT.validate_checkpoint_manifest(plan)

    def test_report_coordinates_must_be_integers_not_equal_booleans(self):
        for coordinate, replacement in [('wordIndex', True), ('typedCharacters', False)]:
            with self.subTest(coordinate=coordinate):
                report, plan, _ = tiny_evidence()
                for row in report['phrases']:
                    row['observations'][0]['checkpoint'][coordinate] = replacement
                with self.assertRaises(SUBJECT.EvidenceError):
                    SUBJECT.validate_report(report, plan)


class DecisionTests(unittest.TestCase):
    def test_partial_loss_is_not_hidden_by_boundary_gain(self):
        baseline, plan, _ = tiny_evidence((False, True, False))
        finalist, _, _ = tiny_evidence((True, False, True))
        before = SUBJECT.validate_report(baseline, plan)
        after = SUBJECT.validate_report(finalist, plan)
        analyzer = RecordingAnalyzer()
        all_points = SUBJECT.compare_indices(before, after, analyzer, subset='all')
        boundary = SUBJECT.compare_indices(before, after, analyzer, subset='word')
        partial = SUBJECT.compare_indices(before, after, analyzer, subset='partial')
        self.assertGreater(SUBJECT.exact_delta(all_points, 'screen'), 0)
        self.assertEqual(SUBJECT.exact_delta(boundary, 'screen'), 1)
        self.assertEqual(SUBJECT.exact_delta(partial, 'screen'), -1)
        self.assertFalse(any(SUBJECT.quality_gates(partial, 'character').values()))
        self.assertIn('screen/science', partial['bootstrap']['accuracyDeltaIntervals'])

    def test_character_gate_rejects_all_checkpoint_or_boundary_comparison(self):
        for subset in ('all', 'word'):
            with self.subTest(subset=subset):
                comparison = gate_comparison(screen=Fraction(1, 10), none=Fraction(1, 10))
                comparison['subset'] = subset
                with self.assertRaises(SUBJECT.EvidenceError):
                    SUBJECT.quality_gates(comparison, 'character')

    def test_comparison_passes_registered_bootstrap_parameters_and_paired_families(self):
        before_report, plan, _ = tiny_evidence(categories=('science', 'work'))
        after_report = copy.deepcopy(before_report)
        for report in (before_report, after_report):
            for row in report['phrases']:
                row['phrase'].update(evaluationGroup=row['phrase']['id'] + '-family', contextKind='useful')
        analyzer = RecordingAnalyzer()
        old, new = SUBJECT.validate_report(before_report, plan), SUBJECT.validate_report(after_report, plan)
        SUBJECT.compare_indices(old, new, analyzer, subset='partial', context_kind='useful')
        a, b, kwargs = analyzer.calls[0]
        self.assertEqual(kwargs, {'samples': 20000, 'seed': 1337, 'metric': 'all'})
        self.assertEqual(set(a), set(b))
        self.assertEqual({key[1] for key in a}, {'none', 'screen'})
        self.assertTrue(all(len(row['observations']) == 1 for row in a.values()))
        self.assertTrue(all(row['phrase']['evaluationGroup'].endswith('-family') for row in a.values()))

    def test_pair_with_same_coordinates_but_different_checkpoint_text_fails(self):
        report, plan, _ = tiny_evidence()
        old = SUBJECT.validate_report(report, plan)
        new = copy.deepcopy(old)
        for row in new.values():
            row['observations'][0]['checkpoint']['expectedWord'] = 'different'
        with self.assertRaises(SUBJECT.EvidenceError):
            SUBJECT.compare_indices(old, new, RecordingAnalyzer())

    def test_fresh_thresholds_accept_equal_effect_and_category_floors(self):
        comparison = gate_comparison()
        self.assertTrue(all(SUBJECT.quality_gates(comparison, 'fresh').values()))
        comparison['deltas']['screen']['suite']['accuracyDelta'] = 0.0
        # Exact fractions, not rounded presentation values, decide the threshold.
        self.assertTrue(SUBJECT.quality_gates(comparison, 'fresh')['fresh-screen-effect'])

    def test_fresh_confidence_lower_bounds_are_strict(self):
        comparison = gate_comparison()
        comparison['bootstrap']['accuracyDeltaIntervals']['screen/suite'][0] = 0
        comparison['bootstrap']['accuracyDeltaIntervals']['none/suite'][0] = -.01
        gates = SUBJECT.quality_gates(comparison, 'fresh')
        self.assertFalse(gates['fresh-screen-interval'])
        self.assertFalse(gates['fresh-none-interval'])

    def test_fresh_thresholds_reject_values_just_below_floors(self):
        comparison = gate_comparison(screen=Fraction(49, 10000), none=-Fraction(51, 10000), category=-Fraction(301, 10000))
        gates = SUBJECT.quality_gates(comparison, 'fresh')
        for key in ('fresh-screen-effect', 'fresh-none-effect', 'fresh-screen-categories'):
            self.assertFalse(gates[key], key)

    def test_fresh_bootstrap_wrong_sample_count_seed_or_cluster_is_rejected(self):
        for key, value in [('samples', 2000), ('seed', 42), ('clusterUnit', 'phrase')]:
            with self.subTest(key=key):
                comparison = gate_comparison()
                comparison['bootstrap'][key] = value
                with self.assertRaises(SUBJECT.EvidenceError):
                    SUBJECT.quality_gates(comparison, 'fresh')

    def test_historical_accepts_zero_but_production_requires_positive_screen(self):
        comparison = gate_comparison(screen=0, none=0, category=0)
        self.assertTrue(all(SUBJECT.quality_gates(comparison, 'historical').values()))
        self.assertFalse(SUBJECT.quality_gates(comparison, 'productionSeed')['productionSeed-screen-positive'])
        comparison = gate_comparison(screen=Fraction(1, 10000), none=-Fraction(1, 200))
        self.assertTrue(all(SUBJECT.quality_gates(comparison, 'productionSeed').values()))

    def test_latency_uses_larger_threshold_and_strict_exceedance(self):
        for baseline, delta, investigation in [(100, 20, False), (100, 20.001, True),
                                                (400, 40, False), (400, 40.001, True)]:
            with self.subTest(baseline=baseline, delta=delta):
                comparison = gate_comparison()
                for condition in ('none', 'screen'):
                    comparison['deltas'][condition]['suite'].update(
                        baseline={'latencyP95Milliseconds': baseline},
                        finalist={'latencyP95Milliseconds': baseline + delta})
                changes = SUBJECT.latency_changes(comparison)
                for value in changes.values():
                    self.assertEqual(value['requiresInvestigation'], investigation)
                    self.assertEqual(value['thresholdMilliseconds'], max(baseline * .1, 20))

    def test_latency_requires_samples(self):
        comparison = gate_comparison()
        for condition in ('none', 'screen'):
            comparison['deltas'][condition]['suite'].update(
                baseline={'latencyP95Milliseconds': None}, finalist={'latencyP95Milliseconds': 100})
        with self.assertRaises(SUBJECT.EvidenceError):
            SUBJECT.latency_changes(comparison)


class TemporaryEvidenceTests(unittest.TestCase):
    """Exercise disk evidence with invented artifacts in an automatically removed directory."""
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory(prefix='round2-assessment-unit-')
        self.addCleanup(self.temporary.cleanup)
        self.root = Path(self.temporary.name)

    def write(self, name, value):
        path = self.root / name
        path.parent.mkdir(parents=True, exist_ok=True)
        data = value.encode() if isinstance(value, str) else (json.dumps(value, sort_keys=True) + '\n').encode()
        path.write_bytes(data)
        return {'path': name, 'sha256': SUBJECT.digest(data)}

    def invented_harness(self, prefix=''):
        paths = set(SUBJECT.HARNESS_FIXED) | {
            'CotabbyTests/Evals/' + name for name in SUBJECT.HARNESS_REQUIRED_EVALS}
        result = {}
        for relative in sorted(paths):
            comment = '#' if relative.endswith('.py') else '//'
            reference = self.write(str(Path(prefix) / relative), f'{comment} Invented harness fixture: {relative}\n')
            result['app/' + relative] = reference['sha256']
        return result

    def reader_with_run(self, role='baseline', reader=None):
        """Build only the read-boundary artifacts needed by load_run, never a real replay."""
        reader = reader or SUBJECT.Assessment(self.root)
        targets = {'renderer': '1' * 64, 'composer': '2' * 64, 'nativeEngine': '3' * 64}
        finalist_targets = dict(targets, renderer='4' * 64)
        reader.frozen = {'candidate': 'F1', 'components': ['F1'], 'frozenUTC': '2026-09-17T09:00:00Z',
            'baselineLabel': 'screen-baseline', 'candidateLabel': 'screen-F1',
            'baselineSourceSHA256': 'c' * 64, 'candidateSourceSHA256': 'd' * 64,
            'baselineTargets': targets, 'candidateTargets': finalist_targets, 'modelSHA256': 'e' * 64,
            'validationHarnessHashes': self.invented_harness()}
        reader.round_record = {'deadlineUTC': '2026-09-17T18:00:00Z'}
        source = reader.frozen['baselineSourceSHA256' if role == 'baseline' else 'candidateSourceSHA256']
        chosen = targets if role == 'baseline' else finalist_targets
        label = 'validation-' + role
        inputs = {'sourceSHA256': source, 'nonLockSourceSHA256': 'f' * 64,
                  'packageLocks': {'invented/Package.resolved': 'a' * 64}}
        report, plan, fixture = tiny_evidence(mode='word')
        fixture_ref = self.write('invented-corpus.json', fixture)
        plan.update(corpusSHA256=fixture_ref['sha256'], selection='all', perCategory=0)
        metadata = report['metadata']
        metadata.update(corpusSHA256=fixture_ref['sha256'], runLabel=label,
            configuration={'modelSHA256': 'e' * 64, 'temperature': '0.1', 'repetitionPenalty': '1.025',
                'topK': '20', 'topP': '0.7', 'minP': '0.08', 'randomSeed': 'Optional(42)',
                'confidenceFloor': '-inf', 'stopAtArgmaxEOG': 'true', 'maxPredictionTokens': '5',
                'defaultWordCountPreset': 'twelveToTwenty', 'selectionSplit': 'all'})
        manifest = {'label': label, 'buildInputs': inputs,
            'build': {'sourceSHA256': source, 'productSHA256': 'b' * 64, 'reused': False},
            'corpusSHA256': plan['corpusSHA256'], 'mode': 'word', 'contextMode': 'paired',
            'phraseIDs': [row['phraseID'] for row in plan['phrases']],
            'selection': {'split': 'all', 'perCategory': None, 'limit': None, 'splitSeed': 1337, 'screenPerCategory': 20},
            'samplingOverrides': dict(SUBJECT.SAMPLING, seed=42), 'workerCount': 1,
            'evaluationInputsSHA256': SUBJECT.digest(json.dumps({'compilerInputsSHA256': source,
                'corpusSHA256': plan['corpusSHA256']}, sort_keys=True).encode()),
            'corpusInput': {'sha256': plan['corpusSHA256'], 'version': 2,
                            'sourcePath': str(self.root / fixture_ref['path']), 'replayPath': None}}
        selected_test = 'BaseCompletionPromptRendererTests/testRoundTwoScreeningPromptAudit'
        checks = {'status': 'passed', 'productSHA256': 'b' * 64, 'buildInputs': inputs,
                  'tests': [selected_test], 'startedUTC': '2026-09-17T09:58:00Z',
                  'finishedUTC': '2026-09-17T09:59:00Z', 'execution': {'root': str(self.root)}}
        checks_ref = self.write(label + '-checks/validation.json', checks)
        self.write(label + '-checks/validation.log',
            "Test Case '-[CotabbyTests.BaseCompletionPromptRendererTests testRoundTwoScreeningPromptAudit]' passed (0.01 seconds).\n"
            '** TEST EXECUTE SUCCEEDED **\n')
        registration = {'label': label, 'phase': 'validation', 'status': 'complete',
            'candidate': 'baseline' if role == 'baseline' else 'F1',
            'startedUTC': '2026-09-17T09:57:00Z', 'inferenceStartedUTC': '2026-09-17T10:00:00Z',
            'finishedUTC': '2026-09-17T10:05:00Z', 'checks': checks_ref['path'],
            'promptSource': {'hashes': {key: chosen[key] for key in ('renderer', 'composer')}},
            'nativeSource': {'sha256': chosen['nativeEngine']}}
        self.write(label + '-registration.json', registration)
        self.write(label + '/manifest.json', manifest)
        self.write(label + '/report.json', report)
        self.write('screen-baseline/manifest.json', {'buildInputs': inputs})
        anchor = copy.deepcopy(report)
        anchor['metadata']['configuration']['selectionSplit'] = 'screen'
        self.write('screen-baseline/report.json', anchor)
        return reader, label, plan, report, manifest, registration

    def test_missing_freeze_does_not_read_evidence_or_reports(self):
        reader = SUBJECT.Assessment(self.root)
        with mock.patch.object(reader, 'read_bytes', wraps=reader.read_bytes) as read:
            with self.assertRaises(FileNotFoundError):
                reader.assess('invented-evidence.json')
        self.assertEqual([str(call.args[0]) for call in read.call_args_list], ['finalist-freeze.json'])

    def test_invalid_freeze_does_not_read_evidence_or_reports(self):
        self.write('finalist-freeze.json', {'schemaVersion': 999})
        self.write('round.json', {})
        reader = SUBJECT.Assessment(self.root)
        with mock.patch.object(reader, 'read_bytes', wraps=reader.read_bytes) as read:
            with self.assertRaises(SUBJECT.EvidenceError):
                reader.assess('invented-evidence.json')
        self.assertEqual([str(call.args[0]) for call in read.call_args_list], ['finalist-freeze.json', 'round.json'])

    def test_direct_run_loader_blocks_all_reads_without_validated_freeze(self):
        reader = SUBJECT.Assessment(self.root)
        with mock.patch.object(reader, 'read_json', side_effect=AssertionError('Unexpected evidence read')):
            with self.assertRaises(SUBJECT.EvidenceError):
                reader.load_run('invented', 'baseline', {}, 'fresh')

    def test_valid_invented_run_passes_source_and_effective_config_checks(self):
        reader, label, plan, _, _, _ = self.reader_with_run()
        result = reader.load_run(label, 'baseline', plan, 'historical')
        self.assertEqual(result['sourceSHA256'], 'c' * 64)
        self.assertEqual(len(result['index']), 2)

    def test_changed_effective_sampler_rejected_even_when_manifest_is_registered(self):
        reader, label, plan, report, _, _ = self.reader_with_run()
        report['metadata']['configuration']['topP'] = '0.95'
        self.write(label + '/report.json', report)
        with self.assertRaisesRegex(SUBJECT.EvidenceError, 'Effective configuration drifted'):
            reader.load_run(label, 'baseline', plan, 'historical')

    def test_pair_rejects_effective_preference_mismatch_beyond_selected_sampler_fields(self):
        reader, baseline, plan, _, _, _ = self.reader_with_run()
        _, finalist, _, report, _, _ = self.reader_with_run('finalist', reader)
        report['metadata']['configuration']['defaultWordCountPreset'] = 'invented-different-preset'
        self.write(finalist + '/report.json', report)
        reference = self.write('checkpoint-plan.json', plan)
        reader.checkpoint_exporter = {'manifests': [reference]}
        with mock.patch.object(reader, 'validate_cohort'):
            with self.assertRaisesRegex(SUBJECT.EvidenceError, 'Effective configuration drifted'):
                reader.pair({'baseline': baseline, 'finalist': finalist, 'checkpoints': reference},
                            'historical', RecordingAnalyzer())

    def test_wrong_source_and_incomplete_registration_stop_before_report_read(self):
        for mutation in ('source', 'status'):
            with self.subTest(mutation=mutation):
                reader, label, plan, _, manifest, registration = self.reader_with_run()
                if mutation == 'source':
                    manifest['buildInputs']['sourceSHA256'] = '0' * 64
                    self.write(label + '/manifest.json', manifest)
                else:
                    registration['status'] = 'failed-or-interrupted'
                    self.write(label + '-registration.json', registration)
                with mock.patch.object(reader, 'read_bytes', wraps=reader.read_bytes) as read:
                    with self.assertRaises(SUBJECT.EvidenceError):
                        reader.load_run(label, 'baseline', plan, 'historical')
                self.assertFalse(any(str(call.args[0]).endswith('/report.json') for call in read.call_args_list))

    def test_check_log_must_prove_the_requested_test_actually_passed(self):
        reader, label, plan, _, _, _ = self.reader_with_run()
        self.write(label + '-checks/validation.log', '** TEST EXECUTE SUCCEEDED **\n')
        with self.assertRaisesRegex(SUBJECT.EvidenceError, 'successful XCTest execution'):
            reader.load_run(label, 'baseline', plan, 'historical')

    def test_artifact_binding_and_end_of_assessment_drift_rejected(self):
        reference = self.write('invented-artifact.json', {'value': 1})
        reader = SUBJECT.Assessment(self.root)
        self.assertEqual(reader.artifact(reference), {'value': 1})
        self.write('invented-artifact.json', {'value': 2})
        with self.assertRaises(SUBJECT.EvidenceError):
            reader.stable_artifacts()
        with self.assertRaises(SUBJECT.EvidenceError):
            SUBJECT.Assessment(self.root).artifact(reference)

    def test_source_binding_rejects_changed_target_or_inventory(self):
        reader, _, _, _, _, _ = self.reader_with_run()
        inventory = {'schemaVersion': 1, 'scope': SUBJECT.PRODUCTION_SCOPE,
            'files': {path: reader.frozen['baselineTargets'][key] for key, path in SUBJECT.TARGET_PATHS.items()}}
        inventory['files']['app/Cotabby/InventedPrerequisite.swift'] = 'a' * 64
        reference = self.write('invented-inventory.json', inventory)
        reader.inventories = {'baseline': inventory}
        binding = {'label': 'new-location', 'role': 'baseline', 'sourceSHA256': '9' * 64,
                   'targets': reader.frozen['baselineTargets'], 'productionInventory': reference}
        changed = copy.deepcopy(binding)
        changed['targets']['renderer'] = '0' * 64
        with self.assertRaisesRegex(SUBJECT.EvidenceError, 'changed selected production targets'):
            reader.add_binding(changed)
        different_inventory = copy.deepcopy(inventory)
        different_inventory['files']['app/Cotabby/InventedPrerequisite.swift'] = 'b' * 64
        binding['productionInventory'] = self.write('changed-inventory.json', different_inventory)
        with self.assertRaises(SUBJECT.EvidenceError):
            reader.add_binding(binding)

    def isolation_evidence(self):
        runs = [{'label': label, 'registration': {'inferenceStartedUTC': start, 'finishedUTC': end}}
                for label, start, end in (
                    ('latency-a', '2026-09-17T10:00:00Z', '2026-09-17T10:05:00Z'),
                    ('latency-b', '2026-09-17T10:06:00Z', '2026-09-17T10:11:00Z'))]
        proof = self.write('invented-isolation.txt', 'Invented machine activity journal for this unit fixture.\n')
        evidence = {'schemaVersion': 1, 'status': 'passed', 'labels': [row['label'] for row in runs],
            'noOverlappingBuildOrInference': True, 'evidence': proof,
            'intervals': [{'label': row['label'], 'startedUTC': row['registration']['inferenceStartedUTC'],
                           'finishedUTC': row['registration']['finishedUTC']} for row in runs]}
        for row in runs:
            self.write(row['label'] + '-registration.json', dict(row['registration'], label=row['label']))
        return runs, self.write('invented-isolation.json', evidence)

    def test_latency_isolation_accepts_disjoint_runs(self):
        runs, reference = self.isolation_evidence()
        SUBJECT.Assessment(self.root).validate_isolation(reference, runs)

    def test_latency_isolation_rejects_other_inference_overlap(self):
        runs, reference = self.isolation_evidence()
        self.write('other-registration.json', {'label': 'other', 'inferenceStartedUTC': '2026-09-17T10:04:00Z',
                                              'finishedUTC': '2026-09-17T10:07:00Z'})
        with self.assertRaisesRegex(SUBJECT.EvidenceError, 'another registered inference'):
            SUBJECT.Assessment(self.root).validate_isolation(reference, runs)

    def test_latency_isolation_rejects_build_overlap(self):
        runs, reference = self.isolation_evidence()
        self.write('other-checks/validation.json', {'startedUTC': '2026-09-17T10:04:00Z',
                                                 'finishedUTC': '2026-09-17T10:07:00Z'})
        with self.assertRaisesRegex(SUBJECT.EvidenceError, 'registered build/test'):
            SUBJECT.Assessment(self.root).validate_isolation(reference, runs)

    def assessment_fixture(self):
        """Stub already-covered statistical loaders to isolate final evidence-state logic."""
        reader = SUBJECT.Assessment(self.root)
        frozen = {'candidate': 'F1', 'candidateSourceSHA256': 'd' * 64, 'frozenUTC': '2026-09-17T09:00:00Z'}
        reader.frozen = frozen
        self.write('scripts/analyze_phrase_experiments.py', '# Invented empty analyzer; pair is a test double.\n')
        self.write('execution.json', {'root': str(self.root)})
        scorer = self.write('CotabbyTests/Evals/PhrasePredictionScoring.swift', '// Invented scorer bytes.\n')
        helper = self.write('checkpoint-helper.swift', '// Invented helper bytes.\n')
        binary = self.write('checkpoint-exporter', 'Invented binary bytes; never executed.\n')
        plan = self.write('checkpoint-plan.json', {})
        exporter = self.write('checkpoint-exporter.json', {'schemaVersion': 1, 'compilerVersion': 'invented',
            'scorerSource': scorer, 'helperSource': helper, 'binary': binary, 'manifests': [plan]})
        evidence = {'schemaVersion': 1, 'currentMainIntegration': {}, 'focusedTests': [],
            'checkpointExporter': exporter,
            'pairs': {kind: {} for kind in ('fresh', 'historical', 'character', 'productionSeed', 'latency')},
            'optionalPairs': [{'name': name, 'kind': kind, 'status': 'not-run', 'reason': 'Invented timing limit.'}
                for name, kind in [('fresh-seed1337', 'freshSeed'), ('character150', 'character'),
                                   ('latency-counterbalanced', 'latency')]]}
        integration = {'baseline': {'label': 'integration-baseline'},
                       'finalist': {'label': 'integration-finalist', 'sourceSHA256': 'd' * 64},
                       'checkpoints': {}, 'focusedTests': []}
        reader.validate_freeze = mock.Mock(return_value=frozen)
        reader.bind_integration = mock.Mock(return_value=integration)
        reader.final_tests = mock.Mock(return_value={'status': 'passed'})
        reader.visible_attempts = mock.Mock(return_value=[])
        def pair(spec, kind, analyzer, optional=False):
            return {'kind': kind, 'baseline': kind + '-baseline', 'finalist': kind + '-finalist',
                    'gates': {kind + '-invented-gate': True},
                    'latency': {condition: {'requiresInvestigation': False} for condition in ('none', 'screen')}}
        reader.pair = mock.Mock(side_effect=pair)
        return reader, evidence, pair

    def test_optional_contradiction_remains_visible_and_blocks_clean_adoption(self):
        reader, evidence, pair = self.assessment_fixture()
        evidence['optionalPairs'][0].update(status='complete', pair={})
        def contradict(spec, kind, analyzer, optional=False):
            result = pair(spec, kind, analyzer, optional)
            if optional and kind == 'freshSeed':
                result['gates']['fresh-screen-effect'] = False
            return result
        reader.pair.side_effect = contradict
        self.write('decision-evidence.json', evidence)
        result = reader.assess('decision-evidence.json')
        self.assertEqual(result['status'], 'needs-review-optional-contradiction')
        self.assertTrue(result['optionalContradiction'])
        self.assertTrue(result['optionalPairs'][0]['contradiction'])
        self.assertEqual(len(result['optionalPairs']), 3)

    def test_missing_mandatory_pair_becomes_incomplete_not_eligible(self):
        reader, evidence, _ = self.assessment_fixture()
        del evidence['pairs']['productionSeed']
        self.write('decision-evidence.json', evidence)
        result = reader.assess('decision-evidence.json')
        self.assertEqual(result['status'], 'incomplete-or-invalid')
        self.assertFalse(result['allRequiredGatesPassed'])
        self.assertTrue(any(item['area'] == 'productionSeed' for item in result['issues']))

    def test_missing_optional_attempt_status_is_rejected(self):
        reader, evidence, _ = self.assessment_fixture()
        evidence['optionalPairs'].pop()
        self.write('decision-evidence.json', evidence)
        with self.assertRaisesRegex(SUBJECT.EvidenceError, 'attempts must all remain visible'):
            reader.assess('decision-evidence.json')

    def optional_attempt_fixture(self):
        evidence = {'pairs': {}, 'optionalPairs': [
            {'name': name, 'kind': kind, 'status': 'not-run', 'reason': 'Invented timing limit.'}
            for name, kind in [('fresh-seed1337', 'freshSeed'), ('character150', 'character'),
                               ('latency-counterbalanced', 'latency')]]}
        for role in ('baseline', 'finalist'):
            label = 'optional-' + role
            self.write(label + '-registration.json', {'label': label, 'phase': 'validation', 'status': 'complete',
                'candidate': 'baseline' if role == 'baseline' else 'F1',
                'command': ['invented', '--corpus', 'invented.json', '--seed', '1337', '--workers', '3']})
        return evidence

    def test_optional_completed_runs_cannot_be_omitted_or_labeled_not_run(self):
        evidence = self.optional_attempt_fixture()
        reader = SUBJECT.Assessment(self.root)
        with self.assertRaisesRegex(SUBJECT.EvidenceError, 'optional attempts were omitted'):
            reader.visible_attempts(evidence)
        evidence['optionalPairs'][0]['attemptLabels'] = ['optional-baseline', 'optional-finalist']
        with self.assertRaisesRegex(SUBJECT.EvidenceError, 'cannot be labeled not-run'):
            reader.visible_attempts(evidence)

    def test_optional_completed_pair_cannot_be_hidden_as_failed(self):
        evidence = self.optional_attempt_fixture()
        evidence['optionalPairs'][0].update(status='failed',
            pair={'baseline': 'optional-baseline', 'finalist': 'optional-finalist'})
        with self.assertRaisesRegex(SUBJECT.EvidenceError, 'completed optional pair cannot be hidden'):
            SUBJECT.Assessment(self.root).visible_attempts(evidence)

    def test_optional_completed_pair_is_preserved_with_both_attempts(self):
        evidence = self.optional_attempt_fixture()
        evidence['optionalPairs'][0].update(status='complete',
            pair={'baseline': 'optional-baseline', 'finalist': 'optional-finalist'})
        attempts = SUBJECT.Assessment(self.root).visible_attempts(evidence)
        self.assertEqual([row['label'] for row in attempts], ['optional-baseline', 'optional-finalist'])

    def baseline_freeze_fixture(self):
        """A complete invented baseline-retention freeze with no protected files at all."""
        targets = {
            'renderer': self.write('prompt-sources/baseline/renderer.swift', '// Invented renderer.\n')['sha256'],
            'composer': self.write('prompt-sources/baseline/composer.swift', '// Invented composer.\n')['sha256'],
            'nativeEngine': self.write('native-history/variants/baseline.cpp', '// Invented native engine.\n')['sha256'],
        }
        source = '4' * 64
        model = '5' * 64
        files = {path: targets[key] for key, path in SUBJECT.TARGET_PATHS.items()}
        prerequisite = 'app/Cotabby/InventedPrerequisite.swift'
        files[prerequisite] = '6' * 64
        inventory = {'schemaVersion': 1, 'scope': SUBJECT.PRODUCTION_SCOPE, 'files': files}
        inventory_ref = self.write('production-inventory.json', inventory)
        snapshot = {owner: {'after': {'files': {}}} for owner in ('app', 'native')}
        for path, sha in files.items():
            owner, relative = path.split('/', 1)
            snapshot[owner]['after']['files'][relative] = {'kind': 'file', 'sha256': sha}
        self.write('starting-snapshot.json', snapshot)
        rows = []
        for candidate in ['baseline', *[f'{family}{i}' for family in 'HFM' for i in range(1, 5)]]:
            label = 'screen-' + candidate
            screen_correct = 100 if candidate == 'baseline' else 99
            # Freeze selection checks serialized aggregates; these small invented
            # objects carry the registered denominator without creating any prompts.
            report_ref = self.write(label + '/report.json', {'schemaVersion': 2, 'errorCount': 0,
                'conditions': {condition: {'suite': {'nextWord': {'correct': correct, 'checkpoints': 770, 'errors': 0}}}
                               for condition, correct in [('screen', screen_correct), ('none', 100)]}})
            record = {'label': label, 'candidate': candidate, 'phase': 'screening', 'status': 'complete',
                      'promptSource': {'hashes': {key: targets[key] for key in ('renderer', 'composer')}},
                      'nativeSource': {'sha256': targets['nativeEngine']}}
            registration_ref = self.write(label + '-registration.json', record)
            rows.append({'candidate': candidate, 'label': label, 'screenCorrect': screen_correct,
                         'noneCorrect': 100, 'reportSHA256': report_ref['sha256'],
                         'registrationSHA256': registration_ref['sha256']})
        ranking = self.write('invented-ranking.json', {'rows': rows})
        self.write('screen-baseline/manifest.json', {'buildInputs': {'sourceSHA256': source}})
        self.write('prompt-sources/manifest.json', {'variants': {'baseline': {'hashes': {key: targets[key] for key in ('renderer', 'composer')}}}})
        self.write('combination-sources/manifest.json', {'variants': {}})
        self.write('native-history/variants/manifest.json', {'variants': {'baseline': {'sha256': targets['nativeEngine'], 'path': 'baseline.cpp'}}})
        self.write('round.json', {'startUTC': '2020-01-01T09:00:00Z', 'freezeDeadlineUTC': '2020-01-01T12:00:00Z',
            'freshReadinessDeadlineUTC': '2020-01-01T09:45:00Z', 'modelSHA256': model})
        readiness = self.write('invented-readiness.json', {'status': 'pass', 'corpusSHA256': SUBJECT.FRESH_CORPUS_SHA,
            'phraseCount': 700, 'familyCount': 140, 'wordCheckpointsPerCondition': 2892, 'readyUTC': '2020-01-01T09:30:00Z'})
        frozen = {'schemaVersion': 1, 'frozenUTC': '2020-01-01T10:00:00Z', 'components': [],
            'candidate': 'baseline', 'selectionQualified': False, 'candidateLabel': 'screen-baseline',
            'baselineLabel': 'screen-baseline', 'modelSHA256': model, 'freshCorpusSHA256': SUBJECT.FRESH_CORPUS_SHA,
            'criteria': self.write('invented-criteria.md', 'Invented unit-test registration.\n'),
            'selectionClarification': self.write('invented-clarification.json', {}),
            'combinationRegistration': self.write('invented-combinations.json', {'combinations': []}),
            'screeningEvidence': ranking, 'screeningEvidenceSHA256': ranking['sha256'], 'freshReadiness': readiness,
            'productionInventories': {'baseline': inventory_ref, 'finalist': inventory_ref},
            'baselineTargets': targets, 'candidateTargets': targets,
            'baselineSourceSHA256': source, 'candidateSourceSHA256': source,
            'prerequisiteHashes': {prerequisite: files[prerequisite]},
            'validationHarnessHashes': self.invented_harness()}
        self.write('execution.json', {'root': str(self.root)})
        self.write('finalist-freeze.json', frozen)
        return frozen, inventory

    def test_valid_baseline_retention_needs_no_decision_evidence_or_protected_reports(self):
        self.baseline_freeze_fixture()
        reader = SUBJECT.Assessment(self.root)
        with mock.patch.object(reader, 'read_bytes', wraps=reader.read_bytes) as read:
            result = reader.assess('nonexistent-decision-evidence.json')
        self.assertEqual(result['status'], 'retained-baseline')
        self.assertFalse(any('nonexistent-decision-evidence' in str(call.args[0]) for call in read.call_args_list))
        self.assertFalse(any('fresh/report.json' in str(call.args[0]) for call in read.call_args_list))

    def test_inventory_cannot_omit_prerequisite_present_in_starting_snapshot(self):
        frozen, inventory = self.baseline_freeze_fixture()
        del inventory['files']['app/Cotabby/InventedPrerequisite.swift']
        reference = self.write('incomplete-inventory.json', inventory)
        frozen.update(productionInventories={'baseline': reference, 'finalist': reference}, prerequisiteHashes={})
        self.write('finalist-freeze.json', frozen)
        with self.assertRaisesRegex(SUBJECT.EvidenceError, 'omits or changes starting production inputs'):
            SUBJECT.Assessment(self.root).validate_freeze()

    def test_freeze_rejects_ranking_totals_that_disagree_with_hashed_screening_report(self):
        frozen, _ = self.baseline_freeze_fixture()
        ranking = json.loads((self.root / 'invented-ranking.json').read_text())
        ranking['rows'][0]['noneCorrect'] += 1
        reference = self.write('invented-ranking.json', ranking)
        frozen.update(screeningEvidence=reference, screeningEvidenceSHA256=reference['sha256'])
        self.write('finalist-freeze.json', frozen)
        with self.assertRaisesRegex(SUBJECT.EvidenceError, 'ranking counts differ from authoritative screening totals'):
            SUBJECT.Assessment(self.root).validate_freeze()

    def test_harness_inventory_rejects_omitted_expected_file(self):
        expected = self.invented_harness()
        del expected['app/CotabbyTests/Evals/PhrasePredictionScoring.swift']
        with self.assertRaisesRegex(SUBJECT.EvidenceError, 'harness inventory is incomplete'):
            SUBJECT.Assessment(self.root).verify_harness(self.root, expected)

    def test_harness_inventory_rejects_new_unregistered_eval_file(self):
        expected = self.invented_harness()
        self.write('CotabbyTests/Evals/InventedAdditionalBehavior.swift', '// Added after the freeze.\n')
        with self.assertRaisesRegex(SUBJECT.EvidenceError, 'gained unregistered files'):
            SUBJECT.Assessment(self.root).verify_harness(self.root, expected)

    def test_identical_relocated_harness_passes_but_changed_bytes_fail(self):
        expected = self.invented_harness()
        self.invented_harness('relocated')
        SUBJECT.Assessment(self.root).verify_harness(self.root / 'relocated', expected)
        self.write('relocated/CotabbyTests/Evals/PhrasePredictionScoring.swift', '// Changed semantics.\n')
        with self.assertRaisesRegex(SUBJECT.EvidenceError, 'Hash-bound evidence artifact changed'):
            SUBJECT.Assessment(self.root).verify_harness(self.root / 'relocated', expected)

    def test_failed_harness_verification_never_marks_freeze_valid(self):
        self.baseline_freeze_fixture()
        self.write('CotabbyTests/Evals/PhrasePredictionScoring.swift', '// Changed after freeze.\n')
        reader = SUBJECT.Assessment(self.root)
        with self.assertRaisesRegex(SUBJECT.EvidenceError, 'Hash-bound evidence artifact changed'):
            reader.validate_freeze()
        self.assertIsNone(reader.frozen)


if __name__ == '__main__':
    unittest.main()
