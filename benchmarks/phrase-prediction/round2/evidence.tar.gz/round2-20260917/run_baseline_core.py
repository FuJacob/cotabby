#!/usr/bin/env python3
"""Execute the registered retained-baseline core workloads sequentially.

Selection is already closed. These runs measure baseline behavior on broader inputs and
seeds; they neither select alternatives nor make adoption claims. Latency and current-main
integration are coordinated separately so their isolation/provenance can be recorded.
"""
import datetime
import fcntl
import hashlib
import json
from pathlib import Path
import subprocess
import sys

HERE = Path(__file__).resolve().parent
NAMES = ['fresh42', 'old42', 'character50', 'fresh1337', 'fresh-production', 'old-production']


def run():
    path = HERE / 'baseline-workloads.json'
    workload_hash = hashlib.sha256(path.read_bytes()).hexdigest()
    workload = json.loads(path.read_text())
    frozen = json.loads((HERE / 'finalist-freeze.json').read_text())
    if frozen['candidate'] != 'baseline' or frozen['selectionQualified']:
        raise ValueError('Baseline-only characterization requires frozen baseline retention')
    indexed = {item['name']: item for item in workload['runs']}
    for name in NAMES:
        if hashlib.sha256(path.read_bytes()).hexdigest() != workload_hash:
            raise ValueError('Workload registration changed during the queue')
        item = indexed[name]
        label = item['label']
        registration = HERE / (label + '-registration.json')
        if registration.exists():
            record = json.loads(registration.read_text())
            if record['status'] != 'complete':
                raise ValueError(f'{label} has incomplete evidence; inspect before continuing')
            continue
        print(datetime.datetime.now(datetime.timezone.utc).isoformat() + ' Starting ' + label, flush=True)
        command = [sys.executable, str(HERE / 'run_experiment.py'), label, '--candidate', 'baseline',
                   '--phase', 'validation', '--split', item['selection'], '--mode', item['mode'],
                   '--seed', str(item['seed']), '--workers', str(item['workerCount']),
                   '--estimated-seconds', str(item['estimatedSeconds'])]
        if item['perCategory']:
            command += ['--per-category', str(item['perCategory'])]
        if item['kind'] == 'freshWord':
            command += ['--corpus', str(HERE / 'protected-fresh/corpus.json')]
        with (HERE / (label + '.orchestrator.log')).open('x') as stream:
            subprocess.run(command, cwd=HERE, stdout=stream, stderr=subprocess.STDOUT, check=True)
        print('Completed ' + label, flush=True)
    print('Core baseline characterization workloads complete.', flush=True)


if __name__ == '__main__':
    with (HERE / 'baseline-core.lock').open('a') as lock:
        fcntl.flock(lock.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        run()
