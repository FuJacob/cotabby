# Supported model evaluation

Local Release replay, one inference worker, fixed seed 42, synthetic English profile (Alex).
Exact intended-word match is not a semantic quality rating; plausible alternatives count as misses.
Final-generation latency excludes model load, keyboard debounce and Accessibility/overlay work.
Completion length: 4-7 words.

| Model | Prompt | Workload | Context | Next word | Partial word | Shown | Precision | p50 / p95 ms | Errors |
|---|---|---|---|---:|---:|---:|---:|---:|---:|
| CoHamster Base | legacy-surface | word | none | 31.6% | — | 100.0% | 31.6% | 110 / 234 | 0 |
| CoHamster Base | legacy-surface | word | screen | 45.1% | — | 100.0% | 45.1% | 103 / 265 | 0 |
| CoHamster Base | legacy-surface | regressions | none | 38.0% | 66.9% | 94.7% | 63.9% | 123 / 184 | 0 |
| CoHamster Base | production | word | none | 29.5% | — | 100.0% | 29.5% | 124 / 247 | 0 |
| CoHamster Base | production | word | screen | 46.6% | — | 100.0% | 46.6% | 112 / 297 | 0 |
| CoHamster Base | production | regressions | none | 39.4% | 66.1% | 94.1% | 64.0% | 132 / 217 | 0 |

Status: complete.

Raw prompts, completions, source/binary/model hashes and per-case suppressions are in each replay directory.
The word and character samples overlap; do not pool them as independent evidence. Regression cases are development examples.
Use a held-out validation campaign after choosing a fix. No model is automatically declared usable from a small sample.
