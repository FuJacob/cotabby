# Supported model evaluation

Local Release replay, one inference worker, fixed seed 42, synthetic English profile (Alex).
Exact intended-word match is not a semantic quality rating; plausible alternatives count as misses.
Final-generation latency excludes model load, keyboard debounce and Accessibility/overlay work.

| Model | Prompt | Workload | Context | Next word | Partial word | Shown | Precision | p50 / p95 ms | Errors |
|---|---|---|---|---:|---:|---:|---:|---:|---:|
| CoHamster Nano | production | word | none | 30.1% | — | 100.0% | 30.1% | 54 / 133 | 0 |
| CoHamster Nano | production | word | screen | 37.3% | — | 100.0% | 37.3% | 58 / 144 | 0 |
| CoHamster Nano | production | regressions | none | 39.4% | 64.1% | 95.7% | 61.4% | 57 / 186 | 0 |
| CoHamster Nano | content-only | word | none | 26.9% | — | 100.0% | 26.9% | 85 / 211 | 0 |
| CoHamster Nano | content-only | word | screen | 33.2% | — | 100.0% | 33.2% | 55 / 150 | 0 |
| CoHamster Nano | content-only | regressions | none | 29.6% | 54.6% | 95.3% | 51.5% | 89 / 235 | 0 |
| CoHamster Mini | production | word | none | 35.8% | — | 100.0% | 35.8% | 93 / 309 | 0 |
| CoHamster Mini | production | word | screen | 46.1% | — | 100.0% | 46.1% | 101 / 267 | 0 |
| CoHamster Mini | production | regressions | none | 39.4% | 66.9% | 96.3% | 63.2% | 124 / 401 | 0 |
| CoHamster Mini | content-only | word | none | 28.5% | — | 100.0% | 28.5% | 159 / 433 | 0 |
| CoHamster Mini | content-only | word | screen | 39.9% | — | 100.0% | 39.9% | 127 / 320 | 0 |
| CoHamster Mini | content-only | regressions | none | 33.8% | 53.0% | 96.6% | 50.5% | 200 / 480 | 0 |
| CoHamster Base | production | word | none | 31.6% | — | 100.0% | 31.6% | 184 / 544 | 0 |
| CoHamster Base | production | word | screen | 45.1% | — | 100.0% | 45.1% | 171 / 520 | 0 |
| CoHamster Base | production | regressions | none | 38.0% | 66.9% | 94.7% | 63.9% | 210 / 611 | 0 |
| CoHamster Base | content-only | word | none | 28.5% | — | 100.0% | 28.5% | 269 / 610 | 0 |
| CoHamster Base | content-only | word | screen | 40.4% | — | 99.5% | 40.6% | 190 / 649 | 0 |
| CoHamster Base | content-only | regressions | none | 36.6% | 55.8% | 93.5% | 55.1% | 203 / 615 | 0 |
| CoHamster Pro | production | word | none | 31.6% | — | 100.0% | 31.6% | 231 / 802 | 0 |
| CoHamster Pro | production | word | screen | 42.5% | — | 100.0% | 42.5% | 276 / 932 | 0 |
| CoHamster Pro | production | regressions | none | 40.8% | 66.1% | 95.7% | 63.3% | 248 / 839 | 0 |
| CoHamster Pro | content-only | word | none | 30.6% | — | 100.0% | 30.6% | 343 / 969 | 0 |
| CoHamster Pro | content-only | word | screen | 42.0% | — | 100.0% | 42.0% | 284 / 861 | 0 |
| CoHamster Pro | content-only | regressions | none | 31.0% | 57.0% | 95.3% | 53.7% | 287 / 1041 | 0 |

Status: complete.

Raw prompts, completions, source/binary/model hashes and per-case suppressions are in each replay directory.
The word and character samples overlap; do not pool them as independent evidence. Regression cases are development examples.
Use a held-out validation campaign after choosing a fix. No model is automatically declared usable from a small sample.
