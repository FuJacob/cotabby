# Supported model evaluation

Local Release replay, one inference worker, fixed seed 42, synthetic English profile (Alex).
Exact intended-word match is not a semantic quality rating; plausible alternatives count as misses.
Final-generation latency excludes model load, keyboard debounce and Accessibility/overlay work.
Completion length: 4-7 words.

| Model | Prompt | Workload | Context | Next word | Partial word | Shown | Precision | p50 / p95 ms | Errors |
|---|---|---|---|---:|---:|---:|---:|---:|---:|
| CoHamster Base | legacy-language | word | none | 31.6% | — | 100.0% | 31.6% | 114 / 243 | 0 |
| CoHamster Base | legacy-language | word | screen | 45.1% | — | 100.0% | 45.1% | 107 / 281 | 0 |
| CoHamster Base | legacy-language | regressions | none | 38.0% | 66.9% | 94.7% | 63.9% | 136 / 199 | 0 |
| CoHamster Base | production | word | none | 35.8% | — | 100.0% | 35.8% | 159 / 235 | 0 |
| CoHamster Base | production | word | screen | 43.5% | — | 99.5% | 43.8% | 125 / 288 | 0 |
| CoHamster Base | production | regressions | none | 36.6% | 63.7% | 94.7% | 61.0% | 148 / 202 | 0 |

Status: complete.

Raw prompts, completions, source/binary/model hashes and per-case suppressions are in each replay directory.
The word and character samples overlap; do not pool them as independent evidence. Regression cases are development examples.
Use a held-out validation campaign after choosing a fix. No model is automatically declared usable from a small sample.
