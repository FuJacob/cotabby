# Supported model evaluation

Local Release replay, one inference worker, fixed seed 42, synthetic English profile (Alex).
Exact intended-word match is not a semantic quality rating; plausible alternatives count as misses.
Final-generation latency excludes model load, keyboard debounce and Accessibility/overlay work.
Completion length: 4-7 words.

| Model | Prompt | Workload | Context | Next word | Partial word | Shown | Precision | p50 / p95 ms | Errors |
|---|---|---|---|---:|---:|---:|---:|---:|---:|
| CoHamster Nano | production | character | none | 28.0% | 78.5% | 100.0% | 68.5% | 68 / 137 | 0 |
| CoHamster Nano | production | character | screen | 35.4% | 82.7% | 99.8% | 73.5% | 67 / 135 | 0 |
| CoHamster Nano | production | regressions | none | 39.4% | 89.6% | 99.4% | 79.1% | 51 / 135 | 0 |
| CoHamster Nano | production | runtime | none | 75.0% | — | 100.0% | 75.0% | 29 / 122 | 0 |
| CoHamster Mini | production | character | none | 30.2% | 80.8% | 99.9% | 70.9% | 119 / 258 | 0 |
| CoHamster Mini | production | character | screen | 37.6% | 87.5% | 99.9% | 77.7% | 124 / 279 | 0 |
| CoHamster Mini | production | regressions | none | 39.4% | 90.8% | 99.4% | 80.0% | 148 / 292 | 0 |
| CoHamster Mini | production | runtime | none | 75.0% | — | 100.0% | 75.0% | 33 / 183 | 0 |
| CoHamster Base | production | character | none | 30.2% | 76.9% | 100.0% | 67.7% | 134 / 269 | 0 |
| CoHamster Base | production | character | screen | 37.6% | 85.0% | 99.4% | 76.1% | 118 / 294 | 0 |
| CoHamster Base | production | regressions | none | 38.0% | 90.4% | 99.4% | 79.4% | 169 / 265 | 0 |
| CoHamster Base | production | runtime | none | 75.0% | — | 100.0% | 75.0% | 42 / 236 | 0 |
| CoHamster Pro | production | character | none | 31.2% | 77.6% | 100.0% | 68.4% | 152 / 359 | 0 |
| CoHamster Pro | production | character | screen | 39.2% | 87.5% | 99.9% | 78.0% | 138 / 374 | 0 |
| CoHamster Pro | production | regressions | none | 40.8% | 89.2% | 99.4% | 79.1% | 182 / 474 | 0 |
| CoHamster Pro | production | runtime | none | 75.0% | — | 100.0% | 75.0% | 67 / 373 | 0 |

Status: complete.

Raw prompts, completions, source/binary/model hashes and per-case suppressions are in each replay directory.
The word and character samples overlap; do not pool them as independent evidence. Regression cases are development examples.
Use a held-out validation campaign after choosing a fix. No model is automatically declared usable from a small sample.
