// Diagnostic differential: independent llama.cpp decode loop versus CoHamster's native wrapper.
#include <llama.h>
#include "CotabbyInferenceEngine.h"
#include <iostream>
#include <iomanip>
#include <algorithm>
#include <numeric>
#include <cmath>
#include <string>
#include <vector>
std::string q(const std::string& s) { std::string o="\""; for (unsigned char c:s) { if(c=='"'||c=='\\'){o+='\\';o+=c;} else if(c<32){char b[7];snprintf(b,7,"\\u%04x",c);o+=b;} else o+=c; }return o+'"'; }
std::string piece(const llama_vocab* v, llama_token t){std::vector<char>b(512);int n=llama_token_to_piece(v,t,b.data(),b.size(),0,false);if(n<0){b.resize(-n);n=llama_token_to_piece(v,t,b.data(),b.size(),0,false);}return n>0?std::string(b.data(),n):"";}
int main(int argc,char**argv){
 if(argc<4)return 2; std::string mode=argv[2]; int heal=atoi(argv[3]); int gpu=argc>4?atoi(argv[4]):99;
 if(mode=="native"){
  CotabbyInferenceEngine engine; if(engine.loadModel(argv[1],gpu,2048,512)!=EngineStatus::ok)return 3;
  std::string prompt; while(std::getline(std::cin,prompt,'\0')){
   auto tokens=engine.tokenize(prompt.data(),prompt.size()); std::string prefix;
   if(heal&&tokens.size()>1){auto p=engine.tokenPiece(tokens.back());prefix=std::string(p.begin(),p.end());tokens.pop_back();}
   SamplingConfig config{.1,20,.7,.08,1.025,42,false};auto seq=engine.createSequence(config);
   engine.setCompletionPrefix(seq,(const uint8_t*)prefix.data(),prefix.size());
   if(engine.decodePrompt(seq,tokens.data(),tokens.size(),0)!=EngineStatus::ok)return 4;
   std::string result;for(int i=0;i<12;i++){auto s=engine.sampleNext(seq);if(s.is_eos||s.was_cancelled)break;result.append(s.piece,s.piece_length);}
   std::cout<<"{\"prompt\":"<<q(prompt)<<",\"heal\":"<<q(prefix)<<",\"output\":"<<q(result.substr(std::min(prefix.size(),result.size())))<<"}"<<std::endl;engine.destroySequence(seq);
  }return 0;
 }
 llama_log_set([](ggml_log_level,const char*,void*){},nullptr);llama_backend_init();auto mp=llama_model_default_params();mp.n_gpu_layers=gpu;
 auto* m=llama_model_load_from_file(argv[1],mp);if(!m)return 3;auto* v=llama_model_get_vocab(m);
 std::cerr<<"BOS="<<llama_vocab_get_add_bos(v)<<",EOS="<<llama_vocab_get_add_eos(v)<<"\n";
 auto cp=llama_context_default_params();cp.n_ctx=2048;cp.n_batch=512;cp.n_ubatch=512;cp.n_threads=8;cp.n_threads_batch=8;auto*c=llama_init_from_model(m,cp);if(!c)return 4;
 auto* sampler=llama_sampler_chain_init(llama_sampler_chain_default_params());
 llama_sampler_chain_add(sampler,llama_sampler_init_penalties(64,1.025,0,0));
 llama_sampler_chain_add(sampler,llama_sampler_init_temp(.1));
 llama_sampler_chain_add(sampler,llama_sampler_init_top_k(20));
 llama_sampler_chain_add(sampler,llama_sampler_init_min_p(.08,1));
 llama_sampler_chain_add(sampler,llama_sampler_init_top_p(.7,1));
 llama_sampler_chain_add(sampler,llama_sampler_init_dist(42));int nv=llama_vocab_n_tokens(v);std::vector<std::string>pieces(nv);for(int t=0;t<nv;t++)pieces[t]=piece(v,t);
 std::string prompt;while(std::getline(std::cin,prompt,'\0')){
  llama_memory_clear(llama_get_memory(c),true);llama_sampler_reset(sampler);std::vector<llama_token>tokens(prompt.size()+64);int n=llama_tokenize(v,prompt.data(),prompt.size(),tokens.data(),tokens.size(),llama_vocab_get_add_bos(v),false);if(n<=0)return 5;tokens.resize(n);
  std::string prefix; if(heal&&tokens.size()>1){prefix=pieces[tokens.back()];tokens.pop_back();
   if(heal==3 && !prompt.empty() && !isspace((unsigned char)prompt.back())) {
    size_t boundary=prompt.find_last_of(" \t\r\n"); size_t need=boundary==std::string::npos?prompt.size():prompt.size()-boundary;
    if(need<=64)while(prefix.size()<need&&tokens.size()>1){auto p=pieces[tokens.back()];if(p.empty())break;prefix=p+prefix;tokens.pop_back();}
   }}
  if(llama_decode(c,llama_batch_get_one(tokens.data(),tokens.size())))return 6; for(auto t:tokens)llama_sampler_accept(sampler,t);
  std::string remaining=prefix,result;std::string top="[";
  for(int i=0;i<12;i++){
   float* logits=llama_get_logits_ith(c,-1);
   bool whole=false; if(heal>=2&&!remaining.empty())for(int t=0;t<nv;t++)if(pieces[t].size()>=remaining.size()&&pieces[t].substr(0,remaining.size())==remaining){whole=true;break;}
   if(!remaining.empty())for(int t=0;t<nv;t++){auto len=std::min(remaining.size(),pieces[t].size());if(len==0||(whole&&pieces[t].size()<remaining.size())||remaining.substr(0,len)!=pieces[t].substr(0,len))logits[t]=-INFINITY;}
   if(i==0){std::vector<int>ix(nv);std::iota(ix.begin(),ix.end(),0);std::partial_sort(ix.begin(),ix.begin()+10,ix.end(),[&](int a,int b){return logits[a]>logits[b];});double den=0;for(int t=0;t<nv;t++)den+=std::exp(logits[t]-logits[ix[0]]);for(int j=0;j<10;j++){if(j)top+=",";int t=ix[j];top+="{\"token\":"+std::to_string(t)+",\"piece\":"+q(pieces[t])+",\"p\":"+std::to_string(std::exp(logits[t]-logits[ix[0]])/den)+"}";}top+="]";}
   auto t=llama_sampler_sample(sampler,c,-1);if(llama_vocab_is_eog(v,t))break;result+=pieces[t];remaining.erase(0,std::min(remaining.size(),pieces[t].size()));if(llama_decode(c,llama_batch_get_one(&t,1)))return 7;
  }
  std::cout<<"{\"prompt\":"<<q(prompt)<<",\"heal\":"<<q(prefix)<<",\"top\":"<<top<<",\"output\":"<<q(result.substr(std::min(prefix.size(),result.size())))<<"}"<<std::endl;
 }
 llama_sampler_free(sampler);llama_free(c);llama_model_free(m);llama_backend_free();
}
